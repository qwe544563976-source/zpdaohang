#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");

const workspace = path.resolve(__dirname, "..");
const sourceRoot = path.join(
  workspace,
  "_judgment_distillation_formal_bphs97_20260816",
);
const targetRoot = path.join(
  workspace,
  process.env.BPHS97_SAMPLE_DIR_NAME || "_bphs97_十个方法样品_第三轮修正_20260817",
);
const acceptedPackagePath =
  "F:/切卡实验/aclass-chunker/runs/bphs-97-santhanam-formal-20260816/accepted-package-20260817.json";

const selectedMethodIds = [
  "varga-assessment",
  "planetary-strength-assessment",
  "bhava-lord-placement-lookup",
  "prosperity-poverty-balance",
  "functional-benefic-yogakaraka-assessment",
  "rajayoga-political-assessment",
  "nakshatra-dasha-selection-balance",
  "nested-period-calculation",
  "longevity-calculation",
  "maraka-period-assessment",
];

const semanticRepairLog = [
  {
    step_id: "varga-assessment.step-03",
    category: "扩大原意",
    root_cause: "把粗略分盘权重和精确位置的细微判断写成了需要把计算结果当输入。",
  },
  {
    step_id: "planetary-strength-assessment.step-01",
    category: "扩大原意",
    root_cause: "把 Uchch Bal（擢升力）一个子项扩大成完整位置力。",
  },
  {
    step_id: "bhava-lord-placement-lookup.step-01",
    category: "漏分支",
    root_cause: "把第二宫主落第八宫与第七宫主落第十二宫两个独立入口合成一条。",
  },
  {
    step_id: "prosperity-poverty-balance.step-02",
    category: "漏分支",
    root_cause: "财富条件保留了结果，却没有把相关运期作为兑现条件。",
  },
  {
    step_id: "prosperity-poverty-balance.step-03",
    category: "取消条件写反",
    root_cause: "把取消条件混进主触发，并漏掉太阳不受土星照射时的财富名望分支。",
  },
  {
    step_id: "functional-benefic-yogakaraka-assessment.step-04",
    category: "扩大原意",
    root_cause: "把节点与角宫主、三合宫主的关系写成角宫主和三合宫主彼此关系。",
  },
  {
    step_id: "rajayoga-political-assessment.step-02",
    category: "漏分支",
    root_cause: "没有展开上升宫、第五宫、擢升、本宫、本 Navamsa 的并列位置入口。",
  },
  {
    step_id: "nakshatra-dasha-selection-balance.step-01",
    category: "扩大原意",
    root_cause: "把 Ashtottari 的特殊采用条件错误地压到默认 Vimshottari 上。",
  },
  {
    step_id: "nested-period-calculation.step-03",
    category: "漏分支",
    root_cause: "漏掉三条减轻条件，并把 Surya-Surya 示例扩大成所有细运通则。",
  },
  {
    step_id: "longevity-calculation.step-03",
    category: "扩大原意",
    root_cause: "把 Pindayu 与 Amsayu 两套算法的输入写成同时必需。",
  },
  {
    step_id: "longevity-calculation.step-04",
    category: "漏分支",
    root_cause: "只写三组交叉核对，没写三组不一致时的两条优先规则。",
  },
  {
    step_id: "longevity-calculation.step-05",
    category: "扩大原意",
    root_cause: "短引只覆盖比例修正，没有覆盖求平均、乘基本年数和除以 30 的净值公式。",
  },
  {
    step_id: "maraka-period-assessment.step-02",
    category: "漏分支",
    root_cause: "漏掉摩羯／天蝎上升和第六宫困难分支，并把吉星保护扩大成取消全部致害。",
  },
];

const semanticRepairLogRound3 = [
  {
    step_id: "varga-assessment.step-03 → varga-assessment.step-04",
    category: "接线不一致",
    root_cause: "Vimshopaka 强度由前一步产出，却没有用同名事实接到运期限制步骤。",
  },
  {
    step_id: "bhava-lord-placement-lookup.step-01",
    category: "扩大原意",
    root_cause: "把事实适配层已经算好的两个命中布尔值写成了本步骤自己从原始宫位计算。",
  },
  {
    step_id: "prosperity-poverty-balance.step-02",
    category: "条件逻辑错误",
    root_cause: "不询问兑现时间时仍把相关运期隐式设成必需，导致基础财富分支被错误阻塞。",
  },
  {
    step_id: "nakshatra-dasha-selection-balance.step-01",
    category: "条件逻辑错误",
    root_cause: "候选系统使用了泛化输入和 AND 逻辑，没有分别产出两个已核验系统布尔结果。",
  },
  {
    step_id: "nakshatra-dasha-selection-balance.step-02",
    category: "接线不一致",
    root_cause: "起始运主计算没有消费已核验的 Vimshottari 结果。",
  },
  {
    step_id: "nakshatra-dasha-selection-balance.step-03",
    category: "接线不一致",
    root_cause: "出生余额计算没有消费已核验系统和前一步起始运主。",
  },
  {
    step_id: "nested-period-calculation.step-03",
    category: "适用范围过宽",
    root_cause: "Pratyantar 示例被写成泛称细运通则。",
  },
  {
    step_id: "nested-period-calculation.step-04 → nested-period-calculation.step-05",
    category: "接线不一致",
    root_cause: "Sukshma 与 Prana 步骤没有逐字消费前一步产出的运期时长。",
  },
  {
    step_id: "longevity-calculation.step-01 → longevity-calculation.step-04",
    category: "步骤顺序错误",
    root_cause: "寿命算法结果、三组寿命类别和优先规则没有按前后产出顺序接线。",
  },
  {
    step_id: "longevity-calculation.step-02",
    category: "条件分支错误",
    root_cause: "Pindayu、Amsayu 和缺公式的 Nisargayu 输入没有按选择结果分开停判。",
  },
  {
    step_id: "longevity-calculation.step-03",
    category: "输出缺失",
    root_cause: "三组原始星座性质没有分别产出三组寿命类别和全不相同标记。",
  },
  {
    step_id: "maraka-period-assessment.step-02",
    category: "条件逻辑错误",
    root_cause: "三个节点分支的开关和分支事实被混成全局必需输入，当前运期错误地对所有分支做 AND。",
  },
];

const semanticRepairLogRound2 = [
  {
    step_id: "varga-assessment.step-01",
    category: "扩大原意",
    root_cause: "把本步骤应计算的目标分盘误写成运行前输入。",
  },
  {
    step_id: "planetary-strength-assessment.step-02",
    category: "扩大原意",
    root_cause: "逐字短引只列六类力量，却把未被短引直接规定的替代关系写进最小意思。",
  },
  {
    step_id: "bhava-lord-placement-lookup.step-01",
    category: "漏分支",
    root_cause: "把两个可由命盘计算的命中布尔事实与两套原文结果输入混在一起。",
  },
  {
    step_id: "bhava-lord-placement-lookup.step-02",
    category: "漏分支",
    root_cause: "没有把相反结果抵消、不同性质结果并存和强弱比例分别写成产出。",
  },
  {
    step_id: "prosperity-poverty-balance.step-02",
    category: "漏分支",
    root_cause: "把只有询问兑现时间时才需要的相关运期错误设成所有分支的必需输入。",
  },
  {
    step_id: "prosperity-poverty-balance.step-04",
    category: "漏分支",
    root_cause: "没有分别表达相反结果抵消、不同性质结果并存和强弱比例。",
  },
  {
    step_id: "functional-benefic-yogakaraka-assessment.step-01",
    category: "扩大原意",
    root_cause: "把按上升和宫主身份计算出的功能吉凶误写成外部输入。",
  },
  {
    step_id: "nakshatra-dasha-selection-balance.step-01",
    category: "漏分支",
    root_cause: "默认 Vimshottari 与 Ashtottari 的特殊条件没有分开核验。",
  },
  {
    step_id: "nakshatra-dasha-selection-balance.step-02",
    category: "扩大原意",
    root_cause: "把按出生星宿计数得到的起始运主误写成输入。",
  },
  {
    step_id: "nakshatra-dasha-selection-balance.step-03",
    category: "扩大原意",
    root_cause: "把按月亮已行时间计算出的出生余额误写成输入。",
  },
  {
    step_id: "nested-period-calculation.step-01",
    category: "扩大原意",
    root_cause: "步骤声称同时计算 Pratyantar，却只绑定了 Antar 的逐字支持。",
  },
  {
    step_id: "nested-period-calculation.step-03",
    category: "取消条件写反",
    root_cause: "把原文明确说不产生的 Pratyantar 结果标成缓解，而不是取消。",
  },
  {
    step_id: "longevity-calculation.step-01",
    category: "扩大原意",
    root_cause: "把由上升、太阳、月亮强弱计算出的算法选择误写成输入。",
  },
  {
    step_id: "longevity-calculation.step-02",
    category: "扩大原意",
    root_cause: "把等强时计算出的平均结果和中间值误写成输入。",
  },
  {
    step_id: "longevity-calculation.step-03",
    category: "漏分支",
    root_cause: "把 Pindayu、Amsayu 两套互斥输入混成同一组，并没有把 Nisargayu 缺公式硬停。",
  },
  {
    step_id: "longevity-calculation.step-04",
    category: "漏分支",
    root_cause: "把只有三组结果全不一致时才需要的月亮位置设成常规必需输入。",
  },
  {
    step_id: "longevity-calculation.step-05",
    category: "扩大原意",
    root_cause: "把总和与净寿命计算结果误写成输入，并把原始贡献者经度拆成了结果式字段。",
  },
  {
    step_id: "maraka-period-assessment.step-02",
    category: "漏分支",
    root_cause: "把节点致害宫位、摩羯／天蝎上升和第六／八／十二宫困难三类分支的事实混成一组必需输入。",
  },
];

const dependencies = {
  "varga-assessment": [],
  "planetary-strength-assessment": [],
  "bhava-lord-placement-lookup": ["planetary-strength-assessment"],
  "prosperity-poverty-balance": [
    "bhava-lord-placement-lookup",
    "planetary-strength-assessment",
  ],
  "functional-benefic-yogakaraka-assessment": [],
  "rajayoga-political-assessment": [
    "varga-assessment",
    "planetary-strength-assessment",
    "functional-benefic-yogakaraka-assessment",
  ],
  "nakshatra-dasha-selection-balance": [],
  "nested-period-calculation": ["nakshatra-dasha-selection-balance"],
  "longevity-calculation": [
    "varga-assessment",
    "planetary-strength-assessment",
  ],
  "maraka-period-assessment": [
    "longevity-calculation",
    "nested-period-calculation",
  ],
};

const methodScopes = {
  "varga-assessment":
    "只用于按 BPHS 97 指定用途选择分盘，并核对跨分盘强弱；不把 D9（九分盘）自动塞进所有问题。",
  "planetary-strength-assessment":
    "只用于 BPHS 97 第 27～28 章明确给出的六类力量、各自行星最低标准和结果比例。",
  "bhava-lord-placement-lookup":
    "本样品只覆盖第二宫主落第八宫、七宫主落第十二宫，以及第 24 章结尾的强弱和双重宫主通则。",
  "prosperity-poverty-balance":
    "只用于分别找回财富支持、贫困条件和同段取消条件；原书没有给出总评分时不得替作者宣布哪边获胜。",
  "functional-benefic-yogakaraka-assessment":
    "只用于已经确定上升星座的本命盘，按该上升下的实际宫主身份判断功能吉凶和瑜伽主。",
  "rajayoga-political-assessment":
    "只用于第 39～40 章列明的王者、部长或官方关联组合；每条组合独立核对，不互相拼接。",
  "nakshatra-dasha-selection-balance":
    "只用于选择 BPHS 97 明示的星宿运系统、确定起始运主并计算出生时运期余额。",
  "nested-period-calculation":
    "只用于按上一级运期逐层计算小运、细运、微运和 Prana（最细一层运期），不得跳级。",
  "longevity-calculation":
    "只用于第 43 章给出的寿命算法选择、计算和交叉核对；缺任一输入就停止，不输出寿命数字。",
  "maraka-period-assessment":
    "本样品只覆盖书内年龄边界冲突和罗喉／计都的致害分支；不冒充完整致害星排名方法。",
};

const claims = {
  "varga-assessment.step-01":
    "原文把身体、财富、兄弟、配偶、权力等主题分别交给指定分盘；婚姻可查 Navāńś，但不能固定只看 D1 或 D9。",
  "varga-assessment.step-02":
    "燃烧、星战失败、弱势或不良状态的行星，其分盘位置不能继续当作吉格支持。",
  "varga-assessment.step-03":
    "Vimshopaka（跨分盘加权力量）有固定权重，细微强弱还要依据精确位置。",
  "varga-assessment.step-04":
    "只有在回答运期兑现时，才把 Vimshopaka 分类与行星升起、落下状态一起用于限制运期结果。",
  "planetary-strength-assessment.step-01":
    "位置力必须从精确经度与深度落陷点计算，不能只用庙旺落陷文字标签代替。",
  "planetary-strength-assessment.step-02":
    "原文把力量分为位置、方向、时间、相位、运动和自然六类，单一尊贵状态不能替代完整六力。",
  "planetary-strength-assessment.step-03":
    "七颗行星各有自己的六力最低标准；土星极强同时可能带来长寿和痛苦，不能共用一条及格线。",
  "planetary-strength-assessment.step-04":
    "吉性和不吉性力量的多寡，只能限制与该行星相关宫位和运期的结果程度。",
  "prosperity-poverty-balance.step-01":
    "第二宫承载财富等主题，第十一宫承载收入与繁荣等主题；这是查询路由，不是财富结论。",
  "prosperity-poverty-balance.step-02":
    "第五宫主、第九宫主及与其结合的行星可以带来财富；原文另把兑现时间限定在相关运期。",
  "prosperity-poverty-balance.step-03":
    "同一段同时给出第二宫毁财条件和取消或反转条件，必须一起核对，不能只摘负面半句。",
  "prosperity-poverty-balance.step-04":
    "第 24 章的抵消规则只处理同一行星的双重宫主结果，不能扩大成所有发财格与贫困格的通用胜负公式。",
  "functional-benefic-yogakaraka-assessment.step-01":
    "功能吉凶随上升星座和全部宫主身份变化，不能把天然吉凶标签直接当成功能结果。",
  "functional-benefic-yogakaraka-assessment.step-02":
    "角宫主与三合宫主的交换、特定落位、合相或完整相位属于并列成立分支；同一行星兼管两类宫位是另一分支。",
  "functional-benefic-yogakaraka-assessment.step-03":
    "只拥有角宫不够自动转吉；同时主管不利宫位时，原文明确限制或取消王者瑜伽。",
  "functional-benefic-yogakaraka-assessment.step-04":
    "罗喉、计都先按落宫和结合宫主取主要结果，满足指定角宫／三合宫关系时才可讨论瑜伽主。",
  "rajayoga-political-assessment.step-01":
    "王者瑜伽要同时从出生上升与 Karakāńś 两套参考点检查，并按相关行星强弱缩放结果。",
  "rajayoga-political-assessment.step-02":
    "大王者瑜伽有多个并列分支；交换分支与 Atma Karaka—Putra Karaka 落位、尊贵、Navāńś 和吉星照射分支不能压成一句模糊关联。",
  "rajayoga-political-assessment.step-03":
    "官方关联收益要求第十一宫由本宫主占据、没有凶星照射，并且 Atma Karaka 与吉星结合，三项缺一不可。",
  "rajayoga-political-assessment.step-04":
    "上升主或 Atma Karaka 与第五宫主结合，并位于角宫或三合宫，才构成本段所说的王者或部长组合。",
  "nakshatra-dasha-selection-balance.step-01":
    "Vimshottari（维姆绍塔里大运）是一般默认；Ashtottari（八十一年运）只能在原文列出的罗喉关系条件下采用。",
  "nakshatra-dasha-selection-balance.step-02":
    "Vimshottari 的出生起始运主按从 Kritika 到出生星宿的计数余数确定，后续次序固定。",
  "nakshatra-dasha-selection-balance.step-03":
    "出生运期余额必须从月亮在出生星宿已经走过的时间按比例扣除，不能只凭出生星宿猜余额。",
  "nested-period-calculation.step-01":
    "小运和细运时长必须用上一级时长、下一级运主固定年数和该系统总年数逐层计算。",
  "nested-period-calculation.step-02":
    "每层运期都从本层主星开始，再按固定大运次序排列，不能自行改序。",
  "nested-period-calculation.step-03":
    "列出的细运结果只是一般结果；还要复查运主宫位、宫主身份和分盘状态，不能直接套成定论。",
  "nested-period-calculation.step-04":
    "Sukshma（微运）必须由 Pratyantar（细运）时长继续计算，不能跳过上一级。",
  "nested-period-calculation.step-05":
    "Prana（最细一层运期）必须由 Sukshma 时长继续计算，不能跳过上一级。",
  "longevity-calculation.step-01":
    "三种寿命算法必须依据上升、太阳、月亮三者谁最强来选择，不得任选。",
  "longevity-calculation.step-02":
    "两者或三者等强时，要分别计算对应算法再取平均，不能擅自选一个。",
  "longevity-calculation.step-03":
    "Pindayu 与 Ańśayu 使用不同输入和公式；当前步骤没有 Nisargayu 的完整公式，选中它时必须停止。",
  "longevity-calculation.step-04":
    "三组星座性质用于交叉核对寿命类别，书中另规定三组不一致时的优先分支。",
  "longevity-calculation.step-05":
    "贡献者在星座起点到终点的比例会修正寿命贡献，完成修正后才能得到净值。",
};

const forbiddenByMethod = {
  "varga-assessment": [
    "不得因为问题涉及婚姻就自动添加原文未要求的所有 D9 检查。",
    "不得把一个分盘中的单一好位置直接写成终局结论。",
  ],
  "planetary-strength-assessment": [
    "不得用庙旺落陷标签代替六力。",
    "不得给所有行星共用同一最低标准。",
  ],
  "bhava-lord-placement-lookup": [
    "不得把第二宫主落第八宫改写成财运损耗；冻结原文写的是土地与财富增加，同时婚姻和兄长幸福受限。",
    "不得给第七宫主落第十二宫擅加 D9、金星、木星救场或离婚结论。",
  ],
  "prosperity-poverty-balance": [
    "不得只取发财句或只取贫困句。",
    "没有原文明示优先级时，不得宣布哪一组一定压倒另一组。",
  ],
  "functional-benefic-yogakaraka-assessment": [
    "不得把一个上升星座的功能吉凶表套给另一个上升星座。",
    "不得把天然吉星、凶星直接等同于功能吉凶。",
  ],
  "rajayoga-political-assessment": [
    "不得只因两颗行星有关联就宣布王者瑜伽成立。",
    "不得把第 39～40 章彼此独立的组合拼成一条新规则。",
  ],
  "nakshatra-dasha-selection-balance": [
    "不得跳过特殊运期系统采用条件。",
    "不得在月亮已行时间缺失时猜出生运期余额。",
  ],
  "nested-period-calculation": [
    "不得跳过上一级运期直接计算更细一层。",
    "不得把阶段性运期结果写成终身烙印。",
  ],
  "longevity-calculation": [
    "不得在算法选择或任一输入缺失时输出寿命数字。",
    "不得把当前没有完整公式的算法用常识补齐。",
  ],
  "maraka-period-assessment": [
    "不得把普通凶星直接升级为致害星。",
    "不得把年龄边界、罗喉／计都分支冒充完整致害星排名。",
  ],
};

const topicGroups = {
  "宫主落宫与分盘边界": [
    "bhava-lord-placement-lookup",
    "varga-assessment",
    "planetary-strength-assessment",
  ],
  "财富支持与贫困取消条件": [
    "prosperity-poverty-balance",
    "functional-benefic-yogakaraka-assessment",
  ],
  "王者格局完整条件": [
    "functional-benefic-yogakaraka-assessment",
    "rajayoga-political-assessment",
    "varga-assessment",
    "planetary-strength-assessment",
  ],
  "运期选择与逐层计算": [
    "nakshatra-dasha-selection-balance",
    "nested-period-calculation",
  ],
  "寿命算法与致害条件": [
    "longevity-calculation",
    "maraka-period-assessment",
  ],
};

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, "utf8"));
}

function writeJson(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, `${JSON.stringify(value, null, 2)}\n`, "utf8");
}

function writeText(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, value, "utf8");
}

function unique(values) {
  return [...new Set(values)];
}

function conditionForFacts(facts, operator = "AND") {
  if (facts.length === 1) return { fact_key: facts[0] };
  return {
    operator,
    operands: facts.map((factKey) => ({ fact_key: factKey })),
  };
}

function refFor(atoms, atomId, quote) {
  const atom = atoms.get(atomId);
  if (!atom) throw new Error(`找不到原文原子：${atomId}`);
  if (!atom.exact_text.includes(quote)) {
    throw new Error(`逐字短引不在原文中：${atomId} → ${quote}`);
  }
  return {
    evidence_atom_id: atomId,
    quote,
    pdf_pages: atom.pdf_pages,
  };
}

function dedupeRefs(refs) {
  const seen = new Set();
  return refs.filter((ref) => {
    const key = JSON.stringify(ref);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function customBhavaMethod(method, atoms) {
  method.title = "宫主落宫原文定位、强弱与双重宫主核对样品";
  method.steps = [
    {
      step_id: "bhava-lord-placement-lookup.step-01",
      action:
        "根据命盘计算两个彼此独立的命中事实：第二宫主是否落第八宫、七宫主是否落第十二宫；两项使用 OR 分支分别返回对应原文，不把原文结果伪装成输入。",
      required_fact_keys: [
        "第二宫主落第八宫是否命中",
        "第七宫主落第十二宫是否命中",
      ],
      evidence_refs: [
        refFor(
          atoms,
          "bphs-97:santhanam:ch24:v20",
          "20. If Dhan’s Lord is in Randhr Bhava, the native will be endowed with abundant land and wealth. But he will have limited marital felicity and be bereft of happiness from his elder brother.",
        ),
        refFor(
          atoms,
          "bphs-97:santhanam:ch24:v84",
          "84. If Yuvati’s Lord is in Vyaya Bhava, the native will incur penury, be a miser and his livelihood will be related to clothes. His wife will be a spendthrift.",
        ),
      ],
      minimum_supported_claim:
        "本步骤只按两个可计算的命中事实返回对应原文分支；第二宫主落第八宫与第七宫主落第十二宫必须分别核对，不能在本步骤合并结论。",
    },
    {
      step_id: "bhava-lord-placement-lookup.step-02",
      action:
        "应用命中的原文分支前，核对同一行星的双重宫主身份和两项结果关系：相反结果按原文抵消，不同性质结果分别发生；再按强弱应用全量、半量或四分之一比例。",
      required_fact_keys: [
        "命中的宫主落宫原文分支",
        "目标宫主强弱",
        "目标宫主的双重宫主身份",
        "目标宫主两项宫主结果是否相反",
        "目标宫主两项宫主结果是否性质不同",
      ],
      evidence_refs: [
        refFor(
          atoms,
          "bphs-97:santhanam:ch24:v145-148",
          "those are the effects of Bhava Lords, which are to be deduced, considering their strengths and weaknesses.",
        ),
        refFor(
          atoms,
          "bphs-97:santhanam:ch24:v145-148",
          "The Grah will yield full, half, or a quarter of the effects according to its strength being full, medium and negligible, respectively.",
        ),
        refFor(
          atoms,
          "bphs-97:santhanam:ch24:v145-148",
          "In the case of a Grah, owning two Bhavas, the results are to be deducted based on its two lordships. If contrary results are thus indicated, the results will be nullified, while results of varied nature will come to pass.",
        ),
      ],
      minimum_supported_claim:
        "宫主落宫结果按宫主强弱缩放；同一行星的双重宫主结果相反时抵消，性质不同则分别发生。",
    },
  ];
  return method;
}

function customMarakaMethod(method, atoms) {
  method.title = "年龄边界与罗喉／计都致害条件样品（不含完整致害星排名）";
  method.steps = [
    {
      step_id: "maraka-period-assessment.step-01",
      action:
        "同时保留书内两个年龄边界：第 9 章写 24 岁前不作确定寿命计算，第 44 章写 20 岁前无法决定寿命；不擅自把两者改成同一个数字。",
      required_fact_keys: ["命主年龄"],
      evidence_refs: [
        refFor(
          atoms,
          "bphs-97:santhanam:ch09:v2",
          "Evils, causing premature end, exist up to the 24<sup>th</sup> year of one’s age. As such, no definite calculation of life span should be made till such year of age.",
        ),
        refFor(
          atoms,
          "bphs-97:santhanam:ch44:v10-14",
          "it is impossible to decide upon longevity till the native is 20 years old.",
        ),
      ],
      minimum_supported_claim:
        "书内存在 24 岁和 20 岁两个不同的禁断边界；至少在各自明确禁止的年龄范围内必须停止，不能宣称两段完全一致。",
    },
    {
      step_id: "maraka-period-assessment.step-02",
      action:
        "只有先取得已经可靠确定的致害宫主，才核对罗喉／计都的落宫、与致害宫主的距离或结合、当前大运或小运，以及吉星保护。",
      required_fact_keys: [
        "已经可靠确定的致害宫主",
        "罗喉或计都是否位于第一七八十二宫",
        "罗喉或计都是否位于致害宫主第七位或与之合相",
        "当前是否为对应大运或小运",
        "罗喉或计都是否受吉星照射或与吉星合相",
      ],
      evidence_refs: [
        refFor(
          atoms,
          "bphs-97:santhanam:ch44:v22-24",
          "If Rahu, or Ketu are placed in Tanu, Yuvati, Randhr, or Vyaya Bhava, or happen to be in the 7<sup>th</sup> from a Marak Lord, or are placed with such a Grah, they acquire powers of killing in their major, or sub-periods.",
        ),
        refFor(
          atoms,
          "bphs-97:santhanam:ch44:v22-24",
          "He will not, however, do so, if Rahu receives a Drishti from, or is yuti with a benefic.",
        ),
      ],
      minimum_supported_claim:
        "罗喉／计都只在原文列出的落宫、与已确定致害宫主的关系和对应运期条件下进入致害分支；吉星照射或结合会取消本段所说的困难。",
    },
  ];
  return method;
}

function applyFactCorrections(method) {
  const steps = new Map(method.steps.map((step) => [step.step_id, step]));

  if (method.method === "planetary-strength-assessment") {
    const step = steps.get("planetary-strength-assessment.step-04");
    step.action =
      "把力量换成结果兑现程度时，先确定要限制的是相关宫位还是相关运期，再分别保留吉性与不吉性力量。";
    step.required_fact_keys = ["综合吉凶力量", "当前要限制的宫位或运期"];
  }

  if (method.method === "prosperity-poverty-balance") {
    const first = steps.get("prosperity-poverty-balance.step-01");
    first.required_fact_keys = ["财富问题类型"];
    first.action =
      "只根据财富问题类型产出第二宫查阅路线和第十一宫查阅路线；本步骤不要求先取得宫位状态，也不直接下财富结论。";

    const third = steps.get("prosperity-poverty-balance.step-03");
    third.required_fact_keys = [
      "火星与土星是否同在第二宫",
      "水星是否照射第二宫的火星与土星",
      "太阳是否在第二宫",
      "土星是否照射第二宫太阳",
      "土星是否在第二宫",
      "太阳是否照射第二宫土星",
    ];
    third.action =
      "逐个核对第 42 章同段的三组贫困分支及其反转条件，不能只取结果最吓人的半句。";

    const fourth = steps.get("prosperity-poverty-balance.step-04");
    fourth.required_fact_keys = [
      "同一行星的双重宫主身份",
      "同一行星两项宫主结果是否相反",
      "同一行星两项宫主结果是否性质不同",
      "同一行星强弱",
    ];
    fourth.action =
      "只有财富正反结果来自同一行星的双重宫主身份时，才进入第 24 章处理；相反结果抵消与性质不同结果分别发生是两个独立分支，两个分支都按强弱应用全量、半量或四分之一比例。";
    fourth.minimum_supported_claim =
      "同一行星的双重宫主结果相反时按原文抵消，性质不同则分别发生，并按该行星强弱取全量、半量或四分之一。";
  }

  if (method.method === "functional-benefic-yogakaraka-assessment") {
    const second = steps.get(
      "functional-benefic-yogakaraka-assessment.step-02",
    );
    second.required_fact_keys = [
      "角宫主与三合宫主发生交换",
      "角宫主与三合宫主在角宫或三合宫合相",
      "三合宫主落入角宫或角宫主落入三合宫",
      "角宫主与三合宫主形成完整相位",
      "同一行星同时主管角宫和三合宫",
      "行星位于角宫或三合宫",
    ];
    second.action =
      "逐项核对角宫主与三合宫主的交换、合相、互置、完整相位，以及原文另列的单一行星位于角宫或三合宫分支；任一独立分支命中才进入功能瑜伽。";
    second.minimum_supported_claim =
      "原文列出交换、合相、互置、完整相位和单一行星位于角宫或三合宫等并列入口；不能把它们合成一个模糊关系。";
  }

  if (method.method === "rajayoga-political-assessment") {
    const second = steps.get("rajayoga-political-assessment.step-02");
    second.required_fact_keys = [
      "上升主与第五宫主交换星座",
      "Atma Karaka 与 Putra Karaka 所在位置",
      "相关行星是否位于擢升本宫或本 Navamsa",
      "相关行星是否受吉星照射",
    ];
    const third = steps.get("rajayoga-political-assessment.step-03");
    third.required_fact_keys = [
      "第十一宫由其宫主占据",
      "第十一宫受凶星照射",
      "Atma Karaka 与吉星合相",
    ];
    const fourth = steps.get("rajayoga-political-assessment.step-04");
    fourth.required_fact_keys = [
      "上升主与第五宫主合相",
      "Atma Karaka 与第五宫主合相",
      "该合相位于角宫",
      "该合相位于三合宫",
    ];
  }

  if (method.method === "nakshatra-dasha-selection-balance") {
    const first = steps.get("nakshatra-dasha-selection-balance.step-01");
    first.required_fact_keys = [
      "候选运期系统",
      "罗喉与上升和上升主的宫位关系",
      "特殊运期系统适用条件",
    ];
  }

  return method;
}

function applySemanticRepairs(method, atoms) {
  const steps = new Map(method.steps.map((step) => [step.step_id, step]));

  if (method.method === "varga-assessment") {
    const routing = steps.get("varga-assessment.step-01");
    routing.action =
      "根据用户问题的生活主题选择原书指定的目标分盘；目标分盘是本步骤计算出的结果，不是预先输入。";
    routing.required_fact_keys = ["用户问题的生活主题"];
    routing.minimum_supported_claim =
      "原文把不同生活主题分别交给指定分盘；本步骤只选择目标分盘，不把目标分盘当成已取得输入。";

    const state = steps.get("varga-assessment.step-02");
    state.required_fact_keys = [
      "目标分盘",
      "目标行星在各相关分盘的位置",
      "目标行星所在分盘的尊贵和受损状态",
    ];

    const step = steps.get("varga-assessment.step-03");
    step.action =
      "先按本书列出的分盘权重取得目标行星 Vimshopaka 强度，再用各分盘内的精确位置判断细微差异；不能把粗略分值当成全部判断。";
    step.required_fact_keys = [
      "目标行星各相关分盘的精确位置",
    ];
    step.evidence_refs = [
      refFor(
        atoms,
        "bphs-97:santhanam:ch07:v17-19",
        "The full Bal for each of the divisions, respectively, are 6, 2, 4, 5, 2 and 1.",
      ),
      refFor(
        atoms,
        "bphs-97:santhanam:ch07:v17-19",
        "These are gross strengths, while subtle ones should be understood by exact positions.",
      ),
    ];
    step.minimum_supported_claim =
      "原文为分盘列出粗略力量；细微强弱还要依据精确位置，不能把粗略权重当成完整判断。";
  }

  if (method.method === "planetary-strength-assessment") {
    const categories = steps.get("planetary-strength-assessment.step-02");
    categories.action =
      "按原文列出的六类力量分别取得力量项：位置、方向、时间、相位、运动和自然。";
    categories.minimum_supported_claim =
      "原文直接把力量分为位置、方向、时间、相位、运动和自然六类；本步骤只保留这六类力量项。";

    const step = steps.get("planetary-strength-assessment.step-01");
    step.action =
      "先按行星经度与深度落陷点计算原文所说的 Uchch Bal（擢升力）子项；这不是完整位置力，不能扩大名称。";
    step.required_fact_keys = [
      "目标行星经度",
      "目标行星深度擢升和落陷点",
    ];
    step.minimum_supported_claim =
      "原文只直接规定从经度和深度落陷点计算 Uchch Bal（擢升力）子项；本步骤不能把它说成完整位置力。";

    const threshold = steps.get("planetary-strength-assessment.step-03");
    threshold.evidence_refs = [
      ...threshold.evidence_refs,
      refFor(
        atoms,
        "bphs-97:santhanam:ch27:v32-33",
        "However, Shani’s extreme strength will give long life as well as miseries.",
      ),
    ];
  }

  if (method.method === "prosperity-poverty-balance") {
    const route = steps.get("prosperity-poverty-balance.step-01");
    route.required_fact_keys = ["财富问题类型"];
    route.action =
      "只根据财富问题类型产出第二宫查阅路线和第十一宫查阅路线；本步骤不要求先取得宫位状态，也不直接下财富结论。";
    route.minimum_supported_claim =
      "原文把财富等主题交给第二宫、把收入和繁荣等主题交给第十一宫；本步骤只产出两条查阅路线。";

    const wealth = steps.get("prosperity-poverty-balance.step-02");
    wealth.required_fact_keys = [
      "第五宫主状态",
      "第九宫主状态",
      "是否有行星与第五宫主结合",
      "是否有行星与第九宫主结合",
      "是否询问财富兑现时间",
    ];
    wealth.action =
      "逐项核对第五宫主状态、第九宫主状态，以及行星与第五宫主或第九宫主的结合；‘与第五宫主结合’和‘与第九宫主结合’是 OR 替代分支，不得要求二者同时成立。只有用户询问兑现时间时，才进入相关运期分支。";
    wealth.minimum_supported_claim =
      "原文直接支持第五宫主、第九宫主以及与第五宫主或第九宫主结合的行星带来财富；两个结合关系是 OR 替代分支。用户询问兑现时间时，才按原文在相关行星运期内核对窗口。";

    const poverty = steps.get("prosperity-poverty-balance.step-03");
    poverty.action =
      "把第 42 章同一原子中的三组分支逐组判定：火星土星同在第二宫时再看水星照射；太阳在第二宫时区分土星照射与不受照射；土星在第二宫受太阳照射时另记贫困，不能把取消条件当成主触发。";
    poverty.minimum_supported_claim =
      "原文同时写出三组分支：火星与土星同在第二宫主毁财、水星照射时改为巨富；太阳在第二宫受土星照射主贫困、不受照射主财富与名望；土星在第二宫受太阳照射主贫困。三组必须分开核对。";
    poverty.evidence_refs = [
      refFor(
        atoms,
        "bphs-97:santhanam:ch42:v16-18",
        "16-18. Now I tell you some Yogas for poverty along with conditions of their nullifications. Should Mangal and Shani be together in Dhan Bhava, the native’s wealth will be destroyed. Should Budh give a Drishti to Mangal and Shani in Dhan Bhava, there will be great wealth. There is no doubt in it. Surya in Dhan Bhava, receiving a Drishti from Shani, will cause penury, while, if Surya is in Dhan Bhava and does not receive a Drishti from Shani, riches and fame will be obtained. The same effects (poverty) will be declared, if Shani is in Dhan Bhava, receiving a Drishti from Surya.",
      ),
    ];
  }

  if (method.method === "bhava-lord-placement-lookup") {
    const step = steps.get("bhava-lord-placement-lookup.step-01");
    step.action =
      "核验事实适配层已经计算好的两个分支命中布尔值：第二宫主落第八宫是否命中、七宫主落第十二宫是否命中；本步骤只按 OR 分支返回对应原文，不自行从原始宫位重新计算。";
    step.minimum_supported_claim =
      "本步骤只核验事实适配层提供的两个命中布尔值，并按 OR 分支返回对应原文；不能把本步骤说成自行计算原始宫位。";
  }

  if (method.method === "functional-benefic-yogakaraka-assessment") {
    const first = steps.get("functional-benefic-yogakaraka-assessment.step-01");
    first.required_fact_keys = ["上升星座", "目标行星主管宫位"];
    first.action =
      "按上升星座和目标行星实际主管的全部宫位计算功能吉凶；功能分类是本步骤产出，不能当成外部输入。";

    const limitation = steps.get(
      "functional-benefic-yogakaraka-assessment.step-03",
    );
    limitation.required_fact_keys = [
      "目标行星是否为凶星",
      "目标行星是否为角宫主或三合宫主",
    ];
    limitation.action =
      "拆开核对两条原文：第14偈只检查凶星是否拥有角宫，以及是否同时拥有三合宫；第15偈另检查角宫主或三合宫主是否同时主管不利宫位，不能给第15偈附加凶星前提。";
    limitation.minimum_supported_claim =
      "第14偈针对凶星规定：仅拥有角宫不足以转吉，还要核对是否同时主管三合宫；第15偈针对角宫主或三合宫主同时主管不利宫位的情况，未要求目标行星必须是凶星。";

    const step = steps.get("functional-benefic-yogakaraka-assessment.step-04");
    step.action =
      "判断罗喉计都时，先按其落宫和所结合宫主取主要结果；只有节点位于角宫，并受三合宫主或角宫主照射或合相时，才进入原文的瑜伽主分支。";
    step.required_fact_keys = [
      "罗喉计都落宫和所结合宫主",
      "罗喉计都是否位于角宫",
      "罗喉计都是否受三合宫主或角宫主照射或合相",
    ];
    step.minimum_supported_claim =
      "罗喉、计都先按落宫和结合宫主取主要结果；节点位于角宫且受三合宫主或角宫主照射或合相时，原文才允许讨论瑜伽主。";
    step.evidence_refs = [
      refFor(
        atoms,
        "bphs-97:santhanam:ch34:v16",
        "16. Rahu and Ketu. Rahu and Ketu give predominantly the effects, as due to their yuti with a Bhava Lord, or, as due to the Bhava they occupy.",
      ),
      refFor(
        atoms,
        "bphs-97:santhanam:ch34:v17",
        "If Rahu and/or Ketu are in Kendr, receiving a Drishti from, or in association with the Lord of a Kon, or of a Kendr, it will become Yog Karak.",
      ),
    ];
  }

  if (method.method === "rajayoga-political-assessment") {
    const step = steps.get("rajayoga-political-assessment.step-02");
    step.action =
      "把大王者瑜伽拆成两个并列入口：上升主与第五宫主交换时，不要求吉星照射；只有进入 Atma Karaka 与 Putra Karaka 的位置分支时，才继续核对上升宫、第五宫、擢升星座、本宫、本 Navamsa 和吉星照射。";
    step.required_fact_keys = [
      "上升主与第五宫主交换星座",
    ];
    step.minimum_supported_claim =
      "原文允许两条并列入口：上升主与第五宫主交换本身即可进入该分支；或 Atma Karaka 与 Putra Karaka 满足列明位置中的任一项并受吉星照射。不能把第二分支的照射条件强加给交换分支。";
    step.evidence_refs = [
      refFor(
        atoms,
        "bphs-97:santhanam:ch39:v6-7",
        "6-7. Maha Raj Yog. Should Lagn’s Lord and Putr’s Lord exchange their Rāśis, or, if Atma Karak and Putr Karak (Char) are in Lagna, or in Putr Bhava, or in the exaltation Rāśi, or in own Rāśi, or in own Navāńś, receiving a Drishti from a benefic, Maha Raj Yog is produced. The native so born will be famous and happy.",
      ),
    ];
  }

  if (method.method === "nakshatra-dasha-selection-balance") {
    const step = steps.get("nakshatra-dasha-selection-balance.step-01");
    step.action =
      "先分别核验两个候选布尔值：候选运期系统为 Vimshottari，或候选运期系统为 Ashtottari；两者按 OR 分支确认，只有 Ashtottari 分支才进入特殊条件核验。";
    step.required_fact_keys = [
      "候选运期系统为 Vimshottari",
      "候选运期系统为 Ashtottari",
    ];
    step.minimum_supported_claim =
      "原文把 Vimshottari 说成一般人群的适用系统；Ashtottari 只有在罗喉不位于上升宫、上升主角宫或上升主三合宫时才采用。两个候选系统必须分别核验，Ashtottari 的三个限制条件都必须明确为否。";
    step.evidence_refs = [
      refFor(
        atoms,
        "bphs-97:santhanam:ch46:v2-5",
        "Dashas are of many kinds. Amongst them Vimshottari is the most appropriate for the general populace. But the other Dashas, followed in special cases, are Astottari, Shodshottari, Dwadashottari, Panchottari, Shatabdik, Chaturashiti-sama, Dwisaptati-sama, Shastihayani, Shat-trimshat-sama.",
      ),
      refFor(
        atoms,
        "bphs-97:santhanam:ch46:v17-20",
        "the sages have recommended the adoption of Ashtottari, when Rahu not being in Lagna, in any other Kendr, or Trikon to the Lord of the Lagn.",
      ),
    ];

    const start = steps.get("nakshatra-dasha-selection-balance.step-02");
    start.required_fact_keys = [
      "已核验系统为 Vimshottari",
      "出生星宿",
    ];
    start.action =
      "仅在已核验系统为 Vimshottari 后，从 Kritika 到出生星宿计数并除以九，计算出生起始运主；固定年数留给后续运期余额计算。";

    const balance = steps.get("nakshatra-dasha-selection-balance.step-03");
    balance.required_fact_keys = [
      "已核验系统为 Vimshottari",
      "出生起始运主",
      "月亮在出生星宿已行时间",
      "月亮在出生星宿总停留时间",
      "各运主固定年数",
    ];
    balance.action =
      "仅在已核验系统为 Vimshottari 且已取得出生起始运主后，按月亮已经走过的出生星宿时间计算已过运期，再从该运主总年数中扣除得到出生余额。";
  }

  if (method.method === "nested-period-calculation") {
    const formula = steps.get("nested-period-calculation.step-01");
    formula.action =
      "按原文分别计算 Antar 和 Pratyantar：上一级运期时长乘下一层运主固定年数，再除以该运期系统总年数；不能只绑定 Antar 公式。";
    formula.minimum_supported_claim =
      "原文分别规定 Antar 与 Pratyantar 的同类计算式：使用上一级时长、下一层运主年数和系统总年数逐层计算。";
    formula.evidence_refs = [
      refFor(
        atoms,
        "bphs-97:santhanam:ch51:v1",
        "For finding out the span of the Antar Dasha of a Grah in the Dasha of the same, or another Grah multiply the Dasha years of the former with the Dasha years of the latter and divide the product by the total Dasha years of all the Grahas.",
      ),
      refFor(
        atoms,
        "bphs-97:santhanam:ch51:v1",
        "For finding out the span of the Pratyantar Dasha of the same, or any other Grah in the Antar Dasha of another Grah multiply the years etc. of the Antar Dasha with the Dasha years of the other Grah and divide the product by the total Dasha years of all the Grahas.",
      ),
    ];

    const step = steps.get("nested-period-calculation.step-03");
    step.action =
      "把 Surya-Surya Pratyantar 的原文示例逐项复查：三合宫、吉宫主、吉宫且在吉分盘是三个独立的取消分支，不能把示例结果改写成别的 Pratyantar 条件。";
    step.required_fact_keys = [
      "当前 Pratyantar 运主",
      "当前运主是否在三合宫",
      "当前运主是否为吉宫主",
      "当前运主是否在吉宫",
      "当前运主是否在吉分盘",
    ];
    step.minimum_supported_claim =
      "原文以 Surya-Surya Pratyantar 为示例，说明该 Pratyantar 的不吉结果在运主位于三合宫、为吉宫主，或位于吉宫且在吉分盘时不产生。";
    step.evidence_refs = [
      refFor(
        atoms,
        "bphs-97:santhanam:ch61:v2",
        "2. Surya-Surya (Pratyantar Dasha of Surya in the Antar Dasha of Surya). Argument with other persons, loss of wealth, distress to wife, headache etc. The above are general effects. Such inauspicious effects will not be produced, if Surya is in a Trikon etc., if Surya is the Lord of an auspicious Bhava, or is in a auspicious Bhava and in a benefic Varg. All other Pratyanta effects should be judged in this manner.",
      ),
    ];

    const sukshma = steps.get("nested-period-calculation.step-04");
    sukshma.required_fact_keys = [
      "Pratyantar 运期时长",
      "下一级运主固定年数",
      "当前 Sukshma 运主",
    ];
    const prana = steps.get("nested-period-calculation.step-05");
    prana.required_fact_keys = [
      "Sukshma 运期时长",
      "下一级运主固定年数",
      "当前 Prana 运主",
    ];
  }

  if (method.method === "longevity-calculation") {
    const selection = steps.get("longevity-calculation.step-01");
    selection.required_fact_keys = ["上升太阳月亮三者强弱"];
    selection.action =
      "比较上升、太阳和月亮三者强弱，只产出选用 Pindayu、选用 Amsayu、选用 Nisargayu 三个算法选择布尔结果；算法选择是本步骤产出，不能把选择结果当成输入，是否需要平均留给下一步根据等强事实判断。";
    selection.minimum_supported_claim =
      "原文按上升、太阳和月亮三者谁更强来选择寿命算法；本步骤只产出三个算法选择，不产出平均结果。";

    const average = steps.get("longevity-calculation.step-02");
    average.required_fact_keys = [
      "选用 Pindayu",
      "选用 Amsayu",
      "选用 Nisargayu",
      "上升太阳月亮是否有两者或三者等强",
    ];
    average.action =
      "消费上一步的算法选择结果，按互斥分支处理：只选中一套算法时只取得该套输入并直接计算；两套算法等强时只取得被选中的两套输入并取两者平均；三套算法等强时取得三套输入并取三者平均，不把本步骤结果反写成输入。";
    average.minimum_supported_claim =
      "原文规定单一算法按所选系统计算；两者或三者等强时，只对相应的两套或三套算法取平均，本步骤按上一步选择结果取得对应输入。";
    average.evidence_refs = [
      refFor(
        atoms,
        "bphs-97:santhanam:ch43:v32",
        "If two among Lagna, Surya and Chandra gain equal strength, then longevity should be worked out, as per both systems and the average of both should be considered. If all the three are equally strong, the average of the three should be considered.",
      ),
      refFor(
        atoms,
        "bphs-97:santhanam:ch43:v4-8",
        "The Grahas contribute to longevity, according to their being in exaltation, or debilitation and also based on their strengths and weaknesses and positions in Ashvini etc. and in the various Rāśis.",
      ),
      refFor(
        atoms,
        "bphs-97:santhanam:ch43:v18-19",
        "The years correspond to the number of Navāńśas, counted from Mesh. Multiply the longitude in question by 108.",
      ),
    ];

    const algorithm = steps.get("longevity-calculation.step-03");
    algorithm.action =
      "根据三组原始星座性质分别产出上升主第八宫主寿命类别、土星月亮寿命类别、出生上升 Hora Lagna 寿命类别和三组结果是否全不相同；本步骤只计算这四个结果。";
    algorithm.required_fact_keys = [
      "上升主和第八宫主的星座性质",
      "土星和月亮的星座性质",
      "出生上升和 Hora Lagna 的星座性质",
    ];
    algorithm.minimum_supported_claim =
      "原文把上升主—第八宫主、土星—月亮、出生上升—Hora Lagna 分成三组核对；本步骤分别产出三组寿命类别和三组结果是否全不相同。";
    algorithm.evidence_refs = [
      refFor(
        atoms,
        "bphs-97:santhanam:ch43:v33-40",
        "33-40. Other Clues to Longevity. O excellent of the Brahmins, I will now give you details of other methods in the matter of longevity, as under. This is based on the positions of Lagn’s Lord, Randhr’s Lord, Shani, Chandra, natal Lagn and Hora Lagn. These six are grouped into three groups thus: the Lords of Lagn and of Randhr Bhava on the one hand, Shani and Chandra on the other hand and the natal Lagn and Hora Lagn on yet the other hand. Out of a group of two, if the two are in Movable Rāśis, long life is denoted. One in a Fixed Rashiand the other in a Dual Rashiwill also bestow long life. One in a Movable Rashiand the other in a Fixed Rashiwill give medium life. If both are in Dual Rāśis, then again medium life will be obtained. Short life is denoted, if one is in a Movable Rāśi, as the other is in a Dual Rāśi, or, if both are in Fixed Rāśis. The type of life, denoted by three, or two groups be only considered. If the three groups denote different scales, then the one, indicated by the pair of natal Lagn and Hora Lagn should be only considered. In case of three different indications, if Chandra is in Lagna, or Yuvati Bhava, then the one, indicated by the Shani-Chandra pair will only come to pass.",
      ),
    ];

    const clues = steps.get("longevity-calculation.step-04");
    clues.action =
      "消费上一步产出的三组寿命类别和三组结果是否全不相同，应用原文优先规则；只有三组结果全不相同时，才进一步取得月亮是否在上升或第七宫。";
    clues.required_fact_keys = [
      "上升主第八宫主寿命类别",
      "土星月亮寿命类别",
      "出生上升 Hora Lagna 寿命类别",
      "三组结果是否全不相同",
    ];
    clues.minimum_supported_claim =
      "消费三组寿命类别；若三组结果全不相同，优先采用出生上升与 Hora Lagna 组，且月亮在上升或第七宫时再采用土星—月亮组。";
    clues.evidence_refs = [
      refFor(
        atoms,
        "bphs-97:santhanam:ch43:v33-40",
        "33-40. Other Clues to Longevity. O excellent of the Brahmins, I will now give you details of other methods in the matter of longevity, as under. This is based on the positions of Lagn’s Lord, Randhr’s Lord, Shani, Chandra, natal Lagn and Hora Lagn. These six are grouped into three groups thus: the Lords of Lagn and of Randhr Bhava on the one hand, Shani and Chandra on the other hand and the natal Lagn and Hora Lagn on yet the other hand. Out of a group of two, if the two are in Movable Rāśis, long life is denoted. One in a Fixed Rashiand the other in a Dual Rashiwill also bestow long life. One in a Movable Rashiand the other in a Fixed Rashiwill give medium life. If both are in Dual Rāśis, then again medium life will be obtained. Short life is denoted, if one is in a Movable Rāśi, as the other is in a Dual Rāśi, or, if both are in Fixed Rāśis. The type of life, denoted by three, or two groups be only considered. If the three groups denote different scales, then the one, indicated by the pair of natal Lagn and Hora Lagn should be only considered. In case of three different indications, if Chandra is in Lagna, or Yuvati Bhava, then the one, indicated by the Shani-Chandra pair will only come to pass.",
      ),
    ];

    const rectification = steps.get("longevity-calculation.step-05");
    rectification.action =
      "先按贡献者在星座内的位置做比例修正，再把贡献者经度求和后除以贡献者数量，乘基本寿命年数并除以 30，最后才得到净寿命。";
    rectification.required_fact_keys = [
      "各贡献者原始经度",
      "贡献者数量",
      "基本寿命年数",
    ];
    rectification.minimum_supported_claim =
      "贡献者在星座起点到终点的比例决定其贡献；再按原文把贡献者经度求平均，乘基本寿命年数并除以 30，才得到净寿命。";
    rectification.evidence_refs = [
      refFor(
        atoms,
        "bphs-97:santhanam:ch43:v45-46",
        "If the contributor is in the beginning of a Rāśi, his donation will be full and it will be nil, if he is at the end of a Rāśi. For intermediary placements rule of three process will apply. Add the longitudes of the contributors and the sum so arrived at must be divided by the number of contributors. The latest product should be multiplied by the number of basic years and divided by 30. This will yield the net longevity.",
      ),
    ];
  }

  if (method.method === "maraka-period-assessment") {
    const step = steps.get("maraka-period-assessment.step-02");
    step.action =
      "按三个分支开关分别核对：节点位于第一、七、八或十二宫、位于致害宫主第七位、或与致害宫主同宫的任一关系；摩羯或天蝎上升的罗喉分支；罗喉第六／八／十二宫困难分支。凡原文要求节点自身大运或小运时，只核对‘当前大运或小运运主为该节点’。";
    step.required_fact_keys = [
      "当前问题是否检查节点与致害宫主关系",
      "当前问题是否检查摩羯或天蝎上升的罗喉分支",
      "当前问题是否检查罗喉第六、八、十二宫困难分支",
    ];
    step.minimum_supported_claim =
      "三个节点分支分别核对：节点是否位于第一、七、八或十二宫、是否位于致害宫主第七位、是否与致害宫主同宫，摩羯或天蝎上升的罗喉身份，以及罗喉第六／八／十二宫困难；要求节点自身运期时只接受‘当前大运或小运运主为该节点’，吉星保护只作用于原文列明的困难分支。";
    step.evidence_refs = [
      refFor(
        atoms,
        "bphs-97:santhanam:ch44:v22-24",
        "22-24. Rahu and Ketu, as Marakas. If Rahu, or Ketu are placed in Tanu, Yuvati, Randhr, or Vyaya Bhava, or happen to be in the 7<sup>th</sup> from a Marak Lord, or are placed with such a Grah, they acquire powers of killing in their major, or sub-periods. For one born in Makar, or in Vrischik, Rahu will be a Marak. Should Rahu be in Ari, Randhr, or Vyaya Bhava, he will give difficulties in his Dasha periods. He will not, however, do so, if Rahu receives a Drishti from, or is yuti with a benefic.",
      ),
    ];
  }

  return method;
}

function customCondition(step) {
  const facts = step.required_fact_keys;
  if (step.step_id === "bhava-lord-placement-lookup.step-01") {
    return {
      operator: "OR",
      operands: [
        { fact_key: facts[0] },
        { fact_key: facts[1] },
      ],
    };
  }
  if (step.step_id === "bhava-lord-placement-lookup.step-02") {
    return {
      operator: "AND",
      operands: [
        { fact_key: facts[0] },
        { fact_key: facts[2] },
        {
          operator: "OR",
          operands: [
            {
              operator: "AND",
              operands: [
                { fact_key: facts[3] },
                { fact_key: facts[1] },
              ],
            },
            {
              operator: "AND",
              operands: [
                { fact_key: facts[4] },
                { fact_key: facts[1] },
              ],
            },
          ],
        },
      ],
    };
  }
  if (step.step_id === "functional-benefic-yogakaraka-assessment.step-02") {
    return conditionForFacts(facts, "OR");
  }
  if (step.step_id === "functional-benefic-yogakaraka-assessment.step-03") {
    return {
      operator: "OR",
      operands: [
        {
          operator: "AND",
          operands: [
            { fact_key: "目标行星是否为凶星" },
            { fact_key: "目标行星是否拥有角宫" },
            {
              operator: "NOT",
              operands: [{ fact_key: "目标行星是否拥有三合宫" }],
            },
          ],
        },
        {
          operator: "AND",
          operands: [
            { fact_key: "目标行星是否为角宫主或三合宫主" },
            {
              operator: "OR",
              operands: [
                { fact_key: "目标行星是否为角宫主" },
                { fact_key: "目标行星是否为三合宫主" },
              ],
            },
            { fact_key: "目标行星是否同时主管不利宫位" },
          ],
        },
      ],
    };
  }
  if (step.step_id === "rajayoga-political-assessment.step-02") {
    const atmaPosition = {
      operator: "OR",
      operands: [
        { fact_key: "Atma Karaka 与 Putra Karaka 是否同在上升宫" },
        { fact_key: "Atma Karaka 与 Putra Karaka 是否同在第五宫" },
        { fact_key: "Atma Karaka 与 Putra Karaka 是否位于擢升星座" },
        { fact_key: "Atma Karaka 与 Putra Karaka 是否位于各自本宫" },
        { fact_key: "Atma Karaka 与 Putra Karaka 是否位于各自本 Navamsa" },
      ],
    };
    return {
      operator: "OR",
      operands: [
        { fact_key: facts[0] },
        {
          operator: "AND",
          operands: [
            atmaPosition,
            { fact_key: "相关行星是否受吉星照射" },
          ],
        },
      ],
    };
  }
  if (step.step_id === "rajayoga-political-assessment.step-03") {
    return {
      operator: "AND",
      operands: [
        { fact_key: facts[0] },
        { operator: "NOT", operands: [{ fact_key: facts[1] }] },
        { fact_key: facts[2] },
      ],
    };
  }
  if (step.step_id === "rajayoga-political-assessment.step-04") {
    return {
      operator: "AND",
      operands: [
        {
          operator: "OR",
          operands: facts.slice(0, 2).map((factKey) => ({ fact_key: factKey })),
        },
        {
          operator: "OR",
          operands: facts.slice(2).map((factKey) => ({ fact_key: factKey })),
        },
      ],
    };
  }
  if (step.step_id === "prosperity-poverty-balance.step-03") {
    return {
      operator: "OR",
      operands: [
        {
          operator: "AND",
          operands: [{ fact_key: facts[0] }, { fact_key: facts[1] }],
        },
        {
          operator: "AND",
          operands: [
            { fact_key: facts[0] },
            { operator: "NOT", operands: [{ fact_key: facts[1] }] },
          ],
        },
        {
          operator: "AND",
          operands: [{ fact_key: facts[2] }, { fact_key: facts[3] }],
        },
        {
          operator: "AND",
          operands: [
            { fact_key: facts[2] },
            { operator: "NOT", operands: [{ fact_key: facts[3] }] },
          ],
        },
        {
          operator: "AND",
          operands: [{ fact_key: facts[4] }, { fact_key: facts[5] }],
        },
      ],
    };
  }
  if (step.step_id === "prosperity-poverty-balance.step-02") {
    const timeQuestion = { fact_key: facts[facts.length - 1] };
    const wealthSupport = {
      operator: "OR",
      operands: [
        { fact_key: facts[0] },
        { fact_key: facts[1] },
        { fact_key: facts[2] },
        { fact_key: facts[3] },
      ],
    };
    return {
      operator: "OR",
      operands: [
        {
          operator: "AND",
          operands: [{ operator: "NOT", operands: [timeQuestion] }, wealthSupport],
        },
        {
          operator: "AND",
          operands: [
            timeQuestion,
            wealthSupport,
            { fact_key: "相关运期" },
          ],
        },
      ],
    };
  }
  if (step.step_id === "prosperity-poverty-balance.step-04") {
    return {
      operator: "AND",
      operands: [
        { fact_key: facts[0] },
        {
          operator: "OR",
          operands: [
            {
              operator: "AND",
              operands: [
                { fact_key: facts[1] },
                { fact_key: facts[3] },
              ],
            },
            {
              operator: "AND",
              operands: [
                { fact_key: facts[2] },
                { fact_key: facts[3] },
              ],
            },
          ],
        },
      ],
    };
  }
  if (step.step_id === "longevity-calculation.step-02") {
    const [pindayu, amsayu, nisargayu, equalStrength] = facts;
    const selected = (factKey) => ({ fact_key: factKey });
    const notSelected = (factKey) => ({
      operator: "NOT",
      operands: [selected(factKey)],
    });
    return {
      operator: "OR",
      operands: [
        {
          operator: "AND",
          operands: [
            selected(pindayu),
            notSelected(amsayu),
            notSelected(nisargayu),
            notSelected(equalStrength),
          ],
        },
        {
          operator: "AND",
          operands: [
            selected(amsayu),
            notSelected(pindayu),
            notSelected(nisargayu),
            notSelected(equalStrength),
          ],
        },
        {
          operator: "AND",
          operands: [
            selected(nisargayu),
            notSelected(pindayu),
            notSelected(amsayu),
            notSelected(equalStrength),
          ],
        },
        {
          operator: "AND",
          operands: [
            selected(pindayu),
            selected(amsayu),
            notSelected(nisargayu),
            selected(equalStrength),
          ],
        },
        {
          operator: "AND",
          operands: [
            selected(pindayu),
            selected(nisargayu),
            notSelected(amsayu),
            selected(equalStrength),
          ],
        },
        {
          operator: "AND",
          operands: [
            selected(amsayu),
            selected(nisargayu),
            notSelected(pindayu),
            selected(equalStrength),
          ],
        },
        {
          operator: "AND",
          operands: [
            selected(pindayu),
            selected(amsayu),
            selected(nisargayu),
            selected(equalStrength),
          ],
        },
      ],
    };
  }
  if (step.step_id === "nakshatra-dasha-selection-balance.step-01") {
    const vimshottari = { fact_key: facts[0] };
    const ashtottari = { fact_key: facts[1] };
    return {
      operator: "OR",
      operands: [
        vimshottari,
        {
          operator: "AND",
          operands: [
            ashtottari,
            {
              operator: "NOT",
              operands: [{ fact_key: "罗喉位于上升宫" }],
            },
            {
              operator: "NOT",
              operands: [{ fact_key: "罗喉位于上升主的角宫" }],
            },
            {
              operator: "NOT",
              operands: [{ fact_key: "罗喉位于上升主的三合宫" }],
            },
          ],
        },
      ],
    };
  }
  if (step.step_id === "nested-period-calculation.step-03") {
    return {
      operator: "OR",
      operands: [
        {
          operator: "AND",
          operands: [{ fact_key: facts[0] }, { fact_key: facts[1] }],
        },
        {
          operator: "AND",
          operands: [{ fact_key: facts[0] }, { fact_key: facts[2] }],
        },
        {
          operator: "AND",
          operands: [
            { fact_key: facts[0] },
            { fact_key: facts[3] },
            { fact_key: facts[4] },
          ],
        },
      ],
    };
  }
  if (step.step_id === "longevity-calculation.step-03") {
    return conditionForFacts(facts);
  }
  if (step.step_id === "maraka-period-assessment.step-02") {
    return {
      operator: "OR",
      operands: [
        {
          operator: "AND",
          operands: [
            { fact_key: facts[0] },
            {
              operator: "OR",
              operands: [
                { fact_key: "节点是否位于第一、七、八或十二宫" },
                { fact_key: "节点是否位于致害宫主第七位" },
                { fact_key: "节点是否与致害宫主同宫" },
              ],
            },
            { fact_key: "当前大运或小运运主为该节点" },
          ],
        },
        {
          operator: "AND",
          operands: [
            { fact_key: facts[1] },
            { fact_key: "出生上升是否为摩羯或天蝎" },
            { fact_key: "当前大运或小运运主为该节点" },
          ],
        },
        {
          operator: "AND",
          operands: [
            { fact_key: facts[2] },
            { fact_key: "罗喉落宫" },
            { fact_key: "吉星照射／合相" },
            { fact_key: "当前大运或小运运主为该节点" },
          ],
        },
      ],
    };
  }
  return conditionForFacts(facts);
}

function exceptionRelations(step) {
  const byStep = {
    "varga-assessment.step-02": [
      {
        type: "limitation",
        description: "燃烧、星战失败、弱势或不良状态会使好分盘失去吉格支持资格。",
        evidence_atom_ids: ["bphs-97:santhanam:ch06:v42-53"],
      },
    ],
    "planetary-strength-assessment.step-03": [
      {
        type: "limitation",
        description: "土星极强并非单向吉利；原文同时保留痛苦结果。",
        evidence_atom_ids: ["bphs-97:santhanam:ch27:v32-33"],
      },
    ],
    "prosperity-poverty-balance.step-03": [
      {
        type: "cancellation",
        description: "水星照射第二宫的火星与土星时，同段把毁财结果改为巨富。",
        evidence_atom_ids: ["bphs-97:santhanam:ch42:v16-18"],
      },
      {
        type: "cancellation",
        description: "太阳在第二宫而不受土星照射时，同段把贫困结果改为财富和名望。",
        evidence_atom_ids: ["bphs-97:santhanam:ch42:v16-18"],
      },
    ],
    "functional-benefic-yogakaraka-assessment.step-03": [
      {
        type: "limitation",
        description: "只拥有角宫不足以自动转吉。",
        evidence_atom_ids: ["bphs-97:santhanam:ch34:v14"],
      },
      {
        type: "cancellation",
        description: "同时主管不利宫位时，单靠既有关系不构成王者瑜伽。",
        evidence_atom_ids: ["bphs-97:santhanam:ch34:v15"],
      },
    ],
    "longevity-calculation.step-02": [
      {
        type: "exception",
        description: "两者或三者等强时改用多算法平均。",
        evidence_atom_ids: ["bphs-97:santhanam:ch43:v32"],
      },
    ],
    "nested-period-calculation.step-03": [
      {
        type: "cancellation",
        description: "在 Surya-Surya Pratyantar 示例中，运主在三合宫时该示例的不吉结果不产生。",
        evidence_atom_ids: ["bphs-97:santhanam:ch61:v2"],
      },
      {
        type: "cancellation",
        description: "在 Surya-Surya Pratyantar 示例中，运主为吉宫主时该示例的不吉结果不产生。",
        evidence_atom_ids: ["bphs-97:santhanam:ch61:v2"],
      },
      {
        type: "cancellation",
        description: "在 Surya-Surya Pratyantar 示例中，运主在吉宫且在吉分盘时该示例的不吉结果不产生。",
        evidence_atom_ids: ["bphs-97:santhanam:ch61:v2"],
      },
    ],
    "maraka-period-assessment.step-01": [
      {
        type: "limitation",
        description: "书内存在 24 岁与 20 岁两个不同禁断边界，不能静默合并。",
        evidence_atom_ids: [
          "bphs-97:santhanam:ch09:v2",
          "bphs-97:santhanam:ch44:v10-14",
        ],
      },
    ],
    "maraka-period-assessment.step-02": [
      {
        type: "cancellation",
        description: "吉星照射或合相只取消罗喉在第六、八、十二宫的运期困难，不自动取消前面列出的全部致害分支。",
        evidence_atom_ids: ["bphs-97:santhanam:ch44:v22-24"],
      },
    ],
  };
  return byStep[step.step_id] || [];
}

const stepFactContracts = {
  "varga-assessment.step-01": {
    produced_fact_keys: ["目标分盘"],
    conditional_fact_requirements: [],
  },
  "varga-assessment.step-02": {
    produced_fact_keys: ["目标行星相关分盘状态是否保留"],
    conditional_fact_requirements: [],
  },
  "varga-assessment.step-03": {
    produced_fact_keys: ["目标行星 Vimshopaka 强度", "目标行星分盘细微强弱"],
    conditional_fact_requirements: [],
  },
  "varga-assessment.step-04": {
    produced_fact_keys: ["行星运期结果限制"],
    conditional_fact_requirements: [],
  },
  "planetary-strength-assessment.step-01": {
    produced_fact_keys: ["目标行星擢升力子项"],
    conditional_fact_requirements: [],
  },
  "planetary-strength-assessment.step-02": {
    produced_fact_keys: ["目标行星六类力量项"],
    conditional_fact_requirements: [],
  },
  "planetary-strength-assessment.step-03": {
    produced_fact_keys: ["目标行星六力是否达到自身标准"],
    conditional_fact_requirements: [],
  },
  "planetary-strength-assessment.step-04": {
    produced_fact_keys: ["目标行星相关宫位或运期结果倾向"],
    conditional_fact_requirements: [],
  },
  "bhava-lord-placement-lookup.step-01": {
    produced_fact_keys: ["命中的宫主落宫原文分支"],
    conditional_fact_requirements: [],
  },
  "bhava-lord-placement-lookup.step-02": {
    produced_fact_keys: [
      "相反宫主结果是否抵消",
      "不同性质宫主结果是否分别保留",
      "宫主结果强度比例",
    ],
    conditional_fact_requirements: [],
  },
  "prosperity-poverty-balance.step-01": {
    produced_fact_keys: ["第二宫查阅路线", "第十一宫查阅路线"],
    conditional_fact_requirements: [],
  },
  "prosperity-poverty-balance.step-02": {
    produced_fact_keys: ["财富组合是否成立及兑现窗口"],
    conditional_fact_requirements: [
      {
        when: { fact_key: "是否询问财富兑现时间" },
        required_fact_keys: ["相关运期"],
        stop_condition: "用户询问兑现时间但缺少相关运期时，停止兑现窗口判断。",
      },
    ],
  },
  "prosperity-poverty-balance.step-03": {
    produced_fact_keys: ["贫困与反转分支结果"],
    conditional_fact_requirements: [],
  },
  "prosperity-poverty-balance.step-04": {
    produced_fact_keys: ["财富双重宫主结果处理", "财富结果强度比例"],
    conditional_fact_requirements: [],
  },
  "functional-benefic-yogakaraka-assessment.step-01": {
    produced_fact_keys: ["目标行星功能吉凶分类"],
    conditional_fact_requirements: [],
  },
  "functional-benefic-yogakaraka-assessment.step-02": {
    produced_fact_keys: ["功能瑜伽是否命中"],
    conditional_fact_requirements: [],
  },
  "functional-benefic-yogakaraka-assessment.step-03": {
    produced_fact_keys: ["功能瑜伽受不利宫位限制"],
    conditional_fact_requirements: [
      {
        when: { fact_key: "目标行星是否为凶星" },
        required_fact_keys: [
          "目标行星是否拥有角宫",
          "目标行星是否拥有三合宫",
        ],
        stop_condition:
          "第14偈分支缺少凶星的角宫或三合宫拥有情况时，停止该分支。",
      },
      {
        when: { fact_key: "目标行星是否为角宫主或三合宫主" },
        required_fact_keys: [
          "目标行星是否为角宫主",
          "目标行星是否为三合宫主",
          "目标行星是否同时主管不利宫位",
        ],
        stop_condition:
          "第15偈分支缺少角宫主或三合宫主的不利宫位主管情况时，停止该分支。",
      },
    ],
  },
  "functional-benefic-yogakaraka-assessment.step-04": {
    produced_fact_keys: ["罗喉计都瑜伽主条件核对结果"],
    conditional_fact_requirements: [],
  },
  "rajayoga-political-assessment.step-01": {
    produced_fact_keys: ["两套王者瑜伽参考系核对结果"],
    conditional_fact_requirements: [],
  },
  "rajayoga-political-assessment.step-02": {
    produced_fact_keys: ["大王者瑜伽是否命中"],
    conditional_fact_requirements: [
      {
        when: {
          operator: "NOT",
          operands: [{ fact_key: "上升主与第五宫主交换星座" }],
        },
        required_fact_keys: [
          "Atma Karaka 与 Putra Karaka 是否同在上升宫",
          "Atma Karaka 与 Putra Karaka 是否同在第五宫",
          "Atma Karaka 与 Putra Karaka 是否位于擢升星座",
          "Atma Karaka 与 Putra Karaka 是否位于各自本宫",
          "Atma Karaka 与 Putra Karaka 是否位于各自本 Navamsa",
          "相关行星是否受吉星照射",
        ],
        stop_condition:
          "交换分支未命中而进入 Atma Karaka—Putra Karaka 分支时，缺少任一位置或吉星照射事实就停止该分支。",
      },
    ],
  },
  "rajayoga-political-assessment.step-03": {
    produced_fact_keys: ["官方关联收益是否命中"],
    conditional_fact_requirements: [],
  },
  "rajayoga-political-assessment.step-04": {
    produced_fact_keys: ["王者或部长组合是否命中"],
    conditional_fact_requirements: [],
  },
  "nakshatra-dasha-selection-balance.step-01": {
    produced_fact_keys: [
      "已核验系统为 Vimshottari",
      "已核验系统为 Ashtottari",
    ],
    conditional_fact_requirements: [
      {
        when: { fact_key: "候选运期系统为 Ashtottari" },
        required_fact_keys: [
          "罗喉位于上升宫",
          "罗喉位于上升主的角宫",
          "罗喉位于上升主的三合宫",
        ],
        stop_condition:
          "候选为 Ashtottari 但缺少任一罗喉位置条件时，停止核验该特殊运期系统。",
      },
    ],
  },
  "nakshatra-dasha-selection-balance.step-02": {
    produced_fact_keys: ["出生起始运主"],
    conditional_fact_requirements: [],
  },
  "nakshatra-dasha-selection-balance.step-03": {
    produced_fact_keys: ["出生运期余额"],
    conditional_fact_requirements: [],
  },
  "nested-period-calculation.step-01": {
    produced_fact_keys: ["Antar 运期时长", "Pratyantar 运期时长"],
    conditional_fact_requirements: [],
  },
  "nested-period-calculation.step-02": {
    produced_fact_keys: ["各层运主顺序"],
    conditional_fact_requirements: [],
  },
  "nested-period-calculation.step-03": {
    produced_fact_keys: ["当前 Pratyantar 一般结果及取消状态"],
    conditional_fact_requirements: [],
  },
  "nested-period-calculation.step-04": {
    produced_fact_keys: ["Sukshma 运期时长"],
    conditional_fact_requirements: [],
  },
  "nested-period-calculation.step-05": {
    produced_fact_keys: ["Prana 运期时长"],
    conditional_fact_requirements: [],
  },
  "longevity-calculation.step-01": {
    produced_fact_keys: [
      "选用 Pindayu",
      "选用 Amsayu",
      "选用 Nisargayu",
    ],
    conditional_fact_requirements: [],
  },
  "longevity-calculation.step-02": {
    produced_fact_keys: ["选定寿命算法结果", "等强时平均寿命结果"],
    conditional_fact_requirements: [
      {
        when: { fact_key: "选用 Pindayu" },
        required_fact_keys: ["Pindayu 的专用输入"],
        stop_condition: "选用 Pindayu 但缺少其专用输入时，停止 Pindayu 计算。",
      },
      {
        when: { fact_key: "选用 Amsayu" },
        required_fact_keys: ["Amsayu 的专用输入"],
        stop_condition: "选用 Amsayu 但缺少其专用输入时，停止 Amsayu 计算。",
      },
      {
        when: { fact_key: "选用 Nisargayu" },
        required_fact_keys: ["Nisargayu 完整算法公式"],
        stop_condition: "选用 Nisargayu 但本轮没有完整公式时，硬停并禁止输出寿命数字。",
      },
    ],
  },
  "longevity-calculation.step-03": {
    produced_fact_keys: [
      "上升主第八宫主寿命类别",
      "土星月亮寿命类别",
      "出生上升 Hora Lagna 寿命类别",
      "三组结果是否全不相同",
    ],
    conditional_fact_requirements: [],
  },
  "longevity-calculation.step-04": {
    produced_fact_keys: ["寿命类别交叉核对结果"],
    conditional_fact_requirements: [
      {
        when: { fact_key: "三组结果是否全不相同" },
        required_fact_keys: ["月亮是否在上升或第七宫"],
        stop_condition: "三组结果各不相同但缺少月亮位置时，停止最后的优先规则判断。",
      },
    ],
  },
  "longevity-calculation.step-05": {
    produced_fact_keys: ["修正后的贡献者经度总和", "净寿命"],
    conditional_fact_requirements: [],
  },
  "maraka-period-assessment.step-01": {
    produced_fact_keys: ["年龄边界核对结果"],
    conditional_fact_requirements: [],
  },
  "maraka-period-assessment.step-02": {
    produced_fact_keys: ["节点致害或运期困难分支结果"],
    conditional_fact_requirements: [
      {
        when: { fact_key: "当前问题是否检查节点与致害宫主关系" },
        required_fact_keys: [
          "已确定致害宫主",
          "节点是否位于第一、七、八或十二宫",
          "节点是否位于致害宫主第七位",
          "节点是否与致害宫主同宫",
          "当前大运或小运运主为该节点",
        ],
        stop_condition: "节点致害宫主关系分支缺少任一事实时，停止该分支。",
      },
      {
        when: { fact_key: "当前问题是否检查摩羯或天蝎上升的罗喉分支" },
        required_fact_keys: [
          "出生上升是否为摩羯或天蝎",
          "当前大运或小运运主为该节点",
        ],
        stop_condition: "缺少出生上升是否为摩羯或天蝎时，停止该分支。",
      },
      {
        when: { fact_key: "当前问题是否检查罗喉第六、八、十二宫困难分支" },
        required_fact_keys: [
          "罗喉落宫",
          "吉星照射／合相",
          "当前大运或小运运主为该节点",
        ],
        stop_condition: "困难分支缺少罗喉落宫或吉星保护事实时，停止该分支。",
      },
    ],
  },
};

function factContractForStep(step) {
  const contract = stepFactContracts[step.step_id];
  if (!contract) throw new Error(`缺少步骤事实合同：${step.step_id}`);
  return {
    produced_fact_keys: [...contract.produced_fact_keys],
    conditional_fact_requirements: contract.conditional_fact_requirements.map(
      (item) => ({
        when: item.when,
        required_fact_keys: [...item.required_fact_keys],
        stop_condition: item.stop_condition,
      }),
    ),
  };
}

function hardenMethods(atoms, sourceScan) {
  const sourceRecipes = readJson(
    path.join(sourceRoot, "references/navigation/method-recipes.json"),
  );
  const dispositionById = new Map(
    sourceScan.atom_dispositions.map((record) => [
      record.evidence_atom_id,
      record.disposition,
    ]),
  );
  const byId = new Map(
    sourceRecipes.methods.map((method) => [method.method, method]),
  );

  return selectedMethodIds.map((methodId) => {
    const original = byId.get(methodId);
    if (!original) throw new Error(`缺少现有方法候选：${methodId}`);
    let method = JSON.parse(JSON.stringify(original));

    if (methodId === "bhava-lord-placement-lookup") {
      method = customBhavaMethod(method, atoms);
    } else if (methodId === "maraka-period-assessment") {
      method = customMarakaMethod(method, atoms);
    } else {
      method.steps = method.steps.map((step) => ({
        ...step,
        evidence_refs: dedupeRefs(
          step.evidence_refs.filter(
            (ref) => dispositionById.get(ref.evidence_atom_id) !== "upstream_issue_blocked",
          ),
        ),
      }));
    }

    method = applyFactCorrections(method);
    method = applySemanticRepairs(method, atoms);
    for (const step of method.steps) {
      if (!step.evidence_refs.length) {
        throw new Error(`样品步骤没有可用原文：${step.step_id}`);
      }
      const atomIds = unique(
        step.evidence_refs.map((ref) => ref.evidence_atom_id),
      );
      for (const ref of step.evidence_refs) {
        const atom = atoms.get(ref.evidence_atom_id);
        if (!atom || !atom.exact_text.includes(ref.quote)) {
          throw new Error(`现有逐字短引失配：${step.step_id} → ${ref.evidence_atom_id}`);
        }
        ref.pdf_pages = atom.pdf_pages;
      }
      const scope =
        step.step_id === "nested-period-calculation.step-03"
          ? "只用于 Surya-Surya Pratyantar 原文示例，不外推到其他运期层级。"
          : methodScopes[methodId];
      step.applicability_scope = `${scope} 本步骤只处理：${step.action}`;
      step.minimum_supported_claim =
        step.minimum_supported_claim || claims[step.step_id];
      if (!step.minimum_supported_claim) {
        throw new Error(`缺少最小支持意思：${step.step_id}`);
      }
      const factContract = factContractForStep(step);
      step.produced_fact_keys = factContract.produced_fact_keys;
      step.conditional_fact_requirements =
        factContract.conditional_fact_requirements;
      if (
        step.produced_fact_keys.some((factKey) =>
          step.required_fact_keys.includes(factKey),
        )
      ) {
        throw new Error(`步骤把本步骤产出当成输入：${step.step_id}`);
      }
      step.condition_logic = customCondition(step);
      step.source_status =
        atomIds.length >= 2 ? "repeated_support" : "single_explicit_source";
      step.stop_condition = `以下事实任一没有取得就停止本步骤：${step.required_fact_keys.join("、")}。`;
      step.stop_fact_keys = [...step.required_fact_keys];
      step.exception_relations = exceptionRelations(step);
      step.forbidden_extensions = [
        ...forbiddenByMethod[methodId],
        "不得把本步骤扩大成完整命盘结论。",
        "不得添加冻结原文没有写出的条件、取消关系或结果。",
      ];
    }

    const methodAtomIds = unique(
      method.steps.flatMap((step) =>
        step.evidence_refs.map((ref) => ref.evidence_atom_id),
      ),
    );
    method.pilot_only = false;
    method.publishable = false;
    method.workflow_status = "pilot_candidate";
    method.workflow_history = ["pilot_candidate"];
    method.source_status = [
      "prosperity-poverty-balance",
      "maraka-period-assessment",
    ].includes(methodId)
      ? "synthesized_candidate"
      : methodAtomIds.length >= 2
        ? "repeated_support"
        : "single_explicit_source";
    method.fact_binding_status = "unmapped";
    method.upstream_issue_ids = [];
    method.dependencies = dependencies[methodId];
    const producedFactKeys = new Set(
      method.steps.flatMap((step) => step.produced_fact_keys),
    );
    method.required_facts = unique(
      method.steps.flatMap((step) => step.required_fact_keys),
    ).filter((factKey) => !producedFactKeys.has(factKey));
    method.conditional_facts = unique(
      method.steps.flatMap((step) =>
        step.conditional_fact_requirements.flatMap(
          (group) => group.required_fact_keys,
        ),
      ),
    ).filter((factKey) => !producedFactKeys.has(factKey));
    const conditionalStopConditions = method.steps.flatMap((step) =>
      step.conditional_fact_requirements.map((group) => group.stop_condition),
    );
    method.stop_conditions = unique([
      ...(method.stop_conditions || []).filter(
        (value) =>
          !value.includes("JH8") &&
          !value.includes("第 11 章") &&
          !value.includes("事实名称尚未"),
      ),
      ...forbiddenByMethod[methodId],
      ...conditionalStopConditions,
      "本样品尚未完成排盘事实接入、独立核验和实际问题考试，禁止执行或发布。",
    ]);
    if (methodId === "prosperity-poverty-balance") {
      method.stop_conditions.push(
        "财富支持与贫困因素并存而原文没有给出优先级时，只报告并存并停止最终胜负判断。",
      );
    }
    if (methodId === "maraka-period-assessment") {
      method.stop_conditions.push(
        "当前样品没有完整、可用的主要致害星识别步骤，禁止形成完整致害星排名。",
      );
    }
    method.executable_in_pilot = false;
    return method;
  });
}

function buildExam(methods) {
  const methodById = new Map(methods.map((method) => [method.method, method]));
  const definitions = [
    {
      test_id: "BPHS97-SAMPLE-001",
      title: "七宫主落第十二宫但强弱和双重宫主事实缺失",
      target_method: "bhava-lord-placement-lookup",
      target_steps: [
        "bhava-lord-placement-lookup.step-01",
        "bhava-lord-placement-lookup.step-02",
      ],
      missing: [
        "目标宫主强弱",
        "目标宫主的双重宫主身份",
        "目标宫主两项宫主结果是否相反",
        "目标宫主两项宫主结果是否性质不同",
      ],
      fragments: ["第七宫主落第十二宫", "不得给第七宫主落第十二宫擅加 D9"],
      forbidden_outputs: ["必然离婚", "木星或金星必然救场", "已经完成完整婚姻判断"],
    },
    {
      test_id: "BPHS97-SAMPLE-002",
      title: "婚姻主题只路由到九分盘，不把九分盘冒充结论",
      target_method: "varga-assessment",
      target_steps: ["varga-assessment.step-01"],
      missing: [],
      fragments: ["本步骤只选择目标分盘", "不把目标分盘当成已取得输入"],
      forbidden_outputs: ["D9 单点直接决定婚姻结果", "所有问题都必须看 D9"],
    },
    {
      test_id: "BPHS97-SAMPLE-003",
      title: "六力不得使用统一及格线",
      target_method: "planetary-strength-assessment",
      target_steps: ["planetary-strength-assessment.step-03"],
      missing: ["目标行星自己的六力最低标准"],
      fragments: ["各有自己的六力最低标准", "不能共用一条及格线"],
      forbidden_outputs: ["所有行星超过 100% 都算强", "只按庙旺判断六力"],
    },
    {
      test_id: "BPHS97-SAMPLE-004",
      title: "财富支持、贫困条件和取消条件同时取回",
      target_method: "prosperity-poverty-balance",
      target_steps: [
        "prosperity-poverty-balance.step-02",
        "prosperity-poverty-balance.step-03",
        "prosperity-poverty-balance.step-04",
      ],
      missing: [],
      fragments: ["三组必须分开核对", "不得宣布哪一组一定压倒"],
      forbidden_outputs: ["一生必定巨富", "一生必定贫困", "虚构总评分"],
    },
    {
      test_id: "BPHS97-SAMPLE-005",
      title: "功能吉凶必须按当前上升重新算",
      target_method: "functional-benefic-yogakaraka-assessment",
      target_steps: [
        "functional-benefic-yogakaraka-assessment.step-01",
        "functional-benefic-yogakaraka-assessment.step-03",
      ],
      missing: [],
      fragments: ["已经确定上升星座", "仅拥有角宫不足以转吉"],
      forbidden_outputs: ["把巨蟹上升规则套给狮子上升", "天然凶星必定功能凶"],
    },
    {
      test_id: "BPHS97-SAMPLE-006",
      title: "交换分支命中时不因缺少吉星照射停判",
      target_method: "rajayoga-political-assessment",
      target_steps: ["rajayoga-political-assessment.step-02"],
      missing: [],
      optional_input_facts: {
        "相关行星是否受吉星照射": { fact_state: "unavailable" },
      },
      fragments: [
        "两个并列入口",
        "交换时，不要求吉星照射",
        "不能把第二分支的照射条件强加给交换分支",
      ],
      forbidden_outputs: ["两星有关联所以必成王者", "缺少位置分支事实仍宣布第二分支成立"],
    },
    {
      test_id: "BPHS97-SAMPLE-007",
      title: "出生运期余额缺月亮已行时间时停止",
      target_method: "nakshatra-dasha-selection-balance",
      target_steps: ["nakshatra-dasha-selection-balance.step-03"],
      missing: ["月亮在出生星宿已行时间"],
      fragments: ["出生运期余额", "不能只凭出生星宿猜余额"],
      forbidden_outputs: ["凭星宿名称猜起运余额", "忽略星宿总停留时间"],
    },
    {
      test_id: "BPHS97-SAMPLE-008",
      title: "微运和最细运缺上一级时长时停止",
      target_method: "nested-period-calculation",
      target_steps: [
        "nested-period-calculation.step-04",
        "nested-period-calculation.step-05",
      ],
      missing: ["Pratyantar 运期时长", "Sukshma 运期时长"],
      fragments: ["不能跳过上一级"],
      forbidden_outputs: ["跳过细运直接算最细运", "把阶段性结果写成终身结果"],
    },
    {
      test_id: "BPHS97-SAMPLE-009",
      title: "寿命算法未比较三者强弱时停止",
      target_method: "longevity-calculation",
      target_steps: [
        "longevity-calculation.step-01",
        "longevity-calculation.step-02",
      ],
      missing: ["上升太阳月亮三者强弱"],
      fragments: ["三个算法选择", "不能把选择结果当成输入", "等强"],
      forbidden_outputs: ["直接输出寿命数字", "擅自选择一种寿命算法"],
    },
    {
      test_id: "BPHS97-SAMPLE-010",
      title: "年龄边界冲突与主要致害星缺失时停止",
      target_method: "maraka-period-assessment",
      target_steps: [
        "maraka-period-assessment.step-01",
        "maraka-period-assessment.step-02",
      ],
      missing: ["当前问题是否检查节点与致害宫主关系"],
      fragments: ["24 岁", "20 岁", "不擅自把两者改成同一个数字", "吉星"],
      forbidden_outputs: ["断言具体死亡时间", "把普通凶星直接叫致害星", "忽略吉星保护"],
    },
  ];

  const cases = definitions.map((definition) => {
    const method = methodById.get(definition.target_method);
    const stepById = new Map(method.steps.map((step) => [step.step_id, step]));
    const steps = definition.target_steps.map((stepId) => {
      const step = stepById.get(stepId);
      if (!step) throw new Error(`考题引用不存在的步骤：${stepId}`);
      return step;
    });
    const requiredFactKeys = unique(
      steps.flatMap((step) => step.required_fact_keys),
    );
    const inputFacts = Object.fromEntries(
      requiredFactKeys.map((factKey) => [
        factKey,
        definition.missing.includes(factKey)
          ? { fact_state: "unavailable" }
          : { fact_state: "known", value: true },
      ]),
    );
    Object.assign(inputFacts, definition.optional_input_facts || {});
    return {
      test_id: definition.test_id,
      title: definition.title,
      target_method: definition.target_method,
      target_steps: definition.target_steps,
      input_facts: inputFacts,
      expected_missing_fact_keys: definition.missing,
      expected_evidence_atom_ids: unique(
        steps.flatMap((step) =>
          step.evidence_refs.map((ref) => ref.evidence_atom_id),
        ),
      ),
      expected_text_fragments: definition.fragments,
      expected_judgment_allowed: false,
      forbidden_outputs: definition.forbidden_outputs,
    };
  });

  return {
    schema_version: "method-sample-exam/v1",
    book_id: "bphs-97",
    edition_id: "santhanam",
    publishable: false,
    execution_allowed: false,
    exam_status: "candidate_only",
    cases,
  };
}

function main() {
  if (fs.existsSync(targetRoot)) {
    throw new Error(`目标已存在，拒绝覆盖：${targetRoot}`);
  }

  const acceptedPackage = readJson(acceptedPackagePath);
  if (
    acceptedPackage.schema_version !== "accepted-package/v1" ||
    acceptedPackage.artifact_scope !== "FORMAL" ||
    acceptedPackage.distillation_allowed !== true
  ) {
    throw new Error("正式书包凭证不允许蒸馏");
  }

  const evidenceAtomsPath = acceptedPackage.evidence_atoms?.path;
  if (!evidenceAtomsPath || !fs.existsSync(evidenceAtomsPath)) {
    throw new Error("正式书包没有可读取的 evidence_atoms.jsonl 路径");
  }

  const atoms = new Map(
    fs
      .readFileSync(evidenceAtomsPath, "utf8")
      .trim()
      .split(/\r?\n/)
      .map(JSON.parse)
      .map((atom) => [atom.evidence_atom_id, atom]),
  );
  const sourceScan = readJson(
    path.join(sourceRoot, "validation/method-source-scan.json"),
  );
  const methods = hardenMethods(atoms, sourceScan);
  const usedBy = new Map();
  for (const method of methods) {
    for (const step of method.steps) {
      for (const ref of step.evidence_refs) {
        if (!usedBy.has(ref.evidence_atom_id)) usedBy.set(ref.evidence_atom_id, []);
        usedBy.get(ref.evidence_atom_id).push(method.method);
      }
    }
  }
  for (const [atomId, methodIds] of usedBy) {
    usedBy.set(atomId, unique(methodIds));
  }
  const atomScope = [...usedBy.keys()].sort((left, right) => {
    const a = atoms.get(left);
    const b = atoms.get(right);
    return (
      a.chapter_number - b.chapter_number ||
      a.chapter_position - b.chapter_position
    );
  });

  const sourceRecords = new Map(
    sourceScan.atom_dispositions.map((record) => [record.evidence_atom_id, record]),
  );
  const sampleScan = atomScope.map((atomId) => {
    const sourceRecord = sourceRecords.get(atomId);
    if (!sourceRecord) throw new Error(`总账缺少样品原文：${atomId}`);
    return {
      ...sourceRecord,
      disposition: "method_step",
      method_ids: usedBy.get(atomId),
    };
  });

  const chapters = new Map();
  for (const atomId of atomScope) {
    const atom = atoms.get(atomId);
    if (!chapters.has(atom.chapter_number)) {
      chapters.set(atom.chapter_number, {
        chapter_number: atom.chapter_number,
        chapter_title: atom.chapter_title,
        evidence_atom_ids: [],
      });
    }
    chapters.get(atom.chapter_number).evidence_atom_ids.push(atomId);
  }

  const methodById = new Map(methods.map((method) => [method.method, method]));
  const topicMap = Object.fromEntries(
    Object.entries(topicGroups).map(([title, methodIds]) => [
      title,
      {
        title,
        evidence_atom_ids: unique(
          methodIds.flatMap((methodId) =>
            methodById
              .get(methodId)
              .steps.flatMap((step) =>
                step.evidence_refs.map((ref) => ref.evidence_atom_id),
              ),
          ),
        ),
      },
    ]),
  );

  const queryTopics = Object.fromEntries(
    Object.entries(topicGroups).map(([title, methodIds]) => {
      const groupedMethods = methodIds.map((methodId) => methodById.get(methodId));
      const lanes = [
        "support_queries",
        "counter_queries",
        "boundary_queries",
        "method_queries",
      ];
      return [
        title,
        {
          title,
          user_intents: unique(
            groupedMethods.flatMap((method) => method.user_intents),
          ),
          method_ids: [],
          candidate_method_ids: methodIds,
          required_facts: unique(
            groupedMethods.flatMap((method) => method.required_facts),
          ),
          conditional_facts: unique(
            groupedMethods.flatMap((method) => method.conditional_facts),
          ),
          fact_binding_status: "unmapped",
          ...Object.fromEntries(
            lanes.map((lane) => [
              lane,
              unique(
                groupedMethods.flatMap(
                  (method) => method.retrieval_plan[lane],
                ),
              ),
            ]),
          ),
          stop_conditions: unique(
            groupedMethods.flatMap((method) => method.stop_conditions),
          ),
          execution_allowed: false,
        },
      ];
    }),
  );

  fs.mkdirSync(targetRoot, { recursive: true });
  writeJson(path.join(targetRoot, "WORK_ORDER.json"), {
    job_name: "BPHS 97 十个高风险方法样品",
    operation: "formal_method_sample_distillation",
    pilot_only: false,
    publishable: false,
    artifact_scope: "FORMAL",
    accepted_package: acceptedPackagePath,
    mechanical_gate_status: "pending",
    allowed_use: "formal_candidate_sample_generation_only",
    book: {
      title: "Brihat Parashara Hora Shastra",
      author: "Maharshi Parashara",
      edition: "R. Santhanam 97-chapter retyped edition",
    },
    input: {
      accepted_package_path: acceptedPackagePath,
      chapter_scope: [],
      evidence_atom_scope: atomScope,
    },
    target_dir: targetRoot.replaceAll("\\", "/"),
    scope: {
      knowledge_map: true,
      method_distillation: true,
      judgment_navigation: true,
      modify_evidence_atoms: false,
      read_pdf_or_book_text: false,
      modify_rag: false,
      modify_chart_engine: false,
      combine_multiple_books: false,
    },
    acceptance: {
      require_step_evidence: true,
      require_four_lane_queries: true,
      require_scope_isolation: true,
      require_source_snapshot_match: true,
      require_no_retired_fields: true,
      require_content_role_boundary: true,
      require_positive_negative_blank_controls: true,
      require_independent_verification_before_release: true,
    },
  });
  writeJson(path.join(targetRoot, "DISTILLATION_SOURCE.json"), {
    distillation_run_id: "bphs-97-santhanam-formal-10-method-samples-20260817",
    artifact_scope: "FORMAL",
    pilot_only: false,
    publishable: false,
    book_id: acceptedPackage.book.book_id,
    edition_id: acceptedPackage.book.edition_id,
    source_artifact_id: acceptedPackage.book.source_artifact_id,
    accepted_package_id: acceptedPackage.package_id,
    accepted_package_path: acceptedPackagePath,
    evidence_contract_version: acceptedPackage.evidence_atoms.contract_version,
    evidence_atoms_path: evidenceAtomsPath,
    evidence_atoms_sha256: acceptedPackage.evidence_atoms.content_sha256,
    chapter_scope: [],
    created_at: "2026-08-17",
  });
  writeJson(path.join(targetRoot, "UPSTREAM_ISSUES.json"), {
    pilot_only: false,
    publishable: false,
    issues: [],
  });
  writeJson(path.join(targetRoot, "references/knowledge/chapter-map.json"), {
    pilot_only: false,
    publishable: false,
    chapters: [...chapters.values()],
  });
  writeJson(path.join(targetRoot, "references/knowledge/topic-map.json"), {
    pilot_only: false,
    publishable: false,
    topics: topicMap,
  });
  writeJson(path.join(targetRoot, "references/knowledge/glossary.json"), {
    pilot_only: false,
    publishable: false,
    terms: Object.entries(topicMap).map(([term, entry]) => ({
      term,
      explanation: "仅用于定位本轮十个方法样品，不是古籍证据。",
      evidence_atom_ids: entry.evidence_atom_ids,
    })),
  });
  writeJson(
    path.join(targetRoot, "references/navigation/method-recipes.json"),
    { pilot_only: false, publishable: false, methods },
  );
  writeJson(
    path.join(targetRoot, "references/navigation/query-recipes.json"),
    { pilot_only: false, publishable: false, topics: queryTopics },
  );
  writeJson(path.join(targetRoot, "validation/method-source-scan.json"), {
    schema_version: "method-source-scan/v1",
    distillation_run_id: "bphs-97-santhanam-formal-10-method-samples-20260817",
    accepted_package_id: acceptedPackage.package_id,
    pilot_only: false,
    publishable: false,
    review_status: "complete",
    atom_dispositions: sampleScan,
  });
  writeJson(
    path.join(targetRoot, "validation/offline-exam.json"),
    buildExam(methods),
  );
  writeJson(
    path.join(targetRoot, "validation/semantic-repair-log.json"),
    {
      schema_version: "semantic-repair-log/v1",
      independent_review_required: true,
      items: [
        ...semanticRepairLog,
        ...semanticRepairLogRound2,
        ...semanticRepairLogRound3,
      ],
    },
  );

  writeText(
    path.join(targetRoot, "SKILL.md"),
    `---\nname: bphs-97-book\ndescription: "BPHS 97 Santhanam 版十个高风险方法样品。只用于核对冻结原文、步骤条件、缺失事实停判和离线试卷；当前不可执行、不可发布。"\n---\n\n# BPHS 97 十个方法样品\n\n本目录只读取正式书包锁定的原文原子。十个方法全部是候选；机械检查只能证明文件结构和逐字证据对得上，不能替代独立语义检查或用户批准。\n`,
  );
  writeText(
    path.join(targetRoot, "PIPELINE_STATE.md"),
    `# 当前进度\n\n- 已完成：从全书分类结果中选出十个高风险方法样品，并按前三轮独立审查异议从唯一生成脚本重生。\n- 当前状态：10 个方法、37 个步骤，全部不可执行、不可发布；仍等待独立窗口逐步复审。\n- 当前输入：正式书包锁定的 ${atomScope.length} 条原文原子，只读。\n- 机器检查：待独立命令运行；以 validation 目录中的真实运行记录和退出码为准，本文件不预印成绩。\n- 下一步：运行正式验证器、交付三对照和离线考题三对照，再把本目录交给 Herschel 全量复查 37 个步骤。\n- 禁止：修改原文原子、读取 PDF 或整本正文补内容、由生产窗口签独立检查通过。\n`,
  );
  writeText(
    path.join(targetRoot, "validation/交给独立检查窗口.md"),
    `# BPHS 97 十个方法样品独立复审交接\n\n## 当前结论\n\n本目录是从唯一生成脚本重生的修正版样品，不是语义通过证明。机器记录尚待运行，必须以 validation 目录中的真实运行记录和退出码为准。\n\n## 检查范围\n\n- 正式书包：${acceptedPackagePath}\n- 只读原文：${atomScope.length} 条 evidence_atom_id\n- 方法：10 个\n- 步骤：37 个\n- 可执行方法：0 个\n- 允许发布：否\n- 三轮修复清单：validation/semantic-repair-log.json\n\n## 机器记录状态\n\n正式验证器、交付三对照和离线考题三对照尚待运行；不得以本文件文字代替真实 receipt。\n\n## 独立窗口只检查这些\n\n1. 每一步的逐字短引是否只支持 minimum_supported_claim 的最小意思。\n2. condition_logic 的 AND、OR、NOT 是否保留原书分支。\n3. 取消、缓解、限制是否只作用于原文写明的结果。\n4. stop_fact_keys 是否只列运行前必须取得的事实，不能把本步骤计算结果伪装成输入。\n5. 是否仍有未列出的扩大、漏分支或跨主题脑补。\n\n独立窗口只能提交异议、证据、影响范围和未检查范围；不得修改本目录、判卷规则或宣布发布。\n`,
  );
  for (const file of [
    "UPSTREAM_ISSUES.md",
    "references/navigation/method-map.md",
    "references/navigation/version-routing.md",
    "methods/verified.md",
  ]) {
    writeText(path.join(targetRoot, file), "待由正式验证器重新生成。\n");
  }
  writeJson(path.join(targetRoot, "references/navigation/required-checks.json"), {
    pilot_only: false,
    publishable: false,
    topics: {},
  });

  process.stdout.write(
    `${JSON.stringify(
      {
        target: targetRoot,
        methods: methods.length,
        scoped_atoms: atomScope.length,
        exam_cases: buildExam(methods).cases.length,
      },
      null,
      2,
    )}\n`,
  );
}

main();
