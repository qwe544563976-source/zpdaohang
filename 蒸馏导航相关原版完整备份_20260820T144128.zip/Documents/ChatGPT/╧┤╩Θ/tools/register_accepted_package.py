#!/usr/bin/env python3
"""登记已验收正式书包，并同步主窗口的写权限。

本工具只登记明确身份的正式凭证；不会猜书、扫描 F 盘或改任何书包产物。
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import tempfile
from datetime import date
from pathlib import Path
from typing import Any, Callable


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_STATUS_FILE = ROOT / "JUDGMENT_PIPELINE_STATUS.json"
DEFAULT_OWNERSHIP_FILE = ROOT / "JUDGMENT_WRITE_OWNERSHIP.json"
AUTHORITATIVE_VALIDATOR = Path(
    r"F:/切卡实验/aclass-chunker/validation/validate_accepted_package.py"
)


class RegistrationError(ValueError):
    pass


def read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise RegistrationError(f"读取 JSON 失败: {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise RegistrationError(f"JSON 顶层必须是对象: {path}")
    return value


def write_json_atomic(path: Path, value: dict[str, Any]) -> None:
    """同目录临时文件后原子替换；不建立跨文件事务。"""
    path = path.resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_name: str | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=path.parent,
            prefix=f".{path.name}.",
            suffix=".tmp",
            delete=False,
        ) as handle:
            temp_name = handle.name
            json.dump(value, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, path)
        temp_name = None
    finally:
        if temp_name:
            try:
                Path(temp_name).unlink()
            except FileNotFoundError:
                pass


def run_authoritative_validation(package_path: Path) -> dict[str, Any]:
    """调用现有权威验包器；测试可注入替身，但 CLI 没有跳过开关。"""
    if not AUTHORITATIVE_VALIDATOR.is_file():
        raise RegistrationError(f"权威验包器不存在: {AUTHORITATIVE_VALIDATOR}")
    with tempfile.TemporaryDirectory(
        dir=package_path.parent,
        prefix=".accepted-package-validation-",
    ) as temp_dir:
        # 只提供尚不存在的输出路径；权威验包器会拒绝覆盖已有结果。
        output_path = Path(temp_dir) / "result.json"
        result = subprocess.run(
            [
                sys.executable,
                str(AUTHORITATIVE_VALIDATOR),
                "--package",
                str(package_path),
                "--output",
                str(output_path),
            ],
            check=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
        )
        report: dict[str, Any] | None = None
        if output_path.is_file() and output_path.stat().st_size:
            try:
                report = read_json(output_path)
            except RegistrationError:
                report = None
        if report is None:
            try:
                parsed = json.loads(result.stdout)
                report = parsed if isinstance(parsed, dict) else None
            except json.JSONDecodeError:
                report = None
        if result.returncode != 0 or not report or report.get("status") != "pass":
            detail = report.get("errors") if report else result.stderr.strip() or result.stdout.strip()
            raise RegistrationError(f"权威验包失败: {detail}")
        return report


def _jsonl_record_count(path: Path) -> int:
    if not path.is_file():
        raise RegistrationError(f"evidence_atoms 文件不存在: {path}")
    count = 0
    try:
        for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            if not line.strip():
                continue
            value = json.loads(line)
            if not isinstance(value, dict):
                raise RegistrationError(f"evidence_atoms 第 {line_number} 行不是对象")
            count += 1
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise RegistrationError(f"读取 evidence_atoms 失败: {path}: {exc}") from exc
    return count


def package_metadata(package_path: Path) -> dict[str, Any]:
    package = read_json(package_path)
    if package.get("schema_version") != "accepted-package/v1":
        raise RegistrationError("正式凭证 schema_version 不符")
    book = package.get("book")
    evidence = package.get("evidence_atoms")
    if not isinstance(book, dict) or not isinstance(evidence, dict):
        raise RegistrationError("正式凭证缺少 book 或 evidence_atoms")
    book_id = book.get("book_id")
    edition_id = book.get("edition_id")
    package_id = package.get("package_id")
    if not all(isinstance(item, str) and item.strip() for item in (book_id, edition_id, package_id)):
        raise RegistrationError("正式凭证缺少 book_id、edition_id 或 package_id")
    expected_package_id = f"{book_id}:{edition_id}:evidence-book-v1"
    if package_id != expected_package_id:
        raise RegistrationError("package_id 与 book_id/edition_id 不一致")
    atoms_path_value = evidence.get("path")
    record_count = evidence.get("record_count")
    atom_count = package.get("atom_count")
    if not isinstance(atoms_path_value, str) or not atoms_path_value.strip():
        raise RegistrationError("evidence_atoms.path 缺失")
    if not isinstance(record_count, int) or record_count < 0:
        raise RegistrationError("evidence_atoms.record_count 缺失或无效")
    if not isinstance(atom_count, int) or atom_count < 0 or atom_count != record_count:
        raise RegistrationError("atom_count 与 evidence_atoms.record_count 不一致")
    atoms_path = Path(atoms_path_value).resolve()
    actual_count = _jsonl_record_count(atoms_path)
    if actual_count != record_count:
        raise RegistrationError(
            f"evidence_atoms 数量不一致: 凭证={record_count}, 实际={actual_count}"
        )
    return {
        "book_id": book_id,
        "edition_id": edition_id,
        "package_id": package_id,
        "package_path": str(package_path.resolve()),
        "atom_count": record_count,
    }


def _formal_rows(status: dict[str, Any]) -> list[dict[str, Any]]:
    rows = status.get("first_formal_books")
    if not isinstance(rows, list) or not rows:
        raise RegistrationError("总账 first_formal_books 必须是非空数组")
    result: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for row in rows:
        if not isinstance(row, dict):
            raise RegistrationError("first_formal_books 含非对象条目")
        book_id = row.get("book_id")
        edition_id = row.get("edition_id")
        if not all(isinstance(item, str) and item.strip() for item in (book_id, edition_id)):
            raise RegistrationError("正式书条目缺少显式 book_id 或 edition_id")
        key = (book_id, edition_id)
        if key in seen:
            raise RegistrationError(f"正式书身份重复: {book_id}/{edition_id}")
        seen.add(key)
        result.append(row)
    return result


def _is_formal_blocker(value: object) -> bool:
    text = str(value)
    return "正式" in text and ("书包" in text or "accepted-package" in text)


def _is_paused(row: dict[str, Any]) -> bool:
    return row.get("accepted_package_status") in {"blocked", "暂停"} and row.get("formal_use_allowed") is False


def _expected_formal_blockers(
    rows: list[dict[str, Any]], registered: list[dict[str, Any]]
) -> list[str]:
    blockers: list[str] = []
    for row in rows:
        if row in registered:
            continue
        label = f"{row['book_id']}/{row['edition_id']}"
        if _is_paused(row):
            blockers.append(f"正式书包已暂停: {label}")
        else:
            blockers.append(f"正式书包未登记: {label}")
    return blockers


def _recompute_status(status: dict[str, Any]) -> None:
    rows = _formal_rows(status)
    registered = [
        row
        for row in rows
        if row.get("accepted_package_status") == "已登记"
        and row.get("formal_use_allowed") is True
        and isinstance(row.get("accepted_package_path"), str)
    ]
    any_registered = bool(registered)
    all_registered = len(registered) == len(rows)
    status["formal_content_production_allowed"] = any_registered
    if any_registered:
        status["current_phase"] = "FORMAL_PACKAGES_REGISTERED"
        status["current_phase_cn"] = "正式书包已登记，可开始逐书蒸馏"
    else:
        status["current_phase"] = "WAITING_FORMAL_ACCEPTED_PACKAGE"
        status["current_phase_cn"] = "等待正式已验收书包"
    blockers = status.get("blocked_by")
    if not isinstance(blockers, list):
        blockers = []
    blockers = [item for item in blockers if not _is_formal_blocker(item)]
    blockers.extend(_expected_formal_blockers(rows, registered))
    status["blocked_by"] = blockers
    status["only_next_action"] = _expected_next_action(rows, registered)


def _expected_next_action(
    rows: list[dict[str, Any]], registered: list[dict[str, Any]]
) -> str:
    paused = [row for row in rows if row not in registered and _is_paused(row)]
    pending = [row for row in rows if row not in registered and not _is_paused(row)]
    if not registered:
        paused_ids = ", ".join(f"{row['book_id']}/{row['edition_id']}" for row in paused)
        if paused_ids:
            return (
                f"等待未暂停的正式书包登记；已暂停正式使用: {paused_ids}；"
                "JH8、RAG、共同查询仍受现有 blocker 限制"
            )
        return (
            "等待正式书包登记；登记后只开放逐书蒸馏，"
            "JH8、RAG、共同查询仍受现有 blocker 限制"
        )
    if pending:
        pending_ids = ", ".join(f"{row['book_id']}/{row['edition_id']}" for row in pending)
        paused_suffix = (
            "；已暂停正式使用: "
            + ", ".join(f"{row['book_id']}/{row['edition_id']}" for row in paused)
            if paused
            else ""
        )
        return (
            f"已登记书籍可以开始逐书蒸馏；等待其余正式书包登记: {pending_ids}"
            f"{paused_suffix}；"
            "JH8、RAG、共同查询仍受现有 blocker 限制"
        )
    if paused:
        paused_ids = ", ".join(f"{row['book_id']}/{row['edition_id']}" for row in paused)
        return (
            f"已登记书籍可以开始逐书蒸馏；已暂停正式使用: {paused_ids}；"
            "JH8、RAG、共同查询仍受现有 blocker 限制"
        )
    return "正式书包均已登记；继续逐书蒸馏，JH8、RAG、共同查询仍受现有 blocker 限制"


def _unfreeze_distillation(ownership: dict[str, Any]) -> None:
    scopes = ownership.get("scopes")
    if not isinstance(scopes, list):
        raise RegistrationError("权限表 scopes 必须是数组")
    found = False
    for scope in scopes:
        if not isinstance(scope, dict):
            raise RegistrationError("权限表 scopes 含非对象条目")
        if scope.get("owner") != "蒸馏窗口":
            continue
        found = True
        scope["write_allowed_now"] = True
        scope["current_state"] = "FORMAL_INPUT_AVAILABLE"
    if not found:
        raise RegistrationError("权限表没有蒸馏窗口范围")


def register_package(
    package_path: Path,
    status_path: Path = DEFAULT_STATUS_FILE,
    ownership_path: Path = DEFAULT_OWNERSHIP_FILE,
    *,
    validator: Callable[[Path], dict[str, Any]] | None = None,
) -> dict[str, Any]:
    try:
        package_path = Path(package_path).resolve()
        status_path = Path(status_path).resolve()
        ownership_path = Path(ownership_path).resolve()
        if not package_path.is_file():
            raise RegistrationError(f"正式凭证不存在: {package_path}")
        if validator is None:
            validator = run_authoritative_validation
        report = validator(package_path)
        if not isinstance(report, dict) or report.get("status") != "pass":
            raise RegistrationError("权威验包没有返回 pass")
        metadata = package_metadata(package_path)
        status = read_json(status_path)
        rows = _formal_rows(status)
        matches = [
            row
            for row in rows
            if row.get("book_id") == metadata["book_id"]
            and row.get("edition_id") == metadata["edition_id"]
        ]
        if not matches:
            raise RegistrationError(
                f"总账没有匹配的正式书: {metadata['book_id']}/{metadata['edition_id']}"
            )
        if len(matches) != 1:
            raise RegistrationError("总账匹配到多个正式书条目")
        target = matches[0]
        target.update(
            {
                "accepted_package_path": metadata["package_path"],
                "package_id": metadata["package_id"],
                "atom_count": metadata["atom_count"],
                "accepted_package_status": "已登记",
                "formal_use_allowed": True,
            }
        )
        for key in ("blocker_reason", "blocker_evidence", "blocker_recorded_on"):
            target.pop(key, None)
        _recompute_status(status)
        ownership = read_json(ownership_path)
        _unfreeze_distillation(ownership)
        today = date.today().isoformat()
        status["updated_on"] = today
        ownership["updated_on"] = today
        write_json_atomic(status_path, status)
        write_json_atomic(ownership_path, ownership)
        return {
            "ok": True,
            "book_id": metadata["book_id"],
            "edition_id": metadata["edition_id"],
            "package_id": metadata["package_id"],
            "atom_count": metadata["atom_count"],
        }
    except (RegistrationError, OSError, TypeError) as exc:
        return {"ok": False, "error": str(exc)}


def pause_book(
    book_id: str,
    evidence_report: Path,
    reason: str,
    status_path: Path = DEFAULT_STATUS_FILE,
) -> dict[str, Any]:
    try:
        book_id = str(book_id or "").strip()
        reason = str(reason or "").strip()
        if not book_id:
            raise RegistrationError("book_id 不能为空")
        if not reason:
            raise RegistrationError("暂停原因不能为空")
        evidence_path = Path(evidence_report).resolve()
        if not evidence_path.is_file():
            raise RegistrationError(f"暂停证据报告不存在: {evidence_path}")
        status_path = Path(status_path).resolve()
        status = read_json(status_path)
        rows = _formal_rows(status)
        matches = [row for row in rows if row.get("book_id") == book_id]
        if not matches:
            raise RegistrationError(f"总账没有匹配的正式书: {book_id}")
        if len(matches) != 1:
            raise RegistrationError(f"总账匹配到多个正式书条目: {book_id}")
        target = matches[0]
        target.update(
            {
                "accepted_package_status": "blocked",
                "formal_use_allowed": False,
                "blocker_reason": reason,
                "blocker_evidence": str(evidence_path),
                "blocker_recorded_on": date.today().isoformat(),
            }
        )
        _recompute_status(status)
        status["updated_on"] = date.today().isoformat()
        write_json_atomic(status_path, status)
        return {
            "ok": True,
            "book_id": book_id,
            "accepted_package_status": "blocked",
            "formal_use_allowed": False,
            "blocker_evidence": str(evidence_path),
        }
    except (RegistrationError, OSError, TypeError) as exc:
        return {"ok": False, "error": str(exc)}


def _check_registered_row(
    row: dict[str, Any],
    validator: Callable[[Path], dict[str, Any]],
) -> list[str]:
    errors: list[str] = []
    status = row.get("accepted_package_status")
    if _is_paused(row):
        evidence = row.get("blocker_evidence")
        reason = row.get("blocker_reason")
        recorded_on = row.get("blocker_recorded_on")
        if not isinstance(evidence, str) or not evidence.strip():
            errors.append(f"暂停条目缺 blocker_evidence: {row.get('book_id')}/{row.get('edition_id')}")
        elif not Path(evidence).resolve().is_file():
            errors.append(f"暂停证据报告不存在: {evidence}")
        if not isinstance(reason, str) or not reason.strip():
            errors.append(f"暂停条目缺 blocker_reason: {row.get('book_id')}/{row.get('edition_id')}")
        if not isinstance(recorded_on, str) or not recorded_on.strip():
            errors.append(f"暂停条目缺 blocker_recorded_on: {row.get('book_id')}/{row.get('edition_id')}")
        return errors
    registered_fields = (
        row.get("accepted_package_path"),
        row.get("package_id"),
        row.get("atom_count"),
    )
    is_registered = status == "已登记" or row.get("formal_use_allowed") is True
    if not is_registered:
        if any(value not in (None, "") for value in registered_fields):
            errors.append(f"未登记条目残留正式凭证字段: {row.get('book_id')}/{row.get('edition_id')}")
        return errors
    if status != "已登记" or row.get("formal_use_allowed") is not True:
        errors.append(f"登记状态与 formal_use_allowed 不一致: {row.get('book_id')}/{row.get('edition_id')}")
    if not isinstance(row.get("accepted_package_path"), str) or not row["accepted_package_path"].strip():
        errors.append(f"已登记条目缺 accepted_package_path: {row.get('book_id')}/{row.get('edition_id')}")
        return errors
    try:
        package_path = Path(row["accepted_package_path"]).resolve()
        report = validator(package_path)
        if not isinstance(report, dict) or report.get("status") != "pass":
            errors.append(f"权威验包失败: {row.get('book_id')}/{row.get('edition_id')}")
            return errors
        metadata = package_metadata(package_path)
    except (RegistrationError, OSError, TypeError) as exc:
        errors.append(str(exc))
        return errors
    if metadata["book_id"] != row.get("book_id") or metadata["edition_id"] != row.get("edition_id"):
        errors.append(f"凭证身份与总账不一致: {row.get('book_id')}/{row.get('edition_id')}")
    if metadata["package_id"] != row.get("package_id"):
        errors.append(f"package_id 与凭证不一致: {row.get('book_id')}/{row.get('edition_id')}")
    if metadata["atom_count"] != row.get("atom_count"):
        errors.append(f"atom_count 与凭证不一致: {row.get('book_id')}/{row.get('edition_id')}")
    return errors


def check_state(
    status_path: Path = DEFAULT_STATUS_FILE,
    ownership_path: Path = DEFAULT_OWNERSHIP_FILE,
    *,
    validator: Callable[[Path], dict[str, Any]] | None = None,
) -> dict[str, Any]:
    try:
        status_path = Path(status_path).resolve()
        ownership_path = Path(ownership_path).resolve()
        status = read_json(status_path)
        rows = _formal_rows(status)
        if validator is None:
            validator = run_authoritative_validation
        errors = [error for row in rows for error in _check_registered_row(row, validator)]
        registered = [row for row in rows if row.get("accepted_package_status") == "已登记" and row.get("formal_use_allowed") is True]
        if not registered:
            errors.append("总账尚未登记任何正式书包")
        expected_allowed = bool(registered)
        if status.get("formal_content_production_allowed") is not expected_allowed:
            errors.append("formal_content_production_allowed 与登记状态不一致")
        expected_phase = "FORMAL_PACKAGES_REGISTERED" if expected_allowed else "WAITING_FORMAL_ACCEPTED_PACKAGE"
        if status.get("current_phase") != expected_phase:
            errors.append("current_phase 与登记状态不一致")
        expected_blockers = _expected_formal_blockers(rows, registered)
        actual_blockers = [item for item in status.get("blocked_by", []) if _is_formal_blocker(item)]
        if actual_blockers != expected_blockers:
            errors.append("正式书包 blocker 与未登记书清单不一致")
        if status.get("only_next_action") != _expected_next_action(rows, registered):
            errors.append("only_next_action 与登记状态不一致")
        ownership = read_json(ownership_path)
        scopes = ownership.get("scopes")
        if not isinstance(scopes, list):
            errors.append("权限表 scopes 必须是数组")
        else:
            distillation = [scope for scope in scopes if isinstance(scope, dict) and scope.get("owner") == "蒸馏窗口"]
            if not distillation:
                errors.append("权限表没有蒸馏窗口范围")
            elif registered:
                for scope in distillation:
                    if scope.get("write_allowed_now") is not True:
                        errors.append(f"蒸馏窗口仍被冻结: {scope.get('resource_scope')}")
                    if scope.get("current_state") != "FORMAL_INPUT_AVAILABLE":
                        errors.append(f"蒸馏窗口状态未更新: {scope.get('resource_scope')}")
        return {"ok": not errors, "errors": errors}
    except (RegistrationError, OSError, TypeError) as exc:
        return {"ok": False, "errors": [str(exc)]}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="登记或检查正式 accepted-package.json")
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--package", type=Path, help="正式 accepted-package.json")
    mode.add_argument("--check", action="store_true", help="只读检查总账与权限表")
    mode.add_argument("--pause-book", metavar="BOOK_ID", help="暂停一本书的正式使用")
    parser.add_argument("--evidence-report", type=Path, help="暂停依据报告")
    parser.add_argument("--reason", help="暂停原因")
    parser.add_argument("--status-file", type=Path, default=DEFAULT_STATUS_FILE)
    parser.add_argument("--ownership-file", type=Path, default=DEFAULT_OWNERSHIP_FILE)
    args = parser.parse_args(argv)
    if args.check:
        result = check_state(args.status_file, args.ownership_file)
    elif args.pause_book is not None:
        result = pause_book(
            args.pause_book,
            args.evidence_report,
            args.reason,
            args.status_file,
        )
    else:
        result = register_package(args.package, args.status_file, args.ownership_file)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
