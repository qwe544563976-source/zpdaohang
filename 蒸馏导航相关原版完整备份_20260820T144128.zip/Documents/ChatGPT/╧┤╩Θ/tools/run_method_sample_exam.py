#!/usr/bin/env python3
"""Run deterministic checks for a method-sample offline exam."""

from __future__ import annotations

import json
import importlib.util
import sys
from pathlib import Path


ALLOWED_FACT_STATES = {"known", "not_applicable"}
EXECUTABLE_WORKFLOW_STATES = {
    "independent_verified",
    "shadow_passed",
    "pilot_passed",
}
ADAPTER_SCRIPT = (
    Path.home()
    / ".codex"
    / "skills"
    / "book-to-judgment-navigation"
    / "scripts"
    / "adapt_jh8_facts.py"
)
ADAPTER_SPEC = importlib.util.spec_from_file_location("jh8_fact_adapter", ADAPTER_SCRIPT)
if ADAPTER_SPEC is None or ADAPTER_SPEC.loader is None:
    raise RuntimeError(f"无法加载事实适配器：{ADAPTER_SCRIPT}")
ADAPTER = importlib.util.module_from_spec(ADAPTER_SPEC)
ADAPTER_SPEC.loader.exec_module(ADAPTER)


def load_json(path: Path, errors: list[str]) -> dict:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        errors.append(f"无法读取 {path}：{exc}")
        return {}
    if not isinstance(data, dict):
        errors.append(f"JSON 顶层必须是对象：{path}")
        return {}
    return data


def condition_state(node: object, input_facts: dict[str, dict]) -> tuple[str, set[str]]:
    """复用 JH8 适配器的 AND/OR/NOT 三值条件判断。"""
    facts = {
        key: {
            **item,
            "status": (
                "available"
                if item.get("fact_state") == "known"
                else "not_applicable"
                if item.get("fact_state") == "not_applicable"
                else "unavailable"
            ),
        }
        for key, item in input_facts.items()
        if isinstance(item, dict)
    }
    return ADAPTER._condition_state(node, facts)


def run(target: Path) -> dict:
    errors: list[str] = []
    recipe_data = load_json(
        target / "references" / "navigation" / "method-recipes.json", errors
    )
    exam_data = load_json(target / "validation" / "offline-exam.json", errors)
    methods = {
        item.get("method"): item
        for item in recipe_data.get("methods", [])
        if isinstance(item, dict) and isinstance(item.get("method"), str)
    }
    cases = exam_data.get("cases")
    if not isinstance(cases, list) or not cases:
        errors.append("离线试卷没有非空 cases")
        cases = []

    case_reports: list[dict] = []
    seen_ids: set[str] = set()
    for index, case in enumerate(cases, 1):
        case_errors: list[str] = []
        if not isinstance(case, dict):
            errors.append(f"第 {index} 道题不是对象")
            continue
        test_id = case.get("test_id")
        if not isinstance(test_id, str) or not test_id:
            test_id = f"第 {index} 道题"
            case_errors.append("缺少 test_id")
        elif test_id in seen_ids:
            case_errors.append("test_id 重复")
        seen_ids.add(test_id)

        method_id = case.get("target_method")
        method = methods.get(method_id)
        if method is None:
            case_errors.append(f"目标方法不存在：{method_id}")
            case_reports.append(
                {"test_id": test_id, "passed": False, "errors": case_errors}
            )
            errors.extend(f"{test_id}：{message}" for message in case_errors)
            continue

        step_by_id = {
            step.get("step_id"): step
            for step in method.get("steps", [])
            if isinstance(step, dict) and isinstance(step.get("step_id"), str)
        }
        target_steps: list[dict] = []
        for step_id in case.get("target_steps", []):
            step = step_by_id.get(step_id)
            if step is None:
                case_errors.append(f"目标步骤不存在：{step_id}")
            else:
                target_steps.append(step)

        required_facts = {
            fact_key
            for step in target_steps
            for fact_key in step.get("required_fact_keys", [])
            if isinstance(fact_key, str)
        }
        input_facts = case.get("input_facts")
        input_facts = input_facts if isinstance(input_facts, dict) else {}
        missing_facts = sorted(
            fact_key
            for fact_key in required_facts
            if not isinstance(input_facts.get(fact_key), dict)
            or input_facts[fact_key].get("fact_state") not in ALLOWED_FACT_STATES
        )
        conditional_missing: set[str] = set()
        conditional_facts = {
            key: {
                **item,
                "status": (
                    "available"
                    if item.get("fact_state") == "known"
                    else "not_applicable"
                    if item.get("fact_state") == "not_applicable"
                    else "unavailable"
                ),
            }
            for key, item in input_facts.items()
            if isinstance(item, dict)
        }
        for step in target_steps:
            conditional_missing.update(
                ADAPTER._conditional_missing_facts(
                    step.get("conditional_fact_requirements", []) or [],
                    conditional_facts,
                )
            )
        missing_facts = sorted(set(missing_facts) | conditional_missing)
        expected_missing = case.get("expected_missing_fact_keys")
        expected_missing = (
            sorted(expected_missing) if isinstance(expected_missing, list) else []
        )
        if missing_facts != expected_missing:
            case_errors.append(
                f"缺失事实不符：实际 {missing_facts}，预期 {expected_missing}"
            )

        evidence_atom_ids = sorted(
            {
                ref.get("evidence_atom_id")
                for step in target_steps
                for ref in step.get("evidence_refs", [])
                if isinstance(ref, dict) and isinstance(ref.get("evidence_atom_id"), str)
            }
        )
        expected_atoms = case.get("expected_evidence_atom_ids")
        expected_atoms = sorted(expected_atoms) if isinstance(expected_atoms, list) else []
        if evidence_atom_ids != expected_atoms:
            case_errors.append(
                f"原文编号不符：实际 {evidence_atom_ids}，预期 {expected_atoms}"
            )

        searchable_text = json.dumps(target_steps, ensure_ascii=False)
        for fragment in case.get("expected_text_fragments", []):
            if not isinstance(fragment, str) or fragment not in searchable_text:
                case_errors.append(f"方法步骤缺少预期语义片段：{fragment}")

        judgment_allowed = (
            not missing_facts
            and method.get("fact_binding_status") == "mapped"
            and method.get("executable_in_pilot") is True
            and method.get("workflow_status") in EXECUTABLE_WORKFLOW_STATES
        )
        if judgment_allowed is not case.get("expected_judgment_allowed"):
            case_errors.append(
                "判断许可不符："
                f"实际 {judgment_allowed}，预期 {case.get('expected_judgment_allowed')}"
            )

        report = {
            "test_id": test_id,
            "target_method": method_id,
            "missing_fact_keys": missing_facts,
            "evidence_atom_ids": evidence_atom_ids,
            "judgment_allowed": judgment_allowed,
            "passed": not case_errors,
            "errors": case_errors,
        }
        case_reports.append(report)
        errors.extend(f"{test_id}：{message}" for message in case_errors)

    return {
        "target": str(target.resolve()),
        "cases": len(cases),
        "passed_cases": sum(item["passed"] for item in case_reports),
        "executable_methods": sum(
            item.get("executable_in_pilot") is True for item in methods.values()
        ),
        "case_reports": case_reports,
        "errors": errors,
        "passed": not errors and bool(cases),
    }


def main() -> int:
    if len(sys.argv) != 2:
        report = {"passed": False, "errors": ["用法：run_method_sample_exam.py <目标目录>"]}
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 2
    report = run(Path(sys.argv[1]).resolve())
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
