const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { isDeepStrictEqual } = require('node:util');

const TOOL_ROOT = path.resolve(__dirname, '..');

function resolveReference(value, baseDir = TOOL_ROOT) {
  return path.normalize(path.isAbsolute(value) ? value : path.resolve(baseDir, value));
}

function samePath(left, right) {
  return path.resolve(left).toLowerCase() === path.resolve(right).toLowerCase();
}

function classifyRun(name, run) {
  if (!run || run.parse_error || typeof run.exit_code !== 'number') return 'error';
  const result = run.validator_report || {};
  if (typeof result.passed !== 'boolean') return 'error';
  if (run.exit_code === 0 && result.passed === true) {
    if (name === 'positive' && result.executable_methods !== 0) return 'error';
    return 'pass';
  }
  if (run.exit_code !== 0 && result.passed === false) return 'fail';
  return 'error';
}

function readFileForValidation(filePath, label, errors) {
  try {
    const stat = fs.statSync(filePath);
    if (!stat.isFile()) {
      errors.push(`${label} 不是文件`);
      return null;
    }
    return fs.readFileSync(filePath);
  } catch (error) {
    errors.push(`${label} 不存在或不可读：${filePath}`);
    return null;
  }
}

function validateArtifactBindings(report, receipt, baseDir, errors) {
  const reportBindings = report.artifact_bindings;
  const receiptBindings = receipt && receipt.artifact_bindings;
  if (!Array.isArray(reportBindings) || reportBindings.length === 0) {
    errors.push('artifact_bindings 必须是非空数组');
  }
  if (!receipt || !Array.isArray(receiptBindings) || receiptBindings.length === 0) {
    errors.push('run_receipt.artifact_bindings 必须是非空数组');
  }
  if (!Array.isArray(reportBindings) || !Array.isArray(receiptBindings)) return;
  if (!isDeepStrictEqual(reportBindings, receiptBindings)) {
    errors.push('报告与 run_receipt 的 artifact_bindings 不一致');
  }
  for (const [index, binding] of reportBindings.entries()) {
    const label = `artifact_bindings[${index}]`;
    if (!binding || typeof binding !== 'object' || Array.isArray(binding)) {
      errors.push(`${label} 必须是对象`);
      continue;
    }
    if (typeof binding.path !== 'string' || binding.path.trim() === '') {
      errors.push(`${label}.path 缺失`);
      continue;
    }
    if (!/^[0-9a-f]{64}$/i.test(binding.sha256 || '')) {
      errors.push(`${label}.sha256 不是有效 SHA-256`);
      continue;
    }
    const artifactPath = resolveReference(binding.path, baseDir);
    const artifactBytes = readFileForValidation(artifactPath, `${label}.path`, errors);
    if (!artifactBytes) continue;
    const actualSha256 = crypto.createHash('sha256').update(artifactBytes).digest('hex');
    if (binding.sha256.toLowerCase() !== actualSha256) {
      errors.push(`受检产物内容已变化：${artifactPath}`);
    }
  }
}

const PLACEHOLDERS = new Set(['unknown', 'n/a', 'na', 'todo', 'tbd', 'null']);

function isPlaceholder(value) {
  return typeof value !== 'string' || value.trim() === '' || PLACEHOLDERS.has(value.trim().toLowerCase());
}

function validateCoverageClaims(report, baseDir, errors) {
  if (!Array.isArray(report.coverage_claims)) {
    errors.push('coverage_claims 必须是数组；没有覆盖率声明时也必须写 []');
    return;
  }
  const allowedBasisTypes = new Set(['manual_inventory', 'source_pages', 'independent_manifest']);
  report.coverage_claims.forEach((claim, index) => {
    const label = `coverage_claims[${index}]`;
    if (!claim || typeof claim !== 'object' || Array.isArray(claim)) {
      errors.push(`${label} 必须是对象`);
      return;
    }
    for (const field of ['claim', 'scope']) {
      if (isPlaceholder(claim[field])) errors.push(`${label}.${field} 缺失或是占位值`);
    }
    if (!Number.isInteger(claim.numerator) || claim.numerator < 0) errors.push(`${label}.numerator 不是非负整数`);
    if (!Number.isInteger(claim.denominator) || claim.denominator <= 0) errors.push(`${label}.denominator 不是正整数`);
    if (Number.isInteger(claim.numerator) && Number.isInteger(claim.denominator) && claim.numerator > claim.denominator) {
      errors.push(`${label} 分子不能大于分母`);
    }
    const basis = claim.basis;
    if (!basis || typeof basis !== 'object' || Array.isArray(basis)) {
      errors.push(`${label}.basis 缺失；分母不能只来自报告自报`);
      return;
    }
    if (!allowedBasisTypes.has(basis.type)) errors.push(`${label}.basis.type 不是允许的外部依据类型`);
    if (isPlaceholder(basis.path)) errors.push(`${label}.basis.path 缺失或是占位值`);
    if (!/^[0-9a-f]{64}$/i.test(basis.fingerprint || '')) errors.push(`${label}.basis.fingerprint 不是有效 SHA-256`);
    if (isPlaceholder(basis.path)) return;
    const basisPath = resolveReference(basis.path, baseDir);
    const basisBytes = readFileForValidation(basisPath, `${label}.basis.path`, errors);
    if (!basisBytes) return;
    const actualFingerprint = crypto.createHash('sha256').update(basisBytes).digest('hex');
    if (basis.fingerprint.toLowerCase() !== actualFingerprint) errors.push(`${label}.basis.fingerprint 与外部依据文件不一致`);
    try {
      const basisRecord = JSON.parse(basisBytes.toString('utf8'));
      if (!basisRecord || typeof basisRecord !== 'object' || Array.isArray(basisRecord)) throw new Error('顶层不是对象');
      if (basisRecord.total !== claim.denominator) errors.push(`${label} 分母与外部依据的 total 不一致`);
      if (basisRecord.scope !== claim.scope) errors.push(`${label} 统计范围与外部依据不一致`);
    } catch (error) {
      errors.push(`${label}.basis.path 不是可读的外部依据 JSON`);
    }
  });
}

function validateMetricDefinitions(report, errors) {
  if (!Array.isArray(report.metric_definitions) || report.metric_definitions.length === 0) {
    errors.push('metric_definitions 必须是非空数组');
    return;
  }
  report.metric_definitions.forEach((metric, index) => {
    const label = `metric_definitions[${index}]`;
    if (!metric || typeof metric !== 'object' || Array.isArray(metric)) {
      errors.push(`${label} 必须是对象`);
      return;
    }
    for (const field of ['id', 'name', 'scope', 'numerator_source', 'denominator_source']) {
      if (isPlaceholder(metric[field])) errors.push(`${label}.${field} 缺失或是占位值`);
    }
    for (const field of ['numerator', 'denominator']) {
      if (!Number.isInteger(metric[field]) || metric[field] < 0) errors.push(`${label}.${field} 不是非负整数`);
    }
    if (Number.isInteger(metric.numerator) && Number.isInteger(metric.denominator) && metric.numerator > metric.denominator) {
      errors.push(`${label} 分子不能大于分母`);
    }
  });
}

function validateAudit(report, errors) {
  const audit = report.audit;
  if (!audit || typeof audit !== 'object' || Array.isArray(audit)) {
    errors.push('audit 必须是对象');
    return;
  }
  for (const field of ['producer', 'validator', 'command', 'started_at']) {
    if (isPlaceholder(audit[field])) errors.push(`audit.${field} 缺失或是占位值`);
  }
  if (typeof audit.independent !== 'boolean') errors.push('audit.independent 必须明确是 true 或 false');
  const auditor = audit.auditor;
  if (!auditor || typeof auditor !== 'object' || Array.isArray(auditor)) {
    errors.push('audit.auditor 缺失');
    return;
  }
  for (const field of ['kind', 'id', 'version', 'config_ref']) {
    if (isPlaceholder(auditor[field])) errors.push(`audit.auditor.${field} 缺失或是占位值`);
  }
}

function validate(report, options = {}) {
  const errors = [];
  const baseDir = options.baseDir || TOOL_ROOT;

  if (report.schema_version !== 'anti-false-green-gate-v1') {
    errors.push('schema_version 不正确');
  }

  const source = report.source || {};
  for (const field of ['book_id', 'edition', 'source_path', 'source_fingerprint', 'evidence_atoms_path', 'evidence_atoms_fingerprint']) {
    if (typeof source[field] !== 'string' || source[field].trim() === '') {
      errors.push(`source.${field} 缺失`);
    }
  }

  let sourcePath;
  let evidenceAtomsPath;
  let sourceBytes;
  let evidenceAtomsBytes;
  let sourceManifest;
  if (typeof source.source_path === 'string' && source.source_path.trim() !== '') {
    sourcePath = resolveReference(source.source_path, baseDir);
    sourceBytes = readFileForValidation(sourcePath, 'source.source_path', errors);
  }
  if (typeof source.evidence_atoms_path === 'string' && source.evidence_atoms_path.trim() !== '') {
    evidenceAtomsPath = resolveReference(source.evidence_atoms_path, baseDir);
    evidenceAtomsBytes = readFileForValidation(evidenceAtomsPath, 'source.evidence_atoms_path', errors);
  }
  let evidenceAtomsSha256;
  if (evidenceAtomsBytes) {
    evidenceAtomsSha256 = crypto.createHash('sha256').update(evidenceAtomsBytes).digest('hex');
    if (!/^[0-9a-f]{64}$/i.test(source.evidence_atoms_fingerprint || '') ||
        source.evidence_atoms_fingerprint.toLowerCase() !== evidenceAtomsSha256) {
      errors.push('source.evidence_atoms_fingerprint 与 evidence_atoms 文件 SHA-256 不一致');
    }
  }
  let sourceSha256;
  if (sourceBytes) {
    sourceSha256 = crypto.createHash('sha256').update(sourceBytes).digest('hex');
    if (!/^[0-9a-f]{64}$/i.test(source.source_fingerprint || '') ||
        source.source_fingerprint.toLowerCase() !== sourceSha256) {
      errors.push('source.source_fingerprint 与 source 文件 SHA-256 不一致');
    }
    try {
      sourceManifest = JSON.parse(sourceBytes.toString('utf8'));
      if (!sourceManifest || typeof sourceManifest !== 'object' || Array.isArray(sourceManifest)) {
        throw new Error('顶层不是对象');
      }
    } catch (error) {
      errors.push('source.source_path 不是可读的 DISTILLATION_SOURCE.json');
      sourceManifest = null;
    }
  }
  if (sourceManifest) {
    if (sourceManifest.book_id !== source.book_id) {
      errors.push('source.book_id 与 DISTILLATION_SOURCE.json 不一致');
    }
    if (sourceManifest.edition_id !== source.edition) {
      errors.push('source.edition 与 DISTILLATION_SOURCE.json 不一致');
    }
    if (typeof sourceManifest.evidence_atoms_path !== 'string' || sourceManifest.evidence_atoms_path.trim() === '') {
      errors.push('DISTILLATION_SOURCE.json 缺少 evidence_atoms_path');
    } else if (evidenceAtomsPath) {
      const manifestEvidencePath = resolveReference(sourceManifest.evidence_atoms_path, path.dirname(sourcePath));
      if (!samePath(manifestEvidencePath, evidenceAtomsPath)) {
        errors.push('source.evidence_atoms_path 与 DISTILLATION_SOURCE.json 不一致');
      }
    }
    if (!/^[0-9a-f]{64}$/i.test(sourceManifest.evidence_atoms_sha256 || '')) {
      errors.push('DISTILLATION_SOURCE.json 缺少有效 evidence_atoms_sha256');
    } else if (evidenceAtomsSha256 && sourceManifest.evidence_atoms_sha256.toLowerCase() !== evidenceAtomsSha256) {
      errors.push('evidence_atoms 文件 SHA-256 与 DISTILLATION_SOURCE.json 不一致');
    }
  }

  const controls = report.controls || {};
  if (controls.positive !== 'pass') errors.push('正确对照没有通过');
  if (controls.negative !== 'fail') errors.push('错误对照没有失败');
  if (controls.baseline !== 'fail') errors.push('空白基线没有失败');

  const counts = report.counts || {};
  const countFields = ['total', 'passed', 'failed', 'errored', 'abstained', 'skipped'];
  for (const field of countFields) {
    if (!Number.isInteger(counts[field]) || counts[field] < 0) {
      errors.push(`counts.${field} 不是非负整数`);
    }
  }
  if (countFields.every((field) => Number.isInteger(counts[field]))) {
    const accounted = counts.passed + counts.failed + counts.errored + counts.abstained + counts.skipped;
    if (counts.total !== accounted) errors.push('counts.total 与分类数量不相等');
  }

  validateCoverageClaims(report, baseDir, errors);
  if (!Array.isArray(report.unchecked_scope)) {
    errors.push('unchecked_scope 必须是数组；没有未检查范围时也必须写 [] 或明确写“无”');
  } else if (report.unchecked_scope.some((item) => isPlaceholder(item) && item !== '无')) {
    errors.push('unchecked_scope 不能包含空值或 unknown/N/A/TODO 等占位值');
  }
  validateMetricDefinitions(report, errors);
  validateAudit(report, errors);

  let receipt;
  if (typeof report.run_receipt !== 'string' || report.run_receipt.trim() === '') {
    errors.push('缺少机器运行记录');
  } else {
    const receiptPath = resolveReference(report.run_receipt, baseDir);
    const receiptBytes = readFileForValidation(receiptPath, 'run_receipt', errors);
    if (receiptBytes) {
      try {
        receipt = JSON.parse(receiptBytes.toString('utf8'));
        if (!receipt || typeof receipt !== 'object' || Array.isArray(receipt)) {
          errors.push('run_receipt 不是 JSON 对象');
          receipt = null;
        }
      } catch (error) {
        errors.push('run_receipt 不是可读的 JSON');
      }
    }
  }
  validateArtifactBindings(report, receipt, baseDir, errors);
  if (receipt) {
    if (receipt.status !== 'completed') {
      errors.push('run_receipt.status 必须为 completed');
    }
    if (receipt.schema_version !== 'anti-false-green-run-v1') {
      errors.push('run_receipt.schema_version 不正确');
    }
    const receiptSource = receipt.source && typeof receipt.source === 'object' ? receipt.source : receipt;
    const bindings = [
      ['book_id', source.book_id],
      ['edition', source.edition],
      ['source_fingerprint', source.source_fingerprint],
      ['evidence_atoms_path', source.evidence_atoms_path],
      ['evidence_atoms_fingerprint', source.evidence_atoms_fingerprint],
    ];
    for (const [field, expected] of bindings) {
      if (receiptSource[field] !== expected) {
        errors.push(`run_receipt.${field} 与报告来源不一致`);
      }
    }
    if (sourcePath && typeof receiptSource.source_path === 'string') {
      if (!samePath(resolveReference(receiptSource.source_path, baseDir), sourcePath)) {
        errors.push('run_receipt.source_path 与报告来源不一致');
      }
    } else {
      errors.push('run_receipt.source_path 缺失');
    }
    if (sourceSha256 && receiptSource.source_fingerprint !== sourceSha256) {
      errors.push('run_receipt.source_fingerprint 不是实际 source SHA-256');
    }
    if (evidenceAtomsSha256 && receiptSource.evidence_atoms_fingerprint !== evidenceAtomsSha256) {
      errors.push('run_receipt.evidence_atoms_fingerprint 不是实际 evidence_atoms SHA-256');
    }
    if (evidenceAtomsPath && typeof receiptSource.evidence_atoms_path === 'string' &&
        !samePath(resolveReference(receiptSource.evidence_atoms_path, baseDir), evidenceAtomsPath)) {
      errors.push('run_receipt.evidence_atoms_path 与报告来源不一致');
    }
    if (!isDeepStrictEqual(receipt.audit, report.audit)) {
      errors.push('run_receipt.audit 与报告 audit 不一致');
    }
    const runs = receipt.runs && typeof receipt.runs === 'object' ? receipt.runs : {};
    for (const name of ['positive', 'negative', 'baseline']) {
      const run = runs[name];
      if (!run || typeof run.record_path !== 'string' || run.record_path.trim() === '') {
        errors.push(`${name} 运行记录缺少 record_path`);
        continue;
      }
      const recordPath = resolveReference(run.record_path, baseDir);
      const recordBytes = readFileForValidation(recordPath, `${name}.record_path`, errors);
      if (!recordBytes) continue;
      let record;
      try {
        record = JSON.parse(recordBytes.toString('utf8'));
      } catch (error) {
        errors.push(`${name}.record_path 不是可读的 JSON`);
        continue;
      }
      if (!record || typeof record !== 'object' || Array.isArray(record)) {
        errors.push(`${name}.record_path 顶层不是 JSON 对象`);
        continue;
      }
      for (const field of ['label', 'target', 'exit_code', 'validator_report', 'parse_error', 'stderr']) {
        if (!isDeepStrictEqual(record[field], run[field])) {
          errors.push(`${name}.record_path 的 ${field} 与 receipt 内嵌记录不一致`);
        }
      }
    }
    const computedControls = {
      positive: classifyRun('positive', runs.positive),
      negative: classifyRun('negative', runs.negative),
      baseline: classifyRun('baseline', runs.baseline),
    };
    for (const name of ['positive', 'negative', 'baseline']) {
      if (controls[name] !== computedControls[name]) {
        errors.push(`${name} 对照与机器运行记录不一致`);
      }
    }
    const computedCounts = {
      total: 3,
      passed: Object.values(computedControls).filter((value) => value === 'pass').length,
      failed: Object.values(computedControls).filter((value) => value === 'fail').length,
      errored: Object.values(computedControls).filter((value) => value === 'error').length,
      abstained: 0,
      skipped: 0,
    };
    for (const field of countFields) {
      if (counts[field] !== computedCounts[field]) {
        errors.push(`counts.${field} 与机器运行记录不一致`);
      }
    }
  }

  if (!Array.isArray(report.unresolved_blockers)) {
    errors.push('unresolved_blockers 必须是数组');
  } else if (report.unresolved_blockers.length > 0 && report.status === 'machine_check_pass') {
    errors.push('存在未解决阻塞却声明机器检查通过');
  }
  if (report.release_authority !== 'human_only') {
    errors.push('最终发布权不是 human_only');
  }
  if (!['machine_check_pass', 'blocked', 'invalid_exam'].includes(report.status)) {
    errors.push('status 不合法');
  }

  return errors;
}

module.exports = (output, context = {}) => {
  let report;
  try {
    report = typeof output === 'string' ? JSON.parse(output) : output;
  } catch (error) {
    report = {};
  }

  const errors = validate(report);
  const vars = context.vars || {};
  const expectedValid = vars.expected_valid === true || vars.expected_valid === 'true';
  const actualValid = errors.length === 0;
  const pass = actualValid === expectedValid;

  return {
    pass,
    score: pass ? 1 : 0,
    reason: pass
      ? expectedValid
        ? '正确对照通过全部硬检查'
        : `已知无效样本被正确拦截：${errors.join('；')}`
      : expectedValid
        ? `正确对照被错误拦截：${errors.join('；')}`
        : '已知无效样本逃过检查，出现假绿',
  };
};

module.exports.validate = validate;

if (require.main === module) {
  const reportPath = process.argv[2];
  let report = {};
  try {
    report = JSON.parse(fs.readFileSync(reportPath, 'utf8'));
  } catch (error) {
    console.log(JSON.stringify({ passed: false, errors: ['无法读取闸门报告'] }, null, 2));
    process.exit(1);
  }
  const errors = validate(report, { baseDir: path.dirname(path.resolve(reportPath)) });
  const passed = errors.length === 0 && report.status === 'machine_check_pass';
  console.log(JSON.stringify({ passed, report_path: path.resolve(reportPath), errors }, null, 2));
  process.exit(passed ? 0 : 1);
}
