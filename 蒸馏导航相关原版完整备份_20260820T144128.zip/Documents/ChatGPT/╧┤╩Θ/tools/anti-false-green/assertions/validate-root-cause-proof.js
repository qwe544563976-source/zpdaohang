const fs = require('node:fs');
const path = require('node:path');

const PLACEHOLDERS = new Set(['unknown', 'n/a', 'na', 'todo', 'tbd', 'null']);

function missing(value) {
  return typeof value !== 'string' || value.trim() === '' || PLACEHOLDERS.has(value.trim().toLowerCase());
}

function validateRootCauseProof(proofs, options = {}) {
  const errors = [];
  const baseDir = options.baseDir || path.resolve(__dirname, '..');
  if (!Array.isArray(proofs) || proofs.length === 0) return ['root_cause_proof 必须是非空数组'];
  const seenIds = new Set();

  proofs.forEach((proof, index) => {
    const label = `root_cause_proof[${index}]`;
    if (!proof || typeof proof !== 'object' || Array.isArray(proof)) {
      errors.push(`${label} 必须是对象`);
      return;
    }
    for (const field of ['id', 'symptom', 'root_cause', 'falsifiable_prediction', 'shared_fix_location']) {
      if (missing(proof[field])) errors.push(`${label}.${field} 缺失或是占位值`);
    }
    if (!missing(proof.id)) {
      if (seenIds.has(proof.id)) errors.push(`${label}.id 不能重复使用`);
      seenIds.add(proof.id);
    }

    const before = proof.before_fix || {};
    for (const field of ['original_specimen', 'same_cause_variant_specimen']) {
      if (missing(before[field])) {
        errors.push(`${label}.before_fix.${field} 缺失或是占位值`);
      } else {
        const specimenPath = path.resolve(baseDir, before[field]);
        if (!fs.existsSync(specimenPath) || !fs.statSync(specimenPath).isFile()) {
          errors.push(`${label}.before_fix.${field} 指向的错误样本不存在`);
        }
      }
    }
    if (!missing(before.original_specimen) && !missing(before.same_cause_variant_specimen) &&
        path.resolve(baseDir, before.original_specimen) === path.resolve(baseDir, before.same_cause_variant_specimen)) {
      errors.push(`${label} 的原错误样本和同原因变体不能是同一个文件`);
    }
    for (const field of ['original_escaped', 'same_cause_variant_escaped']) {
      if (before[field] !== true) errors.push(`${label}.before_fix.${field} 必须由真实旧检查证明为 true`);
    }

    const after = proof.after_fix || {};
    for (const field of ['positive_passed', 'original_rejected', 'same_cause_variant_rejected']) {
      if (after[field] !== true) errors.push(`${label}.after_fix.${field} 必须由真实新检查证明为 true`);
    }
  });

  return errors;
}

module.exports = { validateRootCauseProof };
