const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const specimenPath = path.join(root, 'fixtures', 'error-zoo', 'forged-nonempty-report.json');
const resultsPath = path.join(root, 'results', 'error-zoo', 'pre-fix-forged-receipt.json');

function legacyValidate(report) {
  const errors = [];
  if (report.schema_version !== 'anti-false-green-gate-v1') errors.push('schema_version');
  const source = report.source || {};
  for (const field of ['book_id', 'edition', 'source_path', 'source_fingerprint', 'evidence_atoms_path']) {
    if (typeof source[field] !== 'string' || source[field].trim() === '') errors.push(`source.${field}`);
  }
  const controls = report.controls || {};
  if (controls.positive !== 'pass' || controls.negative !== 'fail' || controls.baseline !== 'fail') {
    errors.push('controls');
  }
  const counts = report.counts || {};
  const countFields = ['total', 'passed', 'failed', 'errored', 'abstained', 'skipped'];
  if (!countFields.every((field) => Number.isInteger(counts[field]) && counts[field] >= 0)) {
    errors.push('counts');
  } else if (counts.total !== counts.passed + counts.failed + counts.errored + counts.abstained + counts.skipped) {
    errors.push('counts.total');
  }
  if (typeof report.run_receipt !== 'string' || report.run_receipt.trim() === '') errors.push('run_receipt');
  if (!Array.isArray(report.unresolved_blockers)) errors.push('unresolved_blockers');
  if (report.release_authority !== 'human_only') errors.push('release_authority');
  if (!['machine_check_pass', 'blocked', 'invalid_exam'].includes(report.status)) errors.push('status');
  return errors;
}

const report = JSON.parse(fs.readFileSync(specimenPath, 'utf8'));
const errors = legacyValidate(report);
const record = {
  schema_version: 'error-zoo-pre-fix-forged-receipt-v1',
  run_at: new Date().toISOString(),
  specimen_path: specimenPath,
  legacy_validator: '仅检查非空字段、自报 controls/counts/status，不读取文件或 receipt 内容',
  escaped: errors.length === 0,
  errors,
};
assert.equal(record.escaped, true, '旧逻辑标本没有复现放行');
fs.mkdirSync(path.dirname(resultsPath), { recursive: true });
fs.writeFileSync(resultsPath, JSON.stringify(record, null, 2) + '\n', 'utf8');
process.stdout.write(JSON.stringify(record, null, 2) + '\n');
