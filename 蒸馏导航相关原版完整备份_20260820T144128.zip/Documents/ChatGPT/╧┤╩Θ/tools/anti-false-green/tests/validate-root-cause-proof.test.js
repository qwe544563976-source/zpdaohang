const assert = require('node:assert/strict');
const { validateRootCauseProof } = require('../assertions/validate-root-cause-proof');

const valid = [{
  id: 'external-denominator-trust',
  symptom: '系统自报总数也能被旧检查放行',
  root_cause: '旧检查只核对报告内部数字，没有与系统外部清单对账',
  falsifiable_prediction: '换一种自报总数的外观，旧检查仍会放行',
  shared_fix_location: 'assertions/validate-gate-report.js:validateCoverageClaims',
  before_fix: {
    original_specimen: 'fixtures/error-zoo/self-reported-denominator.json',
    same_cause_variant_specimen: 'fixtures/error-zoo/mismatched-external-denominator.json',
    original_escaped: true,
    same_cause_variant_escaped: true,
  },
  after_fix: {
    positive_passed: true,
    original_rejected: true,
    same_cause_variant_rejected: true,
  },
}];

assert.deepEqual(validateRootCauseProof(valid), []);
assert.ok(validateRootCauseProof([{ ...valid[0], falsifiable_prediction: 'TODO' }]).some((error) => error.includes('falsifiable_prediction')));
assert.ok(validateRootCauseProof([{ ...valid[0], before_fix: { ...valid[0].before_fix, original_escaped: false } }]).some((error) => error.includes('original_escaped')));
assert.ok(validateRootCauseProof([{ ...valid[0], before_fix: { ...valid[0].before_fix, same_cause_variant_specimen: 'fixtures/error-zoo/missing.json' } }]).some((error) => error.includes('不存在')));
assert.ok(validateRootCauseProof([{ ...valid[0], after_fix: { ...valid[0].after_fix, positive_passed: false } }]).some((error) => error.includes('positive_passed')));
assert.ok(validateRootCauseProof([{ ...valid[0], before_fix: { ...valid[0].before_fix, same_cause_variant_specimen: valid[0].before_fix.original_specimen } }]).some((error) => error.includes('同一个文件')));
assert.ok(validateRootCauseProof([valid[0], valid[0]]).some((error) => error.includes('不能重复使用')));
console.log('根因修复证明检查通过：缺预测、缺同原因变体、缺修复前后证据都会被拦截。');
