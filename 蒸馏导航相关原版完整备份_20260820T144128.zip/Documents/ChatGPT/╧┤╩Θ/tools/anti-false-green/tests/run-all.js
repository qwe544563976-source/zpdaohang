const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { validateRootCauseProof } = require('../assertions/validate-root-cause-proof');

const root = path.resolve(__dirname, '..');
const projectRoot = path.resolve(root, '..', '..');
const resultsDir = path.join(root, 'results');
const resultsPath = path.join(resultsDir, 'data-controls.json');

function run(label, command, args, cwd) {
  const result = spawnSync(command, args, { cwd, encoding: 'utf8', windowsHide: true });
  return {
    label,
    command: [command, ...args].join(' '),
    exit_code: result.status === null ? 1 : result.status,
    stdout: result.stdout || '',
    stderr: result.stderr || '',
    error: result.error ? String(result.error) : null,
  };
}

const python = process.env.PYTHON || 'python';
const checks = [
  run('root_cause_proof_validator', process.execPath, [path.join(root, 'tests', 'validate-root-cause-proof.test.js')], root),
  run('javascript_tests', process.execPath, [path.join(root, 'tests', 'validate-gate-report.test.js')], root),
  run('legacy_receipt_probe', process.execPath, [path.join(root, 'tests', 'legacy-receipt-probe.js')], root),
  run('legacy_evidence_probe', process.execPath, [path.join(root, 'tests', 'legacy-evidence-probe.js')], root),
  run('legacy_record_probe', process.execPath, [path.join(root, 'tests', 'legacy-record-probe.js')], root),
  run('legacy_probe', python, [path.join(projectRoot, 'tests', 'error_zoo', 'legacy_probe.py')], projectRoot),
  run('post_fix_check', python, [path.join(projectRoot, 'tests', 'error_zoo', 'post_fix_check.py')], projectRoot),
];

let rootCauseProof = [];
const rootCauseProofErrors = [];
try {
  rootCauseProof = JSON.parse(checks.find((check) => check.label === 'javascript_tests').stdout).root_cause_proof;
} catch (error) {
  rootCauseProofErrors.push(`无法从真实判卷测试读取 root_cause_proof：${error.message}`);
}
rootCauseProofErrors.push(...validateRootCauseProof(rootCauseProof, { baseDir: root }));

const record = {
  schema_version: 'anti-false-green-data-controls-v1',
  run_at: new Date().toISOString(),
  status: checks.every((check) => check.exit_code === 0) && rootCauseProofErrors.length === 0 ? 'passed' : 'failed',
  checks,
  root_cause_proof: rootCauseProof,
  root_cause_proof_errors: rootCauseProofErrors,
};
fs.mkdirSync(resultsDir, { recursive: true });
fs.writeFileSync(resultsPath, JSON.stringify(record, null, 2), 'utf8');
process.stdout.write(JSON.stringify(record, null, 2) + '\n');
process.exitCode = record.status === 'passed' ? 0 : 1;
