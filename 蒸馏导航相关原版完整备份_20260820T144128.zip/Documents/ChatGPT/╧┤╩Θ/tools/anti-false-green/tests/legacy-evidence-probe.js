const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const source = JSON.parse(fs.readFileSync(path.join(root, 'fixtures', 'example-machine-run.json'), 'utf8')).source;
const originalPath = path.join(root, 'fixtures', 'evidence_atoms.jsonl');
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'anti-false-green-evidence-'));
const mutatedPath = path.join(temp, 'evidence_atoms.jsonl');
const resultsPath = path.join(root, 'results', 'error-zoo', 'pre-fix-evidence-fingerprint.json');

function sha256(pathname) {
  return crypto.createHash('sha256').update(fs.readFileSync(pathname)).digest('hex');
}

function legacyValidate(report) {
  const errors = [];
  const sourceValue = report.source || {};
  for (const field of ['book_id', 'edition', 'source_path', 'source_fingerprint', 'evidence_atoms_path', 'evidence_atoms_fingerprint']) {
    if (typeof sourceValue[field] !== 'string' || sourceValue[field].trim() === '') errors.push(`source.${field}`);
  }
  const evidencePath = sourceValue.evidence_atoms_path;
  if (typeof evidencePath === 'string' && fs.existsSync(evidencePath)) {
    if (sha256(evidencePath) !== sourceValue.evidence_atoms_fingerprint) errors.push('evidence_atoms_fingerprint');
  }
  if (report.run_receipt === '') errors.push('run_receipt');
  return errors;
}

try {
  fs.copyFileSync(originalPath, mutatedPath);
  fs.appendFileSync(mutatedPath, '\n{"evidence_atom_id":"mutated"}\n', 'utf8');
  const originalFingerprint = sha256(originalPath);
  const mutatedFingerprint = sha256(mutatedPath);
  const report = {
    schema_version: 'anti-false-green-gate-v1',
    source: {
      ...source,
      evidence_atoms_path: mutatedPath,
      evidence_atoms_fingerprint: mutatedFingerprint,
    },
    controls: { positive: 'pass', negative: 'fail', baseline: 'fail' },
    counts: { total: 3, passed: 1, failed: 2, errored: 0, abstained: 0, skipped: 0 },
    run_receipt: 'fixtures/example-machine-run.json',
    unresolved_blockers: [],
    release_authority: 'human_only',
    status: 'machine_check_pass',
  };
  const errors = legacyValidate(report);
  const record = {
    schema_version: 'error-zoo-pre-fix-evidence-fingerprint-v1',
    run_at: new Date().toISOString(),
    original_fingerprint: originalFingerprint,
    mutated_fingerprint: mutatedFingerprint,
    manifest_fingerprint: originalFingerprint,
    reported_fingerprint: mutatedFingerprint,
    escaped: errors.length === 0 && originalFingerprint !== mutatedFingerprint,
    errors,
  };
  assert.equal(record.escaped, true, '旧逻辑没有复现 evidence 与来源清单脱钩后的放行');
  fs.mkdirSync(path.dirname(resultsPath), { recursive: true });
  fs.writeFileSync(resultsPath, JSON.stringify(record, null, 2) + '\n', 'utf8');
  process.stdout.write(JSON.stringify(record, null, 2) + '\n');
} finally {
  fs.rmSync(temp, { recursive: true, force: true });
}
