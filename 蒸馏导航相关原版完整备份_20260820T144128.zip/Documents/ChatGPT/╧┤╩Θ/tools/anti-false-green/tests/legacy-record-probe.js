const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const receiptPath = path.join(root, 'fixtures', 'example-machine-run.json');
const resultsPath = path.join(root, 'results', 'error-zoo', 'pre-fix-record-path.json');

function legacyValidateReceipt(receipt) {
  const errors = [];
  if (receipt.status !== 'completed') errors.push('status');
  if (receipt.schema_version !== 'anti-false-green-run-v1') errors.push('schema_version');
  for (const name of ['positive', 'negative', 'baseline']) {
    const run = receipt.runs && receipt.runs[name];
    if (!run || typeof run.exit_code !== 'number' || typeof run.validator_report?.passed !== 'boolean') {
      errors.push(`${name}.run`);
    }
  }
  return errors;
}

const receipt = JSON.parse(fs.readFileSync(receiptPath, 'utf8'));
const missingRecordPath = JSON.parse(JSON.stringify(receipt));
delete missingRecordPath.runs.positive.record_path;
const tamperedRecordPath = JSON.parse(JSON.stringify(receipt));
tamperedRecordPath.runs.negative.record_path = 'fixtures/run-records/positive.json';
const missingErrors = legacyValidateReceipt(missingRecordPath);
const tamperedErrors = legacyValidateReceipt(tamperedRecordPath);
const record = {
  schema_version: 'error-zoo-pre-fix-record-path-v1',
  run_at: new Date().toISOString(),
  receipt_path: receiptPath,
  specimens: {
    missing_record_path: { escaped: missingErrors.length === 0, errors: missingErrors },
    tampered_record_path: { escaped: tamperedErrors.length === 0, errors: tamperedErrors },
  },
};
assert.equal(record.specimens.missing_record_path.escaped, true, '旧逻辑没有放行缺失 record_path 标本');
assert.equal(record.specimens.tampered_record_path.escaped, true, '旧逻辑没有放行篡改 record_path 标本');
fs.mkdirSync(path.dirname(resultsPath), { recursive: true });
fs.writeFileSync(resultsPath, JSON.stringify(record, null, 2) + '\n', 'utf8');
process.stdout.write(JSON.stringify(record, null, 2) + '\n');
