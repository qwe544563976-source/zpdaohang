const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { validate } = require('../assertions/validate-gate-report');

const root = path.resolve(__dirname, '..');
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'anti-false-green-'));
const validArtifactBindings = [
  'references/navigation/method-recipes.json',
  'references/navigation/query-recipes.json',
  'validation/offline-exam.json',
].map((relativePath, index) => {
  const artifactPath = path.join(temp, 'valid-target', relativePath);
  fs.mkdirSync(path.dirname(artifactPath), { recursive: true });
  fs.writeFileSync(artifactPath, `valid-fixture-artifact-${index}\n`, 'utf8');
  return {
    path: artifactPath,
    sha256: crypto.createHash('sha256').update(fs.readFileSync(artifactPath)).digest('hex'),
  };
});
const validReceipt = JSON.parse(fs.readFileSync(path.join(root, 'fixtures', 'example-machine-run.json'), 'utf8'));
validReceipt.artifact_bindings = validArtifactBindings;
const validReceiptPath = path.join(temp, 'valid-receipt.json');
fs.writeFileSync(validReceiptPath, JSON.stringify(validReceipt), 'utf8');
const populationBasisFingerprint = '13fdcc0ca980275cfc1296ee153a025ea949e7b4300963d22a351cad5062b52c';
const valid = {
  schema_version: 'anti-false-green-gate-v1',
  source: {
    book_id: 'BPHS97_TEST',
    edition: 'frozen-test-edition',
    source_path: 'fixtures/DISTILLATION_SOURCE.json',
    source_fingerprint: 'e3087314b4e006294f4776ab0db51b5618b6a6a6263b620cdfa788b554cb815b',
    evidence_atoms_path: 'fixtures/evidence_atoms.jsonl',
    evidence_atoms_fingerprint: 'f6b264561708b51062a510f43f978c19a21dd9805c623e4ad12312e225403697'
  },
  controls: { positive: 'pass', negative: 'fail', baseline: 'fail' },
  counts: { total: 3, passed: 1, failed: 2, errored: 0, abstained: 0, skipped: 0 },
  coverage_claims: [{
    claim: 'evidence_atom_coverage',
    numerator: 1,
    denominator: 1,
    scope: 'fixtures/evidence_atoms.jsonl',
    basis: {
      type: 'independent_manifest',
      path: 'fixtures/population-basis.json',
      fingerprint: populationBasisFingerprint,
    },
  }],
  unchecked_scope: ['本测试夹具不代表真实切书'],
  metric_definitions: [{
    id: 'controls-total-v1',
    name: '三份对照总数',
    numerator: 3,
    denominator: 3,
    scope: 'positive,negative,baseline',
    numerator_source: 'run_receipt.runs',
    denominator_source: '固定三份对照合同',
  }],
  audit: {
    producer: 'fixture-producer',
    validator: 'validate-gate-report.js',
    auditor: {
      kind: 'program',
      id: 'fixture-independent-check',
      version: '1.0.0',
      config_ref: 'fixtures/audit-config.json',
    },
    independent: true,
    command: 'node assertions/validate-gate-report.js',
    started_at: '2026-08-17T00:00:00Z',
  },
  artifact_bindings: validArtifactBindings,
  run_receipt: validReceiptPath,
  unresolved_blockers: [],
  release_authority: 'human_only',
  status: 'machine_check_pass'
};

function legacyCoverageErrors(report) {
  const errors = [];
  for (const claim of report.coverage_claims || []) {
    if (!Number.isInteger(claim.numerator) || claim.numerator < 0) errors.push('numerator');
    if (!Number.isInteger(claim.denominator) || claim.denominator <= 0) errors.push('denominator');
    if (claim.numerator > claim.denominator) errors.push('ratio');
  }
  return errors;
}

assert.deepEqual(validate(valid), []);
assert.ok(validate({ ...valid, artifact_bindings: [] }).some((error) => error.includes('artifact_bindings 必须是非空数组')));
const missingBindingsReceipt = JSON.parse(JSON.stringify(validReceipt));
delete missingBindingsReceipt.artifact_bindings;
const missingBindingsReceiptPath = path.join(temp, 'missing-bindings-receipt.json');
fs.writeFileSync(missingBindingsReceiptPath, JSON.stringify(missingBindingsReceipt), 'utf8');
assert.ok(validate({ ...valid, run_receipt: missingBindingsReceiptPath }).some((error) => error.includes('run_receipt.artifact_bindings 必须是非空数组')));
assert.ok(validate({ ...valid, coverage_claims: undefined }).some((error) => error.includes('coverage_claims')));
assert.ok(validate({ ...valid, coverage_claims: [{ ...valid.coverage_claims[0], basis: { ...valid.coverage_claims[0].basis, type: 'self_reported' } }] }).some((error) => error.includes('外部依据类型')));
assert.ok(validate({ ...valid, coverage_claims: [{ ...valid.coverage_claims[0], denominator: 2 }] }).some((error) => error.includes('分母')));
assert.ok(validate({ ...valid, unchecked_scope: undefined }).some((error) => error.includes('unchecked_scope')));
assert.ok(validate({ ...valid, audit: { ...valid.audit, auditor: { ...valid.audit.auditor, id: 'unknown' } } }).some((error) => error.includes('占位')));
assert.ok(validate({ ...valid, audit: { ...valid.audit, auditor: undefined } }).some((error) => error.includes('auditor')));
assert.ok(validate({ ...valid, controls: { ...valid.controls, negative: 'pass' } }).length > 0);
assert.ok(validate({ ...valid, source: { ...valid.source, source_path: 'fixtures/missing.pdf' } }).some((error) => error.includes('不存在')));
assert.ok(validate({ ...valid, source: { ...valid.source, source_fingerprint: '0'.repeat(64) } }).some((error) => error.includes('SHA-256')));
assert.ok(validate({ ...valid, source: { ...valid.source, evidence_atoms_fingerprint: '0'.repeat(64) } }).some((error) => error.includes('evidence_atoms')));
assert.ok(validate({ ...valid, run_receipt: 'fixtures/missing-receipt.json' }).some((error) => error.includes('run_receipt')));
const mutatedEvidencePath = path.join(temp, 'mutated-evidence.jsonl');
fs.copyFileSync(path.join(root, 'fixtures', 'evidence_atoms.jsonl'), mutatedEvidencePath);
fs.appendFileSync(mutatedEvidencePath, '\n{"evidence_atom_id":"mutated"}\n', 'utf8');
assert.ok(validate({ ...valid, source: { ...valid.source, evidence_atoms_path: mutatedEvidencePath } }).some((error) => error.includes('evidence_atoms_fingerprint')));
const forgedReceiptPath = path.join(temp, 'forged-receipt.json');
const receipt = JSON.parse(fs.readFileSync(path.join(root, 'fixtures', 'example-machine-run.json'), 'utf8'));
const manifestMismatchReceiptPath = path.join(temp, 'manifest-mismatch-receipt.json');
const manifestMismatchReceipt = JSON.parse(JSON.stringify(receipt));
manifestMismatchReceipt.source.evidence_atoms_path = 'fixtures/error-zoo/tampered-evidence_atoms.jsonl';
manifestMismatchReceipt.source.evidence_atoms_fingerprint = 'a3061c68a9a728d6aff23237521239e84180b9df80ee3391d3b0257079b51157';
fs.writeFileSync(manifestMismatchReceiptPath, JSON.stringify(manifestMismatchReceipt), 'utf8');
const manifestMismatch = JSON.parse(JSON.stringify(valid));
manifestMismatch.source.evidence_atoms_path = manifestMismatchReceipt.source.evidence_atoms_path;
manifestMismatch.source.evidence_atoms_fingerprint = manifestMismatchReceipt.source.evidence_atoms_fingerprint;
manifestMismatch.run_receipt = manifestMismatchReceiptPath;
assert.ok(validate(manifestMismatch).some((error) => error.includes('evidence_atoms 文件 SHA-256 与 DISTILLATION_SOURCE.json 不一致')));
receipt.runs.negative = {
  exit_code: 0,
  parse_error: '',
  validator_report: { passed: true },
};
fs.writeFileSync(forgedReceiptPath, JSON.stringify(receipt), 'utf8');
assert.ok(validate({ ...valid, run_receipt: forgedReceiptPath }).some((error) => error.includes('negative 对照与机器运行记录不一致')));
const auditMismatchReceiptPath = path.join(temp, 'audit-mismatch-receipt.json');
const auditMismatchReceipt = JSON.parse(fs.readFileSync(path.join(root, 'fixtures', 'example-machine-run.json'), 'utf8'));
delete auditMismatchReceipt.audit;
fs.writeFileSync(auditMismatchReceiptPath, JSON.stringify(auditMismatchReceipt), 'utf8');
assert.ok(validate({ ...valid, run_receipt: auditMismatchReceiptPath }).some((error) => error.includes('run_receipt.audit')));
const missingRecordReceiptPath = path.join(temp, 'missing-record-receipt.json');
const missingRecordReceipt = JSON.parse(fs.readFileSync(path.join(root, 'fixtures', 'example-machine-run.json'), 'utf8'));
delete missingRecordReceipt.runs.positive.record_path;
fs.writeFileSync(missingRecordReceiptPath, JSON.stringify(missingRecordReceipt), 'utf8');
assert.ok(validate({ ...valid, run_receipt: missingRecordReceiptPath }).some((error) => error.includes('positive 运行记录缺少 record_path')));
const tamperedRecordReceiptPath = path.join(temp, 'tampered-record-receipt.json');
const tamperedRecordReceipt = JSON.parse(fs.readFileSync(path.join(root, 'fixtures', 'example-machine-run.json'), 'utf8'));
tamperedRecordReceipt.runs.negative.record_path = 'fixtures/run-records/positive.json';
fs.writeFileSync(tamperedRecordReceiptPath, JSON.stringify(tamperedRecordReceipt), 'utf8');
assert.ok(validate({ ...valid, run_receipt: tamperedRecordReceiptPath }).some((error) => error.includes('negative.record_path 的 label')));

const boundTarget = path.join(temp, 'bound-positive-target');
const boundArtifacts = [
  'references/navigation/method-recipes.json',
  'references/navigation/query-recipes.json',
  'validation/offline-exam.json',
].map((relativePath, index) => {
  const artifactPath = path.join(boundTarget, relativePath);
  fs.mkdirSync(path.dirname(artifactPath), { recursive: true });
  fs.writeFileSync(artifactPath, `fixture-artifact-${index}\n`, 'utf8');
  const sha256 = crypto.createHash('sha256').update(fs.readFileSync(artifactPath)).digest('hex');
  return { path: artifactPath, sha256 };
});
const boundReceipt = JSON.parse(fs.readFileSync(path.join(root, 'fixtures', 'example-machine-run.json'), 'utf8'));
boundReceipt.artifact_bindings = boundArtifacts;
const boundReceiptPath = path.join(temp, 'bound-receipt.json');
fs.writeFileSync(boundReceiptPath, JSON.stringify(boundReceipt), 'utf8');
const boundReport = { ...valid, artifact_bindings: boundArtifacts, run_receipt: boundReceiptPath };
assert.deepEqual(validate(boundReport), []);
assert.ok(validate({ ...boundReport, artifact_bindings: boundArtifacts.slice(1) }).some((error) => error.includes('artifact_bindings 不一致')));
fs.appendFileSync(boundArtifacts[0].path, 'changed-after-receipt\n', 'utf8');
assert.ok(validate(boundReport).some((error) => error.includes('受检产物内容已变化')));
const incompleteReceipt = JSON.parse(fs.readFileSync(path.join(root, 'fixtures', 'error-zoo', 'incomplete-receipt.json'), 'utf8'));
assert.equal(incompleteReceipt.status, 'running');
const forgedReport = JSON.parse(fs.readFileSync(path.join(root, 'fixtures', 'error-zoo', 'forged-nonempty-report.json'), 'utf8'));
const forgedErrors = validate(forgedReport);
assert.ok(forgedErrors.some((error) => error.includes('不存在')));
assert.ok(forgedErrors.some((error) => error.includes('status')));
assert.ok(fs.existsSync(path.join(root, 'fixtures', 'DISTILLATION_SOURCE.json')));
assert.ok(fs.existsSync(path.join(root, 'fixtures', 'evidence_atoms.jsonl')));

const originalSpecimen = JSON.parse(fs.readFileSync(path.join(root, 'fixtures', 'error-zoo', 'self-reported-denominator.json'), 'utf8'));
const sameCauseVariant = JSON.parse(fs.readFileSync(path.join(root, 'fixtures', 'error-zoo', 'mismatched-external-denominator.json'), 'utf8'));
const originalLegacyErrors = legacyCoverageErrors(originalSpecimen);
const variantLegacyErrors = legacyCoverageErrors(sameCauseVariant);
const originalFixedErrors = validate(originalSpecimen);
const variantFixedErrors = validate(sameCauseVariant);
assert.deepEqual(originalLegacyErrors, []);
assert.deepEqual(variantLegacyErrors, []);
assert.ok(originalFixedErrors.some((error) => error.includes('外部依据类型')));
assert.ok(variantFixedErrors.some((error) => error.includes('分母')));

console.log(JSON.stringify({
  message: '反假绿判卷程序自测通过：正确对照放行，错误对照和伪造凭证均被拦截。',
  root_cause_proof: [{
    id: 'external-denominator-trust',
    symptom: '系统自报总数也能被旧检查放行',
    root_cause: '旧检查只核对报告内部数字，没有与系统外部清单对账',
    falsifiable_prediction: '换一种自报总数的外观，旧检查仍会放行',
    shared_fix_location: 'assertions/validate-gate-report.js:validateCoverageClaims',
    before_fix: {
      original_specimen: 'fixtures/error-zoo/self-reported-denominator.json',
      same_cause_variant_specimen: 'fixtures/error-zoo/mismatched-external-denominator.json',
      original_escaped: originalLegacyErrors.length === 0,
      same_cause_variant_escaped: variantLegacyErrors.length === 0,
    },
    after_fix: {
      positive_passed: validate(valid).length === 0,
      original_rejected: originalFixedErrors.length > 0,
      same_cause_variant_rejected: variantFixedErrors.length > 0,
    },
  }],
}, null, 2));

fs.rmSync(temp, { recursive: true, force: true });
