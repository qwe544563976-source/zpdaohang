#!/usr/bin/env python3
"""Run the judgment-navigation positive, negative, and blank controls."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parents[1]
DEFAULT_VALIDATOR = (
    Path.home()
    / ".codex"
    / "skills"
    / "book-to-judgment-navigation"
    / "scripts"
    / "validate_delivery.py"
)
DEFAULT_POSITIVE = WORKSPACE / "_judgment_distillation_pilot_bphs97_ch11_20260814"
DEFAULT_NEGATIVE = WORKSPACE / "_anti_false_green_runs" / "independent-receipt-spoof-20260814"
ARTIFACT_RELATIVE_PATHS = (
    Path("references/navigation/method-recipes.json"),
    Path("references/navigation/query-recipes.json"),
    Path("validation/offline-exam.json"),
)


def read_json(path: Path) -> dict:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"JSON 顶层必须是对象：{path}")
    return data


def write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def artifact_bindings(target: Path) -> list[dict[str, str]]:
    bindings = []
    for relative_path in ARTIFACT_RELATIVE_PATHS:
        artifact_path = target / relative_path
        if artifact_path.is_file():
            bindings.append({
                "path": str(artifact_path.resolve()),
                "sha256": sha256_file(artifact_path),
            })
    return bindings


def run_control(label: str, validator: Path, target: Path, output_dir: Path) -> dict:
    result = subprocess.run(
        [sys.executable, str(validator), str(target)],
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    report: dict = {}
    parse_error = ""
    try:
        report = json.loads(result.stdout)
        if not isinstance(report, dict):
            raise ValueError("验证器输出顶层不是对象")
    except (json.JSONDecodeError, ValueError) as exc:
        parse_error = str(exc)

    record = {
        "label": label,
        "target": str(target.resolve()),
        "exit_code": result.returncode,
        "validator_report": report,
        "parse_error": parse_error,
        "stderr": result.stderr,
    }
    record_path = output_dir / f"{label}-run.json"
    write_json(record_path, record)
    record["record_path"] = str(record_path.resolve())
    return record


def classify(record: dict) -> str:
    report = record["validator_report"]
    if record["parse_error"] or not isinstance(report.get("passed"), bool):
        return "error"
    if record["exit_code"] == 0 and report["passed"] is True:
        return "pass"
    if record["exit_code"] != 0 and report["passed"] is False:
        return "fail"
    return "error"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--validator", type=Path, default=DEFAULT_VALIDATOR)
    parser.add_argument("--positive", type=Path, default=DEFAULT_POSITIVE)
    parser.add_argument("--negative", type=Path, default=DEFAULT_NEGATIVE)
    parser.add_argument("--baseline", type=Path)
    parser.add_argument("--output-dir", type=Path)
    args = parser.parse_args()

    output_dir = args.output_dir or (
        ROOT / "results" / f"distillation-gate-controls-{datetime.now():%Y%m%d-%H%M%S}"
    )
    output_dir = output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    baseline = (args.baseline or output_dir / "blank-fixture").resolve()
    baseline.mkdir(parents=True, exist_ok=True)

    runs = {
        "positive": run_control("positive", args.validator.resolve(), args.positive.resolve(), output_dir),
        "negative": run_control("negative", args.validator.resolve(), args.negative.resolve(), output_dir),
        "baseline": run_control("baseline", args.validator.resolve(), baseline, output_dir),
    }
    controls = {name: classify(record) for name, record in runs.items()}

    source_path = args.positive.resolve() / "DISTILLATION_SOURCE.json"
    source_manifest = read_json(source_path)
    evidence_atoms_path = Path(source_manifest["evidence_atoms_path"])
    if not evidence_atoms_path.is_absolute():
        evidence_atoms_path = (source_path.parent / evidence_atoms_path).resolve()
    source = {
        "book_id": source_manifest["book_id"],
        "edition": source_manifest["edition_id"],
        "source_path": str(source_path),
        "source_fingerprint": sha256_file(source_path),
        "evidence_atoms_path": str(evidence_atoms_path),
        "evidence_atoms_fingerprint": sha256_file(evidence_atoms_path),
    }
    bindings = artifact_bindings(args.positive.resolve())
    receipt = {
        "schema_version": "anti-false-green-run-v1",
        "status": "completed",
        "source": source,
        "artifact_bindings": bindings,
        "runs": runs,
    }
    audit = {
        "producer": "scripts/run_controls.py",
        "validator": args.validator.name,
        "auditor": {
            "kind": "program",
            "id": "assertions/validate-gate-report.js",
            "version": "anti-false-green-gate-v1",
            "config_ref": "assertions/validate-gate-report.js",
        },
        "independent": True,
        "command": " ".join([sys.executable, *sys.argv]),
        "started_at": datetime.now().astimezone().isoformat(),
    }
    receipt["audit"] = audit
    receipt_path = output_dir / "run-receipt.json"
    write_json(receipt_path, receipt)

    expected = {"positive": "pass", "negative": "fail", "baseline": "fail"}
    blockers = [
        f"{name} 对照实际为 {controls[name]}，预期为 {expected[name]}"
        for name in expected
        if controls[name] != expected[name]
    ]
    counts = {
        "total": 3,
        "passed": sum(value == "pass" for value in controls.values()),
        "failed": sum(value == "fail" for value in controls.values()),
        "errored": sum(value == "error" for value in controls.values()),
        "abstained": 0,
        "skipped": 0,
    }
    gate_report = {
        "schema_version": "anti-false-green-gate-v1",
        "source": source,
        "artifact_bindings": bindings,
        "controls": controls,
        "counts": counts,
        "coverage_claims": [],
        "unchecked_scope": ["本轮只验证三份控制样本，不代表正式切卡、蒸馏或整书内容正确"],
        "metric_definitions": [{
            "id": "controls-total-v1",
            "name": "三份对照总数",
            "numerator": 3,
            "denominator": 3,
            "scope": "positive,negative,baseline",
            "numerator_source": "run_receipt.runs",
            "denominator_source": "固定三份对照合同",
        }],
        "audit": audit,
        "run_receipt": str(receipt_path.resolve()),
        "unresolved_blockers": blockers,
        "release_authority": "human_only",
        "status": "machine_check_pass" if not blockers else "invalid_exam",
    }
    gate_path = output_dir / "gate-report.json"
    write_json(gate_path, gate_report)

    judge = subprocess.run(
        ["node", str(ROOT / "assertions" / "validate-gate-report.js"), str(gate_path)],
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    print(judge.stdout, end="")
    if judge.stderr:
        print(judge.stderr, file=sys.stderr, end="")
    return judge.returncode


if __name__ == "__main__":
    raise SystemExit(main())
