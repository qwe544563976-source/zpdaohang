# BPHS 97 章版章节与单元索引

| 单元 | 标题 | 卡片数 | 文件 |
|---|---|---:|---|
| 第 1 章 | The Creation | 9 | [ch001-the-creation.md](chapters/ch001-the-creation.md) |
| 第 2 章 | Great Incarnations (Of The Lord) | 5 | [ch002-great-incarnations-of-the-lord.md](chapters/ch002-great-incarnations-of-the-lord.md) |
| 第 3 章 | Grah Characters and Description | 62 | [ch003-grah-characters-and-description.md](chapters/ch003-grah-characters-and-description.md) |
| 第 4 章 | Zodiacal Rashis Described | 17 | [ch004-zodiacal-rashis-described.md](chapters/ch004-zodiacal-rashis-described.md) |
| 第 5 章 | Special Lagnas | 9 | [ch005-special-lagnas.md](chapters/ch005-special-lagnas.md) |
| 第 6 章 | The Sixteen Divisions of a Rashi | 20 | [ch006-the-sixteen-divisions-of-a-rashi.md](chapters/ch006-the-sixteen-divisions-of-a-rashi.md) |
| 第 7 章 | Divisional Considerations | 13 | [ch007-divisional-considerations.md](chapters/ch007-divisional-considerations.md) |
| 第 8 章 | Drishtis of the Rashis | 3 | [ch008-drishtis-of-the-rashis.md](chapters/ch008-drishtis-of-the-rashis.md) |
| 第 9 章 | Evils at Birth | 36 | [ch009-evils-at-birth.md](chapters/ch009-evils-at-birth.md) |
| 第 10 章 | Antidotes for Evils | 8 | [ch010-antidotes-for-evils.md](chapters/ch010-antidotes-for-evils.md) |
| 第 11 章 | Judgement of Bhavas | 14 | [ch011-judgement-of-bhavas.md](chapters/ch011-judgement-of-bhavas.md) |
| 第 12 章 | Effects of Tanu Bhava | 10 | [ch012-effects-of-tanu-bhava.md](chapters/ch012-effects-of-tanu-bhava.md) |
| 第 13 章 | Effects of Dhan Bhava | 11 | [ch013-effects-of-dhan-bhava.md](chapters/ch013-effects-of-dhan-bhava.md) |
| 第 14 章 | Effects of Sahaj Bhava | 9 | [ch014-effects-of-sahaj-bhava.md](chapters/ch014-effects-of-sahaj-bhava.md) |
| 第 15 章 | Effects of Bandhu Bhava | 10 | [ch015-effects-of-bandhu-bhava.md](chapters/ch015-effects-of-bandhu-bhava.md) |
| 第 16 章 | Effects of Putr Bhava | 22 | [ch016-effects-of-putr-bhava.md](chapters/ch016-effects-of-putr-bhava.md) |
| 第 17 章 | Effects of Ari Bhava | 12 | [ch017-effects-of-ari-bhava.md](chapters/ch017-effects-of-ari-bhava.md) |
| 第 18 章 | Effects Of Yuvati Bhava | 29 | [ch018-effects-of-yuvati-bhava.md](chapters/ch018-effects-of-yuvati-bhava.md) |
| 第 19 章 | Effects of Randhr Bhava | 7 | [ch019-effects-of-randhr-bhava.md](chapters/ch019-effects-of-randhr-bhava.md) |
| 第 20 章 | Effects Of Dharm Bhava | 18 | [ch020-effects-of-dharm-bhava.md](chapters/ch020-effects-of-dharm-bhava.md) |
| 第 21 章 | Effects of Karm Bhava | 17 | [ch021-effects-of-karm-bhava.md](chapters/ch021-effects-of-karm-bhava.md) |
| 第 22 章 | Effects Of Labh Bhava | 11 | [ch022-effects-of-labh-bhava.md](chapters/ch022-effects-of-labh-bhava.md) |
| 第 23 章 | Effects Of Vyaya Bhava | 10 | [ch023-effects-of-vyaya-bhava.md](chapters/ch023-effects-of-vyaya-bhava.md) |
| 第 24 章 | Effects of the Bhava Lords | 142 | [ch024-effects-of-the-bhava-lords.md](chapters/ch024-effects-of-the-bhava-lords.md) |
| 第 25 章 | Effects of Non-Luminous Grahas | 85 | [ch025-effects-of-non-luminous-grahas.md](chapters/ch025-effects-of-non-luminous-grahas.md) |
| 第 26 章 | Evaluation of Drishtis of Grahas | 6 | [ch026-evaluation-of-drishtis-of-grahas.md](chapters/ch026-evaluation-of-drishtis-of-grahas.md) |
| 第 27 章 | Evaluation Of Strengths | 44 | [ch027-evaluation-of-strengths.md](chapters/ch027-evaluation-of-strengths.md) |
| 第 28 章 | Isht and Kasht Balas | 10 | [ch028-isht-and-kasht-balas.md](chapters/ch028-isht-and-kasht-balas.md) |
| 第 29 章 | Bhava Padas | 32 | [ch029-bhava-padas.md](chapters/ch029-bhava-padas.md) |
| 第 30 章 | Upa Pad | 20 | [ch030-upa-pad.md](chapters/ch030-upa-pad.md) |
| 第 31 章 | Argala or Intervention from Grahas | 11 | [ch031-argala-or-intervention-from-grahas.md](chapters/ch031-argala-or-intervention-from-grahas.md) |
| 第 32 章 | Karakatwas of the Grahas | 17 | [ch032-karakatwas-of-the-grahas.md](chapters/ch032-karakatwas-of-the-grahas.md) |
| 第 33 章 | Effects of Karakamsh | 30 | [ch033-effects-of-karakamsh.md](chapters/ch033-effects-of-karakamsh.md) |
| 第 34 章 | Yoga Karakas | 23 | [ch034-yoga-karakas.md](chapters/ch034-yoga-karakas.md) |
| 第 35 章 | Nabhash Yogas | 43 | [ch035-nabhash-yogas.md](chapters/ch035-nabhash-yogas.md) |
| 第 36 章 | Many Other Yogas | 21 | [ch036-many-other-yogas.md](chapters/ch036-many-other-yogas.md) |
| 第 37 章 | Chandr's Yogas | 6 | [ch037-chandr-s-yogas.md](chapters/ch037-chandr-s-yogas.md) |
| 第 38 章 | Surya's Yogas | 3 | [ch038-surya-s-yogas.md](chapters/ch038-surya-s-yogas.md) |
| 第 39 章 | Raj Yog | 38 | [ch039-raj-yog.md](chapters/ch039-raj-yog.md) |
| 第 40 章 | Yogas For Royal Association | 15 | [ch040-yogas-for-royal-association.md](chapters/ch040-yogas-for-royal-association.md) |
| 第 41 章 | Combinations For Wealth | 23 | [ch041-combinations-for-wealth.md](chapters/ch041-combinations-for-wealth.md) |
| 第 42 章 | Combinations for Penury | 16 | [ch042-combinations-for-penury.md](chapters/ch042-combinations-for-penury.md) |
| 第 43 章 | Longevity | 46 | [ch043-longevity.md](chapters/ch043-longevity.md) |
| 第 44 章 | Marak (Killer) Grahas | 19 | [ch044-marak-killer-grahas.md](chapters/ch044-marak-killer-grahas.md) |
| 第 45 章 | Avasthas of Grahas | 55 | [ch045-avasthas-of-grahas.md](chapters/ch045-avasthas-of-grahas.md) |
| 第 46 章 | Dashas of Grahas | 98 | [ch046-dashas-of-grahas.md](chapters/ch046-dashas-of-grahas.md) |
| 第 47 章 | Effects of Dashas | 28 | [ch047-effects-of-dashas.md](chapters/ch047-effects-of-dashas.md) |
| 第 48 章 | Distinctive Effects of the Nakshatr Dasha or of the | 6 | [ch048-distinctive-effects-of-the-nakshatr-dasha-or-of-the.md](chapters/ch048-distinctive-effects-of-the-nakshatr-dasha-or-of-the.md) |
| 第 49 章 | Effects of the Kaal Chakr Dasha | 14 | [ch049-effects-of-the-kaal-chakr-dasha.md](chapters/ch049-effects-of-the-kaal-chakr-dasha.md) |
| 第 50 章 | Effects of the Char, etc., Dashas | 32 | [ch050-effects-of-the-char-etc-dashas.md](chapters/ch050-effects-of-the-char-etc-dashas.md) |
| 第 51 章 | Working out of Antar Dashas of Grahas and Rashis | 10 | [ch051-working-out-of-antar-dashas-of-grahas-and-rashis.md](chapters/ch051-working-out-of-antar-dashas-of-grahas-and-rashis.md) |
| 第 52 章 | Effects of the Antar Dashas in the Dasha of | 27 | [ch052-effects-of-the-antar-dashas-in-the-dasha-of.md](chapters/ch052-effects-of-the-antar-dashas-in-the-dasha-of.md) |
| 第 53 章 | Effects of the Antar Dashas in the Dasha of | 29 | [ch053-effects-of-the-antar-dashas-in-the-dasha-of.md](chapters/ch053-effects-of-the-antar-dashas-in-the-dasha-of.md) |
| 第 54 章 | Effects of Antar Dashas in the Dashas of Mangal | 33 | [ch054-effects-of-antar-dashas-in-the-dashas-of-mangal.md](chapters/ch054-effects-of-antar-dashas-in-the-dashas-of-mangal.md) |
| 第 55 章 | Effects in the Antar Dashas in the Dasha of | 34 | [ch055-effects-in-the-antar-dashas-in-the-dasha-of.md](chapters/ch055-effects-in-the-antar-dashas-in-the-dasha-of.md) |
| 第 56 章 | Effects of the Antar Dashas in the Dasha of | 36 | [ch056-effects-of-the-antar-dashas-in-the-dasha-of.md](chapters/ch056-effects-of-the-antar-dashas-in-the-dasha-of.md) |
| 第 57 章 | Effects of the Antar Dashas in the Dasha of | 36 | [ch057-effects-of-the-antar-dashas-in-the-dasha-of.md](chapters/ch057-effects-of-the-antar-dashas-in-the-dasha-of.md) |
| 第 58 章 | Effects of the Antar Dashas in the Dasha of | 34 | [ch058-effects-of-the-antar-dashas-in-the-dasha-of.md](chapters/ch058-effects-of-the-antar-dashas-in-the-dasha-of.md) |
| 第 59 章 | Effects of the Antar Dashas in the Dasha of | 34 | [ch059-effects-of-the-antar-dashas-in-the-dasha-of.md](chapters/ch059-effects-of-the-antar-dashas-in-the-dasha-of.md) |
| 第 60 章 | Effects in the Antar Dashas of Shukr | 34 | [ch060-effects-in-the-antar-dashas-of-shukr.md](chapters/ch060-effects-in-the-antar-dashas-of-shukr.md) |
| 第 61 章 | Effects of Pratyantar Dashas in the Antar | 82 | [ch061-effects-of-pratyantar-dashas-in-the-antar.md](chapters/ch061-effects-of-pratyantar-dashas-in-the-antar.md) |
| 第 62 章 | Effects of the Sukshmantar Dashas in the | 83 | [ch062-effects-of-the-sukshmantar-dashas-in-the.md](chapters/ch062-effects-of-the-sukshmantar-dashas-in-the.md) |
| 第 63 章 | Effects of Prana Dashas in the Sukshma Dasha of | 82 | [ch063-effects-of-prana-dashas-in-the-sukshma-dasha-of.md](chapters/ch063-effects-of-prana-dashas-in-the-sukshma-dasha-of.md) |
| 第 64 章 | Effects of Antar Dashas in the Kala Chakr Dasha | 14 | [ch064-effects-of-antar-dashas-in-the-kala-chakr-dasha.md](chapters/ch064-effects-of-antar-dashas-in-the-kala-chakr-dasha.md) |
| 第 65 章 | Effects of Dashas of Rashis in the Amshas of | 14 | [ch065-effects-of-dashas-of-rashis-in-the-amshas-of.md](chapters/ch065-effects-of-dashas-of-rashis-in-the-amshas-of.md) |
| 第 66 章 | Ashtakavarg | 24 | [ch066-ashtakavarg.md](chapters/ch066-ashtakavarg.md) |
| 第 67 章 | Trikon Shodhana (rectification) in the | 3 | [ch067-trikon-shodhana-rectification-in-the.md](chapters/ch067-trikon-shodhana-rectification-in-the.md) |
| 第 68 章 | Ekadhipatya Shodhana in the Ashtakavarg Scheme | 3 | [ch068-ekadhipatya-shodhana-in-the-ashtakavarg-scheme.md](chapters/ch068-ekadhipatya-shodhana-in-the-ashtakavarg-scheme.md) |
| 第 69 章 | Pinda Sadhana in the Ashtakavarg Scheme | 2 | [ch069-pinda-sadhana-in-the-ashtakavarg-scheme.md](chapters/ch069-pinda-sadhana-in-the-ashtakavarg-scheme.md) |
| 第 70 章 | Effects of the Ashtakavarg | 30 | [ch070-effects-of-the-ashtakavarg.md](chapters/ch070-effects-of-the-ashtakavarg.md) |
| 第 71 章 | Determination of Longevity through the Ashtakavarg | 1 | [ch071-determination-of-longevity-through-the-ashtakavarg.md](chapters/ch071-determination-of-longevity-through-the-ashtakavarg.md) |
| 第 72 章 | Aggregational Ashtakavargas | 12 | [ch072-aggregational-ashtakavargas.md](chapters/ch072-aggregational-ashtakavargas.md) |
| 第 73 章 | Effects of the Rays of the Grahas | 7 | [ch073-effects-of-the-rays-of-the-grahas.md](chapters/ch073-effects-of-the-rays-of-the-grahas.md) |
| 第 74 章 | Effects of the Sudarshana Chakr | 14 | [ch074-effects-of-the-sudarshana-chakr.md](chapters/ch074-effects-of-the-sudarshana-chakr.md) |
| 第 75 章 | Characteristic Features of Panchmahapurushas | 6 | [ch075-characteristic-features-of-panchmahapurushas.md](chapters/ch075-characteristic-features-of-panchmahapurushas.md) |
| 第 76 章 | Effects of the five Elements : Space, Air, Fire, | 18 | [ch076-effects-of-the-five-elements-space-air-fire.md](chapters/ch076-effects-of-the-five-elements-space-air-fire.md) |
| 第 77 章 | Effects of Satwa Gun, etc. | 19 | [ch077-effects-of-satwa-gun-etc.md](chapters/ch077-effects-of-satwa-gun-etc.md) |
| 第 78 章 | Lost Horoscopy | 8 | [ch078-lost-horoscopy.md](chapters/ch078-lost-horoscopy.md) |
| 第 79 章 | Yogas leading to Ascetism | 15 | [ch079-yogas-leading-to-ascetism.md](chapters/ch079-yogas-leading-to-ascetism.md) |
| 第 80 章 | Female Horoscopy | 35 | [ch080-female-horoscopy.md](chapters/ch080-female-horoscopy.md) |
| 第 81 章 | Effects of the Characteristic Features of the | 51 | [ch081-effects-of-the-characteristic-features-of-the.md](chapters/ch081-effects-of-the-characteristic-features-of-the.md) |
| 第 82 章 | Effects of Moles, Marks, Signs, etc., for Men | 11 | [ch082-effects-of-moles-marks-signs-etc-for-men.md](chapters/ch082-effects-of-moles-marks-signs-etc-for-men.md) |
| 第 83 章 | Effects of curses in the previous birth | 27 | [ch083-effects-of-curses-in-the-previous-birth.md](chapters/ch083-effects-of-curses-in-the-previous-birth.md) |
| 第 84 章 | Remedial measures to obtain relief from the | 19 | [ch084-remedial-measures-to-obtain-relief-from-the.md](chapters/ch084-remedial-measures-to-obtain-relief-from-the.md) |
| 第 85 章 | Inauspicious Births | 1 | [ch085-inauspicious-births.md](chapters/ch085-inauspicious-births.md) |
| 第 86 章 | Remedial Measures for Birth on Amavasya | 2 | [ch086-remedial-measures-for-birth-on-amavasya.md](chapters/ch086-remedial-measures-for-birth-on-amavasya.md) |
| 第 87 章 | Remedies from the evil effects of birth on | 4 | [ch087-remedies-from-the-evil-effects-of-birth-on.md](chapters/ch087-remedies-from-the-evil-effects-of-birth-on.md) |
| 第 88 章 | Remedies from evil effects of birth in Bhadra and | 3 | [ch088-remedies-from-evil-effects-of-birth-in-bhadra-and.md](chapters/ch088-remedies-from-evil-effects-of-birth-in-bhadra-and.md) |
| 第 89 章 | Remedies from Nakshatr Birth | 2 | [ch089-remedies-from-nakshatr-birth.md](chapters/ch089-remedies-from-nakshatr-birth.md) |
| 第 90 章 | Remedies from Sankranti Birth | 5 | [ch090-remedies-from-sankranti-birth.md](chapters/ch090-remedies-from-sankranti-birth.md) |
| 第 91 章 | Remedies for Birth in Eclipses | 3 | [ch091-remedies-for-birth-in-eclipses.md](chapters/ch091-remedies-for-birth-in-eclipses.md) |
| 第 92 章 | Remedies from Birth in Gandanta | 7 | [ch092-remedies-from-birth-in-gandanta.md](chapters/ch092-remedies-from-birth-in-gandanta.md) |
| 第 93 章 | Remedies for Birth in Abhukta Mula | 7 | [ch093-remedies-for-birth-in-abhukta-mula.md](chapters/ch093-remedies-for-birth-in-abhukta-mula.md) |
| 第 94 章 | Remedies from Effects of Birth in Jyeshtha Gandanta | 6 | [ch094-remedies-from-effects-of-birth-in-jyeshtha-gandanta.md](chapters/ch094-remedies-from-effects-of-birth-in-jyeshtha-gandanta.md) |
| 第 95 章 | Remedies from the effects of birth of a daughter after three | 4 | [ch095-remedies-from-the-effects-of-birth-of-a-daughter-after-three.md](chapters/ch095-remedies-from-the-effects-of-birth-of-a-daughter-after-three.md) |
| 第 96 章 | Remedies from evil effects of unusual delivery | 4 | [ch096-remedies-from-evil-effects-of-unusual-delivery.md](chapters/ch096-remedies-from-evil-effects-of-unusual-delivery.md) |
| 第 97 章 | Conclusion | 5 | [ch097-conclusion.md](chapters/ch097-conclusion.md) |
