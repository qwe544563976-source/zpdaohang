# BPHS 97 章版与 100 章版章节语义映射

章节号不直接等同；本表先按标题语义一对一配对，再做卡片/偈颂差异。

| 97 版 | 标题 | 100 版 | 标题 | 对齐 | 分数 |
|---:|---|---:|---|---|---:|
| 1 | The Creation | 1 | The Creation | fixed-version-map | 1.0 |
| 2 | Great Incarnations (Of The Lord) | 2 | Great Incarnations (Of The Lord) | fixed-version-map | 1.0 |
| 3 | Grah Characters and Description | 3 | Graha Characters and Description | fixed-version-map | 0.9841 |
| 4 | Zodiacal Rashis Described | 4 | Zodiacal Rashis Described | fixed-version-map | 1.0 |
| 5 | Special Lagnas | 6 | Special Lagnas | fixed-version-map | 1.0 |
| 6 | The Sixteen Divisions of a Rashi | 7 | The Sixteen Divisions of a Rashi | fixed-version-map | 1.0 |
| 7 | Divisional Considerations | 8 | Divisional Considerations | fixed-version-map | 1.0 |
| 8 | Drishtis of the Rashis | 9 | Drishtis of the Rashis | fixed-version-map | 1.0 |
| 9 | Evils at Birth | 11 | Evils at Birth | fixed-version-map | 1.0 |
| 10 | Antidotes for Evils | 12 | Antidotes for Evils | fixed-version-map | 1.0 |
| 11 | Judgement of Bhavas | 13 | Judgement of Bhavas | fixed-version-map | 1.0 |
| 12 | Effects of Tanu Bhava | 14 | Effects of Tanu Bhava | fixed-version-map | 1.0 |
| 13 | Effects of Dhan Bhava | 15 | Effects of Dhana Bhava | fixed-version-map | 0.9767 |
| 14 | Effects of Sahaj Bhava | 16 | Effects of Sahaj Bhava | fixed-version-map | 1.0 |
| 15 | Effects of Bandhu Bhava | 17 | Effects of Sukha Bhava | fixed-version-map | 0.8 |
| 16 | Effects of Putr Bhava | 18 | Effects of Putra Bhava | fixed-version-map | 0.9767 |
| 17 | Effects of Ari Bhava | 19 | Effects of Ari Bhava | fixed-version-map | 1.0 |
| 18 | Effects Of Yuvati Bhava | 20 | Effects Of Yuvati Bhava | fixed-version-map | 1.0 |
| 19 | Effects of Randhr Bhava | 21 | Effects of Randhra Bhava | fixed-version-map | 0.9787 |
| 20 | Effects Of Dharm Bhava | 22 | Effects Of Dharma Bhava | fixed-version-map | 0.9778 |
| 21 | Effects of Karm Bhava | 23 | Effects of Karma Bhava | fixed-version-map | 0.9767 |
| 22 | Effects Of Labh Bhava | 24 | Effects Of Labha Bhava | fixed-version-map | 0.9767 |
| 23 | Effects Of Vyaya Bhava | 25 | Effects Of Vyaya Bhava | fixed-version-map | 1.0 |
| 24 | Effects of the Bhava Lords | 26 | Effects of the Bhava Lords | fixed-version-map | 1.0 |
| 25 | Effects of Non-Luminous Grahas | 27 | Effects of Non Luminous Grahas | fixed-version-map | 1.0 |
| 26 | Evaluation of Drishtis of Grahas | 28 | Evaluation of Drishtis of Grahas | fixed-version-map | 1.0 |
| 27 | Evaluation Of Strengths | 29 | Evaluation Of Strengths | fixed-version-map | 1.0 |
| 28 | Isht and Kasht Balas | 30 | Ishta and Kashta Balas | fixed-version-map | 0.9524 |
| 29 | Bhava Padas | 31 | Bhava Padas | fixed-version-map | 1.0 |
| 30 | Upa Pad | 32 | Upa Pada | fixed-version-map | 0.9333 |
| 31 | Argala or Intervention from Grahas | 33 | Argala or Intervention from Grahas | fixed-version-map | 1.0 |
| 32 | Karakatwas of the Grahas | 34 | Karakatwas of the Grahas | fixed-version-map | 1.0 |
| 33 | Effects of Karakamsh | 35 | Effects of Karakamsha | fixed-version-map | 0.9756 |
| 34 | Yoga Karakas | 36 | Yoga Karakas | fixed-version-map | 1.0 |
| 35 | Nabhash Yogas | 37 | Nabhash Yogas | fixed-version-map | 1.0 |
| 36 | Many Other Yogas | 38 | Many Other Yogas | fixed-version-map | 1.0 |
| 37 | Chandr's Yogas | 39 | Chandra's Yogas | fixed-version-map | 0.9655 |
| 38 | Surya's Yogas | 40 | Surya's Yogas | fixed-version-map | 1.0 |
| 39 | Raj Yog | 41 | Raj Yoga | fixed-version-map | 0.9333 |
| 40 | Yogas For Royal Association | 42 | Yogas For Royal Association | fixed-version-map | 1.0 |
| 41 | Combinations For Wealth | 43 | Combinations For Wealth | fixed-version-map | 1.0 |
| 42 | Combinations for Penury | 44 | Combinations for Penury | fixed-version-map | 1.0 |
| 43 | Longevity | 45 | Longevity | fixed-version-map | 1.0 |
| 44 | Marak (Killer) Grahas | 46 | Maraka (Killer) Grahas | fixed-version-map | 0.9744 |
| 45 | Avasthas of Grahas | 47 | Avasthas of Grahas | fixed-version-map | 1.0 |
| 46 | Dashas of Grahas | 48 | Dashas of Grahas | fixed-version-map | 1.0 |
| 47 | Effects of Dashas | 49 | Effects of Dashas | fixed-version-map | 1.0 |
| 48 | Distinctive Effects of the Nakshatr Dasha or of the | 50 | Distinctive Effects of the Nakshatra Dasha or | fixed-version-map | 0.9167 |
| 49 | Effects of the Kaal Chakr Dasha | 51 | Effects of the Kaal Chakra Dasha | fixed-version-map | 0.9841 |
| 50 | Effects of the Char, etc., Dashas | 52 | Effects of the Char, etc., Dashas | fixed-version-map | 1.0 |
| 51 | Working out of Antar Dashas of Grahas and Rashis | 53 | Working out of Antara Dashas of Grahas and Rashis | fixed-version-map | 0.9897 |
| 52 | Effects of the Antar Dashas in the Dasha of | 54 | Effects of the Antara Dashas in the Dasha of Surya according | fixed-version-map | 0.835 |
| 53 | Effects of the Antar Dashas in the Dasha of | 55 | Effects of the Antara Dashas in the Dasha of Chandra | fixed-version-map | 0.9053 |
| 54 | Effects of Antar Dashas in the Dashas of Mangal | 56 | Effects of Antara Dashas in the Dashas of Mangal | fixed-version-map | 0.9895 |
| 55 | Effects in the Antar Dashas in the Dasha of | 57 | Effects in the Antara Dashas in the Dasha of Rahu | fixed-version-map | 0.9348 |
| 56 | Effects of the Antar Dashas in the Dasha of | 58 | Effects of the Antara Dashas in the Dasha of Guru | fixed-version-map | 0.9348 |
| 57 | Effects of the Antar Dashas in the Dasha of | 59 | Effects of the Antara Dashas in the Dasha of Shani | fixed-version-map | 0.9247 |
| 58 | Effects of the Antar Dashas in the Dasha of | 60 | Effects of the Antara Dashas in the Dasha of Buddha | fixed-version-map | 0.9149 |
| 59 | Effects of the Antar Dashas in the Dasha of | 61 | Effects of the Antara Dashas in the Dasha of Ketu | fixed-version-map | 0.9348 |
| 60 | Effects in the Antar Dashas of Shukr | 62 | Effects in the Antara Dashas of Shukra | fixed-version-map | 0.973 |
| 61 | Effects of Pratyantar Dashas in the Antar | 63 | Effects of Pratyantara Dashas in the Antara Dasha of Grahas | fixed-version-map | 0.82 |
| 62 | Effects of the Sukshmantar Dashas in the | 64 | Effects of the Sukshmantaraa Dashas in the Pratyantara | fixed-version-map | 0.8511 |
| 63 | Effects of Prana Dashas in the Sukshma Dasha of | 65 | Effects of Prana Dashas in the Sukshma Dasha of the | fixed-version-map | 0.9592 |
| 64 | Effects of Antar Dashas in the Kala Chakr Dasha | 66 | Effects of Antara Dashas in the Kala Chakra Dasha | fixed-version-map | 0.9792 |
| 65 | Effects of Dashas of Rashis in the Amshas of | 67 | Effects of Dashas of Rashis in the Amshas of the Various | fixed-version-map | 0.88 |
| 66 | Ashtakavarg | 68 | Ashtakavarga | fixed-version-map | 0.9565 |
| 67 | Trikon Shodhana (rectification) in the | 69 | Trikona Shodhana (rectification) in the Ashtakavarga | fixed-version-map | 0.8372 |
| 68 | Ekadhipatya Shodhana in the Ashtakavarg Scheme | 70 | Ekadhipatya Shodhana in the Ashtakavarga Scheme | fixed-version-map | 0.9892 |
| 69 | Pinda Sadhana in the Ashtakavarg Scheme | 71 | Pinda Sadhana in the Ashtakavarga Scheme | fixed-version-map | 0.9873 |
| 70 | Effects of the Ashtakavarg | 72 | Effects of the Ashtakavarga | fixed-version-map | 0.9811 |
| 71 | Determination of Longevity through the Ashtakavarg | 73 | Determination of Longevity through the Ashtakavarga | fixed-version-map | 0.9901 |
| 72 | Aggregational Ashtakavargas | 74 | Aggregational Ashtakavargas | fixed-version-map | 1.0 |
| 73 | Effects of the Rays of the Grahas | 75 | Effects of the Rays of the Grahas | fixed-version-map | 1.0 |
| 74 | Effects of the Sudarshana Chakr | 76 | Effects of the Sudarshana Chakra | fixed-version-map | 0.9841 |
| 75 | Characteristic Features of Panchmahapurushas | 77 | Characteristic Features of Panchmahapurushas | fixed-version-map | 1.0 |
| 76 | Effects of the five Elements : Space, Air, Fire, | 78 | Effects of the five Elements : (Space, Air, Fire, | fixed-version-map | 1.0 |
| 77 | Effects of Satwa Gun, etc. | 79 | Effects of Satwa Guna, etc. | fixed-version-map | 0.9796 |
| 78 | Lost Horoscopy | 80 | Lost Horoscope | fixed-version-map | 0.9286 |
| 79 | Yogas leading to Ascetism | 81 | Yogas leading to Ascetism | fixed-version-map | 1.0 |
| 80 | Female Horoscopy | 82 | Interpretation of Female Horoscope | fixed-version-map | 0.6 |
| 81 | Effects of the Characteristic Features of the | 83 | Effects of the Characteristic Features of the Various | fixed-version-map | 0.9184 |
| 82 | Effects of Moles, Marks, Signs, etc., for Men | 84 | Effects of Moles, Marks, Signs, etc., for Men and Women | fixed-version-map | 0.8889 |
| 83 | Effects of curses in the previous birth | 85 | Effects of curses in the previous birth | fixed-version-map | 1.0 |
| 84 | Remedial measures to obtain relief from the | 86 | Remedial measures to obtain relief from the malevolence | fixed-version-map | 0.8776 |
| 85 | Inauspicious Births | 87 | Inauspicious Births | fixed-version-map | 1.0 |
| 86 | Remedial Measures for Birth on Amavasya | 88 | Remedial Measures for Birth on Amavasya | fixed-version-map | 1.0 |
| 87 | Remedies from the evil effects of birth on | 89 | Remedies from the evil effects of birth on Krishna | fixed-version-map | 0.913 |
| 88 | Remedies from evil effects of birth in Bhadra and | 90 | Remedies from evil effects of birth in Bhadra and | fixed-version-map | 1.0 |
| 89 | Remedies from Nakshatr Birth | 91 | Remedies from Nakshatra Birth | fixed-version-map | 0.9825 |
| 90 | Remedies from Sankranti Birth | 92 | Remedies from Sankranti Birth | fixed-version-map | 1.0 |
| 91 | Remedies for Birth in Eclipses | 93 | Remedies for Birth in Eclipses | fixed-version-map | 1.0 |
| 92 | Remedies from Birth in Gandanta | 94 | Remedies from Birth in Gandanta | fixed-version-map | 1.0 |
| 93 | Remedies for Birth in Abhukta Mula | 95 | Remedies for Birth in Abhukta Mula | fixed-version-map | 1.0 |
| 94 | Remedies from Effects of Birth in Jyeshtha Gandanta | 96 | Remedies from Effects of Birth in Jyeshtha Gandanta | fixed-version-map | 1.0 |
| 95 | Remedies from the effects of birth of a daughter after three | 97 | Remedies from the effects of birth of a daughter after | fixed-version-map | 0.9474 |
| 96 | Remedies from evil effects of unusual delivery | 98 | Remedies from evil effects of unusual delivery | fixed-version-map | 1.0 |
| 97 | Conclusion | 100 | Conclusion | fixed-version-map | 1.0 |

## 100 版独有章节

- 第 5 章：Planetary positions.
- 第 10 章：Surroundings at the time of birth.
- 第 99 章：Horary system
