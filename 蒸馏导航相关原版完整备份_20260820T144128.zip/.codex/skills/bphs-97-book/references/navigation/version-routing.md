# BPHS 97 章版版本路由

本文件只决定版本过滤和差异核对，不是原文证据。

## 用户明确要 97 版

- 公共方法：读取 100 章版导航层。
- 原文过滤：`filters.work_ids = ["BPHS_PL9_CHAP_97"]`。
- 正式引用：只接受 `work_id = BPHS_PL9_CHAP_97` 的 RAG 结果。
- 97 版未命中：写“97 章版本次未检索到”，不得用 100 版替代。

## 用户要比较 97／100

分别运行两次版本限定检索：

```json
{"filters":{"work_ids":["BPHS_PL9_CHAP_97"]}}
{"filters":{"work_ids":["BPHS_PL9_MAIN_100"]}}
```

再按以下结构展示：

```text
【97 章版原文】
【100 章版原文】
【逐字核对后可确认的共同点】
【措辞变化或独有内容】
【尚未人工确认的机器差异】
```

## 现有映射的身份

- `differences/chapter-map.md`：章节标题语义映射，用于找对应章节。
- `differences/INDEX.md`：机器统计的措辞变化、独有卡数量。
- `differences/diff-records.jsonl`：2,096 条机器文本对齐记录。
- `differences/differences/chNNN.md`：按章节整理的机器差异视图。

以上都不是人工确认结论。正式版本差异必须回到两版真实原文卡和完整父段。

## 已知版本边界

- 100 版独有第 5 章 `Planetary positions.`、第 10 章 `Surroundings at the time of birth.`、第 99 章 `Horary system`。
- 两版章节号大部分相差 2，但不能用“统一减 2”代替真实章节映射。
- 两版属于同源 BPHS，不得把重复命中当成两部独立古籍的两票。
