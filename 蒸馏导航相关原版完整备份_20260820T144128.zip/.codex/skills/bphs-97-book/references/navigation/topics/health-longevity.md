# BPHS 97 章版：健康与寿命主题入口

公共判断逻辑只读取：`C:/Users/aa/.codex/skills/bphs-100-book/references/navigation/topics/health-longevity.md`。

- 97 版正式过滤：`filters.work_ids = ["BPHS_PL9_CHAP_97"]`
- 97 版常见截尾拼写补充：["Randhr", "Marak", "Ashtakavarg"]
- 97 版目标章节：["第 9 章 Evils at Birth", "第 10 章 Antidotes for Evils", "第 11 章 Judgement of Bhavas", "第 12 章 Effects of Tanu Bhava", "第 17 章 Effects of Ari Bhava", "第 19 章 Effects of Randhr Bhava", "第 24 章 Effects of the Bhava Lords", "第 27 章 Evaluation Of Strengths", "第 28 章 Isht and Kasht Balas", "第 43 章 Longevity", "第 44 章 Marak (Killer) Grahas", "第 45 章 Avasthas of Grahas", "第 46 章 Dashas of Grahas", "第 47 章 Effects of Dashas", "第 71 章 Determination of Longevity through the Ashtakavarg"]
- 100 版目标章节仅用于版本比较：["第 11 章 Evils at Birth", "第 12 章 Antidotes for Evils", "第 13 章 Judgement of Bhavas", "第 14 章 Effects of Tanu Bhava", "第 19 章 Effects of Ari Bhava", "第 21 章 Effects of Randhra Bhava", "第 26 章 Effects of the Bhava Lords", "第 29 章 Evaluation Of Strengths", "第 30 章 Ishta and Kashta Balas", "第 45 章 Longevity", "第 46 章 Maraka (Killer) Grahas", "第 47 章 Avasthas of Grahas", "第 48 章 Dashas of Grahas", "第 49 章 Effects of Dashas", "第 73 章 Determination of Longevity through the Ashtakavarga"]
- 写“本版没有”的章节不得借用 100 版内容补位。
- 正式证据只接受 97 版 RAG 返回的 `work_id + parent_id + card_id + 章节 + 偈号 + PDF 页`。
- 两版冲突时并列展示，不融合、不裁决。
