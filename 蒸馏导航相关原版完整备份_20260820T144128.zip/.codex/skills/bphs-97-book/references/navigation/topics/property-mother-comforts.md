# BPHS 97 章版：房产／母亲／享乐主题入口

公共判断逻辑只读取：`C:/Users/aa/.codex/skills/bphs-100-book/references/navigation/topics/property-mother-comforts.md`。

- 97 版正式过滤：`filters.work_ids = ["BPHS_PL9_CHAP_97"]`
- 97 版常见截尾拼写补充：["Bandhu Bhava", "Bhava Pad", "Antar Dasha"]
- 97 版目标章节：["第 11 章 Judgement of Bhavas", "第 15 章 Effects of Bandhu Bhava", "第 24 章 Effects of the Bhava Lords", "第 29 章 Bhava Padas", "第 32 章 Karakatwas of the Grahas", "第 46 章 Dashas of Grahas", "第 47 章 Effects of Dashas", "第 52 章 Effects of the Antar Dashas in the Dasha of", "第 53 章 Effects of the Antar Dashas in the Dasha of", "第 54 章 Effects of Antar Dashas in the Dashas of Mangal", "第 55 章 Effects in the Antar Dashas in the Dasha of", "第 56 章 Effects of the Antar Dashas in the Dasha of", "第 57 章 Effects of the Antar Dashas in the Dasha of", "第 58 章 Effects of the Antar Dashas in the Dasha of", "第 59 章 Effects of the Antar Dashas in the Dasha of", "第 60 章 Effects in the Antar Dashas of Shukr"]
- 100 版目标章节仅用于版本比较：["第 13 章 Judgement of Bhavas", "第 17 章 Effects of Sukha Bhava", "第 26 章 Effects of the Bhava Lords", "第 31 章 Bhava Padas", "第 34 章 Karakatwas of the Grahas", "第 48 章 Dashas of Grahas", "第 49 章 Effects of Dashas", "第 54 章 Effects of the Antara Dashas in the Dasha of Surya according", "第 55 章 Effects of the Antara Dashas in the Dasha of Chandra", "第 56 章 Effects of Antara Dashas in the Dashas of Mangal", "第 57 章 Effects in the Antara Dashas in the Dasha of Rahu", "第 58 章 Effects of the Antara Dashas in the Dasha of Guru", "第 59 章 Effects of the Antara Dashas in the Dasha of Shani", "第 60 章 Effects of the Antara Dashas in the Dasha of Buddha", "第 61 章 Effects of the Antara Dashas in the Dasha of Ketu", "第 62 章 Effects in the Antara Dashas of Shukra"]
- 写“本版没有”的章节不得借用 100 版内容补位。
- 正式证据只接受 97 版 RAG 返回的 `work_id + parent_id + card_id + 章节 + 偈号 + PDF 页`。
- 两版冲突时并列展示，不融合、不裁决。
