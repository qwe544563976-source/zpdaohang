# BPHS 97 章版：补救措施主题入口

公共判断逻辑只读取：`C:/Users/aa/.codex/skills/bphs-100-book/references/navigation/topics/remedies.md`。

- 97 版正式过滤：`filters.work_ids = ["BPHS_PL9_CHAP_97"]`
- 97 版常见截尾拼写补充：["Nakshatr", "Kaal", "Chakr", "Gandant"]
- 97 版目标章节：["第 84 章 Remedial measures to obtain relief from the", "第 85 章 Inauspicious Births", "第 86 章 Remedial Measures for Birth on Amavasya", "第 87 章 Remedies from the evil effects of birth on", "第 88 章 Remedies from evil effects of birth in Bhadra and", "第 89 章 Remedies from Nakshatr Birth", "第 90 章 Remedies from Sankranti Birth", "第 91 章 Remedies for Birth in Eclipses", "第 92 章 Remedies from Birth in Gandanta", "第 93 章 Remedies for Birth in Abhukta Mula", "第 94 章 Remedies from Effects of Birth in Jyeshtha Gandanta", "第 95 章 Remedies from the effects of birth of a daughter after three", "第 96 章 Remedies from evil effects of unusual delivery"]
- 100 版目标章节仅用于版本比较：["第 86 章 Remedial measures to obtain relief from the malevolence", "第 87 章 Inauspicious Births", "第 88 章 Remedial Measures for Birth on Amavasya", "第 89 章 Remedies from the evil effects of birth on Krishna", "第 90 章 Remedies from evil effects of birth in Bhadra and", "第 91 章 Remedies from Nakshatra Birth", "第 92 章 Remedies from Sankranti Birth", "第 93 章 Remedies for Birth in Eclipses", "第 94 章 Remedies from Birth in Gandanta", "第 95 章 Remedies for Birth in Abhukta Mula", "第 96 章 Remedies from Effects of Birth in Jyeshtha Gandanta", "第 97 章 Remedies from the effects of birth of a daughter after", "第 98 章 Remedies from evil effects of unusual delivery"]
- 写“本版没有”的章节不得借用 100 版内容补位。
- 正式证据只接受 97 版 RAG 返回的 `work_id + parent_id + card_id + 章节 + 偈号 + PDF 页`。
- 两版冲突时并列展示，不融合、不裁决。
