# BPHS 97 章版：前世业力／诅咒主题入口

公共判断逻辑只读取：`C:/Users/aa/.codex/skills/bphs-100-book/references/navigation/topics/karma-curses.md`。

- 97 版正式过滤：`filters.work_ids = ["BPHS_PL9_CHAP_97"]`
- 97 版常见截尾拼写补充：["Putr", "curses in the previous birth", "not having a son"]
- 97 版目标章节：["第 16 章 Effects of Putr Bhava", "第 24 章 Effects of the Bhava Lords", "第 32 章 Karakatwas of the Grahas", "第 80 章 Female Horoscopy", "第 83 章 Effects of curses in the previous birth", "第 84 章 Remedial measures to obtain relief from the"]
- 100 版目标章节仅用于版本比较：["第 18 章 Effects of Putra Bhava", "第 26 章 Effects of the Bhava Lords", "第 34 章 Karakatwas of the Grahas", "第 82 章 Interpretation of Female Horoscope", "第 85 章 Effects of curses in the previous birth", "第 86 章 Remedial measures to obtain relief from the malevolence"]
- 写“本版没有”的章节不得借用 100 版内容补位。
- 正式证据只接受 97 版 RAG 返回的 `work_id + parent_id + card_id + 章节 + 偈号 + PDF 页`。
- 两版冲突时并列展示，不融合、不裁决。
