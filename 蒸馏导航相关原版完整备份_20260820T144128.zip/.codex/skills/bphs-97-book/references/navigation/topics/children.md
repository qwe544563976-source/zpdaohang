# BPHS 97 章版：子女主题入口

公共判断逻辑只读取：`C:/Users/aa/.codex/skills/bphs-100-book/references/navigation/topics/children.md`。

- 97 版正式过滤：`filters.work_ids = ["BPHS_PL9_CHAP_97"]`
- 97 版常见截尾拼写补充：["Putr", "Saptamsh", "not having a son"]
- 97 版目标章节：["第 11 章 Judgement of Bhavas", "第 16 章 Effects of Putr Bhava", "第 24 章 Effects of the Bhava Lords", "第 32 章 Karakatwas of the Grahas", "第 41 章 Combinations For Wealth", "第 46 章 Dashas of Grahas", "第 47 章 Effects of Dashas", "第 52 章 Effects of the Antar Dashas in the Dasha of", "第 53 章 Effects of the Antar Dashas in the Dasha of", "第 54 章 Effects of Antar Dashas in the Dashas of Mangal", "第 55 章 Effects in the Antar Dashas in the Dasha of", "第 56 章 Effects of the Antar Dashas in the Dasha of", "第 57 章 Effects of the Antar Dashas in the Dasha of", "第 58 章 Effects of the Antar Dashas in the Dasha of", "第 59 章 Effects of the Antar Dashas in the Dasha of", "第 60 章 Effects in the Antar Dashas of Shukr", "第 70 章 Effects of the Ashtakavarg", "第 80 章 Female Horoscopy", "第 83 章 Effects of curses in the previous birth"]
- 100 版目标章节仅用于版本比较：["第 13 章 Judgement of Bhavas", "第 18 章 Effects of Putra Bhava", "第 26 章 Effects of the Bhava Lords", "第 34 章 Karakatwas of the Grahas", "第 43 章 Combinations For Wealth", "第 48 章 Dashas of Grahas", "第 49 章 Effects of Dashas", "第 54 章 Effects of the Antara Dashas in the Dasha of Surya according", "第 55 章 Effects of the Antara Dashas in the Dasha of Chandra", "第 56 章 Effects of Antara Dashas in the Dashas of Mangal", "第 57 章 Effects in the Antara Dashas in the Dasha of Rahu", "第 58 章 Effects of the Antara Dashas in the Dasha of Guru", "第 59 章 Effects of the Antara Dashas in the Dasha of Shani", "第 60 章 Effects of the Antara Dashas in the Dasha of Buddha", "第 61 章 Effects of the Antara Dashas in the Dasha of Ketu", "第 62 章 Effects in the Antara Dashas of Shukra", "第 72 章 Effects of the Ashtakavarga", "第 82 章 Interpretation of Female Horoscope", "第 85 章 Effects of curses in the previous birth"]
- 写“本版没有”的章节不得借用 100 版内容补位。
- 正式证据只接受 97 版 RAG 返回的 `work_id + parent_id + card_id + 章节 + 偈号 + PDF 页`。
- 两版冲突时并列展示，不融合、不裁决。
