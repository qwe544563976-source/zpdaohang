# 第 79 章：Yogas leading to Ascetism

- 来源：BPHS 97 章版
- 原始卡片：15 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P329_B002_01

- 身份：正文
- PDF 页：329
- 偈颂：1
- 标题路径：CHAPTER 79 Yogas leading to Ascetism
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas leading to Ascetism · Sloka 1 [present] · PDF page 329

1. The Sage said: O Brahmin! Now I will describe to you the
Yogas leading to ascetism under the influence of which the
persons give up their homes and become initiated in some holy
order.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P329_B003_01

- 身份：正文
- PDF 页：329
- 偈颂：2-3
- 标题路径：CHAPTER 79 Yogas leading to Ascetism
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas leading to Ascetism · Sloka 2-3 [present] · PDF page 329

2-3. The Yog for ascetism is formed, when four or more grahas
(5, 6, 7), possessed of strength occupy a single bhava. The
person born will become a Tapasvi, a Kapali, he will be
wearing a red robe, be one who keeps a danda (staff), Yati,
he will be keeper of a Chakr, or he will be a naked Sanyasin,
according to the grah which of the grah the strongest of the
group is: Surya, Chandr, Mangal, Buddh, Guru, Shukr, or
Shani. If a number of grahas are endowed with strength, the
holy order of the one strongest amongst them is accepted (or
entered into).
Notes: There is a similar verse in Varahamihir's Brihat Jatak
which translated into English reads as under: "If at birth,
four or more grahas possessed of strength, occupy a single
bhava, the person born will become a Sakya, Jeevika, Bhikshu,
a Vriddha or Guru, a Charak, a Nirgrantha or Visava, a
Vanyasana or Vanaprastha, according to which of the grahas
the strongest grah of the group is: Mangal, Buddh, Guru,
Chandr, Shukr, Shani, or Surya. If the strongest grah be
conquered in planetary war by another grah or grahas at the
time of birth, the person will relinquish that stage of
ascetic life and review to his previous condition of life."
A Vanaprastha is a religious man engaged in the practice of
rigorous and devout penance (i.e. he will be a Tapasvi);  a
Vivas is a naked ascetic (that is dwelling in hills and
forests. A Bhikshu is an illustrious ascetic with a single
staff for his symbol engaged ever and anon in the
contemplation of truths of the sacred scriptures. A Charak is
a religious mendicant wandering over many countries. A Shakya
is an ascetic of the Buddhist clan. A Guru is a celebrated
teacher endowed with royal splendour. A Jeevika is a
garrulous and gluttonous mendicant.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P329_B003_02

- 身份：正文
- PDF 页：329
- 偈颂：2-3
- 标题路径：CHAPTER 79 Yogas leading to Ascetism
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas leading to Ascetism · Sloka 2-3 [present] · PDF page 329

2-3. The Yog for ascetism is formed, when four or more grahas
(5, 6, 7), possessed of strength occupy a single bhava. The
person born will become a Tapasvi, a Kapali, he will be
wearing a red robe, be one who keeps a danda (staff), Yati,
he will be keeper of a Chakr, or he will be a naked Sanyasin,
according to the grah which of the grah the strongest of the
group is: Surya, Chandr, Mangal, Buddh, Guru, Shukr, or
Shani. If a number of grahas are endowed with strength, the
holy order of the one strongest amongst them is accepted (or
entered into).
Notes: There is a similar verse in Varahamihir's Brihat Jatak
which translated into English reads as under: "If at birth,
four or more grahas possessed of strength, occupy a single
bhava, the person born will become a Sakya, Jeevika, Bhikshu,
a Vriddha or Guru, a Charak, a Nirgrantha or Visava, a
Vanyasana or Vanaprastha, according to which of the grahas
the strongest grah of the group is: Mangal, Buddh, Guru,
Chandr, Shukr, Shani, or Surya. If the strongest grah be
conquered in planetary war by another grah or grahas at the
time of birth, the person will relinquish that stage of
ascetic life and review to his previous condition of life."
A Vanaprastha is a religious man engaged in the practice of
rigorous and devout penance (i.e. he will be a Tapasvi);  a
Vivas is a naked ascetic (that is dwelling in hills and
forests. A Bhikshu is an illustrious ascetic with a single
staff for his symbol engaged ever and anon in the
contemplation of truths of the sacred scriptures. A Charak is
a religious mendicant wandering over many countries. A Shakya
is an ascetic of the Buddhist clan. A Guru is a celebrated
teacher endowed with royal splendour. A Jeevika is a
garrulous and gluttonous mendicant.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P329_B004_01

- 身份：正文
- PDF 页：329
- 偈颂：4
- 标题路径：CHAPTER 79 Yogas leading to Ascetism
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas leading to Ascetism · Sloka 4 [present] · PDF page 329

4. If strong grahas capable of leading to ascetism be obscure
by Surya's rays (that is they be combust), the person born,
in spite of having reverence for the holy order, will not
become initiated in that holy order.
Notes: Brihat Jatak adds in this connection that if the
grahas referred to above be overcome in planetary war and be
aspected by other grahas, the person concerned will seek
admission into the holy order without success.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P329_B005_01

- 身份：正文
- PDF 页：329
- 偈颂：5
- 标题路径：CHAPTER 79 Yogas leading to Ascetism
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas leading to Ascetism · Sloka 5 [present] · PDF page 329

5. If the other grahas lose their strength (in spite of being
in their exaltation rashis, etc.) as a result of combustion
with Surya, the native will enter the holy order as signified
by Surya, that is, he will become a Tapasvi.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P329_B006_01

- 身份：正文
- PDF 页：329
- 偈颂：6
- 标题路径：CHAPTER 79 Yogas leading to Ascetism
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas leading to Ascetism · Sloka 6 [present] · PDF page 329

6. If the lord of the rashi occupied by Chandr (Janm Rashi),
having no aspect of other grahas on himself, aspects Shani,
the native gets initiated into the holy order of the grah who
is stronger amongst the two.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P330_B001_01

- 身份：正文
- PDF 页：330
- 偈颂：7
- 标题路径：CHAPTER 79 Yogas leading to Ascetism
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas leading to Ascetism · Sloka 7 [present] · PDF page 330

7. If the lord of the rashi occupied by Chandr be devoid of
strength and is aspected only by Shani, the native becomes
initiated into the holy order signified by Shani (that is, he
enters the holy order of the ascetics known a Nirgranthas
(naked ascetics).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P330_B002_01

- 身份：正文
- PDF 页：330
- 偈颂：8
- 标题路径：CHAPTER 79 Yogas leading to Ascetism
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas leading to Ascetism · Sloka 8 [present] · PDF page 330

8. If Chandr be in the decanate of Shani or in the Navams of
Shani or Mangal, and be aspected by Shani, the native becomes
an ascetic and enters the holy order signified by Shani.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P330_B003_01

- 身份：正文
- PDF 页：330
- 偈颂：9
- 标题路径：CHAPTER 79 Yogas leading to Ascetism
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas leading to Ascetism · Sloka 9 [present] · PDF page 330

9. There is planetary war if Mangal, Buddh, Guru, Shukr, and
Shani are together (within one degree of each other), Shukr
is the conquerer whether he is in North or South, but amongst
the other four only one, who is in the North is the conquerer
and that in the South is considered defeated in the planetary
war.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P330_B004_01

- 身份：正文
- PDF 页：330
- 偈颂：10
- 标题路径：CHAPTER 79 Yogas leading to Ascetism
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas leading to Ascetism · Sloka 10 [present] · PDF page 330

10. If the grah who leads the native to ascetism, is
conquered in planetary war by another grah or grahas at the
time of birth, the person will relinquish the holy order in
which he becomes initiated.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P330_B005_01

- 身份：正文
- PDF 页：330
- 偈颂：11
- 标题路径：CHAPTER 79 Yogas leading to Ascetism
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas leading to Ascetism · Sloka 11 [present] · PDF page 330

11. Maitreya asked: O Venerable Sage! If there be many grahas
who are significators for ascetism, then which holy order the
native will get initiated into?

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P330_B006_01

- 身份：正文
- PDF 页：330
- 偈颂：12
- 标题路径：CHAPTER 79 Yogas leading to Ascetism
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas leading to Ascetism · Sloka 12 [present] · PDF page 330

12. Maharishi Parasara replied: O Brahmin! If all the grahas
be possessed of strength, the native enters into the holy
orders of all the grahas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P330_B007_01

- 身份：正文
- PDF 页：330
- 偈颂：13
- 标题路径：CHAPTER 79 Yogas leading to Ascetism
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas leading to Ascetism · Sloka 13 [present] · PDF page 330

13. The native gets initiated into the holy order of the grah
(amongst the grahas who are significators for ascetism) whose
Dasa gets into operation at first. Then he relinquishes this
holy order of this grah at the commencement of the Dasa of
the next grah and accepts the holy order signified by him.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P330_B008_01

- 身份：正文
- PDF 页：330
- 偈颂：14
- 标题路径：CHAPTER 79 Yogas leading to Ascetism
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas leading to Ascetism · Sloka 14 [present] · PDF page 330

14. When Guru, Chandr, and Lagn are aspected by Shani, and
Guru occupies the 9th, the person born in the Rajayog, will
become a holy illustrious founder of a system of philosophy
(or holy order).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P330_B009_01

- 身份：正文
- PDF 页：330
- 偈颂：15
- 标题路径：CHAPTER 79 Yogas leading to Ascetism
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas leading to Ascetism · Sloka 15 [present] · PDF page 330

15. When Shani occupies the 9th bhava from Lagn and is not
aspected by any grah, the person possessed of Rajayog, will
take himself to the holy order before becoming a lord of men.
If there be no Rajayog the native becomes an ascetic
(religious wanderer).
