# 第 51 章：Working out of Antar Dashas of Grahas and Rashis

- 来源：BPHS 97 章版
- 原始卡片：10 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P214_B002_01

- 身份：正文
- PDF 页：214
- 偈颂：—
- 标题路径：CHAPTER 51 Working out of Antar Dashas of Grahas and Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Working out of Antar Dashas of Grahas and Rashis · Sloka unknown [unknown] · PDF page 214 · page_block BPHS_PL9_CHAP_97_P214_B002

in Vimshottari, etc., Dasha systems.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P214_B003_01

- 身份：正文
- PDF 页：214
- 偈颂：1
- 标题路径：CHAPTER 51 Working out of Antar Dashas of Grahas and Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Working out of Antar Dashas of Grahas and Rashis · Sloka 1 [present] · PDF page 214

1. For finding out the span of the Antar Dasha of a Grah in
the Dasha of the same or another Grah, multiply the Dasha
years of the former with the Dasha years of the latter and
divide the product by the total Dasha of the same or any
other Grah in the Antar Dasha of another Grah. Multiply the
years, etc., of the Antar Dasha with the Dasha years of the
other Grah and divide the product by the total Dasha years
of all the Grahas. The figure so available in months, etc.,
will represent the Pratyantar Dasha of the former.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P214_B004_01

- 身份：正文
- PDF 页：214
- 偈颂：2
- 标题路径：CHAPTER 51 Working out of Antar Dashas of Grahas and Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Working out of Antar Dashas of Grahas and Rashis · Sloka 2 [present] · PDF page 214

2. In every Dasha the first Antar Dasha belongs to the lord
of the Dasha. Then, the further Antar Dashas belong to the
other 8 Grahas in the same order as followed for the
Dashas. The same applies to Pratyantar Dasha.
The Antar Dashas of Char Grahas in Char, etc., Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P214_B005_01

- 身份：正文
- PDF 页：214
- 偈颂：3-4
- 标题路径：CHAPTER 51 Working out of Antar Dashas of Grahas and Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Working out of Antar Dashas of Grahas and Rashis · Sloka 3-4 [present] · PDF page 214

3-4. The Antar Dashas of the Charadi Kendradi Dasha of the
Grahas are  worked out by dividing the Dasha years by 9.
The first Dasha will invariably be of the lord of the
Dasha. Thereafter, there will be Antar Dashas of Grahas
placed in Kendras, Panapharas, and Apoklimas respectively
according to their strength.
Antar Dashas of Rashis

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P214_B006_01

- 身份：正文
- PDF 页：214
- 偈颂：5
- 标题路径：CHAPTER 51 Working out of Antar Dashas of Grahas and Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Working out of Antar Dashas of Grahas and Rashis · Sloka 5 [present] · PDF page 214

5. The Antar Dashas of Rashis is worked out by dividing the
Dasha years by 12 (in other words, 1/12th part of the Dasha
years of a Rashi is the period of its Antar Dasha).
Pratyantar Dashas of the Antar Dashas are also calculated
in the same manner.
The order of Antar Dashas of Rashis

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P214_B007_01

- 身份：正文
- PDF 页：214
- 偈颂：6
- 标题路径：CHAPTER 51 Working out of Antar Dashas of Grahas and Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Working out of Antar Dashas of Grahas and Rashis · Sloka 6 [present] · PDF page 214

6. The Antar Dashas will start from the Dasha Rashi or from
the Rashi 7th there from, which ever is stronger. The Antar
Dashas are in the onwards order if the Dasha Rashi is odd
in the reverse order if it is even.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P215_B001_01

- 身份：正文
- PDF 页：215
- 偈颂：7-12
- 标题路径：CHAPTER 51 Working out of Antar Dashas of Grahas and Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Working out of Antar Dashas of Grahas and Rashis · Sloka 7-12 [present] · PDF page 215

7-12. 0 Brahmin! Now, I will acquaint you with the special
characteristics of the order of the Antar Dashas of the
Rashis. If the Dasha Rashi is a moveable one, the Antar
Dashas of the 12 Rashis are in the onwards or reverse
order. If the Dasha Asraya Rashi is a fixed one, the Antar
Dashas will start from it and there after there will be an
Antar Dasha of every sixth Rashi. If the Dasha Ashraya
Rashi is a dual one, the first Antar Dasha will belong to
it. Thereafter, there will be Antar Dashas of Rashis in
Kendr to it, Rashis in Kendr to the 5th from it, and Rashis
in Kendr to the 9th from it in that order. In the case of
all kinds of Rashis, namely moveable, fixed, or dual, the
order will be onwards, if the Dasha Asraya Rashi is an odd
one, and in the reverse order if it is an even one. The so
called Dasha Asraya Rashi is known as Pak Rashi. In the
first order Rashi which is Pak Rashi is also called Bhog
Rashi. Later if the Dasha Prad Rashi is even, then the Bhog
Rashi will be that which is at the same Rashi distance as
the Dasha Asraya Rashi is from the Dasha Prad Rashi. For
the Char, Sthir, and Trikon Dasha, the Pak and Bhog should
be determined in this manner. If Pak and Bhog Rashis are
associated with malefics, there will be pain in the body
and mental agony. There will be enjoyment if they are
associated with benefics.
In the Kaal Chakr Dasha like the Vimshottari Dasha system,
the span of Dasha should be multiplied by the span of the
Dasha of the Rashi whose Antar Dasha is required and the
product should be divided by the total Dasha years of the
Rashi. The years, months, etc., as arrived at will
represent the Antar Dasha of the Rashi concerned.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P215_B001_02

- 身份：正文
- PDF 页：215
- 偈颂：7-12
- 标题路径：CHAPTER 51 Working out of Antar Dashas of Grahas and Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Working out of Antar Dashas of Grahas and Rashis · Sloka 7-12 [present] · PDF page 215

7-12. 0 Brahmin! Now, I will acquaint you with the special
characteristics of the order of the Antar Dashas of the
Rashis. If the Dasha Rashi is a moveable one, the Antar
Dashas of the 12 Rashis are in the onwards or reverse
order. If the Dasha Asraya Rashi is a fixed one, the Antar
Dashas will start from it and there after there will be an
Antar Dasha of every sixth Rashi. If the Dasha Ashraya
Rashi is a dual one, the first Antar Dasha will belong to
it. Thereafter, there will be Antar Dashas of Rashis in
Kendr to it, Rashis in Kendr to the 5th from it, and Rashis
in Kendr to the 9th from it in that order. In the case of
all kinds of Rashis, namely moveable, fixed, or dual, the
order will be onwards, if the Dasha Asraya Rashi is an odd
one, and in the reverse order if it is an even one. The so
called Dasha Asraya Rashi is known as Pak Rashi. In the
first order Rashi which is Pak Rashi is also called Bhog
Rashi. Later if the Dasha Prad Rashi is even, then the Bhog
Rashi will be that which is at the same Rashi distance as
the Dasha Asraya Rashi is from the Dasha Prad Rashi. For
the Char, Sthir, and Trikon Dasha, the Pak and Bhog should
be determined in this manner. If Pak and Bhog Rashis are
associated with malefics, there will be pain in the body
and mental agony. There will be enjoyment if they are
associated with benefics.
In the Kaal Chakr Dasha like the Vimshottari Dasha system,
the span of Dasha should be multiplied by the span of the
Dasha of the Rashi whose Antar Dasha is required and the
product should be divided by the total Dasha years of the
Rashi. The years, months, etc., as arrived at will
represent the Antar Dasha of the Rashi concerned.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P215_B002_01

- 身份：正文
- PDF 页：215
- 偈颂：13-16
- 标题路径：CHAPTER 51 Working out of Antar Dashas of Grahas and Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Working out of Antar Dashas of Grahas and Rashis · Sloka 13-16 [present] · PDF page 215

13-16. Now, I will tell you the method of working out the
Antar Dashas in the Pinda, Amsh, and Nisarg Dashas. The
lord of Dasha is Dasha Pachak of full part (l/1) of the
Grah associated with is Pachak of 1/2 part; the Grah in
Trikon from him is Pachak of l/3 part, and the Grah in the
4th and 8th from him are Pachak of 1/4 part, and the Grah
in the 7th from him is Pachak of l/7 part of the Dasha. No
Grah in any other Bhava is Antar Dash Pachak. In this
manner there are Antar Dasha Pachakas in the above
mentioned Bhavas from the various Bhavas including Lagn. In
any of such Bhavas if there are more than one Grah, then,
the one who is the strongest amongst them will be the
Pachak.
Take the fractions (as mentioned above) and reduce them in
equivalent fractions with a common denominator. Add up the
aliquot parts of the Dasha representative of the various
numerators leaving out the denominators. The Antar Dashas
will be arrived at when the various aliquots are converted
into years, months, etc., within the main Dasha and divided
by a common factor.
(The calculations given above are not the literal
translation of the text in the verses concerned, but their
actual meaning and sense. This has been got confirmed by
checking up with similar information given in Kalyana
Varma's Saravali and Varamihir's Brihat Jatak. They may be
referred to if necessary).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P215_B002_02

- 身份：正文
- PDF 页：215
- 偈颂：13-16
- 标题路径：CHAPTER 51 Working out of Antar Dashas of Grahas and Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Working out of Antar Dashas of Grahas and Rashis · Sloka 13-16 [present] · PDF page 215

13-16. Now, I will tell you the method of working out the
Antar Dashas in the Pinda, Amsh, and Nisarg Dashas. The
lord of Dasha is Dasha Pachak of full part (l/1) of the
Grah associated with is Pachak of 1/2 part; the Grah in
Trikon from him is Pachak of l/3 part, and the Grah in the
4th and 8th from him are Pachak of 1/4 part, and the Grah
in the 7th from him is Pachak of l/7 part of the Dasha. No
Grah in any other Bhava is Antar Dash Pachak. In this
manner there are Antar Dasha Pachakas in the above
mentioned Bhavas from the various Bhavas including Lagn. In
any of such Bhavas if there are more than one Grah, then,
the one who is the strongest amongst them will be the
Pachak.
Take the fractions (as mentioned above) and reduce them in
equivalent fractions with a common denominator. Add up the
aliquot parts of the Dasha representative of the various
numerators leaving out the denominators. The Antar Dashas
will be arrived at when the various aliquots are converted
into years, months, etc., within the main Dasha and divided
by a common factor.
(The calculations given above are not the literal
translation of the text in the verses concerned, but their
actual meaning and sense. This has been got confirmed by
checking up with similar information given in Kalyana
Varma's Saravali and Varamihir's Brihat Jatak. They may be
referred to if necessary).
