# 第 93 章：Remedies for Birth in Abhukta Mula

- 来源：BPHS 97 章版
- 原始卡片：7 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P367_B002_01

- 身份：正文
- PDF 页：367
- 偈颂：1-2
- 标题路径：CHAPTER 93 Remedies for Birth in Abhukta Mula
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies for Birth in Abhukta Mula · Sloka 1-2 [present] · PDF page 367

1-2. The Sage Parasara said: The ruling deity of Jyeshtha is
Indra and the ruling deity of Mula is Rakshasa. As both the
deities are inimical to each other, this gandanta is
considered as the most evil. A boy or girl born during the
period of Abhukta Mula should either be abandoned or the
father should not see the face of the child for 8 years. Now,
I shall describe the remedial measures to obtain deliverence
from the evil effects of birth during this extremely
inauspicious period.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P367_B003_01

- 身份：正文
- PDF 页：367
- 偈颂：3-4
- 标题路径：CHAPTER 93 Remedies for Birth in Abhukta Mula
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies for Birth in Abhukta Mula · Sloka 3-4 [present] · PDF page 367

3-4. In view of the extremely inauspicious effects of birth
during Abhukta, I shall first describe the remedial measures
to obtain relief from Mula . The religious remedial rites
should be performed after the 12th day after the birth, the
next Janm Nakshatr day or on an auspicious day when Chandr
and the stars are favourable.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P367_B004_01

- 身份：正文
- PDF 页：367
- 偈颂：5-8
- 标题路径：CHAPTER 93 Remedies for Birth in Abhukta Mula
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies for Birth in Abhukta Mula · Sloka 5-8 [present] · PDF page 367

5-8. Erect a canopy (Mandap) with four arched gateways
embellished with festoons on a sacred spot besmeared with cow
dung paste to the east or the north of the house. Prepare
there a pit (Kund) or ( place there a square vessel of clay
or metal) for performing havan. Then, according to one's
means prepare or get prepared an idol of Rakshasa (the deity
of the Nakshatr) of 16, 8, or 4 masas of gold as may be
possible within one's means. The idol should be with a
horrible looking face, black in colour with two heads two
arms carrying a sword and a shield and seated on a dead body.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P367_B005_01

- 身份：正文
- PDF 页：367
- 偈颂：9
- 标题路径：CHAPTER 93 Remedies for Birth in Abhukta Mula
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies for Birth in Abhukta Mula · Sloka 9 [present] · PDF page 367

9. In the absence of an idol a piece of gold of the weight
mentioned above should be used for worship, as gold is dear
to all the deities.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P367_B006_01

- 身份：正文
- PDF 页：367
- 偈颂：10-20
- 标题路径：CHAPTER 93 Remedies for Birth in Abhukta Mula
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies for Birth in Abhukta Mula · Sloka 10-20 [present] · PDF page 367

10-20. Thereafter, the remedial rites should be performed
in the following order:
(l) Select a learned priest to perform the religious rites
according to the prescribed procedure;
(2) Install a kalash and put in it Panchagavya (five articles
yielded by a cow, namely, milk, curd, ghee, dung, and urine
Shataushadhi and water of the holy river (Ganga etc.);
(3) Then, install the idol of the Rakshasa of Mula facing
west on an earthen pot (Dhata) with one hundred tiny holes.
After placing bamboo leaves on it, perform the worship of the
idol by offering it white flowers, sandal and clothes, etc..
(4) Also perform worship of its Adhideva: Indra, and
Pratyadhideva: Jal.
(5) Then, perform havan to appease the deities. According to
one's means 1008 or 108 oblations should be offered in the
havan.
(6) After this to obtain deliverence from death, Mrityunjaya
mantra, etc., should be recited and prayers offered to all
the deities for the purpose of Abhisheka.
(7) The father, mother, and the child should thereafter take
bath from the water of the two kalashas. Then the parents
dressed in white clothes and with white sandal paste
besmeared on their foreheads, should give a cow with calf as
a present (Dakshina) to the chief priest and feed the other
priests and Brahmins according to one's means.
(8) Lastly, after reciting the 'Yatapapan', etc., (see verse

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P367_B006_02

- 身份：正文
- PDF 页：367
- 偈颂：10-20
- 标题路径：CHAPTER 93 Remedies for Birth in Abhukta Mula
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies for Birth in Abhukta Mula · Sloka 10-20 [present] · PDF page 367

10-20. Thereafter, the remedial rites should be performed
in the following order:
(l) Select a learned priest to perform the religious rites
according to the prescribed procedure;
(2) Install a kalash and put in it Panchagavya (five articles
yielded by a cow, namely, milk, curd, ghee, dung, and urine
Shataushadhi and water of the holy river (Ganga etc.);
(3) Then, install the idol of the Rakshasa of Mula facing
west on an earthen pot (Dhata) with one hundred tiny holes.
After placing bamboo leaves on it, perform the worship of the
idol by offering it white flowers, sandal and clothes, etc..
(4) Also perform worship of its Adhideva: Indra, and
Pratyadhideva: Jal.
(5) Then, perform havan to appease the deities. According to
one's means 1008 or 108 oblations should be offered in the
havan.
(6) After this to obtain deliverence from death, Mrityunjaya
mantra, etc., should be recited and prayers offered to all
the deities for the purpose of Abhisheka.
(7) The father, mother, and the child should thereafter take
bath from the water of the two kalashas. Then the parents
dressed in white clothes and with white sandal paste
besmeared on their foreheads, should give a cow with calf as
a present (Dakshina) to the chief priest and feed the other
priests and Brahmins according to one's means.
(8) Lastly, after reciting the 'Yatapapan', etc., (see verse

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P368_B001_01

- 身份：正文
- PDF 页：368
- 偈颂：19
- 标题路径：CHAPTER 93 Remedies for Birth in Abhukta Mula
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies for Birth in Abhukta Mula · Sloka 19 [present] · PDF page 368

19) mantra, the father, mother, and the child should see the
reflection of their faces in the ghee (melted ghee). By the
performance of the remedial rites in the manner described,
all evil effects of the birth during Abhukta Mula are
completely wiped out.
