# 第 49 章：Effects of the Kaal Chakr Dasha

- 来源：BPHS 97 章版
- 原始卡片：14 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P204_B002_01

- 身份：正文
- PDF 页：204
- 偈颂：1-5
- 标题路径：CHAPTER 49 Effects of the Kaal Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Kaal Chakr Dasha · Sloka 1-5 [present] · PDF page 204

1-5. Maharishi Parashar said: O Brahmin! I am now going to
describe to you the effects of the Kaal Chakr Dasha.
During the Dasha of the Rashi owned or occupied by Surya,
there will be ill health due to the blood or bile troubles.
In the Dasha of the Rashi owned or occupied by Chandr,
there will be gain of wealth and clothes, name and fame and
birth of children. In the Dasha of the Rashi owned or
occupied by Mangal, there will be bilious fever, gout and
wounds. In the Dasha of the Rashi owned or occupied by
Buddh, there will be acquisition of wealth and birth of
children. In the Dasha of the Rashi owned and occupied by
Guru there will be increase in the number of children,
acquisition of wealth, and enjoyment. In the Dasha owned or
occupied by Shukr, there will be acquisition of learning,
marriage, and gain of wealth. In the Dasha of the Rashi
occupied by Shani, there will be all kinds of adverse
happenings.
The Effects of the Dashas on the Basis of the Navamsh of
each Rashi
The Effects of the Dashas of the Padas of Mesh

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P204_B003_01

- 身份：正文
- PDF 页：204
- 偈颂：6-7
- 标题路径：CHAPTER 49 Effects of the Kaal Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Kaal Chakr Dasha · Sloka 6-7 [present] · PDF page 204

6-7. In the Kaal Chakr Dasha of Mesh in Mesh Navamsh, there
will be distress due to troubles caused by the pollution of
blood. In the Dasha of  Mesh in the Navamsh of Vrishabh,
there will be increase in wealth and agricultural product.
In the Navamsh of Mithun, there will be advancement of
knowledge. In the Navamsh of Kark there will be acquisition
of wealth, in the Simh Navamsh danger from enemies, in the
Kanya Navamsh distress to wife, in the Tula Navamsh
kingship, in the Vrischik Navamsh death, and in the Dhanu
Navamsh acquisition of wealth. Such will be the effects of
the 9 Padas of Mesh. In assessing the net effects, the
nature of the grah occupying the Rashi should also be taken
into account.
Effects of the Dashas of the Navamsh Rashis of Vrishabh

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P204_B004_01

- 身份：正文
- PDF 页：204
- 偈颂：8-10
- 标题路径：CHAPTER 49 Effects of the Kaal Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Kaal Chakr Dasha · Sloka 8-10 [present] · PDF page 204

8-10. In the Dasha of Makar Navamsh in Vrishabh, there will
be tendency to perform undesirable deeds along with more
adverse effects. In the Kumbh Navamsh there will be profits
in business, in the Meen Navamsh success in all ventures,.
In the Dasha of Vrischik Navamsh danger from fire, in the
Dasha of Tula Navamsh recognition from Government and
reverence from all, in the Dasha of Kanya Navamsh danger
from enemies, in the Dasha of Kark Navamsh distress to
wife, in the Dasha of Simh Navamsh diseases of eyes and in
the Dasha of Mithun Navamsh obstacles in earning
livelihood. Such will be the effects of the 9 Navamshas of
Vrishabh. Similar interpretation should be made of further
verses on this subject.
Effects of the Dashas of the Navamsh Rashis of Mithun

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P205_B001_01

- 身份：正文
- PDF 页：205
- 偈颂：11-12
- 标题路径：CHAPTER 49 Effects of the Kaal Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Kaal Chakr Dasha · Sloka 11-12 [present] · PDF page 205

11-12. In Mithun, in the Dasha of the Vrishabh Amsh, there
will be acquisition of wealth, in the Dasha of Mesh Amsh
attacks of fever, in the Dasha of Meen Amsh affectionate
relations with maternal uncle, in the Dasha of Kumbh Amsh
increase in the number of enemies, in the Dasha of Makar
Amsh danger from thieves, in the Dasha of Dhanu Amsh
increase in the stock of weapons, in the Dasha of Vrishabh
Amsh injury by some weapon and in the Dasha of Mithun Amsh
enjoyment.
Effects of the Dashas of the Navamsh Rashis of Kark

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P205_B002_01

- 身份：正文
- PDF 页：205
- 偈颂：13-15
- 标题路径：CHAPTER 49 Effects of the Kaal Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Kaal Chakr Dasha · Sloka 13-15 [present] · PDF page 205

13-15. In Kark, in the Dasha of Kark Amsh there be
distress, in the Dasha of Simh Amsh displeasure of the
Sovereign, in the Dasha of Kanya Amsh reverence from
kinsmen, in the Dasha of Tula Amsh beneficence, in the
Dasha of Vrischik Amsh creation of obstacles by father, in
the Dasha of Dhanu Amsh increase of learning and wealth, in
the Dasha of Makar Amsh danger from water, in the Dasha of
Kumbh Amsh increase in the production of agricultural
products and in the Dasha of the Meen Amsh acquisition of
more wealth and enjoyment.
Effects of the Dashas of the Navamsh Rashis of Simh

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P205_B003_01

- 身份：正文
- PDF 页：205
- 偈颂：16-17
- 标题路径：CHAPTER 49 Effects of the Kaal Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Kaal Chakr Dasha · Sloka 16-17 [present] · PDF page 205

16-17. In Simh, in the Dasha of the Navamsh of Vrischik
there will be distress and disputes, in the Dasha of Tula
Amsh extraordinary gains, in the Dasha of Kanya Amsh gains
of wealth, in the Dasha of Kark Amsh danger from wild
animals, in the Dasha of Simh Amsh birth of a son, in the
Dasha of Mithun Amsh increase of enemies, in the Dasha of
Vrishabh Amsh gains from sale of cattle, in the Dasha of
Mesh Amsh danger from animals, and in the Dasha of Meen
Amsh journeys to distant places.
Effects of the Dashas of the Navamsh Rashis of Kanya

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P205_B004_01

- 身份：正文
- PDF 页：205
- 偈颂：18-19
- 标题路径：CHAPTER 49 Effects of the Kaal Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Kaal Chakr Dasha · Sloka 18-19 [present] · PDF page 205

18-19. In Kanya, in the Dasha of Kumbh Amsh there will be
acquisition of wealth, in the Dasha of Makar Amsh financial
gains, in the Dasha of Dhanu Amsh mingling with kinsmen, in
the Dasha of Mesh Amsh happiness from mother, in the Dasha
of Vrishabh Amsh birth of children, in the Dasha Mithun
Amsh increase in enemies, in the Dasha of Kark Amsh love
with some woman, in the Dasha of Simh Amsh aggravation of
diseases, and in the Dasha of Kanya Amsh birth of
children.
Effects of the Dashas of the Navamsh Rashi of Tula

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P205_B005_01

- 身份：正文
- PDF 页：205
- 偈颂：20-22
- 标题路径：CHAPTER 49 Effects of the Kaal Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Kaal Chakr Dasha · Sloka 20-22 [present] · PDF page 205

20-22. In Tula, in the Dasha of Tula Amsh there will be
financial gains, in the Dasha of Vrischik Amsh good
relations with kinsmen, in the Dasha of Dhanu Amsh
happiness from father, in the Dasha of Makar Amsh disputes
with mother, in the Dasha of Kumbh Amsh birth of a son and
financial gains, in the Dasha of Meen Amsh entanglement
with enemies, in the Dasha of Vrischik Amsh disputes with
women, in the Dasha of Tula Amsh danger from water, and in
Dasha of Kanya Amsh more financial gains.
Effects of the Dashas of the Navamsh Rashis of Vrischik

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P206_B001_01

- 身份：正文
- PDF 页：206
- 偈颂：23-241/2
- 标题路径：CHAPTER 49 Effects of the Kaal Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Kaal Chakr Dasha · Sloka 23-241/2 [present] · PDF page 206

23-241/2. In Vrischik, in the Dasha of Kark Amsh there will
be financial gains, in the Dasha of Simh Amsh opposition to
the king (Government), in the Dasha of Mithun Amsh
acquisition of land, in the Dasha of Vrishabh Amsh
financial gains, in the Dasha of Mesh Amsh danger from
reptiles, in the Dasha of Meen Amsh danger from water, in
the Dasha of Kumbh Amsh profits in business, in the Dasha
of Makar Amsh profits in business, in the Dasha of Makar
Amsh possibility of suffering from diseases, and in the
Dasha of Dhanu Amsh financial gains.
Effects of the Dasha of the Navamsh Rashis of Dhanu

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P206_B002_01

- 身份：正文
- PDF 页：206
- 偈颂：25-27
- 标题路径：CHAPTER 49 Effects of the Kaal Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Kaal Chakr Dasha · Sloka 25-27 [present] · PDF page 206

25-27. In Dhanu, in the Dasha of Mesh Amsh there will be
financial gains, in the Dasha of Vrishabh Amsh acquisition
of more land, in the Dasha of Mithun Amsh success in
ventures, in the Dasha of Kark Amsh success all round, in
the Dasha of Simh Amsh increase in the accumulated wealth,
in the Dasha of Kanya Amsh disputes, in the Dasha of Tula
Amsh financial gains, in the Dasha of Vrischik Amsh
affliction with diseases, in the Dasha of Dhanu Amsh
happiness from children (birth of a son, etc.).
Effects of the Dasha of the Navamsh Rashis of Makar

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P206_B003_01

- 身份：正文
- PDF 页：206
- 偈颂：28-29
- 标题路径：CHAPTER 49 Effects of the Kaal Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Kaal Chakr Dasha · Sloka 28-29 [present] · PDF page 206

28-29. In Makar, in the Dasha of Makar Amsh there will be
happiness from children, in the Dasha of Kumbh Amsh gain of
agricultural products, in the Dasha of Meen Amsh well
being, in the Dasha of Vrischik Amsh danger from poison, in
the Dasha of Tula Amsh financial gains, in the Dasha of
Kanya Amsh increase in enemies, in the Dasha of Kark Amsh
acquisition of property, in the Dasha of Simh Amsh danger
from wild animals, and in the Dasha of Mithun Amsh danger
of falling from a tree.
Effects of the Dasha of the Navamsh Rashis of Kumbh

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P206_B004_01

- 身份：正文
- PDF 页：206
- 偈颂：30-32
- 标题路径：CHAPTER 49 Effects of the Kaal Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Kaal Chakr Dasha · Sloka 30-32 [present] · PDF page 206

30-32. In Kumbh, in the Dasha of Vrishabh Amsh there will
be financial gains,  in the Dasha of Mesh Amsh diseases of
the eyes, in the Dasha of Meen Amsh journeys to distant
places, in the Dasha of Kumbh Amsh increase in wealth, in
the Dasha of Makar Amsh success in all kinds of ventures,
in the Dasha of Dhanu Amsh more enemies, in the Dasha of
Mesh Amsh loss of happiness and enjoyment, in the Dasha of
Vrishabh Amsh death, in the Dasha of Mithun Amsh well
being.
Effects of the Dasha of the Navamsh Rashis of Meen

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P206_B005_01

- 身份：正文
- PDF 页：206
- 偈颂：33-34 1/2
- 标题路径：CHAPTER 49 Effects of the Kaal Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Kaal Chakr Dasha · Sloka 33-34 1/2 [present] · PDF page 206

33-34 1/2. In the Meen, in the Dasha of Kark Amsh there
will be increase in wealth, in the Dasha of Simh Amsh
recognition by Government, in the Dasha of Kanya Amsh
financial gains, in the Dasha of Tula Amsh gains from all
sources, in the Dasha of Vrischik Amsh fever, in the Dasha
of Dhanu Amsh more enemies, in the Dasha of Makar Amsh
conjugal disputes, in the Dasha of Kumbh Amsh danger from
water, and in the Dasha of Meen Amsh good fortune all
round.
In this manner on the Kaal Chakr, prepared on the basis the
Pad of the Janm Nakshatr, the Dashas of the Navamsh Rashis
and their duration can be assessed and prediction can be
made for the whole life of the native. Appropriate remedial
measures (recitation of mantras, oblations, etc.) should be
taken to alleviate the adverse effects caused by malefic
Dashas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P207_B001_01

- 身份：正文
- PDF 页：207
- 偈颂：35-37
- 标题路径：CHAPTER 49 Effects of the Kaal Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Kaal Chakr Dasha · Sloka 35-37 [present] · PDF page 207

35-37. The effects of Dasha in Raj Yog, etc., have already
been described in Vol. I of this book. The same should be
applied in a judicious manner in the Kaal Chakr. These are
in brief effects of Kaal Chakr Dasha.
