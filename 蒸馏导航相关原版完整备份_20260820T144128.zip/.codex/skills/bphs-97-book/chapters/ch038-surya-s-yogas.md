# 第 38 章：Surya's Yogas

- 来源：BPHS 97 章版
- 原始卡片：3 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P135_B002_01

- 身份：正文
- PDF 页：135
- 偈颂：1
- 标题路径：CHAPTER 38 Surya's Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Surya's Yogas · Sloka 1 [present] · PDF page 135

1. Vesi, Vosi, and Abhayachari Yogas: Barring Chandr, if a
grah among Mangal etc. be in the 2nd from Surya, Vesi Yog
is formed;
~(.DI12)1~
barring Chandr, if a grah among Mangal etc. be in the 12th
from Surya, Vosi Yog is formed;
~(.DI12)1*(.DI2)1~
and barring Chandr, if a grah among Mangal etc. be in both
the 2nd and the 12th from Surya Ubhayachari Yog is caused.
~(.DI2)1~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P135_B003_01

- 身份：正文
- PDF 页：135
- 偈颂：2-3
- 标题路径：CHAPTER 38 Surya's Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Surya's Yogas · Sloka 2-3 [present] · PDF page 135

2-3. Effects of Vesi, Vosi, and Ubhayachari Yogas: One born
in Vesi Yog will be even sighted, truthful, long bodied,
indolent, happy, and endowed with negligible wealth.
~(.DI12)1~
One born with Vosi Yog will be skilful, charitable, and
endowed with fame, learning and strength.
~(.DI12)1*(.DI2)1~
The Ubhayachari native will be a king or a equal to a king
and be happy.
~(3I2)1+(7I2)1+(3I12)1+(7I12)1~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P135_B004_01

- 身份：正文
- PDF 页：135
- 偈颂：4
- 标题路径：CHAPTER 38 Surya's Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Surya's Yogas · Sloka 4 [present] · PDF page 135

4. Benefics causing Vesi, Vosi, or Ubhayachari Yogas will
give the above mentioned effects, while malefics will
produce contrary effects.
