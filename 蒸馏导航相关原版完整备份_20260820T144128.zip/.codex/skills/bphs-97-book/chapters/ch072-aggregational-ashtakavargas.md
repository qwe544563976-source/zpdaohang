# 第 72 章：Aggregational Ashtakavargas

- 来源：BPHS 97 章版
- 原始卡片：12 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P313_B002_01

- 身份：正文
- PDF 页：313
- 偈颂：1-2
- 标题路径：CHAPTER 72 Aggregational Ashtakavargas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Aggregational Ashtakavargas · Sloka 1-2 [present] · PDF page 313

1-2. The sage said: O Brahmin! Write down a rashi kundali
with 12 bhavas including Lagn. Then insert the total of the
rekhas in all the Ashtakavargas of the grahas in the rashi
concerned. The Ashtakavarg with such rekhas is called the
Samuday Ashtakavarg or the aggregational Ashtakavarg. From
this should be judged good and adverse effects of the rashi
kundali.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P313_B003_01

- 身份：正文
- PDF 页：313
- 偈颂：3-5
- 标题路径：CHAPTER 72 Aggregational Ashtakavargas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Aggregational Ashtakavargas · Sloka 3-5 [present] · PDF page 313

3-5. In the aggregational Ashtakavarg the rashi which has
more than 30 rekhas gives favourable effects, that having
between 25 and 30 rekhas produces medium effects and that
rashi who has less than 25 rekhas yields adverse effects.
Auspicious functions like marriage etc., should be performed
when the grah on whose basis the time and date of functions
are performed, moves into the rashi with favourable effects.
The rashi which is productive of adverse effects (that is
with rekhas less than 25) should be avoided for these
purposes. For example, the strength of Chandr (Chandrabal) is
generally acceptable for all auspicious functions. Therefore,
auspicious functions should be performed or started when
Chandr is in the rashi with maximum number of rekhas. The
grah in the rashi with favourable number of rekhas produces
auspicious effects and the grah in the rashi with
unfavourable number of rekhas yields evil results.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P313_B004_01

- 身份：正文
- PDF 页：313
- 偈颂：6-6 1/2
- 标题路径：CHAPTER 72 Aggregational Ashtakavargas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Aggregational Ashtakavargas · Sloka 6-6 1/2 [present] · PDF page 313

6-6 1/2. Amongst the 12 bhavas (including Lagn), more than 30
rekhas advance the effects of a bhava, between 25 and 30
rekhas produce medium effects and the effects of the bhava
which contains less than 25 rekhas gets damaged.
Notes: From the above rules, it can be interpreted that if
there are less than 25 rekhas in 6th, 8th, and 12th bhava
their effects become favourable. The effects will become
adverse if these bhavas contain more than 25 rekhas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P313_B005_01

- 身份：正文
- PDF 页：313
- 偈颂：7-8
- 标题路径：CHAPTER 72 Aggregational Ashtakavargas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Aggregational Ashtakavargas · Sloka 7-8 [present] · PDF page 313

7-8. If in a rashi kundali there are larger number of rekhas
in the 11th than those in 10th, and there are smaller number
of rekhas in the 12th than those in the 11th, and Lagn
contains largest number of rekhas, the native will be wealthy
and will enjoy all kinds of comforts and luxury.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P313_B006_01

- 身份：正文
- PDF 页：313
- 偈颂：9-10
- 标题路径：CHAPTER 72 Aggregational Ashtakavargas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Aggregational Ashtakavargas · Sloka 9-10 [present] · PDF page 313

9-10. Divide the 12 bhavas in 3 sections. There will be
sufferings and distress in that part of the life which is
represented by the section of the rashi kundali with more
malefics. There will be happiness etc., in the part of the
life represented by the section of the rashi kundali
containing more benefics. There will be mixed results in that
area of life when the relative section of the rashi kundali
has equal number of benefics and malefics. The bhavas from
Lagn up to the 4th signify childhood, those from 5th to 8th
youth (adulthood), and those from the 9th to 12th represent
old age.
Evil effects of the number of less than 25 rekhas in a rashi
and remedial measures.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P314_B001_01

- 身份：正文
- PDF 页：314
- 偈颂：11-28
- 标题路径：CHAPTER 72 Aggregational Ashtakavargas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Aggregational Ashtakavargas · Sloka 11-28 [present] · PDF page 314

11-28. There will be danger of death in the month of the
rashi (during the period Surya transits that rashi) which has
7 or less than 7 rekhas in the samudaya Ashtakavarg. To ward
off this evil effect, 20 tolas of gold and 2 heaps of sesame
seeds resembling the shape of a mountain, should be given in
charity.
There will be possibility of death in the month of that rashi
(solar month) which has 8 rekhas. Tuladan of camphor is
recommended to obtain relief from this evil effect.
There will be danger of snakes in the month of the rashi
(solar month) which has 9 rekhas. A chariot with 7 horses
should be given in charity to obtain relief from this evil
effect.
There will be danger from weapons in the month of the rashi
(solar month) which contains 10 rekhas. An armour together
with Vajra should be given in charity to ward off this evil
effect.
There will be danger of disgrace for no cause in the month of
the rashi (solar month) which has 11 rekhas. An idol of the
moon made of 10 tolas of gold should be given in charity to
obtain relief from this evil effect.
There will be danger of snakes in the month of the rashi
(solar month) which has 9 rekhas. A chariot with 7 horses
should be given in charity to obtain relief from this evil
effect.
There will be danger from weapons in the month of the rashi
(solar month) which contains 10 rekhas. An armour together
with Vajra should be given in charity to ward off this evil
effect.
There will be danger of disgrace for no cause in the  month
of the rashi (solar month) which has 11 rekhas. An idol of
the moon made of 10 tolas of gold should be given in charity
to obtain relief from this evil effect.
There will be danger of death from drowning in the month of
the rashi (solar month) which has 12 rekhas. Land full of
crops should be given in charity to obtain relief from this
evil effect.
There will be danger of death from wild and violent animals
in the month of the rashi (solar month) in which there are 13
rekhas. A Shaligram Shila should be given in charity to
obtain relief from this evil effect.
There will be danger of death in the month of the rashi
(solar month) in which there are 14 rekhas. A Varah Murti
made of gold should be given in charity to obtain relief from
this evil effect.
There will be danger of the wrath of the king (Government) in
the month of the rashi (solar month) in which there are 15
rekhas. An elephant should be given in charity to obtain
relief from this evil effect.
There will be danger of arishta (calamity, disaster, or
misfortune) in the month of the rashi (solar month) in which
there are 16 rekhas. A kalpa Vriksha made of gold should be
given in charity to obtain relief from this evil effect.
There will be danger from diseases in the month of the rashi
that has 17 rekhas. A cow and jaggery should be given in
charity to obtain relief from this evil effect.
There will be danger of conflict in the month of the rashi
that has 18 rekhas. A cow, jewels, land, and gold should be
given in charity to obtain relief from this evil effect.
There will be possibility of banishment from the homeland in
the month of the rashi which has 19 rekhas. Family deity
should be worshipped to obtain relief from this evil effect.
There will be loss of intelligence in the month of the rashi
which has 20 rekhas. Goddess Saraswati should be worshipped
to obtain relief from this evil effect.
There will be distress from diseases in the month of the
rashi that has 21 rekhas. A heap of grains, shaped like a
mountain, should be given in charity to obtain relief from
this evil effect.
There will be distress to kinsmen in the month of the rashi
that has 22 rekhas. Gold should be given in charity to obtain
relief from this evil effect.
The native will be in distress in the month of the rashi that
has 23 rekhas. An idol of the sun made of 7 tolas of gold
should be given in charity to obtain relief from this evil
effect.
There will be death of the kinsmen in the month of the rashi
that has 24 rekhas. 10 cows should be given in charity to
obtain relief from this evil effect.
There will be loss of wisdom in the month of the rashi that
has 25 rekhas. Goddess Saraswati should be worshipped to
obtain relief from this evil effect.
There will be loss of wealth in the month of the rashi that
has 26 rekhas. Gold should be given in charity to obtain
relief from this evil effect.
There will be loss of wealth in the month of the rashi that
has 27 rekhas. Sri Sukta Japa should be performed to obtain
relief from this evil effect.
There will be losses in several ways in the month of the
rashi that has 28 rekhas. Havana of Surya should be performed
to obtain relief from this evil effect.
There will be anxieties all round in the month of the rashi
that has 29 rekhas. Ghee, clothes, and gold should be given
in charity to obtain relief from this evil effect.
There will be gains of wealth and grains etc., in the month
of the rashi that has 30 rekhas.
Auspicious effects of more than 30 rekhas in a Rashi

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P314_B001_02

- 身份：正文
- PDF 页：314
- 偈颂：11-28
- 标题路径：CHAPTER 72 Aggregational Ashtakavargas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Aggregational Ashtakavargas · Sloka 11-28 [present] · PDF page 314

11-28. There will be danger of death in the month of the
rashi (during the period Surya transits that rashi) which has
7 or less than 7 rekhas in the samudaya Ashtakavarg. To ward
off this evil effect, 20 tolas of gold and 2 heaps of sesame
seeds resembling the shape of a mountain, should be given in
charity.
There will be possibility of death in the month of that rashi
(solar month) which has 8 rekhas. Tuladan of camphor is
recommended to obtain relief from this evil effect.
There will be danger of snakes in the month of the rashi
(solar month) which has 9 rekhas. A chariot with 7 horses
should be given in charity to obtain relief from this evil
effect.
There will be danger from weapons in the month of the rashi
(solar month) which contains 10 rekhas. An armour together
with Vajra should be given in charity to ward off this evil
effect.
There will be danger of disgrace for no cause in the month of
the rashi (solar month) which has 11 rekhas. An idol of the
moon made of 10 tolas of gold should be given in charity to
obtain relief from this evil effect.
There will be danger of snakes in the month of the rashi
(solar month) which has 9 rekhas. A chariot with 7 horses
should be given in charity to obtain relief from this evil
effect.
There will be danger from weapons in the month of the rashi
(solar month) which contains 10 rekhas. An armour together
with Vajra should be given in charity to ward off this evil
effect.
There will be danger of disgrace for no cause in the  month
of the rashi (solar month) which has 11 rekhas. An idol of
the moon made of 10 tolas of gold should be given in charity
to obtain relief from this evil effect.
There will be danger of death from drowning in the month of
the rashi (solar month) which has 12 rekhas. Land full of
crops should be given in charity to obtain relief from this
evil effect.
There will be danger of death from wild and violent animals
in the month of the rashi (solar month) in which there are 13
rekhas. A Shaligram Shila should be given in charity to
obtain relief from this evil effect.
There will be danger of death in the month of the rashi
(solar month) in which there are 14 rekhas. A Varah Murti
made of gold should be given in charity to obtain relief from
this evil effect.
There will be danger of the wrath of the king (Government) in
the month of the rashi (solar month) in which there are 15
rekhas. An elephant should be given in charity to obtain
relief from this evil effect.
There will be danger of arishta (calamity, disaster, or
misfortune) in the month of the rashi (solar month) in which
there are 16 rekhas. A kalpa Vriksha made of gold should be
given in charity to obtain relief from this evil effect.
There will be danger from diseases in the month of the rashi
that has 17 rekhas. A cow and jaggery should be given in
charity to obtain relief from this evil effect.
There will be danger of conflict in the month of the rashi
that has 18 rekhas. A cow, jewels, land, and gold should be
given in charity to obtain relief from this evil effect.
There will be possibility of banishment from the homeland in
the month of the rashi which has 19 rekhas. Family deity
should be worshipped to obtain relief from this evil effect.
There will be loss of intelligence in the month of the rashi
which has 20 rekhas. Goddess Saraswati should be worshipped
to obtain relief from this evil effect.
There will be distress from diseases in the month of the
rashi that has 21 rekhas. A heap of grains, shaped like a
mountain, should be given in charity to obtain relief from
this evil effect.
There will be distress to kinsmen in the month of the rashi
that has 22 rekhas. Gold should be given in charity to obtain
relief from this evil effect.
The native will be in distress in the month of the rashi that
has 23 rekhas. An idol of the sun made of 7 tolas of gold
should be given in charity to obtain relief from this evil
effect.
There will be death of the kinsmen in the month of the rashi
that has 24 rekhas. 10 cows should be given in charity to
obtain relief from this evil effect.
There will be loss of wisdom in the month of the rashi that
has 25 rekhas. Goddess Saraswati should be worshipped to
obtain relief from this evil effect.
There will be loss of wealth in the month of the rashi that
has 26 rekhas. Gold should be given in charity to obtain
relief from this evil effect.
There will be loss of wealth in the month of the rashi that
has 27 rekhas. Sri Sukta Japa should be performed to obtain
relief from this evil effect.
There will be losses in several ways in the month of the
rashi that has 28 rekhas. Havana of Surya should be performed
to obtain relief from this evil effect.
There will be anxieties all round in the month of the rashi
that has 29 rekhas. Ghee, clothes, and gold should be given
in charity to obtain relief from this evil effect.
There will be gains of wealth and grains etc., in the month
of the rashi that has 30 rekhas.
Auspicious effects of more than 30 rekhas in a Rashi

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P314_B001_03

- 身份：正文
- PDF 页：314
- 偈颂：11-28
- 标题路径：CHAPTER 72 Aggregational Ashtakavargas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Aggregational Ashtakavargas · Sloka 11-28 [present] · PDF page 314

11-28. There will be danger of death in the month of the
rashi (during the period Surya transits that rashi) which has
7 or less than 7 rekhas in the samudaya Ashtakavarg. To ward
off this evil effect, 20 tolas of gold and 2 heaps of sesame
seeds resembling the shape of a mountain, should be given in
charity.
There will be possibility of death in the month of that rashi
(solar month) which has 8 rekhas. Tuladan of camphor is
recommended to obtain relief from this evil effect.
There will be danger of snakes in the month of the rashi
(solar month) which has 9 rekhas. A chariot with 7 horses
should be given in charity to obtain relief from this evil
effect.
There will be danger from weapons in the month of the rashi
(solar month) which contains 10 rekhas. An armour together
with Vajra should be given in charity to ward off this evil
effect.
There will be danger of disgrace for no cause in the month of
the rashi (solar month) which has 11 rekhas. An idol of the
moon made of 10 tolas of gold should be given in charity to
obtain relief from this evil effect.
There will be danger of snakes in the month of the rashi
(solar month) which has 9 rekhas. A chariot with 7 horses
should be given in charity to obtain relief from this evil
effect.
There will be danger from weapons in the month of the rashi
(solar month) which contains 10 rekhas. An armour together
with Vajra should be given in charity to ward off this evil
effect.
There will be danger of disgrace for no cause in the  month
of the rashi (solar month) which has 11 rekhas. An idol of
the moon made of 10 tolas of gold should be given in charity
to obtain relief from this evil effect.
There will be danger of death from drowning in the month of
the rashi (solar month) which has 12 rekhas. Land full of
crops should be given in charity to obtain relief from this
evil effect.
There will be danger of death from wild and violent animals
in the month of the rashi (solar month) in which there are 13
rekhas. A Shaligram Shila should be given in charity to
obtain relief from this evil effect.
There will be danger of death in the month of the rashi
(solar month) in which there are 14 rekhas. A Varah Murti
made of gold should be given in charity to obtain relief from
this evil effect.
There will be danger of the wrath of the king (Government) in
the month of the rashi (solar month) in which there are 15
rekhas. An elephant should be given in charity to obtain
relief from this evil effect.
There will be danger of arishta (calamity, disaster, or
misfortune) in the month of the rashi (solar month) in which
there are 16 rekhas. A kalpa Vriksha made of gold should be
given in charity to obtain relief from this evil effect.
There will be danger from diseases in the month of the rashi
that has 17 rekhas. A cow and jaggery should be given in
charity to obtain relief from this evil effect.
There will be danger of conflict in the month of the rashi
that has 18 rekhas. A cow, jewels, land, and gold should be
given in charity to obtain relief from this evil effect.
There will be possibility of banishment from the homeland in
the month of the rashi which has 19 rekhas. Family deity
should be worshipped to obtain relief from this evil effect.
There will be loss of intelligence in the month of the rashi
which has 20 rekhas. Goddess Saraswati should be worshipped
to obtain relief from this evil effect.
There will be distress from diseases in the month of the
rashi that has 21 rekhas. A heap of grains, shaped like a
mountain, should be given in charity to obtain relief from
this evil effect.
There will be distress to kinsmen in the month of the rashi
that has 22 rekhas. Gold should be given in charity to obtain
relief from this evil effect.
The native will be in distress in the month of the rashi that
has 23 rekhas. An idol of the sun made of 7 tolas of gold
should be given in charity to obtain relief from this evil
effect.
There will be death of the kinsmen in the month of the rashi
that has 24 rekhas. 10 cows should be given in charity to
obtain relief from this evil effect.
There will be loss of wisdom in the month of the rashi that
has 25 rekhas. Goddess Saraswati should be worshipped to
obtain relief from this evil effect.
There will be loss of wealth in the month of the rashi that
has 26 rekhas. Gold should be given in charity to obtain
relief from this evil effect.
There will be loss of wealth in the month of the rashi that
has 27 rekhas. Sri Sukta Japa should be performed to obtain
relief from this evil effect.
There will be losses in several ways in the month of the
rashi that has 28 rekhas. Havana of Surya should be performed
to obtain relief from this evil effect.
There will be anxieties all round in the month of the rashi
that has 29 rekhas. Ghee, clothes, and gold should be given
in charity to obtain relief from this evil effect.
There will be gains of wealth and grains etc., in the month
of the rashi that has 30 rekhas.
Auspicious effects of more than 30 rekhas in a Rashi

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P314_B001_04

- 身份：正文
- PDF 页：314
- 偈颂：11-28
- 标题路径：CHAPTER 72 Aggregational Ashtakavargas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Aggregational Ashtakavargas · Sloka 11-28 [present] · PDF page 314

11-28. There will be danger of death in the month of the
rashi (during the period Surya transits that rashi) which has
7 or less than 7 rekhas in the samudaya Ashtakavarg. To ward
off this evil effect, 20 tolas of gold and 2 heaps of sesame
seeds resembling the shape of a mountain, should be given in
charity.
There will be possibility of death in the month of that rashi
(solar month) which has 8 rekhas. Tuladan of camphor is
recommended to obtain relief from this evil effect.
There will be danger of snakes in the month of the rashi
(solar month) which has 9 rekhas. A chariot with 7 horses
should be given in charity to obtain relief from this evil
effect.
There will be danger from weapons in the month of the rashi
(solar month) which contains 10 rekhas. An armour together
with Vajra should be given in charity to ward off this evil
effect.
There will be danger of disgrace for no cause in the month of
the rashi (solar month) which has 11 rekhas. An idol of the
moon made of 10 tolas of gold should be given in charity to
obtain relief from this evil effect.
There will be danger of snakes in the month of the rashi
(solar month) which has 9 rekhas. A chariot with 7 horses
should be given in charity to obtain relief from this evil
effect.
There will be danger from weapons in the month of the rashi
(solar month) which contains 10 rekhas. An armour together
with Vajra should be given in charity to ward off this evil
effect.
There will be danger of disgrace for no cause in the  month
of the rashi (solar month) which has 11 rekhas. An idol of
the moon made of 10 tolas of gold should be given in charity
to obtain relief from this evil effect.
There will be danger of death from drowning in the month of
the rashi (solar month) which has 12 rekhas. Land full of
crops should be given in charity to obtain relief from this
evil effect.
There will be danger of death from wild and violent animals
in the month of the rashi (solar month) in which there are 13
rekhas. A Shaligram Shila should be given in charity to
obtain relief from this evil effect.
There will be danger of death in the month of the rashi
(solar month) in which there are 14 rekhas. A Varah Murti
made of gold should be given in charity to obtain relief from
this evil effect.
There will be danger of the wrath of the king (Government) in
the month of the rashi (solar month) in which there are 15
rekhas. An elephant should be given in charity to obtain
relief from this evil effect.
There will be danger of arishta (calamity, disaster, or
misfortune) in the month of the rashi (solar month) in which
there are 16 rekhas. A kalpa Vriksha made of gold should be
given in charity to obtain relief from this evil effect.
There will be danger from diseases in the month of the rashi
that has 17 rekhas. A cow and jaggery should be given in
charity to obtain relief from this evil effect.
There will be danger of conflict in the month of the rashi
that has 18 rekhas. A cow, jewels, land, and gold should be
given in charity to obtain relief from this evil effect.
There will be possibility of banishment from the homeland in
the month of the rashi which has 19 rekhas. Family deity
should be worshipped to obtain relief from this evil effect.
There will be loss of intelligence in the month of the rashi
which has 20 rekhas. Goddess Saraswati should be worshipped
to obtain relief from this evil effect.
There will be distress from diseases in the month of the
rashi that has 21 rekhas. A heap of grains, shaped like a
mountain, should be given in charity to obtain relief from
this evil effect.
There will be distress to kinsmen in the month of the rashi
that has 22 rekhas. Gold should be given in charity to obtain
relief from this evil effect.
The native will be in distress in the month of the rashi that
has 23 rekhas. An idol of the sun made of 7 tolas of gold
should be given in charity to obtain relief from this evil
effect.
There will be death of the kinsmen in the month of the rashi
that has 24 rekhas. 10 cows should be given in charity to
obtain relief from this evil effect.
There will be loss of wisdom in the month of the rashi that
has 25 rekhas. Goddess Saraswati should be worshipped to
obtain relief from this evil effect.
There will be loss of wealth in the month of the rashi that
has 26 rekhas. Gold should be given in charity to obtain
relief from this evil effect.
There will be loss of wealth in the month of the rashi that
has 27 rekhas. Sri Sukta Japa should be performed to obtain
relief from this evil effect.
There will be losses in several ways in the month of the
rashi that has 28 rekhas. Havana of Surya should be performed
to obtain relief from this evil effect.
There will be anxieties all round in the month of the rashi
that has 29 rekhas. Ghee, clothes, and gold should be given
in charity to obtain relief from this evil effect.
There will be gains of wealth and grains etc., in the month
of the rashi that has 30 rekhas.
Auspicious effects of more than 30 rekhas in a Rashi

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P314_B001_05

- 身份：正文
- PDF 页：314
- 偈颂：11-28
- 标题路径：CHAPTER 72 Aggregational Ashtakavargas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Aggregational Ashtakavargas · Sloka 11-28 [present] · PDF page 314

11-28. There will be danger of death in the month of the
rashi (during the period Surya transits that rashi) which has
7 or less than 7 rekhas in the samudaya Ashtakavarg. To ward
off this evil effect, 20 tolas of gold and 2 heaps of sesame
seeds resembling the shape of a mountain, should be given in
charity.
There will be possibility of death in the month of that rashi
(solar month) which has 8 rekhas. Tuladan of camphor is
recommended to obtain relief from this evil effect.
There will be danger of snakes in the month of the rashi
(solar month) which has 9 rekhas. A chariot with 7 horses
should be given in charity to obtain relief from this evil
effect.
There will be danger from weapons in the month of the rashi
(solar month) which contains 10 rekhas. An armour together
with Vajra should be given in charity to ward off this evil
effect.
There will be danger of disgrace for no cause in the month of
the rashi (solar month) which has 11 rekhas. An idol of the
moon made of 10 tolas of gold should be given in charity to
obtain relief from this evil effect.
There will be danger of snakes in the month of the rashi
(solar month) which has 9 rekhas. A chariot with 7 horses
should be given in charity to obtain relief from this evil
effect.
There will be danger from weapons in the month of the rashi
(solar month) which contains 10 rekhas. An armour together
with Vajra should be given in charity to ward off this evil
effect.
There will be danger of disgrace for no cause in the  month
of the rashi (solar month) which has 11 rekhas. An idol of
the moon made of 10 tolas of gold should be given in charity
to obtain relief from this evil effect.
There will be danger of death from drowning in the month of
the rashi (solar month) which has 12 rekhas. Land full of
crops should be given in charity to obtain relief from this
evil effect.
There will be danger of death from wild and violent animals
in the month of the rashi (solar month) in which there are 13
rekhas. A Shaligram Shila should be given in charity to
obtain relief from this evil effect.
There will be danger of death in the month of the rashi
(solar month) in which there are 14 rekhas. A Varah Murti
made of gold should be given in charity to obtain relief from
this evil effect.
There will be danger of the wrath of the king (Government) in
the month of the rashi (solar month) in which there are 15
rekhas. An elephant should be given in charity to obtain
relief from this evil effect.
There will be danger of arishta (calamity, disaster, or
misfortune) in the month of the rashi (solar month) in which
there are 16 rekhas. A kalpa Vriksha made of gold should be
given in charity to obtain relief from this evil effect.
There will be danger from diseases in the month of the rashi
that has 17 rekhas. A cow and jaggery should be given in
charity to obtain relief from this evil effect.
There will be danger of conflict in the month of the rashi
that has 18 rekhas. A cow, jewels, land, and gold should be
given in charity to obtain relief from this evil effect.
There will be possibility of banishment from the homeland in
the month of the rashi which has 19 rekhas. Family deity
should be worshipped to obtain relief from this evil effect.
There will be loss of intelligence in the month of the rashi
which has 20 rekhas. Goddess Saraswati should be worshipped
to obtain relief from this evil effect.
There will be distress from diseases in the month of the
rashi that has 21 rekhas. A heap of grains, shaped like a
mountain, should be given in charity to obtain relief from
this evil effect.
There will be distress to kinsmen in the month of the rashi
that has 22 rekhas. Gold should be given in charity to obtain
relief from this evil effect.
The native will be in distress in the month of the rashi that
has 23 rekhas. An idol of the sun made of 7 tolas of gold
should be given in charity to obtain relief from this evil
effect.
There will be death of the kinsmen in the month of the rashi
that has 24 rekhas. 10 cows should be given in charity to
obtain relief from this evil effect.
There will be loss of wisdom in the month of the rashi that
has 25 rekhas. Goddess Saraswati should be worshipped to
obtain relief from this evil effect.
There will be loss of wealth in the month of the rashi that
has 26 rekhas. Gold should be given in charity to obtain
relief from this evil effect.
There will be loss of wealth in the month of the rashi that
has 27 rekhas. Sri Sukta Japa should be performed to obtain
relief from this evil effect.
There will be losses in several ways in the month of the
rashi that has 28 rekhas. Havana of Surya should be performed
to obtain relief from this evil effect.
There will be anxieties all round in the month of the rashi
that has 29 rekhas. Ghee, clothes, and gold should be given
in charity to obtain relief from this evil effect.
There will be gains of wealth and grains etc., in the month
of the rashi that has 30 rekhas.
Auspicious effects of more than 30 rekhas in a Rashi

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P315_B001_01

- 身份：正文
- PDF 页：315
- 偈颂：29
- 标题路径：CHAPTER 72 Aggregational Ashtakavargas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Aggregational Ashtakavargas · Sloka 29 [present] · PDF page 315

29. There will be all round increase in wealth, happiness in
respect of children, and enjoyments in the Samvatsar, month
and nakshatr of the rashi which has more than 30 rekhas.
There will be increase in wealth, property, children, and
good reputation if the rashi has more than 40 rekhas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P315_B002_01

- 身份：正文
- PDF 页：315
- 偈颂：30-31
- 标题路径：CHAPTER 72 Aggregational Ashtakavargas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Aggregational Ashtakavargas · Sloka 30-31 [present] · PDF page 315

30-31. The rashi which is auspicious in Ashtakavarg Samudaya,
is considered auspicious for all auspicious functions.
Consequently, the auspiciousness of Ashtakavarg should be got
checked before performing any function like marriage, etc..
If a rashi is not auspicious in Ashtakavarg, then its
auspiciousness should be checked from transit effects. lt is
not necessary to check transit effects, if a rashi is
auspicious in Ashtakavarg. Thus, the auspiciousness of the
rashi in the Ashtakavarg should be considered as paramount.
