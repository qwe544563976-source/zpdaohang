# 第 70 章：Effects of the Ashtakavarg

- 来源：BPHS 97 章版
- 原始卡片：30 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P308_B002_01

- 身份：正文
- PDF 页：308
- 偈颂：1-6
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 1-6 [present] · PDF page 308

1-6. The matters to be considered from Surya and other grahas
are as follows:
Surya : The soul (Atma), nature, physical strength, joys and
sorrows, and father.
Chandr: Mind, wisdom, joy and mother.
Mangal: Co-borns, strength, qualities, and land.
Buddh : Business dealings, livelihood, and friends.
Guru  : Nourishment of the body, learning, son (children),
wealth, and property.
Shukr : Marriage, enjoyments, conveyance, prostitution, and
sexual intercourse with women.
Shani : Longevity, source of maintenance, grief, danger,
losses, and death.
The following procedure should be adopted to ascertain the
effects of a house. Multiply the number of rekhas with the
Yog Pinda (Rashi Pinda plus Grah Pinda) connected with the
Ashtakavarg of that grah and divide the product by 27. The
remainder will denote the number of the nakshatras beginning
from Ashvini. During the transit of Shani in that nakshatr
the bhava concerned will be harmed. In other words, the
effects of that bhava will become unfavourable.
Surya's  Ashtakavarg

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P308_B003_01

- 身份：正文
- PDF 页：308
- 偈颂：7-9
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 7-9 [present] · PDF page 308

7-9. The 9th house from Surya at the time of birth deals with
father. The rekhas of the rashi (of that bhava) as marked in
Surya's Ashtakavarg should be multiplied by the Yog Pinda and
the product be divided by 27 (the number of nakshatras). The
remainder will denote the number of nakshatras beginning from
Ashvini. The father will be in distress or he will otherwise
suffer when Shani in transit passes through the nakshatr.
Even when Shani passes in transit the Trikon nakshatras (5th
and 9th), father or relatives like father may die or suffer.
Notes: The 27 nakshatras are:

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P308_B004_01

- 身份：正文
- PDF 页：308
- 偈颂：1
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 1. Ashvini 10. Magha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 1 [present] · PDF page 308

1. Ashvini      10. Magha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P308_B005_01

- 身份：正文
- PDF 页：308
- 偈颂：2
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 2. Bharani 11. Purvaphalguni
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 2 [present] · PDF page 308

2. Bharani      11. Purvaphalguni

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P308_B006_01

- 身份：正文
- PDF 页：308
- 偈颂：3
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 3. Krittika 12. Uttaraphalguni
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 3 [present] · PDF page 308

3. Krittika     12. Uttaraphalguni

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P308_B007_01

- 身份：正文
- PDF 页：308
- 偈颂：4
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 4. Rohini 13. Hasta
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 4 [present] · PDF page 308

4. Rohini       13. Hasta

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P308_B008_01

- 身份：正文
- PDF 页：308
- 偈颂：5
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 5. Mrigasira 14. Chitra
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 5 [present] · PDF page 308

5. Mrigasira    14. Chitra

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P308_B009_01

- 身份：正文
- PDF 页：308
- 偈颂：6
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 6. Ardra 15. Swati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 6 [present] · PDF page 308

6. Ardra        15. Swati

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P308_B010_01

- 身份：正文
- PDF 页：308
- 偈颂：7
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 7. Punarvasu 16. Vishaka
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 7 [present] · PDF page 308

7. Punarvasu    16. Vishaka

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P308_B011_01

- 身份：正文
- PDF 页：308
- 偈颂：8
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 8. Pushya 17. Anuradha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 8 [present] · PDF page 308

8. Pushya       17. Anuradha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P308_B012_01

- 身份：正文
- PDF 页：308
- 偈颂：9
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 9. Aslesha 18. Jyeshtha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 9 [present] · PDF page 308

9. Aslesha      18. Jyeshtha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P308_B013_01

- 身份：正文
- PDF 页：308
- 偈颂：19
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 19. Mula 24. Satabhisha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 19 [present] · PDF page 308

19. Mula        24. Satabhisha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P308_B014_01

- 身份：正文
- PDF 页：308
- 偈颂：20
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 20. Purvashada 25. Purvabhadra
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 20 [present] · PDF page 308

20. Purvashada  25. Purvabhadra

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P308_B015_01

- 身份：正文
- PDF 页：308
- 偈颂：21
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 21. Uttarashada 26. Uttarabhadra
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 21 [present] · PDF page 308

21. Uttarashada 26. Uttarabhadra

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P308_B016_01

- 身份：正文
- PDF 页：308
- 偈颂：22
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 22. Shravana 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 22 [present] · PDF page 308

22. Shravana    27. Revati

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P309_B001_01

- 身份：正文
- PDF 页：309
- 偈颂：23
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 22. Shravana 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 23 [present] · PDF page 309

23. Dhanishtha
By dividing the 27 nakshatras in three equal parts the 1st,
10th, and 19th fall in Trikon from each other. Surya is
Pitrakarak (significator of father). Therefore, all about
father is ascertained from the Surya's Ashtakavarg.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P309_B002_01

- 身份：正文
- PDF 页：309
- 偈颂：10-11
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 22. Shravana 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 10-11 [present] · PDF page 309

10-11. If the Ashtakavarg rekha number is multiplied by the
Yog Pinda and the product is divided by 12, the remainder
will denote the rashi through which or through the rashis in
Trikon to it, the transit of Shani will cause harm or
unfavourable effects to father. Death of the father may occur
if the Dasa prevailing at that time be unfavourable. If the
Dasa be favourable father will face only adverse effects
(like serious illness).
Arishta to father

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P309_B003_01

- 身份：正文
- PDF 页：309
- 偈颂：12-14
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 22. Shravana 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 12-14 [present] · PDF page 309

12-14. The death of the father may be expected if Rahu,
Shani, or Mangal are in the 4th from Surya at the time of
transit of Shani through any of the above three rashis
(Trikon rashis). The death of the father will come to pass by
such transit if at that time:
1). Shani associated or aspected by a malefic be in the 9th
from Lagn or Chandr.
2). The Dasa of the lord of the 4th from Lagn be in
operation.
The death does not take place if a favourable Dasa be in
force at the time of Shani's transit. This should be kept in
mind by the Jyotishi's while making predictions.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P309_B004_01

- 身份：正文
- PDF 页：309
- 偈颂：15
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 22. Shravana 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 15 [present] · PDF page 309

15. If the rashi of Lagn of the native be the 8th rashi from
Lagn of the father or if the lord of the 8th from father's
Lagn be in Lagn of the native, he takes over all the
responsibilities of his father after the latter's death.

Favourable Yogas for father

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P309_B005_01

- 身份：正文
- PDF 页：309
- 偈颂：16-18
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 22. Shravana 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 16-18 [present] · PDF page 309

16-18. (1) The father enjoys happiness in the Dasa of the
lord of the 4th from Lagn.
~L4I1+L4I11+(L4I10)2+(L4I11)2~
(2) The native is obedient to his father if the lord of the
4th be in Lagn or the 11th, or in the 11th or the 10th from
Chandr.
(3) If the birth be in the 3rd rashi from Lagn or Chandr of
the father, the native makes proper use of the wealth
inherited from his father.
(4) If the birth be in the 10th rashi from Lagn or Chandr of
the father, the native will inherit all the good qualities of
his father.
(5) If the lord of the 10th be in Lagn (in the rashi kundali
of the native), the native will be more distinguished than
his father.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P310_B001_01

- 身份：正文
- PDF 页：310
- 偈颂：19-20
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 22. Shravana 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 19-20 [present] · PDF page 310

19-20. No auspicious functions like marriage etc., should be
performed in the month of rashis (that is.when Surya transits
that rashi) which has more number of dots in Surya's
Ashtakavarg. The same applies to the Samvatsar of that rashi
[that is, when the mean Guru transits that rashi. Auspicious
functions should be performed when Surya or the mean Guru
transits the rashi which has more rekhas in Surya's
Ashtakavarg.

Effects of Chandr's Ashtakavarg

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P310_B002_01

- 身份：正文
- PDF 页：310
- 偈颂：21-23
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 22. Shravana 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 21-23 [present] · PDF page 310

21-23. In the same manner no auspicious functions should be
performed during the transit of Chandr in the rashi which has
larger number of dots in Chandr's Ashtakavarg. Consideration
regarding mother, house, and village should be done from the
4th bhava from Chandr. Therefore, multiply the number of
rekhas in the Ashtakavarg of Chandr by the Yog Pinda of that
Ashtakavarg and divide the product by 27. The death of or
distress to mother may be expected when Shani passes in
transit through the nakshatr denoted by the remainder. Then,
divide the product by 12. The death of the mother may occur
when Shani transits the rashi denoted by the remainder.
Distress to mother may be predicted when Shani transits the
nakshatras or rashis in Trikon to nakshatr and rashi
indicated above.

Effects of the Ashtakavarg of Mangal

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P310_B003_01

- 身份：正文
- PDF 页：310
- 偈颂：24-27
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 22. Shravana 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 24-27 [present] · PDF page 310

24-27. Consideration of brothers (co-borns), valour and
patience is done from Mangal's Ashtakavarg. If the number of
rekha is larger in any rashi after Trikon Shodhana, there
will be gains of land, happiness from wife and great
happiness to brother when Mangal passes through that rashi in
transit. If Mangal be weak, the brothers will be short lived.
There will be distress to brothers when Mangal transits a
rashi without rekhas. Here also the Yog Pinda of Mangal
should be multiplied by the number of rekhas in the
Ashtakavarg and the product be divided separately by 27 and

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P310_B004_01

- 身份：正文
- PDF 页：310
- 偈颂：12
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 22. Shravana 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 12 [present] · PDF page 310

12. The remainder will denote the nakshatr and rashi
respectively. The brother will suffer whenever Shani transits
that nakshatr or rashi (or the Trikon nakshatras or rashis).
Effects of Buddh's Ashtakavarg

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P310_B005_01

- 身份：正文
- PDF 页：310
- 偈颂：28-29
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 22. Shravana 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 28-29 [present] · PDF page 310

28-29. Consideration in regard to family, maternal uncle, and
friends should be done from the 4th bhava from Buddh. The
family etc., will enjoy happiness during the transit of
Buddh's Ashtakavarg. After performing Trikon and Ekadhipatya
Shodhana in Buddh's Ashtakavarg, the happiness or distress of
the family should be predicted from the transit of Shani
through the resultant nakshatr and rashi (and those in Trikon
to them)
Effects of Guru's Ashtakavarg

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P311_B001_01

- 身份：正文
- PDF 页：311
- 偈颂：30-33
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 22. Shravana 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 30-33 [present] · PDF page 311

30-33. All about knowledge, religious inclinations of the
native and son (progeny) is to be ascertained from the 5th
bhava from Guru. If the rekhas in the 5th bhava from Guru are
larger in number in the Ashtakavarg, there will be great
happiness in respect of progeny. If the dots are larger in
number, the happiness in respect of progeny will be meagre.
The number of children are equal to the number of rekhas in
the 5th bhava (from Guru) provided it is not the rashi of
debilitation of Guru or his enemy's rashi. In that case the
number of children will be very limited. The number of
children is also equal to the number of navams in which the
lord of the 5th from Guru is posited.
Multiply the Yog Pinda of Guru by the number of rekhas in the
Ashtakavarg and divide the product separately by 27 and 12.
The remainders will denote the nakshatr and transit of Shani
through that nakshatr and its Trikon nakshatras and of that
rashi and its Trikon rashis.  During that period the
knowledge, learning, and religious activities of the native
will also be adversely affected.
Effects of the Ashtakavarg of Shukr

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P311_B002_01

- 身份：正文
- PDF 页：311
- 偈颂：34-36
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 22. Shravana 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 34-36 [present] · PDF page 311

34-36. There will be gain of wealth, land, and happiness, and
marriage, whenever Shukr passes in transit through the rashis
which have larger number of rekhas in the Ashtakavarg of
Shukr. These gains will be from the directions of the 7th
rashi from Shukr and of its Trikon rashis. The effects should
be judged in the manner already explained earlier after
multiplying the rekhas in the 7th bhava from Shukr by the Yog
Pinda.
Effects of Shani's Ashtakavarg

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P311_B003_01

- 身份：正文
- PDF 页：311
- 偈颂：37-40
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 22. Shravana 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 37-40 [present] · PDF page 311

37-40. The 8th bhava from Shani signifies death as well as
longevity. Assessment about longevity (span of life) should
be made from that bhava through the Ashtakavarg. Therefore,
predict distress to the native in the year equal to the
number of rekhas in the Ashtakavarg from Lagn up to Shani.
The year equal to the number of rekhas from Shani up to Lagn
will also be of distress. If in the year equal to the total
of the above rekhas Arishta Dasa be also in operation, there
can be possibility of death of the native.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P311_B004_01

- 身份：正文
- PDF 页：311
- 偈颂：41-42
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 22. Shravana 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 41-42 [present] · PDF page 311

41-42. Multiply the Yog Pinda by the number of rekhas in the
Ashtakavarg and divide the product by 27. The death of the
native will take place when Shani passes in transit through
the nakshatr denoted by the remainder or its Trikon
nakshatras. Again, divide the product by 12. The native will
face danger of death when Shani passes in transit through the
rashi denoted by the remainder or through its Trikon rashis.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P311_B005_01

- 身份：正文
- PDF 页：311
- 偈颂：43-44
- 标题路径：CHAPTER 70 Effects of the Ashtakavarg › 22. Shravana 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Ashtakavarg · Sloka 43-44 [present] · PDF page 311

43-44. The results will be favourable when Shani passes in
transit through rashis which have larger number of rekhas in
Shani's Ashtakavarg. Shani's transit through rashis which
have larger number of dots will produce only evil effects.
