# 第 23 章：Effects Of Vyaya Bhava

- 来源：BPHS 97 章版
- 原始卡片：10 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P059_B002_01

- 身份：正文
- PDF 页：59
- 偈颂：1-4
- 标题路径：CHAPTER 23 Effects Of Vyaya Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Vyaya Bhava · Sloka 1-4 [present] · PDF page 59

1-4. 0 Brahmin, now I tell you about the effects of Vyaya
Bhava. There will be expenses on good accounts if Vyaya's
lord is with a benefic, or in his own Bhava, or exalted, or
if a benefic occupies Vyaya.
~2iL12**2E+2O+2NO+2I11+2IN11+2I5+2IN5+2I9+2IN9~
One will own beautiful houses and beds and be endowed with
superior scented articles and pleasures if Chandr happens
to be Vyaya's lord and be exalted, or be in its own Rashi
and/or Navamsh or in Labh/Dharm/Putr Bhava in Rashi/Navamsh.
The said native will live with rich clothes, and ornaments,
be learned and lordly.
~L12I6+L12I8+L12Ne+L12Nd+L12IN8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P059_B003_01

- 身份：正文
- PDF 页：59
- 偈颂：5-6
- 标题路径：CHAPTER 23 Effects Of Vyaya Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Vyaya Bhava · Sloka 5-6 [present] · PDF page 59

5-6. And if Vyaya's lord is in Ari, or Randhr Bhava, or be
in enemy's Navamsh, in debilitation Navamsh, or in Randhr
Bhava in Navamsh, one will be devoid of happiness from
wife, be troubled by expenses and deprived of general
happiness.
~L12K+L12T~
If he be in an angle or trine, the native will beget a
spouse.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P059_B004_01

- 身份：正文
- PDF 页：59
- 偈颂：7
- 标题路径：CHAPTER 23 Effects Of Vyaya Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Vyaya Bhava · Sloka 7 [present] · PDF page 59

7. Just as these effects are derived from Tanu Bhava in
regard to the native, similar deductions be made about
co-borns, etc., from Sahaj and other bhavas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P059_B005_01

- 身份：正文
- PDF 页：59
- 偈颂：8
- 标题路径：CHAPTER 23 Effects Of Vyaya Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Vyaya Bhava · Sloka 8 [present] · PDF page 59

8. Grahas placed in the visible half of the zodiac will
give explicit results while the ones in the invisible half
will confer secret results.
~8I12*3I12*7I12*1I12+L12Y1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P059_B006_01

- 身份：正文
- PDF 页：59
- 偈颂：9
- 标题路径：CHAPTER 23 Effects Of Vyaya Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Vyaya Bhava · Sloka 9 [present] · PDF page 59

9. If Rahu is in Vyaya along with Mangal, Shani, and Surya,
the native will go to hell. Similar effect will occur if
Vyaya's lord is with Surya.
~BI12*L12E+BI12*L12DB+BI12*L12AB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P059_B007_01

- 身份：正文
- PDF 页：59
- 偈颂：10
- 标题路径：CHAPTER 23 Effects Of Vyaya Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Vyaya Bhava · Sloka 10 [present] · PDF page 59

10. If there is a benefic in Vyaya, while its lord is
exalted or is yuti with or receives a drishti from a
benefic, one will attain final emancipation.
~L12Ym*mI12*L12Dm~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P059_B008_01

- 身份：正文
- PDF 页：59
- 偈颂：11
- 标题路径：CHAPTER 23 Effects Of Vyaya Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Vyaya Bhava · Sloka 11 [present] · PDF page 59

11. One will wander from country to country if Vyaya's lord
and Vyaya Bhava are with malefics and Vyaya's lord gives a
drishti to or receives a drishti from malefics.
~L12YB*BI12*L12DB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P059_B009_01

- 身份：正文
- PDF 页：59
- 偈颂：12
- 标题路径：CHAPTER 23 Effects Of Vyaya Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Vyaya Bhava · Sloka 12 [present] · PDF page 59

12. One will move in his own country if Vyaya's lord and
Vyaya Bhava are with benefics and  Vyaya's lord gives a
drishti to or receives a drishti from benefics.
~7I12*-7DB+3I12*-3DB+8I12*-8DB+9I12*-9DB~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P059_B010_01

- 身份：正文
- PDF 页：59
- 偈颂：13
- 标题路径：CHAPTER 23 Effects Of Vyaya Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Vyaya Bhava · Sloka 13 [present] · PDF page 59

13. Earnings will be through sinful measures if Vyaya is
occupied by Shani, or Mangal, etc., and is not receiving a
drishti from a benefic.
~L1I12*L12I1*L12Y6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P059_B011_01

- 身份：正文
- PDF 页：59
- 偈颂：14
- 标题路径：CHAPTER 23 Effects Of Vyaya Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Vyaya Bhava · Sloka 14 [present] · PDF page 59

14. If Lagn's lord is in Vyaya, while Vyaya's lord is in
Lagn with Shukr, expenses will be on religious grounds.
