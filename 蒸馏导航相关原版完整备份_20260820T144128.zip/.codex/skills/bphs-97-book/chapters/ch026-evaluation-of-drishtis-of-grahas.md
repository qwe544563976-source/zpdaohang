# 第 26 章：Evaluation of Drishtis of Grahas

- 来源：BPHS 97 章版
- 原始卡片：6 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P082_B002_01

- 身份：正文
- PDF 页：82
- 偈颂：1
- 标题路径：CHAPTER 26 Evaluation of Drishtis of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation of Drishtis of Grahas · Sloka 1 [present] · PDF page 82

1. O Glorious, it is said that drishtis (of grahas) and
their strengths are to be known in deciding the effects.
How many kinds are these? Please clarify doubts.
{gascal}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P082_B003_01

- 身份：正文
- PDF 页：82
- 偈颂：2-5
- 标题路径：CHAPTER 26 Evaluation of Drishtis of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation of Drishtis of Grahas · Sloka 2-5 [present] · PDF page 82

2-5. Drishtis of the grahas: O Brahmin, I have earlier
stated drishtis based on rashis. The other kind is between
grahas which I detail below. 3rd and 10th, 5th and 9th, 4th
and 8th, and lastly 7th: on these places the drishtis
increase gradually in slabs of quarters i.e 1/4, 1/2,
3/4th, and full. The effects (due to such drishtis) will
also be proportionate. All grahas give a drishti to the 7th
fully. Shani, Guru and Mangal have special drishtis
respectively on the 3rd and the10th, the 5th and the 9th,
and the 4th and the 8th. The ancient preceptors have
explained these which ordinary (arising by mere rashi
positions). By subtle mathematical calculations, these
drishtis will have to be clearly understood as under.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P082_B004_01

- 身份：正文
- PDF 页：82
- 偈颂：6-8
- 标题路径：CHAPTER 26 Evaluation of Drishtis of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation of Drishtis of Grahas · Sloka 6-8 [present] · PDF page 82

6-8. Evaluations of the Drishtis of the Grahas: Deduct the
longitude of the grah (or bhava) that receives a drishti
from that of the grah which gives the drishti. If the sum
exceeds six rashis (or 180 degrees) deduct the sum again
from 10 rashis (or 300 degrees). Convert the latter sum
into degrees and divide by two. The resultant product is
Drishti Kona (or aspectual angle). If the difference
(between the grah that gives the drishti and the grah that
receives the drishti) is in excess of 5 rashis, ignore the
rashis and multiply the degrees, etc., by 2 which is the
value of the drishti. If the difference is in excess of 4
rashis deduct it from 5 rashis (or 150 degrees) and the
resultant degees, etc., become the Drishti value. If the
difference is in excess of 3 rashis deduct it from 4 rashis
(or 120 degrees) and 'halve the product to be increased by
30' (?) to get the Drishti value. If the difference is
above 2 rashis ignore the rashis and add 15 to the degrees,
etc., to get the Drishti value. If it is in excess of one
rashi, ignore the rashis and divide the degrees by 2 to get
Drishti value.
{sandri}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P082_B005_01

- 身份：正文
- PDF 页：82
- 偈颂：9-10
- 标题路径：CHAPTER 26 Evaluation of Drishtis of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation of Drishtis of Grahas · Sloka 9-10 [present] · PDF page 82

9-10. Special consideration for Shani's drishtis: O
Brahmin, if Shani is the grah that gives a drishti find out
the difference between him and the  grah that receives the
drishti; if the sum is above 1 rashi, multiply the degrees,
etc., (ignoring rashi) by 2 to get the Drishti value. If
the sum is above nine rashis, the degrees to elapse be
doubled to get the Drishti value. If the sum is above 2
rashis, the degrees, etc., (in excess of 2 rashis) be
halved and deducted from 60. If the sum exceeds 8 rashis,
add to the degrees, etc., a figure of 30 to get the Drishti
value. In other cases, the sums be processed as explained
earlier.
{mandri}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P083_B001_01

- 身份：正文
- PDF 页：83
- 偈颂：11
- 标题路径：CHAPTER 26 Evaluation of Drishtis of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation of Drishtis of Grahas · Sloka 11 [present] · PDF page 83

11. Special consideration for Mangal's drishtis: Deduct the
longitude of Mangal from that of the grah that receives the
drishti (from Mangal). If the sum is 3 rashis & c (?) or 7
rashis & c, the degrees, etc., (after ignoring rashis) be
reduced from 60. If it is above 2 rashis, the degrees,
etc., be increased by half of it (i.e. add 50x) and
superadd 15. If the sum is 6 rashis, one Rup is the value.
{gurdri}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P083_B002_01

- 身份：正文
- PDF 页：83
- 偈颂：12
- 标题路径：CHAPTER 26 Evaluation of Drishtis of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation of Drishtis of Grahas · Sloka 12 [present] · PDF page 83

12. Special consideration for Guru's drishtis: Deduct the
longitude of Guru from that of the grah  taht receives the
drishti from Guru. If the resultant sum is 3 rashis & c or
7 rashis & c, halve the degrees, etc., (ignoring rashis)
and increase it by 15. It the sum is 4 rashis & c or 8
rashis 8 & c, the degrees, etc., (ignoring rashis) be
subtracted from 60 This will be the Drishti value. The sum
being in conformity with others than these be treated as
stated earlier.
