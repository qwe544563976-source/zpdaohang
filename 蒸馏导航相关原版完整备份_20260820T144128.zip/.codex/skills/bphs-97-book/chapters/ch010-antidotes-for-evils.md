# 第 10 章：Antidotes for Evils

- 来源：BPHS 97 章版
- 原始卡片：8 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P030_B002_01

- 身份：正文
- PDF 页：30
- 偈颂：1
- 标题路径：CHAPTER 10 Antidotes for Evils
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Antidotes for Evils · Sloka 1 [present] · PDF page 30

1. Those are the evils (due to a native). I now narrate the
antidotes for such evils as well, which will be helpful to
assess the extent of inauspiciousness.
~4K+5K+6K~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P030_B003_01

- 身份：正文
- PDF 页：30
- 偈颂：2
- 标题路径：CHAPTER 10 Antidotes for Evils
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Antidotes for Evils · Sloka 2 [present] · PDF page 30

2. Should one among Buddh, Guru, and Shukr be in an angle
from Lagn, all evils are destroyed as Surya eliminates
darkness.
~5X*5I1~909~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P030_B004_01

- 身份：正文
- PDF 页：30
- 偈颂：3
- 标题路径：CHAPTER 10 Antidotes for Evils
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Antidotes for Evils · Sloka 3 [present] · PDF page 30

3. Just as a single reverential obeisance before Lord
Shiva, the Trident holder, frees one from all sins, a
single but strong Guru in Lagn will ward off all the
evils.
~L1X*L1K~909~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P030_B005_01

- 身份：正文
- PDF 页：30
- 偈颂：4
- 标题路径：CHAPTER 10 Antidotes for Evils
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Antidotes for Evils · Sloka 4 [present] · PDF page 30

4. Lagn lord is singly capable of counteracting all evils
if he is strongly placed in an angle just as Lord Shiva,
the holder of the Bow, destroyed the three cities built of
gold, silver, and iron for the demons by Maya.
~!1DB*@bn+!1Dm*@bd~909~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P030_B006_01

- 身份：正文
- PDF 页：30
- 偈颂：5
- 标题路径：CHAPTER 10 Antidotes for Evils
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Antidotes for Evils · Sloka 5 [present] · PDF page 30

5. All evils are destroyed if a benefic drishties Lagn of
one born during the night in the bright half. Similarly, a
malefic's drishti on Lagn of one born during day time in
the dark half.
~1I12*R7I1~909~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P030_B007_01

- 身份：正文
- PDF 页：30
- 偈颂：6
- 标题路径：CHAPTER 10 Antidotes for Evils
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Antidotes for Evils · Sloka 6 [present] · PDF page 30

6. Surya in Vyaya will confer a hundred-year life span on
one born in Tul Lagn.
~5Y3+3D5~909~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P030_B008_01

- 身份：正文
- PDF 页：30
- 偈颂：7
- 标题路径：CHAPTER 10 Antidotes for Evils
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Antidotes for Evils · Sloka 7 [present] · PDF page 30

7. It will prove auspicious for the mother as well as the
native if Mangal joins or is drishtied by Guru.
~mH*BK+mH*BT~909~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P030_B009_01

- 身份：正文
- PDF 页：30
- 偈颂：9
- 标题路径：CHAPTER 10 Antidotes for Evils
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Antidotes for Evils · Sloka 9 [present] · PDF page 30

9. If malefics are surrounded by benefics while angles or
trines are themselves benefic-occupied evils disappear
soon. Not only this, evils will not follow from the bhavas
concerned.~909~
