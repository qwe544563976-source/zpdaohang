# 第 4 章：Zodiacal Rashis Described

- 来源：BPHS 97 章版
- 原始卡片：17 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P013_B002_01

- 身份：正文
- PDF 页：13
- 偈颂：1-2
- 标题路径：CHAPTER 4 Zodiacal Rashis Described
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Zodiacal Rashis Described · Sloka 1-2 [present] · PDF page 13

1-2. Importance of Hora: The word Hora is derived from
Ahoratr after dropping the first and last syllables. Thus,
Hora (lagnas) remains in between Ahoratr (i.e. day and
night) and after knowing Hora, the good and bad effects of
a native be known. Shri Vishnu, the Invisible is Time
personified. His limbs are the 12 rashis commencing from
Mesh.
{rasnam}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P013_B003_01

- 身份：正文
- PDF 页：13
- 偈颂：3
- 标题路径：CHAPTER 4 Zodiacal Rashis Described
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Zodiacal Rashis Described · Sloka 3 [present] · PDF page 13

3. Names of Rashis: The 12 rashis of the zodiac in order
are: Mesh,Vrishabh, Mithun, Kark, Simh , Kanya, Tula,
Vrischik, Dhanu, Makar, Kumbh, and Meen.
{raslim}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P013_B004_01

- 身份：正文
- PDF 页：13
- 偈颂：4-41/2
- 标题路径：CHAPTER 4 Zodiacal Rashis Described
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Zodiacal Rashis Described · Sloka 4-41/2 [present] · PDF page 13

4-41/2. Limbs of Kaal Purush: Kaal Purush (or time
personified) has his limbs as under with reference to the
12 rashis respectively: Head, face, arms, heart, stomach,
hip, space below navel, privities, thighs, knees, ankles,
and feet.
{rascla}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P013_B005_01

- 身份：正文
- PDF 页：13
- 偈颂：5-5 1/2
- 标题路径：CHAPTER 4 Zodiacal Rashis Described
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Zodiacal Rashis Described · Sloka 5-5 1/2 [present] · PDF page 13

5-5 1/2. Classification of Rashis : Movable, Fixed, and
Dual are the names given to the 12 rashis in order. These
are again known as malefic and benefic, successively.
Similarly, are male and female. Mesh, Simh, and Dhanu are
bilious. Vrishabh, Kanya, and Makar are windy. Mithun,
Tula, and Kumbh are mixed, while the rest are phlegmatic.
{rasmes}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P013_B006_01

- 身份：正文
- PDF 页：13
- 偈颂：6-7
- 标题路径：CHAPTER 4 Zodiacal Rashis Described
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Zodiacal Rashis Described · Sloka 6-7 [present] · PDF page 13

6-7. Mesh described: The Mesh is blood-red in complexion.
lt has a prominent (big) physique. It is a quadruped rashi
and strong during night. It denotes courage. It resides in
the east and is related to kings. It wanders in hills and
predominates in Rajo-gun (the second of the three
constituent qualities and the cause of great activity in
living beings). It rises with its back (a Prishtodaya
rashi) and is fiery. Its ruler is Mangal.
{rasvrb}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P013_B007_01

- 身份：正文
- PDF 页：13
- 偈颂：8
- 标题路径：CHAPTER 4 Zodiacal Rashis Described
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Zodiacal Rashis Described · Sloka 8 [present] · PDF page 13

8. Vrishabh described: Vrishabh's complexion is white, and
is lorded by Shukr. It is long and is a quadruped rashi. It
has strength in night and resides in the south. It
represents villages and businessmen. An earthy rashi,
Vrishabh rises with its back.
{rasmit}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P013_B008_01

- 身份：正文
- PDF 页：13
- 偈颂：9-9 1/2
- 标题路径：CHAPTER 4 Zodiacal Rashis Described
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Zodiacal Rashis Described · Sloka 9-9 1/2 [present] · PDF page 13

9-9 1/2. Mithun described: The rashi Mithun rises with its
head and represents a male and a female holding a mace and
lute. It lives in the west and is an, airy rashi. It is a
biped rashi as well and is strong in nights. It lives in
villages and is windy in temperament. It has an even body
with a green (grass like) hue. Its ruler is Buddh.
{raskar}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P014_B001_01

- 身份：正文
- PDF 页：14
- 偈颂：10-11
- 标题路径：CHAPTER 4 Zodiacal Rashis Described
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Zodiacal Rashis Described · Sloka 10-11 [present] · PDF page 14

10-11. Kark described: The rashi Kark is pale-red. It
resorts to forests and represents Brahmins. It is strong in
nights. It has many feet (i.e. it is a centipede rashi) and
has a bulky body. It is Sattvic in disposition (seen in
gods) and it is a watery rashi. It rises with its back and
is ruled by Chandr.
{rassim}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P014_B002_01

- 身份：正文
- PDF 页：14
- 偈颂：12
- 标题路径：CHAPTER 4 Zodiacal Rashis Described
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Zodiacal Rashis Described · Sloka 12 [present] · PDF page 14

12. Simh described: Simh  is ruled by Surya and is Sattvic.
It is a quadruped rashi and a royal rashi. It resorts to
forests and rises with its head. It has a large, white
body. It resides in the east and is strong during daytime.
{raskan}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P014_B003_01

- 身份：正文
- PDF 页：14
- 偈颂：13-14
- 标题路径：CHAPTER 4 Zodiacal Rashis Described
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Zodiacal Rashis Described · Sloka 13-14 [present] · PDF page 14

13-14. Kanya described: This rashi is a hill-resorter, and
is strong in daytime. It rises with its head and has a
medium build. It is a biped rashi and resides in the south.
It  has grains and fire in its hands. It belongs to the
business community and is variegated. It relates to
hurricanes ('Prabharanjani'). It is a Virgin and is Tamasic
(a disposition of demons). Its ruler is Buddh.
{rastul}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P014_B004_01

- 身份：正文
- PDF 页：14
- 偈颂：15-16 1/2
- 标题路径：CHAPTER 4 Zodiacal Rashis Described
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Zodiacal Rashis Described · Sloka 15-16 1/2 [present] · PDF page 14

15-16 1/2. Tula described: Tula is a Seershodaya rashi
rising with its head; Tula is strong in daytime. It is
black in complexion and is predominant with Rajo-gun. It
relates to the western direction and resorts to land. It is
destructive or mischievous ('Dhatin'). It represents Sudras
or the 4th Varna. It has a medium build physique and is a
biped rashi. Its lord is Shukr.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P014_B005_01

- 身份：正文
- PDF 页：14
- 偈颂：—
- 标题路径：CHAPTER 4 Zodiacal Rashis Described
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Zodiacal Rashis Described · Sloka unknown [unknown] · PDF page 14 · page_block BPHS_PL9_CHAP_97_P014_B005

{rasvrk}
Vrischik described:
Vrischik has a slender physique and is a centipede rashi.
It denotes Brahmins and resides in holes. Its direction is
north and is strong in daytime. It is reddish-brown and
resorts to water and land. It has a hairy physique and is
very sharp (or passionate). Mangal is its ruler.
{rasdha}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P014_B006_01

- 身份：正文
- PDF 页：14
- 偈颂：17-18 1/2
- 标题路径：CHAPTER 4 Zodiacal Rashis Described
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Zodiacal Rashis Described · Sloka 17-18 1/2 [present] · PDF page 14

17-18 1/2. Dhanu described: The rashi Dhanu rises with its
head and is lorded by Guru. It is a Sattvic rashi and is
tawny in hue. It has strength in night and is fiery. A
royal rashi, Dhanu is biped in first half. Its second half
is quadruped. It has an even build and adores an arch. It
resides in the east, resorts to land and is splendourous.
{rasmak}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P014_B007_01

- 身份：正文
- PDF 页：14
- 偈颂：19-20
- 标题路径：CHAPTER 4 Zodiacal Rashis Described
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Zodiacal Rashis Described · Sloka 19-20 [present] · PDF page 14

19-20. Makar described: Makar is lorded by Shani and has
predominance of Tamo-gun (a disposition seen in demons). It
is an earthy rashi and represents the southern direction.
It is strong in nights, and rises with back. It has a large
body. Its complexion is variegated and it resorts to both
forests and lands. Its first half is quadruped and its
second half footless moving in water.
{raskum}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P015_B001_01

- 身份：正文
- PDF 页：15
- 偈颂：21-21 1/2
- 标题路径：CHAPTER 4 Zodiacal Rashis Described
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Zodiacal Rashis Described · Sloka 21-21 1/2 [present] · PDF page 15

21-21 1/2. Kumbh described: The rashi Kumbh represents a
man holding a pot. Its complexion is deep-brown. It has
medium build and a biped rashi. It is very strong in
daytime. It resorts to deep water and is airy. It rises
with its head and is Tamasic. It rules Sudras, the 4th
Varna, and the west. Its lord is Shani, Surya's offspring.
{rasmee}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P015_B002_01

- 身份：正文
- PDF 页：15
- 偈颂：22-24
- 标题路径：CHAPTER 4 Zodiacal Rashis Described
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Zodiacal Rashis Described · Sloka 22-24 [present] · PDF page 15

22-24. Meen described: Meen resembles a pair of fish, one
tailed with the head of the other. This rashi is strong at
night. It is a watery rashi and is predominant with
Sattwa-gun. It denotes resoluteness and is a
water-resorter. It is footless and has a medium build. It
rules the north and rises with both head and back. It is
ruled by Guru. This is how the twelve rashis each of 30
degrees extent are described to evaluate gross and specific
effects.
{niscal}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P015_B003_01

- 身份：正文
- PDF 页：15
- 偈颂：25-30
- 标题路径：CHAPTER 4 Zodiacal Rashis Described
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Zodiacal Rashis Described · Sloka 25-30 [present] · PDF page 15

25-30. Nishek Lagn: O excellent of Maharishis, now is a
step explained to arrive at the Nishek Lagn when the natal
Lagn is known. Note the angular distance between Shani and
Mandi (Gulik). Add this to the difference between the Lagn
bhava (Madhya or cusp) and the 9th bhava (cusp). The
resultant product in rashis, degrees, etc. will represent
the months, days, etc. that elapsed between Nishek and
birth. At birth if Lagn  lord is in the invisible half
(i.e. from Lagn cusp to descendental cusp) add the degrees,
etc. Chandr  moved in the particular rashi occupied by her
to the above mentioned product. Then, Lagn at Nishek can be
worked out and the good and bad experienced by the native
in the womb can be guessed. One can also guess, with the
help of Nishek Lagn, effects like longevity, death, etc. of
the parents.
