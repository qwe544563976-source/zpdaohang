# 第 40 章：Yogas For Royal Association

- 来源：BPHS 97 章版
- 原始卡片：15 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P140_B002_01

- 身份：正文
- PDF 页：140
- 偈颂：1
- 标题路径：CHAPTER 40 Yogas For Royal Association
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas For Royal Association · Sloka 1 [present] · PDF page 140

1. If Karm's lord is yuti with or receives a drishti from
the dispositor of Amatya Karak, or even if Karm's lord is
yuti with or receives a drishti form Amatya Karak himself,
the native will be a chief in the kings court.
~-!10Dm*-!11Dm*-mI10*-mI11*!11DL11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P140_B003_01

- 身份：正文
- PDF 页：140
- 偈颂：2
- 标题路径：CHAPTER 40 Yogas For Royal Association
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas For Royal Association · Sloka 2 [present] · PDF page 140

2. If Karm and Labh Bhava are devoid of malefic occupation
and devoid of drishti from a malefic, while Labh Bhava
receives a drishti from its own lord, the native will be a
chief in the king's court.
~ºYã$~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P140_B004_01

- 身份：正文
- PDF 页：140
- 偈颂：3
- 标题路径：CHAPTER 40 Yogas For Royal Association
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas For Royal Association · Sloka 3 [present] · PDF page 140

3. Should Amatya Karak and the dispositor of Atma Karak be
together the native will be endowed with great intelligence
and will be a king's minister.
('Karakendr' is interpreted here as the dispositor of
Atma Karak. Similarly, 'Amatyesa' means the dispositor of
Amatya Karak).
~$S*$YB+ºï~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P140_B005_01

- 身份：正文
- PDF 页：140
- 偈颂：4
- 标题路径：CHAPTER 40 Yogas For Royal Association
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas For Royal Association · Sloka 4 [present] · PDF page 140

4. If Atma Karak is strong and is with a benefic or Amatya
Karak is in its own Bhava or in exaltation, one will surely
become a king's minister.
~$I1+$I5+$I9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P140_B006_01

- 身份：正文
- PDF 页：140
- 偈颂：5
- 标题路径：CHAPTER 40 Yogas For Royal Association
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas For Royal Association · Sloka 5 [present] · PDF page 140

5. There is no doubt in one's becoming a king's minister
and famous if Atma Karak is in Tanu, or Putr, or Dharm
Bhava.
~$K+$T+ºK+ºT~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P140_B007_01

- 身份：正文
- PDF 页：140
- 偈颂：6
- 标题路径：CHAPTER 40 Yogas For Royal Association
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas For Royal Association · Sloka 6 [present] · PDF page 140

6. If Atma Karak or Amatya Karak is placed in a Kendr or in
a Kon the native will beget royal mercy, royal patronage,
and happiness thereof.
~(mI3)$*(mI6)$+(mI3)La*(mI6)La+mI3*mI6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P140_B008_01

- 身份：正文
- PDF 页：140
- 偈颂：7
- 标题路径：CHAPTER 40 Yogas For Royal Association
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas For Royal Association · Sloka 7 [present] · PDF page 140

7. Should malefics be in the 3rd and the 6th from Atma
Karak, or from Arudh Lagn, or in Sahaj and Ari Bhava, one
will become army chief.
~L9D$*$K+L9D$*$T+L9D$*$E+L9D$*$O~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P140_B009_01

- 身份：正文
- PDF 页：140
- 偈颂：8
- 标题路径：CHAPTER 40 Yogas For Royal Association
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas For Royal Association · Sloka 8 [present] · PDF page 140

8. If Atma Karak is in a Kendr, or in a Kon, or in
exaltation, or in its own bhava, and gives a drishti to
Dharm's lord, the native will be a king's minister.
~ã2i$*ã2I1*ã2YB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P140_B010_01

- 身份：正文
- PDF 页：140
- 偈颂：9
- 标题路径：CHAPTER 40 Yogas For Royal Association
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas For Royal Association · Sloka 9 [present] · PDF page 140

9. If the lord of the rashi where Chandr is placed becomes
Atma Karak and if this lord is placed in Tanu Bhava along
with a benefic, the native will become a king's minister at
his advanced age.
~$I5*$YB+$I7*$YB+$I10*$YB+$I9*$YB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P140_B011_01

- 身份：正文
- PDF 页：140
- 偈颂：10
- 标题路径：CHAPTER 40 Yogas For Royal Association
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas For Royal Association · Sloka 10 [present] · PDF page 140

10. Should the Atma Karak be in Putr, Yuvati, Karm, or
Dharm Bhava and happen to be with a benefic, one will earn
wealth through royal patronage.
~L9I5+$I9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P141_B001_01

- 身份：正文
- PDF 页：141
- 偈颂：11
- 标题路径：CHAPTER 40 Yogas For Royal Association
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas For Royal Association · Sloka 11 [present] · PDF page 141

11. If the Arudh of Dharm Bhava happens to be itself the
Janm Lagn, or if Atma Karak is placed in Dharm Bhava the
native will be associated with royal circles.
~L11I11*-L11Dm*$YB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P141_B002_01

- 身份：正文
- PDF 页：141
- 偈颂：12
- 标题路径：CHAPTER 40 Yogas For Royal Association
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas For Royal Association · Sloka 12 [present] · PDF page 141

12. One will gain through royal association if Labh Bhava
is occupied by its own lord, and is devoid of a drishti
from a malefic. The Atma Karak should at the same time be
yuti with a benefic.
~L10I1*L1I10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P141_B003_01

- 身份：正文
- PDF 页：141
- 偈颂：13
- 标题路径：CHAPTER 40 Yogas For Royal Association
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas For Royal Association · Sloka 13 [present] · PDF page 141

13. An exchange of rashis between Karm's lord and Lagn's
lord will make the native associated with the king in a
great manner.
~2Y6*(2I4)Ka~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P141_B004_01

- 身份：正文
- PDF 页：141
- 偈颂：14
- 标题路径：CHAPTER 40 Yogas For Royal Association
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas For Royal Association · Sloka 14 [present] · PDF page 141

14. If Shukr and Chandr are in the 4th from Karakamsh Lagn,
the native will be endowed with royal insignia.
~L1YL5*L1K+L1YL5*L1T+$YL5*L5K+$YL5*L5T~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P141_B005_01

- 身份：正文
- PDF 页：141
- 偈颂：15
- 标题路径：CHAPTER 40 Yogas For Royal Association
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yogas For Royal Association · Sloka 15 [present] · PDF page 141

15. Should Lagn's lord, or the Atma Karak, be yuti with
Putr's lord and be in a Kendr or in a Kon, the native will
be a king or minister.
