# 第 22 章：Effects Of Labh Bhava

- 来源：BPHS 97 章版
- 原始卡片：11 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P058_B002_01

- 身份：正文
- PDF 页：58
- 偈颂：1
- 标题路径：CHAPTER 22 Effects Of Labh Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Labh Bhava · Sloka 1 [present] · PDF page 58

1. O excellent of the Brahmins, I now explain effects
relating to Labh Bhava, the auspiciousness of which bhava
will make one happy at all times.
~L11I11+L11K+L11T~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P058_B003_01

- 身份：正文
- PDF 页：58
- 偈颂：2
- 标题路径：CHAPTER 22 Effects Of Labh Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Labh Bhava · Sloka 2 [present] · PDF page 58

2. Should Labh's lord be in Labh itself or be in an angle
or in a trine from Lagn, there will be many gains.
~L11E+L11E*L11c~
Similarly, if Labh's lord is exalted, though in combustion
there will be many gains.
~L11I2*L2K*L2Y5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P058_B004_01

- 身份：正文
- PDF 页：58
- 偈颂：3
- 标题路径：CHAPTER 22 Effects Of Labh Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Labh Bhava · Sloka 3 [present] · PDF page 58

3. If Labh's lord is in Dhan Bhava, while Dhan's lord is in
an angle (from Lagn) along with Guru, the gains will be
great.
~L11I3*BI11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P058_B005_01

- 身份：正文
- PDF 页：58
- 偈颂：4
- 标题路径：CHAPTER 22 Effects Of Labh Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Labh Bhava · Sloka 4 [present] · PDF page 58

4. If Labh's lord is in Sahaj Bhava, while Labh Bhava is
occupied by a benefic, the native will gain 2000 Nishkas in
his 36th year.
~L11YB*L11K+L11YB*L11T~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P058_B006_01

- 身份：正文
- PDF 页：58
- 偈颂：5
- 标题路径：CHAPTER 22 Effects Of Labh Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Labh Bhava · Sloka 5 [present] · PDF page 58

5. If Labh's lord is yuti with a benefic in an angle or in
a trine (from Lagn), the native will acquire 500 Nishkas in
his 40th year.
~5I11*2I2*6I9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P058_B007_01

- 身份：正文
- PDF 页：58
- 偈颂：6
- 标题路径：CHAPTER 22 Effects Of Labh Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Labh Bhava · Sloka 6 [present] · PDF page 58

6. The native will own 6000 Nishkas if Labh Bhava is
occupied by Guru, while Dhan Bhava and Dharm Bhava are
respectively taken over by Chandr and Shukr by position.
~2I9*4I9*5I9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P058_B008_01

- 身份：正文
- PDF 页：58
- 偈颂：7
- 标题路径：CHAPTER 22 Effects Of Labh Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Labh Bhava · Sloka 7 [present] · PDF page 58

7. Should Guru, Buddh, and Chandr be in the 11th from Labh
(i.e. Dharm Bhava) the native will be endowed with wealth,
grains, fortunes, diamonds, ornaments, etc..
~L11I1*L1I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P058_B009_01

- 身份：正文
- PDF 页：58
- 偈颂：8
- 标题路径：CHAPTER 22 Effects Of Labh Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Labh Bhava · Sloka 8 [present] · PDF page 58

8. One will gain 1000 Nishkas in his 33rd year if Labh's
lord is in Lagn and Lagn's lord is in Labh Bhava.
~L11I2*L2I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P058_B010_01

- 身份：正文
- PDF 页：58
- 偈颂：9
- 标题路径：CHAPTER 22 Effects Of Labh Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Labh Bhava · Sloka 9 [present] · PDF page 58

9. If Labh's lord is in Dhan Bhava as Dhan's lord is in
Labh Bhava, one will amass abundant fortunes after
marriage.
~L11I3*L3I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P058_B011_01

- 身份：正文
- PDF 页：58
- 偈颂：10
- 标题路径：CHAPTER 22 Effects Of Labh Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Labh Bhava · Sloka 10 [present] · PDF page 58

10. If Labh's lord is in Sahaj Bhava, as Sahaj's lord is in
Labh Bhava, one will gain wealth through co-borns and will
be endowed with excellent ornaments.
~L11d+L11c+L11I12*L11Ym+L11I6*L11Ym+L11I8*L11Ym~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P058_B012_01

- 身份：正文
- PDF 页：58
- 偈颂：11
- 标题路径：CHAPTER 22 Effects Of Labh Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Labh Bhava · Sloka 11 [present] · PDF page 58

11. There will be no gains in spite of numerous efforts if
Labh's lord is in fall, in combustion, or be in Ari,
Randhr, or Vyaya Bhava with a malefic.
