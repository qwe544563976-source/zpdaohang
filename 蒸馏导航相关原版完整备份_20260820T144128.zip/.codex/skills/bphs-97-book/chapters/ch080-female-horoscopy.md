# 第 80 章：Female Horoscopy

- 来源：BPHS 97 章版
- 原始卡片：35 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P331_B002_01

- 身份：正文
- PDF 页：331
- 偈颂：1
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 1 [present] · PDF page 331

1. Maitreya asked: O Sage! You have described the effects of
many kinds. Now be kind enough to throw light on Shri Jatak
(female Horoscopy).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P331_B003_01

- 身份：正文
- PDF 页：331
- 偈颂：2
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 2 [present] · PDF page 331

2. Maharishi Parasara replied: What a good question! listen
to what I am going to tell you about the rashi kundalis of
females. All the effects that have been described till now in
the case of male horoscopies will apply to females also.
Matters relating to her physical appearance should be
determined from Lagn, those relating to children from the 5th
bhava, fortune for the husband from the 7th bhava, and death
of the husband (widowhood) should be deduced from the 8th
bhava. Those effects which are impossible to ascribed to the
female, should be declared to be applicable to her husband.
[ Brihat Jatak: "Of the effects that have been described
till now in the case of male horoscopes, and those that may
be found in female horoscopes suitable to females should be
declared as applicable to them alone; the rest should be
ascribed to their husbands. The death of the husband is to
be deduced through the 8th place (from Lagn or Chandr
whichever is stronger). Matters relating to her appearance,
beauty etc, should be determined from Lagn and the rashi
occupied by Chandr. It is from the 7th place (from Lagn or
Chandr whichever is stronger) that her welfare (happiness)
and the nature of the husband should be ascertained."
Mantreswara's Phaldeepika "Whatever effects are declared for
men, they are entirely applicable to women too.
The woman's prosperity and happiness have to be deduced from
the 8th place (from Lagn or Chandr whichever is stronger).
Children should be declared from the 9th bhava and matters
relating to her appearance, beauty etc., should be determined
from Lagn. It is from the 7th place that her welfare (power
of influencing her husband) and the nature of the husband
should be ascertained while her association and chastity
should be predicted from an examination of the 4th bhava.
Benefics in those bhavas produce good results while malefics
in the above bhavas are productive of evil unless they happen
to own the bhavas, in which case the effects will be good."
Jatak Parijata: Whatever effects may accrue from the
horoscopes of females are applicable only to men,
should be ascribed to the husband. The good and evil
affecting their person should be calculated from Chandr and
Lagn whichever of them is stronger. It is from the 7th bhava
from Lagn or Chandr, that all that is worthy or unworthy in
the husband should be ascertained and the death of the
husband is foretold through the 8th bhava (from Lagn or
Chandr). All this should be well weighed by the strength or
weakness of the grahas, benefic and malefic, before an
announcement is made, of Lagn and Chandr, find which is
stronger. It is with reference to this that the luck,
beauty, and strength of the women should be announced.
Children and wealth in abundance should be
declared through the 9th bhava there from. Wedded happiness
or otherwise should be gathered from the 8th bhava, and
husband's fortune from the 7th. Some Jyotishi's opine that
the well being or the reverses of the husband can be
determined from the 9th bhava.     ]
~ZI1*2IZ*@W~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P331_B003_02

- 身份：正文
- PDF 页：331
- 偈颂：2
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 2 [present] · PDF page 331

2. Maharishi Parasara replied: What a good question! listen
to what I am going to tell you about the rashi kundalis of
females. All the effects that have been described till now in
the case of male horoscopies will apply to females also.
Matters relating to her physical appearance should be
determined from Lagn, those relating to children from the 5th
bhava, fortune for the husband from the 7th bhava, and death
of the husband (widowhood) should be deduced from the 8th
bhava. Those effects which are impossible to ascribed to the
female, should be declared to be applicable to her husband.
[ Brihat Jatak: "Of the effects that have been described
till now in the case of male horoscopes, and those that may
be found in female horoscopes suitable to females should be
declared as applicable to them alone; the rest should be
ascribed to their husbands. The death of the husband is to
be deduced through the 8th place (from Lagn or Chandr
whichever is stronger). Matters relating to her appearance,
beauty etc, should be determined from Lagn and the rashi
occupied by Chandr. It is from the 7th place (from Lagn or
Chandr whichever is stronger) that her welfare (happiness)
and the nature of the husband should be ascertained."
Mantreswara's Phaldeepika "Whatever effects are declared for
men, they are entirely applicable to women too.
The woman's prosperity and happiness have to be deduced from
the 8th place (from Lagn or Chandr whichever is stronger).
Children should be declared from the 9th bhava and matters
relating to her appearance, beauty etc., should be determined
from Lagn. It is from the 7th place that her welfare (power
of influencing her husband) and the nature of the husband
should be ascertained while her association and chastity
should be predicted from an examination of the 4th bhava.
Benefics in those bhavas produce good results while malefics
in the above bhavas are productive of evil unless they happen
to own the bhavas, in which case the effects will be good."
Jatak Parijata: Whatever effects may accrue from the
horoscopes of females are applicable only to men,
should be ascribed to the husband. The good and evil
affecting their person should be calculated from Chandr and
Lagn whichever of them is stronger. It is from the 7th bhava
from Lagn or Chandr, that all that is worthy or unworthy in
the husband should be ascertained and the death of the
husband is foretold through the 8th bhava (from Lagn or
Chandr). All this should be well weighed by the strength or
weakness of the grahas, benefic and malefic, before an
announcement is made, of Lagn and Chandr, find which is
stronger. It is with reference to this that the luck,
beauty, and strength of the women should be announced.
Children and wealth in abundance should be
declared through the 9th bhava there from. Wedded happiness
or otherwise should be gathered from the 8th bhava, and
husband's fortune from the 7th. Some Jyotishi's opine that
the well being or the reverses of the husband can be
determined from the 9th bhava.     ]
~ZI1*2IZ*@W~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P331_B003_03

- 身份：正文
- PDF 页：331
- 偈颂：2
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 2 [present] · PDF page 331

2. Maharishi Parasara replied: What a good question! listen
to what I am going to tell you about the rashi kundalis of
females. All the effects that have been described till now in
the case of male horoscopies will apply to females also.
Matters relating to her physical appearance should be
determined from Lagn, those relating to children from the 5th
bhava, fortune for the husband from the 7th bhava, and death
of the husband (widowhood) should be deduced from the 8th
bhava. Those effects which are impossible to ascribed to the
female, should be declared to be applicable to her husband.
[ Brihat Jatak: "Of the effects that have been described
till now in the case of male horoscopes, and those that may
be found in female horoscopes suitable to females should be
declared as applicable to them alone; the rest should be
ascribed to their husbands. The death of the husband is to
be deduced through the 8th place (from Lagn or Chandr
whichever is stronger). Matters relating to her appearance,
beauty etc, should be determined from Lagn and the rashi
occupied by Chandr. It is from the 7th place (from Lagn or
Chandr whichever is stronger) that her welfare (happiness)
and the nature of the husband should be ascertained."
Mantreswara's Phaldeepika "Whatever effects are declared for
men, they are entirely applicable to women too.
The woman's prosperity and happiness have to be deduced from
the 8th place (from Lagn or Chandr whichever is stronger).
Children should be declared from the 9th bhava and matters
relating to her appearance, beauty etc., should be determined
from Lagn. It is from the 7th place that her welfare (power
of influencing her husband) and the nature of the husband
should be ascertained while her association and chastity
should be predicted from an examination of the 4th bhava.
Benefics in those bhavas produce good results while malefics
in the above bhavas are productive of evil unless they happen
to own the bhavas, in which case the effects will be good."
Jatak Parijata: Whatever effects may accrue from the
horoscopes of females are applicable only to men,
should be ascribed to the husband. The good and evil
affecting their person should be calculated from Chandr and
Lagn whichever of them is stronger. It is from the 7th bhava
from Lagn or Chandr, that all that is worthy or unworthy in
the husband should be ascertained and the death of the
husband is foretold through the 8th bhava (from Lagn or
Chandr). All this should be well weighed by the strength or
weakness of the grahas, benefic and malefic, before an
announcement is made, of Lagn and Chandr, find which is
stronger. It is with reference to this that the luck,
beauty, and strength of the women should be announced.
Children and wealth in abundance should be
declared through the 9th bhava there from. Wedded happiness
or otherwise should be gathered from the 8th bhava, and
husband's fortune from the 7th. Some Jyotishi's opine that
the well being or the reverses of the husband can be
determined from the 9th bhava.     ]
~ZI1*2IZ*@W~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P332_B001_01

- 身份：正文
- PDF 页：332
- 偈颂：5
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 5 [present] · PDF page 332

5. If at the time of birth of a woman, Lagn and Chandr are in
even rashis, the woman will be truly feminine in character.
She will possess excellent qualities, be of steadfast
character, beautiful and physically fit.
~-ZI1*-2IZ*@W~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P332_B002_01

- 身份：正文
- PDF 页：332
- 偈颂：6
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 6 [present] · PDF page 332

6. If Lagn and Chandr are in odd rashis, she will be
masculine in form and masculine in bearing, and if they be
associated with or aspected by malefics, she will be devoid
of good qualities and be sinful.
~-ZI1*2IZ+ZI1*-2IZ**@W~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P332_B003_01

- 身份：正文
- PDF 页：332
- 偈颂：7
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 7 [present] · PDF page 332

7. If amongst Lagn and Chandr, one be in an even rashi and
the other be in an odd one, the woman concerned should be
declared to partake the characteristics of both male and
female. The qualities of Lagn or Chandr will be more
predominant according to their strength.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P332_B004_01

- 身份：正文
- PDF 页：332
- 偈颂：8
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 8 [present] · PDF page 332

8. 0 Brahmin! The effects in respect of women would
particularly depend on the rashi and Trimsams of Lagn or
Chandr, whichever is stronger.
~ã.CLi3*Tã.CLi3*@W~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P333_B001_01

- 身份：正文
- PDF 页：333
- 偈颂：9-16
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 9-16 [present] · PDF page 333

9-16. When Lagn or Chandr (whichever is stronger) is in a
rashi belonging to Mangal, the woman born in a Trimsams of
Mangal, will have illicit relations with a man before
marriage.
~ã.CLi3*Tã.CLi6*@W~n
If she be born in Trimsams of Shukr she will become unchaste
after marriage;
~ã.CLi3*Tã.CLi4*@W~m
if born in a Trimsams of Buddh she will be full of guile and
adept in conjuration;
~ã.CLi3*Tã.CLi5*@W~
if the Trimsams be of Guru she will be worthy and virtuous;
~ã.CLi3*Tã.CLi7*@W~n
she will be menial or slave if birth be in a Trimsams of
Shani.
~ã.CLi4*Tã.CLi3*@W~m
When Lagn or Chandr, is in a rashi owned by Buddh, the female
born in a Trimsams of Mangal will be full of guile, she will
be a hard worker
~ã.CLi4*Tã.CLi6*@W~
if the Trimsams be of Shukr, she will be possessed of good
qualities
~ã.CLi4*Tã.CLi4*@W~n
if the Trimsams be of Buddh, she will be of the nature of
hermaphrodite,
~ã.CLi4*Tã.CLi5*@W~
if the Trimsams be of Guru she will be chaste.
~ã.CLi6*Tã.CLi3*@W~n
In a rashi owned by Shukr, a female born in a Trimsams of
Mangal will be deprived;
~ã.CLi6*Tã.CLi6*@W~
if the Trimsams be of Shukr, she
will be well known and be possessed of excellent qualities;
~ã.CLi6*Tã.CLi4*@W~
if the Trimsams be of Buddh she will be skilled in all the
arts;
~ã.CLi6*Tã.CLi5*@W~
she will be endowed with all good qualities if born in a
Trimsams of Guru;
~ã.CLi6*Tã.CLi7*@W~
she will remarry if born in a Trimsams of Shani.
~ã.CLi2*Tã.CLi3*@W~n
When Lagn or Chandr happens to be in a rashi owned by Chandr,
and the Trimsams of birth is owned by Mangal, the female born
will be self willed and uncontrolled;
~ã.CLi2*Tã.CLi6*@W~n
she will be unchaste and of loose character if born in a
Trimsams of Shukr;
~ã.CLi2*Tã.CLi4*@W~
she will be skilled in arts and handiwork if born in a
Trimsams of Buddh;
~ã.CLi2*Tã.CLi5*@W~
she will be gifted with all excellent qualities if born in a
Trimsams of Guru;
~ã.CLi2*Tã.CLi7*@W~m
she will become a widow if born in the Trimsams of Shani.
~ã.CLi1*Tã.CLi3*@W~m
When Lagn or Chandr happens to be in the rashi owned by Surya
and the Trimsams of birth be owned by Mangal, the female born
will be very talkative;
~ã.CLi1*Tã.CLi6*@W~
she will be virtuous if born in a Trimsams of Shukr;
~ã.CLi1*Tã.CLi4*@W~
she will bear masculine features if born in a Trimsams of
Buddh;
~ã.CLi1*Tã.CLi5*@W~
she will be chaste and virtuous if born in a Trimsams of
Guru;
~ã.CLi1*Tã.CLi7*@W~n
she will be unchaste if born in a Trimsams of Shani.
~ã.CLi5*Tã.CLi3*@W~
When the rising rashi or the rashi occupied by Chandr, is
owned by Guru, the female born in a Trimsams of Mangal will
be endowed with many good qualities;
~ã.CLi5*Tã.CLi6*@W~
she will be punschali if born in a Trimsams of Shukr;
~ã.CLi5*Tã.CLi4*@W~
she will be well versed in many sciences if born in a
Trimsams of Buddh;
~ã.CLi5*Tã.CLi5*@W~
she will be endowed with all good qualities if born in a
Trimsams of Guru;
~ã.CLi5*Tã.CLi7*@W~
she will not indulge much in sexual intercourse if born in a
Trimsams of Shani.
~ã.CLi7*Tã.CLi3*@W~n
When Lagn or the rashi occupied by Chandr belongs to Shani,
the female born in a Trimsams of Mangal will be a maid
servant;
~ã.CLi7*Tã.CLi6*@W~
she will be learned (barren according to Brihat Jatak) if
born in a Trimsams of Shukr;
~ã.CLi7*Tã.CLi4*@W~n
she will be cruel and immoral if born in a Trimsams of
Buddh;
~ã.CLi7*Tã.CLi5*@W~
she will be devoted to her husband if born in a Trimsams
of Guru;
~ã.CLi7*Tã.CLi7*@W~n
she will be unchaste (addicted to men of low caste
according to Brihat Jatak) if born in a Trimsams of Shani.
~~NO CODE

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P333_B001_02

- 身份：正文
- PDF 页：333
- 偈颂：9-16
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 9-16 [present] · PDF page 333

9-16. When Lagn or Chandr (whichever is stronger) is in a
rashi belonging to Mangal, the woman born in a Trimsams of
Mangal, will have illicit relations with a man before
marriage.
~ã.CLi3*Tã.CLi6*@W~n
If she be born in Trimsams of Shukr she will become unchaste
after marriage;
~ã.CLi3*Tã.CLi4*@W~m
if born in a Trimsams of Buddh she will be full of guile and
adept in conjuration;
~ã.CLi3*Tã.CLi5*@W~
if the Trimsams be of Guru she will be worthy and virtuous;
~ã.CLi3*Tã.CLi7*@W~n
she will be menial or slave if birth be in a Trimsams of
Shani.
~ã.CLi4*Tã.CLi3*@W~m
When Lagn or Chandr, is in a rashi owned by Buddh, the female
born in a Trimsams of Mangal will be full of guile, she will
be a hard worker
~ã.CLi4*Tã.CLi6*@W~
if the Trimsams be of Shukr, she will be possessed of good
qualities
~ã.CLi4*Tã.CLi4*@W~n
if the Trimsams be of Buddh, she will be of the nature of
hermaphrodite,
~ã.CLi4*Tã.CLi5*@W~
if the Trimsams be of Guru she will be chaste.
~ã.CLi6*Tã.CLi3*@W~n
In a rashi owned by Shukr, a female born in a Trimsams of
Mangal will be deprived;
~ã.CLi6*Tã.CLi6*@W~
if the Trimsams be of Shukr, she
will be well known and be possessed of excellent qualities;
~ã.CLi6*Tã.CLi4*@W~
if the Trimsams be of Buddh she will be skilled in all the
arts;
~ã.CLi6*Tã.CLi5*@W~
she will be endowed with all good qualities if born in a
Trimsams of Guru;
~ã.CLi6*Tã.CLi7*@W~
she will remarry if born in a Trimsams of Shani.
~ã.CLi2*Tã.CLi3*@W~n
When Lagn or Chandr happens to be in a rashi owned by Chandr,
and the Trimsams of birth is owned by Mangal, the female born
will be self willed and uncontrolled;
~ã.CLi2*Tã.CLi6*@W~n
she will be unchaste and of loose character if born in a
Trimsams of Shukr;
~ã.CLi2*Tã.CLi4*@W~
she will be skilled in arts and handiwork if born in a
Trimsams of Buddh;
~ã.CLi2*Tã.CLi5*@W~
she will be gifted with all excellent qualities if born in a
Trimsams of Guru;
~ã.CLi2*Tã.CLi7*@W~m
she will become a widow if born in the Trimsams of Shani.
~ã.CLi1*Tã.CLi3*@W~m
When Lagn or Chandr happens to be in the rashi owned by Surya
and the Trimsams of birth be owned by Mangal, the female born
will be very talkative;
~ã.CLi1*Tã.CLi6*@W~
she will be virtuous if born in a Trimsams of Shukr;
~ã.CLi1*Tã.CLi4*@W~
she will bear masculine features if born in a Trimsams of
Buddh;
~ã.CLi1*Tã.CLi5*@W~
she will be chaste and virtuous if born in a Trimsams of
Guru;
~ã.CLi1*Tã.CLi7*@W~n
she will be unchaste if born in a Trimsams of Shani.
~ã.CLi5*Tã.CLi3*@W~
When the rising rashi or the rashi occupied by Chandr, is
owned by Guru, the female born in a Trimsams of Mangal will
be endowed with many good qualities;
~ã.CLi5*Tã.CLi6*@W~
she will be punschali if born in a Trimsams of Shukr;
~ã.CLi5*Tã.CLi4*@W~
she will be well versed in many sciences if born in a
Trimsams of Buddh;
~ã.CLi5*Tã.CLi5*@W~
she will be endowed with all good qualities if born in a
Trimsams of Guru;
~ã.CLi5*Tã.CLi7*@W~
she will not indulge much in sexual intercourse if born in a
Trimsams of Shani.
~ã.CLi7*Tã.CLi3*@W~n
When Lagn or the rashi occupied by Chandr belongs to Shani,
the female born in a Trimsams of Mangal will be a maid
servant;
~ã.CLi7*Tã.CLi6*@W~
she will be learned (barren according to Brihat Jatak) if
born in a Trimsams of Shukr;
~ã.CLi7*Tã.CLi4*@W~n
she will be cruel and immoral if born in a Trimsams of
Buddh;
~ã.CLi7*Tã.CLi5*@W~
she will be devoted to her husband if born in a Trimsams
of Guru;
~ã.CLi7*Tã.CLi7*@W~n
she will be unchaste (addicted to men of low caste
according to Brihat Jatak) if born in a Trimsams of Shani.
~~NO CODE

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P333_B001_03

- 身份：正文
- PDF 页：333
- 偈颂：9-16
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 9-16 [present] · PDF page 333

9-16. When Lagn or Chandr (whichever is stronger) is in a
rashi belonging to Mangal, the woman born in a Trimsams of
Mangal, will have illicit relations with a man before
marriage.
~ã.CLi3*Tã.CLi6*@W~n
If she be born in Trimsams of Shukr she will become unchaste
after marriage;
~ã.CLi3*Tã.CLi4*@W~m
if born in a Trimsams of Buddh she will be full of guile and
adept in conjuration;
~ã.CLi3*Tã.CLi5*@W~
if the Trimsams be of Guru she will be worthy and virtuous;
~ã.CLi3*Tã.CLi7*@W~n
she will be menial or slave if birth be in a Trimsams of
Shani.
~ã.CLi4*Tã.CLi3*@W~m
When Lagn or Chandr, is in a rashi owned by Buddh, the female
born in a Trimsams of Mangal will be full of guile, she will
be a hard worker
~ã.CLi4*Tã.CLi6*@W~
if the Trimsams be of Shukr, she will be possessed of good
qualities
~ã.CLi4*Tã.CLi4*@W~n
if the Trimsams be of Buddh, she will be of the nature of
hermaphrodite,
~ã.CLi4*Tã.CLi5*@W~
if the Trimsams be of Guru she will be chaste.
~ã.CLi6*Tã.CLi3*@W~n
In a rashi owned by Shukr, a female born in a Trimsams of
Mangal will be deprived;
~ã.CLi6*Tã.CLi6*@W~
if the Trimsams be of Shukr, she
will be well known and be possessed of excellent qualities;
~ã.CLi6*Tã.CLi4*@W~
if the Trimsams be of Buddh she will be skilled in all the
arts;
~ã.CLi6*Tã.CLi5*@W~
she will be endowed with all good qualities if born in a
Trimsams of Guru;
~ã.CLi6*Tã.CLi7*@W~
she will remarry if born in a Trimsams of Shani.
~ã.CLi2*Tã.CLi3*@W~n
When Lagn or Chandr happens to be in a rashi owned by Chandr,
and the Trimsams of birth is owned by Mangal, the female born
will be self willed and uncontrolled;
~ã.CLi2*Tã.CLi6*@W~n
she will be unchaste and of loose character if born in a
Trimsams of Shukr;
~ã.CLi2*Tã.CLi4*@W~
she will be skilled in arts and handiwork if born in a
Trimsams of Buddh;
~ã.CLi2*Tã.CLi5*@W~
she will be gifted with all excellent qualities if born in a
Trimsams of Guru;
~ã.CLi2*Tã.CLi7*@W~m
she will become a widow if born in the Trimsams of Shani.
~ã.CLi1*Tã.CLi3*@W~m
When Lagn or Chandr happens to be in the rashi owned by Surya
and the Trimsams of birth be owned by Mangal, the female born
will be very talkative;
~ã.CLi1*Tã.CLi6*@W~
she will be virtuous if born in a Trimsams of Shukr;
~ã.CLi1*Tã.CLi4*@W~
she will bear masculine features if born in a Trimsams of
Buddh;
~ã.CLi1*Tã.CLi5*@W~
she will be chaste and virtuous if born in a Trimsams of
Guru;
~ã.CLi1*Tã.CLi7*@W~n
she will be unchaste if born in a Trimsams of Shani.
~ã.CLi5*Tã.CLi3*@W~
When the rising rashi or the rashi occupied by Chandr, is
owned by Guru, the female born in a Trimsams of Mangal will
be endowed with many good qualities;
~ã.CLi5*Tã.CLi6*@W~
she will be punschali if born in a Trimsams of Shukr;
~ã.CLi5*Tã.CLi4*@W~
she will be well versed in many sciences if born in a
Trimsams of Buddh;
~ã.CLi5*Tã.CLi5*@W~
she will be endowed with all good qualities if born in a
Trimsams of Guru;
~ã.CLi5*Tã.CLi7*@W~
she will not indulge much in sexual intercourse if born in a
Trimsams of Shani.
~ã.CLi7*Tã.CLi3*@W~n
When Lagn or the rashi occupied by Chandr belongs to Shani,
the female born in a Trimsams of Mangal will be a maid
servant;
~ã.CLi7*Tã.CLi6*@W~
she will be learned (barren according to Brihat Jatak) if
born in a Trimsams of Shukr;
~ã.CLi7*Tã.CLi4*@W~n
she will be cruel and immoral if born in a Trimsams of
Buddh;
~ã.CLi7*Tã.CLi5*@W~
she will be devoted to her husband if born in a Trimsams
of Guru;
~ã.CLi7*Tã.CLi7*@W~n
she will be unchaste (addicted to men of low caste
according to Brihat Jatak) if born in a Trimsams of Shani.
~~NO CODE

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P334_B001_01

- 身份：正文
- PDF 页：334
- 偈颂：17-21
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 17-21 [present] · PDF page 334

17-21. If the 7th bhava be without a grah (without strength)
and without benefic aspect, the female born will have a
coward and contemptible wretch for her husband.
~RmI7*@W~m
When the 7th bhava is a moveable rashi, the husband will
always be away from home.
~4I7*7I7*@W~n
If Buddh and Shani be in the 7th bhava, the husband of the
woman concerned will be impotent.
~1I7*@W~n
If Surya occupies the 7th bhava, the woman concerned is
abandoned by her husband.
~3I7*@W~n
If Mangal be in the 7th the female concerned becomes a widow
in her childhood.
~7I7*@W~
If Shani be in the 7th, she lives to an old age remaining
unmarried.
~mI7*-BI7*@W~n
If there be a malefic, she becomes a widow while young.
~BI7*-mI7*@W~
If there be a benefic in the 7th, the female born will enjoy
marital happiness and will be chaste.
~BI7*mI7*@W~m
If there be both benefics and malefics in the 7th, both
benefic and evil effects will be experienced.
~Nã6i3*Nã3i6*@W~n
If Mangal be in the Navams of Shukr and Shukr be in the
Navams of Mangal, the female concerned will have illicit
relations with other men.
~Nã6i3*Nã3i6*2I7*@W~n
If in this Yog Chandr be in the 7th the female concerned
enters into illicit connections at the instance of her
husband.
~L7i3+NL7i3**@W~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P335_B001_01

- 身份：正文
- PDF 页：335
- 偈颂：22-25
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 22-25 [present] · PDF page 335

22-25. If at woman's birth, the 7th bhava or the setting
Navams be that of Mangal, the husband will be fond of other
women and will be of an irascible temper.
~L7i4+NL7i4**@W~
If it be a rashi or Navams of Buddh, her husband will be
very learned and clever.
~L7i5+NL7i5**@W~
If it be a rashi or Navams of Guru, the husband of the woman
concerned will be of great merit and will have passions under
his control.
~L7i6+NL7i6**@W~
If it be a rashi or Navams of Shukr, her husband will be
fortunate, very good looking and will be liked by women.
~L7i7+NL7i7**@W~n
If the rashi or Navams belongs to Shani, her husband will be
an old man and a fool.
~L7i1+NL7i1**@W~
If the rashi or Navams be Simh, her husband will be
exceedingly soft in his disposition and will be very hard
working.
~L7i2+NL7i2**@W~
If the 7th bhava or the setting Navams be a rashi owned by
Chandr, the husband of the woman will be love-sick and
gentle.
~-L7iNL7*@W~
If there be different rashis and Navamsas in the 7th bhava,
the effects will be of a mixed nature. The effects of the
rashis and Navamsas will depend on their strength.
~1I8*@W~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P335_B002_01

- 身份：正文
- PDF 页：335
- 偈颂：26-29
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 26-29 [present] · PDF page 335

26-29. If in a female's horoscope, Surya be in the 8th bhava,
the native will be unhappy, poverty-stricken, of deformed
limbs, and without faith in religion.
~2I8*@W~n
If Chandr be in the 8th, the woman concerned will be of a
defective vagina, will have ugly breasts, with sinister
(impropitious) eyes, without robes or ornaments, sickly,
and will be defamed in the society.
~3I8*@W~n
If Mangal be in the 8th, the native will be of weak
constitution. sickly, widow, ugly looking, and full of
sorrows and agonies.
~4I8*@W~n
If Buddh be in the 8th, she will be without faith in
religion, timid, devoid of wealth, self respect, and good
qualities,and she will be quarrelsome.
~5I8*@W~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P336_B001_01

- 身份：正文
- PDF 页：336
- 偈颂：30-33
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 30-33 [present] · PDF page 336

30-33. If in a female's horoscope Guru be in the 8th, the
woman concerned will be shameless and without virtue, will
have few children, fatty hands and feet, will be abandoned by
her husband, and will be gluttonous.
~6I8*@W~n
If Shukr be in the 8th, she will be fond of pleasures,
devoid of sympathy, religion, wealth, she will be dirty and
deceptive.
~7I8*@W~n
If Shani be in the 8th, the woman concerned will be of wicked
disposition, dirty, deceptive and devoid of conjugal harmony.
~8I8*@W~n
If Rahu be in the 8th, she will be ugly, without marital
happiness, cruel hearted, sickly, and unchaste.
~mI5*@W+!5Dm*@W**2A7*6A7+2A7*6A3+2A3*6A7+2A3*6A3~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P336_B002_01

- 身份：正文
- PDF 页：336
- 偈颂：34
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 34 [present] · PDF page 336

34. The woman will be barren if in her rashi kundali, Chandr
and Shukr be associated with Shani or Mangal and the 5th
bhava be occupied or aspected by a malefic.
~NL7i3*@W~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P336_B003_01

- 身份：正文
- PDF 页：336
- 偈颂：35
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 35 [present] · PDF page 336

35. If the 7th bhava be in the Navams of Mangal, the vagina
(female organ of the woman concerned), will be diseased.
~NL7iB*@W~
If the 7th bhava be the Navams of a benefic, she will have a
well formed female organ and will be beloved by her husband.
~2IR3*6IR3*@W+2IR6*6IR6*@W~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P336_B004_01

- 身份：正文
- PDF 页：336
- 偈颂：36
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 36 [present] · PDF page 336

36. If Mithun or Kanya Lagn in a female's horoscope is
occupied by Shukr and Chandr, the woman concerned lives
happily and is equipped with all kinds of comforts, in her
father's house.
~2I1*4I1*6I1*@W~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P336_B005_01

- 身份：正文
- PDF 页：336
- 偈颂：37
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 37 [present] · PDF page 336

37. If Chandr, Buddh, and Shukr be in Lagn, the woman
concerned is endowed with many good qualities and happiness.
~5I1*@W~
If Guru be in Lagn, she is happy, wealthy and has children.
~R4I8+R5I8**1I8*2I8*@W~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P336_B006_01

- 身份：正文
- PDF 页：336
- 偈颂：38
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 38 [present] · PDF page 336

38. If the 8th bhava be Simh or Kark and Surya and Chandr be
both placed there, the woman concerned will be barren.
~R3I8+R6I8+R4I8**2I8*4I8*@W~
If the 8th bhava be Mithun, Kanya, or Kark and Buddh and
Chandr be posited there, the female native will have only one
child.
~Lni1+Lni8+Lni10+Lni11**2I1*6I1*2Dm*@W~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P336_B007_01

- 身份：正文
- PDF 页：336
- 偈颂：39
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 39 [present] · PDF page 336

39. The woman concerned will be definitely barren if Lagn be
Mesh, Vrischik, Makar, or Kumbh and Chandr and Shukr be
posited there aspected by malefics.
~8I7*1I7*mI5*@W+5I8*8I8*mI5*@W~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P336_B008_01

- 身份：正文
- PDF 页：336
- 偈颂：40
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 40 [present] · PDF page 336

40. The woman concerned will give birth to an already dead
child, if the 7th be occupied by Rahu and Surya or Guru and
Rahu be in the 8th, and the 5th be occupied by malefics.
~5I8*6I8*5A3+3I8*7I8*@W~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P337_B001_01

- 身份：正文
- PDF 页：337
- 偈颂：41
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 41 [present] · PDF page 337

41. The woman concerned will not be able to conceive if Guru
and Shukr be associated with Mangal in the 8th bhava or
Mangal be with Shani in the 8th bhava.
~~NOCODE

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P337_B002_01

- 身份：正文
- PDF 页：337
- 偈颂：42
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 42 [present] · PDF page 337

42. The woman concerned becomes a destructor of her husband's
family and her father's family if at her birth, Chandr and
Lagn be subjected to Papa Kartari Yog (direct malefic grahas
in the 12th and retrograde malefics in the 2nd).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P337_B003_01

- 身份：正文
- PDF 页：337
- 偈颂：43
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 43 [present] · PDF page 337

43. The woman whose birth takes place under the following
conditions is named as Visha Kanya:
(I) Day of birth Sunday, Nakshatr Aslesha 2nd tithi.
(2) Day of birth Saturday, Nakshatr Krittika, 7th tithi.
(3) Day of birth Tuesday, Nakshatr Satabhisha, 12th tithi.
~mI1*BI1*.2I1*.2e*@W~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P337_B004_01

- 身份：正文
- PDF 页：337
- 偈颂：44
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 44 [present] · PDF page 337

44. The woman will be Visha Kanya if at birth, Lagn be
occupied by a malefic and a benefic and two grahas be in
inimical rashis.
~~NO CODE

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P337_B005_01

- 身份：正文
- PDF 页：337
- 偈颂：45
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 45 [present] · PDF page 337

45. Visha Kanya gives birth to a child already dead. She has
a defective generative organ and is bereft of robes,
ornaments, etc..
~mI1*BI1*.2I1*.2e*@W**L7iB+NI7+(BI7)2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P337_B006_01

- 身份：正文
- PDF 页：337
- 偈颂：46
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 46 [present] · PDF page 337

46. The evil effects of Visha Kanya are destroyed if the lord
of the 7th is a benefic or a benefic grah be in the 7th from
Lagn or Chandr.
~3I12+3I4+3I7+3I8**-3AB*-3DB*@W~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P337_B007_01

- 身份：正文
- PDF 页：337
- 偈颂：47
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 47 [present] · PDF page 337

47. The woman born becomes a widow, if Mangal be in the 12th,
4th, 7th, or 8th from Lagn unaspected by or associated with
any benefic.
~3I12+3I4+3I7+3I8**-3AB*-3DB*-@W~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P337_B008_01

- 身份：正文
- PDF 页：337
- 偈颂：48-49
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 48-49 [present] · PDF page 337

48-49. The Yog which causes the woman to become widow also
causes a male native to become a widower. If the man and
woman possessing this Yog join in wedlock, the Yog ceases to
have any effect.
~L1i6*NL1i7*@W**6D7*7D6+N6l7~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P337_B009_01

- 身份：正文
- PDF 页：337
- 偈颂：50-51
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 50-51 [present] · PDF page 337

50-51. If at a woman's birth the rising rashi be that of
Shukr and the rising Navams be of Shani (Kumbh according to
Brihat Jatak) and if Shukr and Shani aspect each other or are
occupying each other's Navams, she will be afflicted with too
much lust and will allay her fire of passion with the help of
other females acting the part of a male.
~5S*3S*4S*6S*RZI1*@W~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P337_B010_01

- 身份：正文
- PDF 页：337
- 偈颂：52
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 52 [present] · PDF page 337

52. When Guru, Mangal, Buddh, and Shukr are strong and when
the rising rashi is an even one, the woman born will be
learned in Shastras and an expounder of the Vedanta
Philosophy.
~mI7*&I8*@W~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P337_B011_01

- 身份：正文
- PDF 页：337
- 偈颂：53
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 53 [present] · PDF page 337

53. When a malefic grah, is in the 7th and some grah in the
8th, the woman concerned will become an ascetic.
~BI8*-!8Dm*-!8Am*@W~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P338_B001_01

- 身份：正文
- PDF 页：338
- 偈颂：54
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 54 [present] · PDF page 338

54. The woman dies before her husband when in her nativity,
there is a benefic in the 8th bhava unaspected by or
associated with a malefic.
~~NO CODE

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P338_B002_01

- 身份：正文
- PDF 页：338
- 偈颂：55
- 标题路径：CHAPTER 80 Female Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Female Horoscopy · Sloka 55 [present] · PDF page 338

55. If at the birth of a woman, there are equal number of
benefics and malefics and they possess the same strength,
she, without doubt, will leave for her heavenly abode along
with her husband.
