# 第 64 章：Effects of Antar Dashas in the Kala Chakr Dasha

- 来源：BPHS 97 章版
- 原始卡片：14 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P292_B002_01

- 身份：正文
- PDF 页：292
- 偈颂：1
- 标题路径：CHAPTER 64 Effects of Antar Dashas in the Kala Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Kala Chakr Dasha · Sloka 1 [present] · PDF page 292

1. Maharishi Parashar said: Now, I am going to describe to
you the effects of Antar Dashas in the Kala Chakr Dasha as
related by Lord Shiva to the Goddess Parvati.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P292_B003_01

- 身份：正文
- PDF 页：292
- 偈颂：2
- 标题路径：CHAPTER 64 Effects of Antar Dashas in the Kala Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Kala Chakr Dasha · Sloka 2 [present] · PDF page 292

2. Dasha of Mesh Amsh:
There will be wounds and fever in the Antar Dasha of Mangal
(that is Mesh or Vrischik) in the Dasha of Mesh Amsh. In
the same Dasha and Antar Dasha of the Rashis owned by
Buddh, Shukr, Chandr, and Guru all kinds of happiness will
be enjoyed. Danger from an enemy will be experienced in the
Antar Dasha of Surya.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P292_B004_01

- 身份：正文
- PDF 页：292
- 偈颂：3-5
- 标题路径：CHAPTER 64 Effects of Antar Dashas in the Kala Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Kala Chakr Dasha · Sloka 3-5 [present] · PDF page 292

3-5. Dasha or Vrishabh Amsh:
Effects like quarrels and diseases will be experienced in
Antar Dasha of Shani  (that is Makar or Kumbh). There will
be gains of education and physical felicity in the Antar
Dasha of Guru (Dhanu or Meen), going away from home, death
or distress from fevers in the Antar Dasha of Mangal (Mesh
and Vrischik), and gains of garments, happy association
with women in the Antar Dashas of the Rashis owned by Shukr
and Buddh. Danger from the king and violent animals may be
expected in the Antar Dasha of Rashi (Simh) owned by
Surya.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P292_B005_01

- 身份：正文
- PDF 页：292
- 偈颂：6-10
- 标题路径：CHAPTER 64 Effects of Antar Dashas in the Kala Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Kala Chakr Dasha · Sloka 6-10 [present] · PDF page 292

6-10. Dasha of Mithun Amsh: The effects in the Antar Dashas
of the Rashis concerned will be as follows:
Shukr (Vrishabh or Tula): Gain of wealth and garments.
Mangal (Mesh and Vrischik): Death of parents, danger,
fever, wounds and travels to distant places.
Guru (Dhanu or Meen): Increase in intelligence, success in
education, opulence, and glory, popularity and affection
towards others.
Shani  (Makar or Kumbh): Foreign journeys, diseases, fear
of death, loss of wealth and kinsmen.
Buddh (Mithun or Kanya): Success in education, gains of
garments, etc., happiness from wife and children, and
reverence from all quarters.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P292_B006_01

- 身份：正文
- PDF 页：292
- 偈颂：11-16
- 标题路径：CHAPTER 64 Effects of Antar Dashas in the Kala Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Kala Chakr Dasha · Sloka 11-16 [present] · PDF page 292

11-16. Dasha of Kark Amsh:
The effects in the various Antar Dashas of the Rashis
concerned will be as follows:
Chandr (Kark): Happiness from wife and children, gain of
wealth and reverence from the public (popularity).
Surya (Simh): Danger from enemies, animals, and the royal
family, mental agony, and fear of diseases.
Buddh (Mithun or Kanya) and
Shukr (Vrishabh and Tula): Happiness from wife, children,
and friends, increase in wealth, popularity, and name and
fame.
Mangal (Mesh or Vrischik): Danger from poison, weapons and
diseases like fever.
Guru (Dhanu or Meen): Gains of wealth, physical felicity,
honours from the king.
Shani  (Makar or Kumbh): Rheumatism, danger from snakes and
scorpions, and distress of all kinds.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P293_B001_01

- 身份：正文
- PDF 页：293
- 偈颂：17-21
- 标题路径：CHAPTER 64 Effects of Antar Dashas in the Kala Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Kala Chakr Dasha · Sloka 17-21 [present] · PDF page 293

17-21. Dasha of Simh Amsh:
The effects in the various Antar Dashas of Rashis concerned
will be as follows:
Mangal (Mesh and Vrischik): Diseases of the mouth, bilious
fever and danger from weapon.
Buddh (Mithun or Kanya) and
Shukr (Vrishabh and Tula): gain of clothes, happiness from
wife and children.
Chandr (Kark): Danger from fall from some height, meagre
gains of wealth, foreign journeys.
Surya (Simh): Danger from enemies, fevers, loss of wisdom,
fear of death.
Guru (Dhanu or Meen): Gains of wealth and grains,
beneficence of the king and Brahmins, progress in
education.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P293_B002_01

- 身份：正文
- PDF 页：293
- 偈颂：22-26
- 标题路径：CHAPTER 64 Effects of Antar Dashas in the Kala Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Kala Chakr Dasha · Sloka 22-26 [present] · PDF page 293

22-26. Dasha of Kanya Amsh:
The effects in the various Antar Dashas of the Rashis
concerned will be as follows:
Shani  (Makar or Kumbh): Many kinds of troubles travels to
distant places, fevers, distress from hunger.
Guru (Dhanu or Meen): Gains of wealth through the
beneficence of the king, arrival of friends and kinsmen,
and success in education.
Mangal (Mesh or Vrischik): Bilious fever, travels to
distant places, danger from fire and from weapons.
Buddh (Mithun or Kanya) and
Shukr (Vrishabh and Tula) and
Chandr (Kark): Gains of wealth through sons and employees,
many enjoyments.
Surya (Simh): Travel to distant lands, danger from
diseases, quarrels with kinsmen, danger of assaults by
weapons.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P293_B003_01

- 身份：正文
- PDF 页：293
- 偈颂：27-31
- 标题路径：CHAPTER 64 Effects of Antar Dashas in the Kala Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Kala Chakr Dasha · Sloka 27-31 [present] · PDF page 293

27-31. Dasha of Tula Amsh:
The effects in the various Antar Dashas of the Rashis
concerned will be as follows:
Shukr (Vrishabh and Tula): Wisdom, comforts, happiness from
wife and children, and from wealth, garments, etc..
Mangal (Mesh or Vrischik): Distress to father, enmity with
friends, danger from disease of forehead, fevers, poison,
weapons, etc..
Guru (Dhanu or Meen): Gain of wealth, acquisition of a
kingdom, performance of religious rites, honours from  the
king and happiness all round.
Shani  (Makar or Kumbh): Travels to distant places,
critical diseases, loss in the agricultural sphere, danger
from enemies.
Buddh (Mithun or Kanya): Birth of a son, gain of wealth,
happiness from one's wife, joy, dawn of fortune.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P294_B001_01

- 身份：正文
- PDF 页：294
- 偈颂：32-33
- 标题路径：CHAPTER 64 Effects of Antar Dashas in the Kala Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Kala Chakr Dasha · Sloka 32-33 [present] · PDF page 294

32-33. Dasha of Vrischik Amsh:
The following effects will be experienced in the Antar
Dashas of the Rashis concerned:
Chandr (Kark), and
Buddh (Mithun or Kanya), and
Shukr (Vrishabh or Tula): Gain of wealth and grains in
different ways, freedom from diseases, enjoyments of  many
kinds.
Surya (Simh): Danger from enemies, loss of wealth, distress
to father, danger from wild and violent animals.
Mangal (Mesh or Vrischik): Troubles from wind and bile,
wounds, danger from fire and from weapons.
Guru (Dhanu or Meen): Gains of wealth, grains,. and gems,
devotion towards deities and Brahmins, beneficence of the
king.
Shani  (Makar or Kumbh): Loss of wealth, separation from
kinsmen, mental anxiety, danger from enemies, diseases.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P294_B002_01

- 身份：正文
- PDF 页：294
- 偈颂：34-40
- 标题路径：CHAPTER 64 Effects of Antar Dashas in the Kala Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Kala Chakr Dasha · Sloka 34-40 [present] · PDF page 294

34-40. Dasha of Dhanu Amsh:
The following effects will be derived in the various Antar
Dashas of the Rashis owned by:
Mangal (Mesh or Vrischik): Heart burn, fevers, cold,
diseases of the mouth, many kinds of troubles.
Shukr (Vrishabh or Tula), and
Buddh (Mithun or Kanya), and
Chandr (Kark): Increase in wealth and property and fortune,
progress in education, destruction of  enemies, happiness
from the king.
Surya (Simh): Loss of wife and wealth, quarrels, danger
from the king, travels to distant lands.
Guru (Dhanu or Meen): Charity, self mortifications, honours
from the king, increase in religious mindedness, happiness
from wife, gain of wealth.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P294_B003_01

- 身份：正文
- PDF 页：294
- 偈颂：41-44
- 标题路径：CHAPTER 64 Effects of Antar Dashas in the Kala Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Kala Chakr Dasha · Sloka 41-44 [present] · PDF page 294

41-44. Dasha of Makar Amsh: The following effects will be
experienced in the various Antar Dashas of the Rashis owned
by:
Shani  (Makar or Kumbh): Wrath of Brahmins, deities, and
the king, loss of kinsmen, abandonment of the homeland.
Shukr (Vrishabh or Tula), and
Buddh (Mithun or Kanya), and
Chandr (Kark), and
Guru (Dhanu or Meen): Devotion towards deities,
self-mortification, honours from the government.
Mangal (Mesh or Vrischik): Disease of the forehead,
assaults on hands and feet, danger from dysentery, blood
pollution and bilious troubles.
Shani  (Makar or Kumbh): Loss of father and kinsmen,
fevers, danger from the king and the enemies.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P295_B001_01

- 身份：正文
- PDF 页：295
- 偈颂：45-49
- 标题路径：CHAPTER 64 Effects of Antar Dashas in the Kala Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Kala Chakr Dasha · Sloka 45-49 [present] · PDF page 295

45-49. Dasha of Kumbh Amsh:
The following effects will be experienced in the Antar
Dashas of the Rashis owned by:
Shukr (Vrishabh or Tula): Many kinds of educational
attainments, gains of property, happiness from wife and
children, sound health, and increase in wealth.
Mangal (Mesh or Vrischik): Fevers, danger from fire and
from enemies, distress from enemies, and mental agony.
Shani  (Makar or Kumbh): Danger of troubles from wind,
bile, and phlegm, quarrels, foreign journey, danger of
suffering from tuberculosis.  Guru (Dhanu or Meen): Freedom
from ill health, happiness, honours from the king, and
joy.
Buddh (Mithun or Kanya): Happiness from wife,
children, and wealth, joy, increase in good fortune.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P295_B002_01

- 身份：正文
- PDF 页：295
- 偈颂：50-55
- 标题路径：CHAPTER 64 Effects of Antar Dashas in the Kala Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Kala Chakr Dasha · Sloka 50-55 [present] · PDF page 295

50-55. Dasha of Meen Amsh:
The following will be the effects in the various Antar
Dashas of the Rashis owned by:
Chandr (Kark): Increase in wisdom and educational
attainments, happiness from wife, freedom from disease,
association with friends, joy and happiness.
Surya (Simh): Quarrels with kinsmen, danger from thieves,
mental agony, loss of position.
Buddh (Kanya or Mithun), and
Shukr (Vrishabh or Tula): Victory in war, birth of a son,
gains of land and cattle, increase in wealth.
Mangal (Mesh or Vrischik): Bilious troubles, dissension
with members of the family, danger from enemies.
Guru (Dhanu or Meen): Gain of wealth and grains, happiness
from wife, honours from the king, name and fame.
Shani (Makar or Kumbh): Loss of wealth, mental agony,
abandonment of the homeland on account of associations with
prostitutes.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P295_B003_01

- 身份：正文
- PDF 页：295
- 偈颂：56-58
- 标题路径：CHAPTER 64 Effects of Antar Dashas in the Kala Chakr Dasha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Kala Chakr Dasha · Sloka 56-58 [present] · PDF page 295

56-58. Maharishi Parashar said to Maitreya: O Brahmin! The
effects of Antar Dashas in the Kala Chakr Dasha which have
been described above are based on Savya Chakr. The effects
of Antar Dashas in the Dashas of the Rashis in the Apsavya
Chakr have to be assessed after taking into account the
benefic and malefic natures of the lords of the Rashis.
People have to enjoy the good or suffer the bad results
according to their good or bad actions in the previous
births. Everybody suffers or enjoys accordingly. The
peculiarity in this respect is that inauspicious results
have been ascribed to malefics. But, if during the Antar
Dasha the Grah concerned is a friend of the lord of the
Dasha, the results of the Antar Dasha will be favourable.
If the Grah concerned is a benefic, but an enemy of the
lord of the Dasha, his Antar Dasha effects will not prove
favourable. This is how the Antar Dasha effects have to be
analyzed and conclusions arrived at.
