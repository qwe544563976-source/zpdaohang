# 第 9 章：Evils at Birth

- 来源：BPHS 97 章版
- 原始卡片：36 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P026_B002_01

- 身份：正文
- PDF 页：26
- 偈颂：1
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 1 [present] · PDF page 26

1. O Brahmin, first of all, estimate the evils and checking
factors thereof through Lagn and then declare the effects
of the 12 bhavas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P026_B003_01

- 身份：正文
- PDF 页：26
- 偈颂：2
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 2 [present] · PDF page 26

2. Evils causing premature end exist up to the 24th year of
one's age, As such, no definite calculation of life span
should be made till such year of age.
~2I6*2Dm+2I8*2Dm+2I12*2Dm~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P026_B004_01

- 身份：正文
- PDF 页：26
- 偈颂：3-6
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 3-6 [present] · PDF page 26

3-6. Short-life Combinations: (up to sloka 23): Should
Chandr be in Ari, Randhr, or Vyaya Bhava and receives a
drishti from a malefic; the child will die soon.
~2I6+2I8+2I12**2Dm*2DB~n
If in the process there be a drishti from a benefic, it may
live up to 8.
~.BrI6*!6Dm+.BrI8*!8Dm+.BrI12*!12Dm**-BI1~n
If a benefic is retrograde in Ari, Randhr, or Vyaya Bhava
receiving a drishti from a malefic, death will occur within
a month of birth. This is true only when Lagn is not
occupied by a benefic.
~7I5*7Y3*7Y1~n
Should Putr Bhava be occupied by Shani, Mangal, and Surya
jointly (early) death of mother and brother will come to
pass.
~3I1*-3DB+3I8*-3DB**3Y7+3Y1+3Dm~n
Mangal placed in Tanu, or in Randhr Bhava and be yuti with
Shani or Surya or receiving a drishti from a malefic, being
bereft of a drishti from a benefic will prove a source of
(immediate) death.
~!1D7*!1D3*1Y8*2Y8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P026_B005_01

- 身份：正文
- PDF 页：26
- 偈颂：7-11
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 7-11 [present] · PDF page 26

7-11. If Shani and Mangal give a drishti to Lagn as the
luminaries are yuti with Rahu (elsewhere), the child will
live a fortnight.
~7I10*2I6*3I7~n
Immediate death of the child along with its mother will
occur if Shani is in Karm Bhava, Chandr in Ari Bhava, and
Mangal in Yuvati Bhava.
~7I1*2I8*5I3~n
One will immediately go to the abode of Yama if Shani is in
Tanu Bhava, while Chandr and Guru are in their order in
Randhr and Sahaj Bhava.
~1I9*3I7*5I11*6I11~n
Only a month will be the span of ones life who had
Surya in Dharm Bhava, Mangal in Yuvati Bhava, and Guru and
Shukr in Labh Bhava.
~1I12*2I12*6I12*8I12~enM
All Grahas (any Grah) in Vyaya Bhava will be the source of
a short life, specifically the luminaries, Shukr, and Rahu.
But the drishti of these four grahas (on Vyaya Bhava) will
counteract such evils.
~2Ym*-2rB**2I8+2I7+2I1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P026_B006_01

- 身份：正文
- PDF 页：26
- 偈颂：12
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 12 [present] · PDF page 26

12. Chandr is capable of causing early end if she is with a
malefic in Yuvati, Randhr, or Tanu Bhava and unrelated to a
benefic.
~@j+@h+@g**2K*mK~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P027_B001_01

- 身份：正文
- PDF 页：27
- 偈颂：13
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 13 [present] · PDF page 27

13. Early death will come to pass if there be a birth in the
morning or evening junctions or in a Hora ruled by Chandr
or in Gandanta, while Chandr and malefics occupy Kendras
from Lagn.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P027_B002_01

- 身份：正文
- PDF 页：27
- 偈颂：14
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 14 [present] · PDF page 27

14. Definition of Sandhya: 3 Ghatis before the sight of the
semi disc (half) of the rising Surya and a similar duration
following Surya's set are called as morning twilight and
evening twilight, respectively.
~@occ*R8I1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P027_B003_01

- 身份：正文
- PDF 页：27
- 偈颂：15
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 15 [present] · PDF page 27

15. Early Death: Should all the malefics be in the oriental
half, while benefics are in the occidental half, early
death of one born in Vrischik will follow. In this case
there is no need of any rethinking.
~mI12*mI6*!1h+mI2*mI8*!1h~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P027_B004_01

- 身份：正文
- PDF 页：27
- 偈颂：16
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 16 [present] · PDF page 27

16. Malefic in Vyaya and Ari Bhava, or in Randhr and Dhan
Bhava, while Lagn is hemmed between other malefics will
bring early death.
~mI1*mI7*2Ym*-2DB~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P027_B005_01

- 身份：正文
- PDF 页：27
- 偈颂：17
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 17 [present] · PDF page 27

17. Malefics occupying Tanu and Yuvati Bhava, while Chandr
is yuti with a malefic with no relief from a benefic will
also cause premature death.
~2w*2I1*mI8*mK~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P027_B006_01

- 身份：正文
- PDF 页：27
- 偈颂：18
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 18 [present] · PDF page 27

18. Early death will be inflicted on the native if
decreasing Chandr is in Tanu Bhava, while malefics capture
Randhr Bhava and a Kendra. There is no doubt about that.
~2I1*2h+2I8*2h+2I7*2h+2I12*2h~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P027_B007_01

- 身份：正文
- PDF 页：27
- 偈颂：19
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 19 [present] · PDF page 27

19. Chandr in Tanu, Randhr, Vyaya, or Yuvati Bhava, and
hemmed between malefics, will confer premature death.
~2I1*2h*mI7+2I1*2h*mI8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P027_B008_01

- 身份：正文
- PDF 页：27
- 偈颂：20
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 20 [present] · PDF page 27

20. Should Chandr be in Tanu Bhava hemmed between malefics,
while Yuvati or Randhr Bhava has a malefic in it, he will
face immediate death along with his mother.
~7I12*-7DB*1I9*-7DB*3I8*-3DB~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P027_B009_01

- 身份：正文
- PDF 页：27
- 偈颂：21
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 21 [present] · PDF page 27

21. Should Shani, Surya, and Mangal be in Vyaya, Dharm, and
Randhr Bhava without drishti from a benefic, the child will
face instant death.
~mI7*2w*2I1+DmI1*2w*2I1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P027_B010_01

- 身份：正文
- PDF 页：27
- 偈颂：22
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 22 [present] · PDF page 27

22. With a malefic in Yuvati Bhava or in the rising
Dreshkan, while decreasing Chandr is in Tanu Bhava death be
experienced early.
~@a~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P027_B011_01

- 身份：正文
- PDF 页：27
- 偈颂：23
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 23 [present] · PDF page 27

23. The life span of the child will be either 2 months or 6
months only, if all grahas devoid of strength are relegated
to Apoklima bhavas (i.e. Sahaj, Ari, Dharm, and Vyaya
Bhava).
~@m23~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P028_B001_01

- 身份：正文
- PDF 页：28
- 偈颂：24
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 24 [present] · PDF page 28

24. Evils to Mother: (up to sloka 33): The mother of the
native will incur evils (will die soon) if Chandr at birth
receives a drishti from three malefics.
~2DB~
Benefics giving a drishti to Chandr will bring good to the
mother.
~8I2*4I2*6I2*1I2*7I2~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P028_B002_01

- 身份：正文
- PDF 页：28
- 偈颂：25
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 25 [present] · PDF page 28

25. Should Dhan Bhava be occupied by Rahu, Buddh, Shukr,
Surya, and Shani, the child's birth has been after its
father's death, while even the mother will face early
death.
~(mI7)2*2Ym*2Dm+(mI6)2*2Ym*2Dm~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P028_B003_01

- 身份：正文
- PDF 页：28
- 偈颂：26
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 26 [present] · PDF page 28

26. If Chandr is in the 7th or the 8th from a malefic, be
herself with a malefic, and receives a drishti from a
strong malefic, predict mothers end to be early.
~1E*1I7+1d*1I7~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P028_B004_01

- 身份：正文
- PDF 页：28
- 偈颂：27
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 27 [present] · PDF page 28

27. The child will not live on mother's milk, but on that
of she-goat if Surya is exalted or debilitated in Yuvati
Bhava.
~(1I4)2*1e+(3I4)2*3e+(7I4)2*7e+(8I4)2*8e+(9I4)2*9e**-BK~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P028_B005_01

- 身份：正文
- PDF 页：28
- 偈颂：28
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 28 [present] · PDF page 28

28. Should a malefic be in the 4th, identical with an
inimical rashi, counted from Chandr, while there is no
benefic in a Kendra, the child will lose its mother in a
premature manner.
~mI6*mI12~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P028_B006_01

- 身份：正文
- PDF 页：28
- 偈颂：29
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 29 [present] · PDF page 28

29. Malefics in Ari and Vyaya Bhava will bring evils to
mother.
~mI4*mI10~n
The child's father will receive similar effects if Bandhu
and Karm Bhava are captured by malefics.
~4I1*mI1*mI12~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P028_B007_01

- 身份：正文
- PDF 页：28
- 偈颂：30
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 30 [present] · PDF page 28

30. Buddh in Dhan Bhava, while malefics occupy Tanu and
Vyaya Bhava: this yoga will destroy the entire family.
~5I1*7I2*8I3~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P028_B008_01

- 身份：正文
- PDF 页：28
- 偈颂：31
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 31 [present] · PDF page 28

31. Guru, Shani, and Rahu respectively posited in Tanu,
Dhan, and Sahaj Bhava, will cause mother's death early.
~(mT)2*2w-(BT)2~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P028_B009_01

- 身份：正文
- PDF 页：28
- 偈颂：32
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 32 [present] · PDF page 28

32. Doubtlessly the mother will give up the child if it has
malefics in Konas counted from the decreasing Chandr. No
benefic shall be yuti with the said malefics.
~3Y7*(3K)2*N3Y7~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P028_B010_01

- 身份：正文
- PDF 页：28
- 偈颂：33
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 33 [present] · PDF page 28

33. If Mangal and Shani are together in a Kendra with
reference to Chandr and occupy one and the same Navamsh the
child will have two mothers. Yet it will be short-lived.
~7I1*3I7*2I6~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P028_B011_01

- 身份：正文
- PDF 页：28
- 偈颂：34
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 34 [present] · PDF page 28

34. Evil to Father: (up to sloka 42) One's father will
incur early death if Shani, Mangal, and Chandr in their
orders are in Tanu, Yuati and Ari Bhava.
~5I1*7I2*7Y1*1Y3*7Y4~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P029_B001_01

- 身份：正文
- PDF 页：29
- 偈颂：35
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 35 [present] · PDF page 29

35. The native will at the time of his marriage lose his
father if Guru is in Tanu Bhava, while Shani, Surya, Mangal
and Buddh are together in Dhan Bhava.
~1Ym*(mI7)1+1h*(mI7)1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P029_B002_01

- 身份：正文
- PDF 页：29
- 偈颂：36
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 36 [present] · PDF page 29

36. Early loss of father will take place if Surya is with a
malefic or is hemmed between malefics as there is another
malefic in the 7th from Surya.
~1I7*3I10*8I12~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P029_B003_01

- 身份：正文
- PDF 页：29
- 偈颂：37
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 37 [present] · PDF page 29

37. Remote will be the possibility of one's father
sustaining if Surya is in Yuvati, while Mangal is in Karm
and Rahu is in Vyaya Bhava.
~3I10*3e~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P029_B004_01

- 身份：正文
- PDF 页：29
- 偈颂：38
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 38 [present] · PDF page 29

38. Early and troubled will be one's father's death if
Mangal is in Karm Bhava identical with his enemy's rashi.
~2I6*7I1*3I7~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P029_B005_01

- 身份：正文
- PDF 页：29
- 偈颂：39
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 39 [present] · PDF page 29

39. Chandr in Ari Bhava, Shani in Tanu Bhava, and Mangal in
Yuvati Bhava: this array of heavenly bodies at birth will
not ensure a long span of life for the father.
~1A7*1INR1+1A7*1INR8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P029_B006_01

- 身份：正文
- PDF 页：29
- 偈颂：40
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 40 [present] · PDF page 29

40. If Surya receives a drishti from Shani and be in Mesh
or in Vrischik Navamsh, the father would have given up the
family before birth of the child or would have passed
away.
~mI4*mI10*mI12~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P029_B007_01

- 身份：正文
- PDF 页：29
- 偈颂：41
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 41 [present] · PDF page 29

41. If Bandhu, Karm, and Vyaya Bhava are all occupied by
malefics, both the parents will leave the child to its own
fate and wander from place to place.
~8e*8Y5*8I1+8e*8I4*8Y5~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P029_B008_01

- 身份：正文
- PDF 页：29
- 偈颂：42
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 42 [present] · PDF page 29

42. The father will not see the native till his (the
native's) 23rd year if Rahu and Guru are together in an
inimical rashi identical with Tanu or Bandhu Bhava.
~1Dm+1h+2Dm+2h~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P029_B009_01

- 身份：正文
- PDF 页：29
- 偈颂：43-45
- 标题路径：CHAPTER 9 Evils at Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evils at Birth · Sloka 43-45 [present] · PDF page 29

43-45. Parents: Surya is the indicator of father for all
beings, while the mother is indicated by Chandr. Should
Surya receive a drishti from one or more malefics or be
hemmed between them, this will cause evils to father.
Similarly, Chandr be considered in respect of mother.
~(mI6)1+(mI8)1+(mI4)1~n
Malefics in the 6th, the 8th, or the 4th from Surya will
bring inauspicious results about the father.
~(mI6)2+(mI8)2+(mI4)2~n
Malefics in such places from Chandr will be adverse for the
mother. The strength or otherwise of the occupants
concerned be suitably estimated.
