# 第 84 章：Remedial measures to obtain relief from the

- 来源：BPHS 97 章版
- 原始卡片：19 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P357_B002_01

- 身份：正文
- PDF 页：357
- 偈颂：—
- 标题路径：CHAPTER 84 Remedial measures to obtain relief from the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedial measures to obtain relief from the · Sloka unknown [unknown] · PDF page 357 · page_block BPHS_PL9_CHAP_97_P357_B002

malevolence of the grahas

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P357_B003_01

- 身份：正文
- PDF 页：357
- 偈颂：1
- 标题路径：CHAPTER 84 Remedial measures to obtain relief from the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedial measures to obtain relief from the · Sloka 1 [present] · PDF page 357

1. Maitreya said: O venerable Sage! Please describe for the
good of mankind the remedial measures for appeasement of the
malevolent grahas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P357_B004_01

- 身份：正文
- PDF 页：357
- 偈颂：2
- 标题路径：CHAPTER 84 Remedial measures to obtain relief from the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedial measures to obtain relief from the · Sloka 2 [present] · PDF page 357

2. The Sage replied: I have already described the names and
characteristic features and qualities of the grahas. Joys and
sorrows of all the creatures in the world are dependent on
these grahas. Therefore, persons desirous of peace, wealth
and prosperity, rainfall, good health and longevity, should
worship the grahas (by prayers, recitation of mantras,
charity, etc.).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P357_B005_01

- 身份：正文
- PDF 页：357
- 偈颂：3-5
- 标题路径：CHAPTER 84 Remedial measures to obtain relief from the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedial measures to obtain relief from the · Sloka 3-5 [present] · PDF page 357

3-5. For the purpose of worshipping them, the idols of Surya,
Chandr, Mangal, Buddh, Guru, Shukr, Shani, Rahu, and Ketu
should be made of copper, sphatika (rock crystal), red sandal
wood, gold (of both Buddh and Guru), silver, iron, glass, and
bell metal respectively). Alternatively the sketches of all
the above grahas should be drawn in the colours belonging to
them on a piece of cloth by sandal etc., and they should be
placed in their own directions.

Forms of the grahas for worship and contemplation

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P357_B006_01

- 身份：正文
- PDF 页：357
- 偈颂：6
- 标题路径：CHAPTER 84 Remedial measures to obtain relief from the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedial measures to obtain relief from the · Sloka 6 [present] · PDF page 357

6. Contemplate of Surya well adorned with two arms seated on
a lotus, with a lotus flower in one hand, red coloured like
lotus, and aboard a chariot of seven horses.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P357_B007_01

- 身份：正文
- PDF 页：357
- 偈颂：7
- 标题路径：CHAPTER 84 Remedial measures to obtain relief from the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedial measures to obtain relief from the · Sloka 7 [present] · PDF page 357

7. Contemplate of Chandr white coloured, dressed in white
robes, with two arms carrying a mace in one hand and a vara
in the other, adorned with white coloured ornaments and
aboard a chariot of ten horses.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P357_B008_01

- 身份：正文
- PDF 页：357
- 偈颂：8
- 标题路径：CHAPTER 84 Remedial measures to obtain relief from the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedial measures to obtain relief from the · Sloka 8 [present] · PDF page 357

8. Contemplate of Mangal with a red necklace, dressed in red
coloured robes, with four arms, carrying Shakti, Shoola, gada
(mace), and vara and mounted on a lamb.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P357_B009_01

- 身份：正文
- PDF 页：357
- 偈颂：9
- 标题路径：CHAPTER 84 Remedial measures to obtain relief from the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedial measures to obtain relief from the · Sloka 9 [present] · PDF page 357

9. Contemplate of Buddh with a yellow coloured garland,
dressed in yellow robes, with four arms carrying a sword, a
shield, a mace, and vara, mounted on a lion.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P357_B010_01

- 身份：正文
- PDF 页：357
- 偈颂：10
- 标题路径：CHAPTER 84 Remedial measures to obtain relief from the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedial measures to obtain relief from the · Sloka 10 [present] · PDF page 357

10. Contemplate of Guru as yellow complexion, and Shukr of
fair complexion, both with four arms carrying a danda,
akshasutra, kamandal and vara.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P357_B011_01

- 身份：正文
- PDF 页：357
- 偈颂：11
- 标题路径：CHAPTER 84 Remedial measures to obtain relief from the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedial measures to obtain relief from the · Sloka 11 [present] · PDF page 357

11. O Maitreya! Contemplate of Shani with the lustre like
that of Indraneela, with four arms carrying shoola, bow,
arrow, and vara, mounted on a donkey.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P357_B012_01

- 身份：正文
- PDF 页：357
- 偈颂：12
- 标题路径：CHAPTER 84 Remedial measures to obtain relief from the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedial measures to obtain relief from the · Sloka 12 [present] · PDF page 357

12. Contemplate of Rahu with a hideous face, with four arms
carrying a sword, a shield, a shoola, and a vara, blue
coloured and mounted on a lion.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P357_B013_01

- 身份：正文
- PDF 页：357
- 偈颂：13
- 标题路径：CHAPTER 84 Remedial measures to obtain relief from the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedial measures to obtain relief from the · Sloka 13 [present] · PDF page 357

13. There are many Ketus. All of them are of smoky colour,
with two arms carrying a mace and a vara, with a hideous face
and mounted on a donkey.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P358_B001_01

- 身份：正文
- PDF 页：358
- 偈颂：14
- 标题路径：CHAPTER 84 Remedial measures to obtain relief from the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedial measures to obtain relief from the · Sloka 14 [present] · PDF page 358

14. All the idols should be so made that they are 108 fingers
tall by one's own fingers.
Notes: Such a measurement is taken from the middle finger.

Procedure for worshipping the grahas

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P358_B002_01

- 身份：正文
- PDF 页：358
- 偈颂：15-16
- 标题路径：CHAPTER 84 Remedial measures to obtain relief from the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedial measures to obtain relief from the · Sloka 15-16 [present] · PDF page 358

15-16. Dedicate with devotion to the grah concerned the
flowers and garments of the colour belonging to him, sandal,
deep, guggul, etc., his metal and the grains dear to him and
distribute all these things to Brahmins to appease the grah.
Mantras of grahas

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P358_B003_01

- 身份：正文
- PDF 页：358
- 偈颂：17-20
- 标题路径：CHAPTER 84 Remedial measures to obtain relief from the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedial measures to obtain relief from the · Sloka 17-20 [present] · PDF page 358

17-20. The mantras of all the grahas and the prescribed
number of their recitation are given below. The recitation of
mantras should be done after worshipping the grahas as
indicated in verses 15-16:
GrahMantraPrescribed number
Surya7000
Chandr11000
Mangal11000
Buddh9000
Guru19000
Shukr16000
Shani23000
Rahu18000
Ketu 17000
Procedure for Havana

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P358_B004_01

- 身份：正文
- PDF 页：358
- 偈颂：21-22
- 标题路径：CHAPTER 84 Remedial measures to obtain relief from the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedial measures to obtain relief from the · Sloka 21-22 [present] · PDF page 358

21-22. Havan should be performed with Aak, Palash, Khair,
Chirchiri, Pipal, Goolar, Shami, Wood pieces. Doob, and Kush,
for Surya, Chandr, Mangal, Buddh, Guru, Shukr, Shani, Rahu,
and Ketu respectively, mixed with honey, ghee, curd or milk.
The number of offerings to the sacred fire is 108 or 28.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P358_B005_01

- 身份：正文
- PDF 页：358
- 偈颂：23-24
- 标题路径：CHAPTER 84 Remedial measures to obtain relief from the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedial measures to obtain relief from the · Sloka 23-24 [present] · PDF page 358

23-24. To appease Surya and the other eight grahas, Brahmins
should be fed with:
(1) [cream] of rice cooked with jaggery;
(2) rice cooked in milk;
(3) havishya;
(4) paddy cooked in milk;
(5) curd and rice;
(6) rice with ghee;
(7) rice cooked with powder of  sesame seeds;
(8) rice cooked with meat;
(9) rice cooked with cereals, respectively.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P358_B006_01

- 身份：正文
- PDF 页：358
- 偈颂：25
- 标题路径：CHAPTER 84 Remedial measures to obtain relief from the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedial measures to obtain relief from the · Sloka 25 [present] · PDF page 358

25. To appease Surya and other grahas the things to be given
in charity are:
(I) cow with calf, (2) conch, (3) bullock, (4) gold, (5)
robes, (6) horse, (7) black cow, (8) weapons made of iron,
and (9) goat, respectively.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P358_B007_01

- 身份：正文
- PDF 页：358
- 偈颂：26-27
- 标题路径：CHAPTER 84 Remedial measures to obtain relief from the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedial measures to obtain relief from the · Sloka 26-27 [present] · PDF page 358

26-27. The grah who is the cause of adverse effects to a
person at any time should be worshipped and appeased because
Brahma has blessed the grahas with the boon "Do good to the
persons who worship you." And the development and progress,
and downfall of the people and the creation and destruction
of the universe are all under the administration and
authority of the grahas. Therefore they are most venerable.
