# 第 43 章：Longevity

- 来源：BPHS 97 章版
- 原始卡片：46 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P149_B002_01

- 身份：正文
- PDF 页：149
- 偈颂：1
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 1 [present] · PDF page 149

1. O Maharishi Parashar, you have dealt with combinations
for wealth and poverty. Kindly detail methods of
ascertaining the life span of human beings.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P149_B003_01

- 身份：正文
- PDF 页：149
- 偈颂：2-3
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 2-3 [present] · PDF page 149

2-3. 0 Brahmin, for the benefit of mankind I narrate
methods of ascertaining longevity; knowing that longevity
is difficult even for gods. Many exponents have laid down
various methods of longevity calculations. Following is the
summary of such schools of thoughts.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P149_B004_01

- 身份：正文
- PDF 页：149
- 偈颂：4-8
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 4-8 [present] · PDF page 149

4-8. Pindayu: The grahas contribute to longevity according
to their being in exaltation, or debilitation, and also
based on their strengths and weaknesses and positions in
Ashvini, etc., and in the various rashis. First of all,
Pindayu is based on the positions of the grahas. O Brahmin,
listen carefully to what I say: 19, 25, 15, 12, 15, 21, and
20 are the number of years contributed by the grahas from
Surya, etc., when in (deep) exaltation. These are half of
the above in (deep) debilitation; and if the grahas are in
between exaltation and debilitation, the rule of three
process should be used. Deduct the actual position of the
grah from its deep exaltation point. If the product is less
than 6 rashis, deduct it again from 12 rashis. The product
concerned should be multiplied by the number of years
allotted to the grah and divided by 12 to get the grah's
actual contribution.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P149_B005_01

- 身份：正文
- PDF 页：149
- 偈颂：9
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 9 [present] · PDF page 149

9. Rectifications: Excepting Shukr and Shani, the
contributions made by others should be halved, if they are
eclipsed, by Surya. One third should be reduced if the grah
is in its inimical rashi. This does not apply to the one in
retrogression (see Vakra Charam).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P149_B006_01

- 身份：正文
- PDF 页：149
- 偈颂：10-11
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 10-11 [present] · PDF page 149

10-11. Deductions for Grahas in the Visible Half of the
Zodiac: Full, half, one third, one fourth, one fifth, and
one sixth are the deductions of contributions made by
malefics placed in the visible half of the zodiac. Benefics
in such cases lose only half of what malefics lose. Should
there be more than one grah in a bhava, the deduction due
to the strongest will only prevail, and not deductions due
to other grahas in that particular bhava. Waning Chandr is
a benefic for this purpose.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P149_B007_01

- 身份：正文
- PDF 页：149
- 偈颂：12-13
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 12-13 [present] · PDF page 149

12-13. Malefics in Lagn: In case Tanu Bhava is occupied by
malefics, adopt the following procedure: Convert Lagn's
Sphuta into minutes of arc and multiple it by the years,
etc., contributed by the occupant and divide by 21600. The
years etc. so arrived be deducted from the respective
contribution which will be the net span donated by the
grah. If there is benefics drishti on Lagn containing
malefics then the loss is only half (obtained through these
calculations).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P150_B001_01

- 身份：正文
- PDF 页：150
- 偈颂：14-15
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 14-15 [present] · PDF page 150

14-15. Lagn's Contribution: The number of years contributed
by Lagn will correspond to the number of rashis it gained
(from Mesh), while the degrees Lagn has gained in the
particular rashi will also correspondingly donate (i.e. 30
degrees=l year). If the Lagn's lord in the Navamsh is
stronger than Lagn's lord, then the contribution should be
computed only based on the number of Navamshas gained (from
Mesh), otherwise the computation will be for the Rashi
Lagn.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P150_B002_01

- 身份：正文
- PDF 页：150
- 偈颂：16-17
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 16-17 [present] · PDF page 150

16-17. Nisargayu: O Brahmin, now I tell you about Nisargayu
1, 2, 9, 20, 18, 20,and 50 are the years allotted to
Chandr, Mangal, Buddh, Shukr, Guru, Surya, and Shani from
the period of birth.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P150_B003_01

- 身份：正文
- PDF 页：150
- 偈颂：18-19
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 18-19 [present] · PDF page 150

18-19. Amshayu: Now, I will tell you about Amshayu
contributions by Lagn and grahas. The years correspond to
the number of Navamshas counted from Mesh. Multiply the
longitude in question by 108. If the product exceeds 12,
expunge multiples of 12 and consider the final product in
rashis, degrees, etc., as years, months, etc..

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P150_B004_01

- 身份：正文
- PDF 页：150
- 偈颂：20-22
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 20-22 [present] · PDF page 150

20-22. The same reductions as per Pindayu apply to Amshayu
as well; i.e. half for a combust grah, one third for
inimical placement and the ones due for placements in the
half of the zodiac counted from the 12th backwards. Some
scholars suggest further corrections for Amshayu, viz. to
increase three fold the contribution of a grah in
exaltation or in own bhava and double the contribution if
the contributor is in his own Navamsh or in his own
Dreshkan. If doubling and trebling is warranted, only
trebling be done. In case of reductions also, only halving
is to be done if both halving and reducing a third are
required. That is how the final life span of men be
understood.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P150_B005_01

- 身份：正文
- PDF 页：150
- 偈颂：23
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 23 [present] · PDF page 150

23. Longevity for Other Living Beings: For other living
beings as well such computations can be made. The said
figure should be multiplied by the figure corresponding to
its full span of life and divided by the figure
corresponding to the full span of life for human beings.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P150_B006_01

- 身份：正文
- PDF 页：150
- 偈颂：24-29
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 24-29 [present] · PDF page 150

24-29. Full Life Span of Various Living Beings:  Now, I'll
tell you about the full life span figures for various
living beings. Gods and sages enjoy endless life span (i.e.
in astronomical proportions as against ordinary mortals).
The full life span of eagles, owls, parrots, crows, and
snakes is one thousand years. For falcon, monkey, bear, and
frog the full span of life is 300 years. Demon's full life
span is 150 years, while it is 120 years for human beings.
32 years for horses. 25 years for donkeys and camels, 24
years for oxen and buffaloes, 20 years for peacocks, 16
years for goats and rams. 14 years for swans, 12 years for
cuckoo, dog, and dove, 8 years for hens, etc., and 7 years
for birds, etc..

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P150_B007_01

- 身份：正文
- PDF 页：150
- 偈颂：30-31
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 30-31 [present] · PDF page 150

30-31. Choice of Longevity: I have narrated 3 different
methods of longevity. Listen to me about the choice among
the three systems. According to which of the three: Lagn,
Surya, or Chandr is stronger than the other two, Amshayu,
Pindayu, or Nisargayu should be respectively chosen.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P151_B001_01

- 身份：正文
- PDF 页：151
- 偈颂：32
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 32 [present] · PDF page 151

32. Doubtful Cases: If two among Lagn, Surya, and Chandr
gain equal strength, then longevity should be worked out as
per both systems and the average of both (final) should be
considered. If all the three are equally strong, the
average of the three should be considered.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P151_B002_01

- 身份：正文
- PDF 页：151
- 偈颂：33-40
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 33-40 [present] · PDF page 151

33-40. Other Clues to Longevity: O excellent of the
Brahmins, I will now give you details of other methods in
the matter of longevity as under: This is based on the
positions of Lagn's lord, Randhr's lord, Shani, Chandr,
natal Lagn, and Hora Lagn. These six are grouped into three
groups, thus:

the lords of Lagn and of Randhr Bhava on the one hand,
Shani and Chandr on the other hand, and
the natal Lagn and Hora Lagn on yet the other hand.
Out of a group of two, if the two are in movable rashis
long life is denoted. One in a fixed rashi and the other in
a dual rashi will also bestow long life. One in a movable
rashi and the other in a fixed rashi will give medium life.
If both are in dual rashis then, again medium life will be
obtained. Short life is denoted if one is in a movable
rashi as the other is in a dual rashi, or if both are in
fixed rashis. The type of life denoted by three or two
groups be only considered. If the three groups denote
different scales, then the one indicated by the pair of
natal Lagn and Hora Lagn should be only considered. In case
of three different indications if Chandr is in Lagn or
Yuvati Bhava, then, the one indicated by the Shani-Chandr
pair will only come to pass.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P151_B002_02

- 身份：正文
- PDF 页：151
- 偈颂：33-40
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 33-40 [present] · PDF page 151

33-40. Other Clues to Longevity: O excellent of the
Brahmins, I will now give you details of other methods in
the matter of longevity as under: This is based on the
positions of Lagn's lord, Randhr's lord, Shani, Chandr,
natal Lagn, and Hora Lagn. These six are grouped into three
groups, thus:

the lords of Lagn and of Randhr Bhava on the one hand,
Shani and Chandr on the other hand, and
the natal Lagn and Hora Lagn on yet the other hand.
Out of a group of two, if the two are in movable rashis
long life is denoted. One in a fixed rashi and the other in
a dual rashi will also bestow long life. One in a movable
rashi and the other in a fixed rashi will give medium life.
If both are in dual rashis then, again medium life will be
obtained. Short life is denoted if one is in a movable
rashi as the other is in a dual rashi, or if both are in
fixed rashis. The type of life denoted by three or two
groups be only considered. If the three groups denote
different scales, then the one indicated by the pair of
natal Lagn and Hora Lagn should be only considered. In case
of three different indications if Chandr is in Lagn or
Yuvati Bhava, then, the one indicated by the Shani-Chandr
pair will only come to pass.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P151_B003_01

- 身份：正文
- PDF 页：151
- 偈颂：41-44
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 41-44 [present] · PDF page 151

41-44. Further Clarifications: If long life is denoted by
all the said three groups, the span is 120 years, if by two
groups it is 108 years, and if only by one group it is 91
years. If medium life is arrived at by three groups it is
80 years, if medium life span is indicated by 2 groups it
is 72 years, and if medium life span is indicated by one
group it is 64 years. If short life is denoted by the said
three groups it is only 32 years, if short life is
indicated by two groups, the life span is 36 years, and if
short life is indicated by one group the life span is 40
years. These are rectified as under.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P151_B004_01

- 身份：正文
- PDF 页：151
- 偈颂：45-46
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 45-46 [present] · PDF page 151

45-46. Rectifications: If the contributor is in the
beginning of a rashi, his donation will be full, and it
will be nil if he is at the end of a rashi. For
intermediary placements, rule of the process will apply.
Add the longitudes of the contributors (devoid of rashis)
and the sum so arrived at must be divided by the number of
contributors. The latest product should be multiplied by
the number of basic years and divided by 30. This will
yield the net longevity.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P151_B005_01

- 身份：正文
- PDF 页：151
- 偈颂：47
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 47 [present] · PDF page 151

47. Special Rule for Shani: Should Shani be a contributor,
the class of longevity declines. Some advocate contrarily,
an increase of class in this context. If Shani is in its
own rashi or in exaltation, change in class will not occur.
Even if he receives a drishti from or is yuti with only a
malefic, no change occurs.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P152_B001_01

- 身份：正文
- PDF 页：152
- 偈颂：48
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 48 [present] · PDF page 152

48. Special Rule for Guru: If Guru is in Lagn or in Yuvati
Bhava, and receives a drishti from or is yuti with only
benefics, the class of longevity will increase.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P152_B002_01

- 身份：正文
- PDF 页：152
- 偈颂：49-50
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 49-50 [present] · PDF page 152

49-50. Increase and Fall in Class of Longevity: From very
short life to short life, from short life to medium life,
from medium life to long life and from long life to
extremely long life are the increases in the classification
of longevity when Guru warrants an increase. The reverse is
true if Shani warrants a fall in the span of life.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P152_B003_01

- 身份：正文
- PDF 页：152
- 偈颂：51
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 51 [present] · PDF page 152

51. (Maitreya says): You have narrated various kinds of
longevity computations. Please favour me by denoting subtle
classes there of and poor and long life spans.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P152_B004_01

- 身份：正文
- PDF 页：152
- 偈颂：52
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 52 [present] · PDF page 152

52. (Maharishi Parashar replies): These are seven-fold,
viz. Bal Risht, Yog Risht, short, medium, long,
super-natural (Divya), and immortality (Amritayu).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P152_B005_01

- 身份：正文
- PDF 页：152
- 偈颂：53-54
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 53-54 [present] · PDF page 152

53-54. The life span in Bal Risht is 8 years, in Yog Risht
20 years; in short, medium, and long lives respectively 32,
64, and 120 years. Super-natural life span is 1000 years.
Above this super-natural life span of 1000 years it is
Amritayu, which can be acquired only by those who deserve
it (Merits).
~5E*5I1*5Y2*6K*4K*&I3*&I6*&I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P152_B006_01

- 身份：正文
- PDF 页：152
- 偈颂：55
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 55 [present] · PDF page 152

55. Limitless Longevity: Should Kark be Lagn with Guru and
Chandr there in, while Shukr and Buddh are in Kendras, and
others are in Sahaj, Ari, and Labh Bhava, the native will
obtain limitless longevity.
~BK*mI3*mI6*mI11*L8iB+BT*mI3*mI6*mI11*L8iB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P152_B007_01

- 身份：正文
- PDF 页：152
- 偈颂：56
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 56 [present] · PDF page 152

56. Super-natural Longevity: One having benefics in Kendras
and/or Konas, while malefics are in Sahaj, Ari, and Labh
Bhava will obtain super-natural life span (one thousand
years). Randhr Bhava in this case should be one of the
rashis owned by a benefic.
~R4I1*5K*5Ié*6T*6Ië~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P152_B008_01

- 身份：正文
- PDF 页：152
- 偈颂：57
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 57 [present] · PDF page 152

57. Living until the End of the Yuga: One born in Kark Lagn
will live till the end of the yuga if Guru is in a Kendr
and happens to be in Gopuramsh, while Shukr is in a Kon and
happens to be in Paravatamsh.
~5I1*5Iê*7Iì*3ë~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P152_B009_01

- 身份：正文
- PDF 页：152
- 偈颂：58
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 58 [present] · PDF page 152

58. Living the Life Span of a Sage: Guru in Simhasanamsh
being in Lagn, Shani in Devalokamsh, and Mangal in
Paravatamsh; if these are so, one will enjoy the life span
as due to a sage.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P152_B010_01

- 身份：正文
- PDF 页：152
- 偈颂：59
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 59 [present] · PDF page 152

59. Good Yogas increase the life span and bad Yogas
decrease the same (as arrived by mathematical means).
Hence, I tell you such Yogas as to know of full, medium,
and short span combinations.
~BK*L1YB+BK*L1DB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P152_B011_01

- 身份：正文
- PDF 页：152
- 偈颂：60
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 60 [present] · PDF page 152

60. If a Kendr contains a benefic, while Lagn's lord is
yuti with or receives a drishti from a benefic, or Guru
in particular, the native will live a full span of life.
~L1K*L1Y5*5Y6+L1K*L1D5*L1Y6+L1K*L1D5*L1D6+L1K*L1Y5*L1D6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P153_B001_01

- 身份：正文
- PDF 页：153
- 偈颂：61
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 61 [present] · PDF page 153

61. Should Lagn's lord be in a Kendr yuti with or
receiving a drishti from Guru and Shukr, full life span
will result.
~@E3*L1E*L8E*-mI8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P153_B002_01

- 身份：正文
- PDF 页：153
- 偈颂：62
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 62 [present] · PDF page 153

62. If at birth three grahas are exalted, out of which the
lords, of Lagn  and Randhr Bhava are inclusive, as Randhr
Bhava is devoid of a malefic in it, full life span will
result.
~L1S*.3I8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P153_B003_01

- 身份：正文
- PDF 页：153
- 偈颂：63
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 63 [present] · PDF page 153

63. Long life is denoted if three grahas are in Randhr
Bhava, in exaltation, own or friendly divisions, while
Lagn's lord is strong.
~7Y&E+L1Y&E~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P153_B004_01

- 身份：正文
- PDF 页：153
- 偈颂：64
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 64 [present] · PDF page 153

64. If Shani or Lagn's lord is yuti with any exalted grah,
long life will result.
~BK*mI3*mI6*mI11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P153_B005_01

- 身份：正文
- PDF 页：153
- 偈颂：65
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 65 [present] · PDF page 153

65. Long life will be enjoyed if malefics are in Sahaj,
Ari, and Labh Bhava, while benefics are in Kendras.
~BI6*BI7*BI8*mI3*mI11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P153_B006_01

- 身份：正文
- PDF 页：153
- 偈颂：66
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 66 [present] · PDF page 153

66. If Ari, Yuvati, and Randhr Bhava are occupied by
benefics, while malefics are in Sahaj and Labh Bhava, full
life span will follow the birth.
~L8i2+L8i3+L8i9**mI6*mI12*L1K~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P153_B007_01

- 身份：正文
- PDF 页：153
- 偈颂：67
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 67 [present] · PDF page 153

67. If Randhr's lord is friendly to Surya, while malefics
are in Ari and Vyaya Bhava, as Lagn's lord is in a Kendr,
the native will live the full span of life.
~mI8*L10E~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P153_B008_01

- 身份：正文
- PDF 页：153
- 偈颂：68
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 68 [present] · PDF page 153

68. 0 excellent of the Brahmins, if a malefic is in Randhr
Bhava, while Karm's lord is exalted, one will be long
lived.
~LdI1*L1K

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P153_B009_01

- 身份：正文
- PDF 页：153
- 偈颂：69
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 69 [present] · PDF page 153

69. Long life will follow if Lagn is a dual rashi, while
Lagn's lord is in a Kendr, or in exaltation, or in a Kon.
~LdI1*(.:I!K)L1*L1S~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P153_B010_01

- 身份：正文
- PDF 页：153
- 偈颂：70
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 70 [present] · PDF page 153

70. Should Lagn be a dual rashi, while two malefics are in
a Kendr with reference to a strong Lagn's lord, long life
is indicated.
~.RLK~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P153_B011_01

- 身份：正文
- PDF 页：153
- 偈颂：71-73
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 71-73 [present] · PDF page 153

71-73. If the stronger among Lagn's lord and Randhr's lord
is placed in a Kendr long life is indicated;
~.RLI!P~m
and if in a Panaphara (Dhan, Putr, Randhr, or Labh Bhava)
medium life is indicated;
~.RLI!A~n
If the stronger among Lagn's lord and Randhr's lord is
placed in Apoklima (Sahaj, Ari, Dharm, or Vyaya Bhava)
short life will come to pass.
According to Lagn's lord being friendly, neutral, or
inimical to Surya, long, medium, or short life will
result.
~3cm*L3cm+L8cm*7cm~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P154_B001_01

- 身份：正文
- PDF 页：154
- 偈颂：74
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 74 [present] · PDF page 154

74. Should Mangal and Sahaj's lord, or Randhr's lord and
Shani, be combust or (two of either pair) be yuti with
malefics or receive a drishti from malefics, there will be
short life.
~L1Ia*L1Ym*-L1RB~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P154_B002_01

- 身份：正文
- PDF 页：154
- 偈颂：75
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 75 [present] · PDF page 154

75. If Lagn's lord is in Ari, Randhr, or Vyaya Bhava yuti
with malefics and devoid of yuti with and/or drishti from a
benefic, short life will come to pass.
~-L1S**mI1*-!1RB+mI4*-!4RB+mI7*-!7RB+mI10*-!10RB~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P154_B003_01

- 身份：正文
- PDF 页：154
- 偈颂：76
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 76 [present] · PDF page 154

76. If malefics are in Kendras devoid of yuti with or a
drishti from benefics, while Lagn's lord is not strong,
only short life will result.
~mI2*mI12*-!2RB*-!12RB~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P154_B004_01

- 身份：正文
- PDF 页：154
- 偈颂：77
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 77 [present] · PDF page 154

77. 0 excellent of Brahmins, if Vyaya and Dhan Bhava are
occupied by malefics and devoid of a drishti from a benefic
or devoid of yuti with a benefic, the native will be
short-lived.
~L1u*L1x*L8u*L8x~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P154_B005_01

- 身份：正文
- PDF 页：154
- 偈颂：78
- 标题路径：CHAPTER 43 Longevity
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Longevity · Sloka 78 [present] · PDF page 154

78. If the lords of Lagn and Randhr Bhava are bereft of
dignities and strength, short life will come to pass.
~L1e*L1x*L8e*L8x**L1RB*L8RB~m
If the lords of Lagn and Randhr Bhava are helped by others,
while being so, medium life span will come to pass.
