# 第 61 章：Effects of Pratyantar Dashas in the Antar

- 来源：BPHS 97 章版
- 原始卡片：82 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P272_B002_01

- 身份：正文
- PDF 页：272
- 偈颂：—
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka unknown [unknown] · PDF page 272 · page_block BPHS_PL9_CHAP_97_P272_B002

Dasha of Grahas

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P272_B003_01

- 身份：正文
- PDF 页：272
- 偈颂：1
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 1 [present] · PDF page 272

1. By multiplying the years, etc., of the Antar Dasha of
the Grahas separately by the Dasha years of each grah, and
by dividing the product by the total span of the
Vimshottari Dasha, namely 120 years, we will arrive at the
Pratyantar Dasha of each Grah.
Dasha of Surya
@1213@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P272_B004_01

- 身份：正文
- PDF 页：272
- 偈颂：2
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 2 [present] · PDF page 272

2. Surya-Surya (This means Pratyantar Dasha of Surya in the
Antar Dasha of Surya): Argument with other persons, loss of
wealth, distress to wife, headache, etc.. The above are
general effects. Such inauspicious effects will not be
produced if Surya is in a Trikon, etc., if Surya is the
lord of an auspicious bhava, or if Surya is in a auspicious
Bhava and in a benefic Varg. All other Pratyanta effects
should be judged in this manner.
@1223@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P272_B005_01

- 身份：正文
- PDF 页：272
- 偈颂：3
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 3 [present] · PDF page 272

3. Surya-Chandr: Excitement, quarrels, loss of wealth,
mental agony, etc..
@1233@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P272_B006_01

- 身份：正文
- PDF 页：272
- 偈颂：4
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 4 [present] · PDF page 272

4. Surya-Mangal: Danger from the king and from weapons,
imprisonment, and distress from enemies and fire.
@1283@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P272_B007_01

- 身份：正文
- PDF 页：272
- 偈颂：5
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 5 [present] · PDF page 272

5. Surya-Rahu: Disorder of phlegm, danger from weapons,
loss of wealth, destruction of a kingdom, and mental
agony.
@1253@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P272_B008_01

- 身份：正文
- PDF 页：272
- 偈颂：6
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 6 [present] · PDF page 272

6. Surya-Guru: Victory, increase in wealth, gains of gold,
garments, conveyances, etc..
@1273@
Surya-Shani: Loss of wealth, distress to cattle,
excitement, diseases, etc..
@1243@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P272_B009_01

- 身份：正文
- PDF 页：272
- 偈颂：8
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 8 [present] · PDF page 272

8. Surya-Buddh: Affectionate relations with kinsmen
availability of good food, gains of wealth, religious
mindedness, reverence from the king (government).
@1293@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P272_B010_01

- 身份：正文
- PDF 页：272
- 偈颂：9
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 9 [present] · PDF page 272

9. Surya-Ketu: Danger to life, loss of wealth, danger from
the king (government), trouble with enemies.
@1263@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P272_B011_01

- 身份：正文
- PDF 页：272
- 偈颂：10
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 10 [present] · PDF page 272

10. Surya-Shukr: Moderate effects or some gains of wealth
may be expected.
Daasha of Chandr
@2223@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P272_B012_01

- 身份：正文
- PDF 页：272
- 偈颂：11
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 11 [present] · PDF page 272

11. Chandr-Chandr: Acquisition of land, wealth, and
property reverence from the king (government), and
availability of sweetish preparations.
@2233@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P273_B001_01

- 身份：正文
- PDF 页：273
- 偈颂：12
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 12 [present] · PDF page 273

12. Chandr-Mangal: Wisdom and discretion, reverence from
the people, increase in wealth, enjoyments to kinsmen, but
there will be danger from an enemy.
@2283@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P273_B002_01

- 身份：正文
- PDF 页：273
- 偈颂：13
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 13 [present] · PDF page 273

13. Chandr-Rahu: Well-being, gain of wealth from the king
(government), and danger of death, if Rahu is yuti with a
malefic.
@2253@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P273_B003_01

- 身份：正文
- PDF 页：273
- 偈颂：14
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 14 [present] · PDF page 273

14. Chandr-Guru: Enjoyments, increase in dignity and glory,
gain of knowledge through the preceptor, acquisition of a
kingdom (high position in government), and acquisition of
gems, etc..
@2273@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P273_B004_01

- 身份：正文
- PDF 页：273
- 偈颂：15
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 15 [present] · PDF page 273

15. Chandr-Shani: Bilious troubles, loss of wealth and name
and fame.
@2243@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P273_B005_01

- 身份：正文
- PDF 页：273
- 偈颂：16
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 16 [present] · PDF page 273

16. Chandr-Buddh: Birth of a son, acquisition of a horse
and other conveyances, success in education, progress, gain
of white garments and grains.
@2293@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P273_B006_01

- 身份：正文
- PDF 页：273
- 偈颂：17
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 17 [present] · PDF page 273

17. Chandr-Ketu: Quarrels with Brahmins, fear of premature
death, loss of happiness, and distress all round.
@2263@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P273_B007_01

- 身份：正文
- PDF 页：273
- 偈颂：18
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 18 [present] · PDF page 273

18. Chandr-Shukr: Gain of wealth, enjoyments, birth of a
daughter, availability of sweet preparations, and cordial
relations with all.
@2213@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P273_B008_01

- 身份：正文
- PDF 页：273
- 偈颂：19
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 19 [present] · PDF page 273

19. Chandr-Surya: Gain of happiness, grains and garments,
victories everywhere.
Dasha of Mangal
@3233@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P273_B009_01

- 身份：正文
- PDF 页：273
- 偈颂：20
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 20 [present] · PDF page 273

20. Mangal-Mangal: Danger from enemies, quarrels, and fear
of premature death on account of blood diseases.
@3283@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P273_B010_01

- 身份：正文
- PDF 页：273
- 偈颂：21
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 21 [present] · PDF page 273

21. Mangal-Rahu: Destruction of wealth and kingdom (fall of
government), unpalatable food, and quarrels with the
enemy.
@3253@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P273_B011_01

- 身份：正文
- PDF 页：273
- 偈颂：22
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 22 [present] · PDF page 273

22. Mangal-Guru: Loss of intelligence, distress, sorrows
children, fear of premature death, negligence, quarrels,
and no fulfillment of any ambition.
@3273@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P273_B012_01

- 身份：正文
- PDF 页：273
- 偈颂：23
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 23 [present] · PDF page 273

23. Mangal-Shani: Destruction of the employer, distress,
loss of wealth, danger from enemies, anxiety, quarrels, and
sorrows.
@3243@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P273_B013_01

- 身份：正文
- PDF 页：273
- 偈颂：24
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 24 [present] · PDF page 273

24. Mangal-Buddh: Loss of intelligence, loss of wealth,
fevers, and loss of grains, garments, and friends.
@3293@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P274_B001_01

- 身份：正文
- PDF 页：274
- 偈颂：25
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 25 [present] · PDF page 274

25. Mangal-Ketu: Distress from diseases, lethargy,
premature death, danger from the king and weapons.
@3263@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P274_B002_01

- 身份：正文
- PDF 页：274
- 偈颂：26
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 26 [present] · PDF page 274

26. Mangal-Shukr: Distress from Chandal, sorrows, danger
from the king and from weapons, dysentery, and vomiting.
@3213@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P274_B003_01

- 身份：正文
- PDF 页：274
- 偈颂：27
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 27 [present] · PDF page 274

27. Mangal-Surya: Increase in landed property and wealth,
satisfaction, visits of friends, happiness all round.
@3223@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P274_B004_01

- 身份：正文
- PDF 页：274
- 偈颂：28
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 28 [present] · PDF page 274

28. Mangal-Chandr: gains of white garments, etc., from the
southern direction, success in all ventures.
Dasha of Rahu
@8283@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P274_B005_01

- 身份：正文
- PDF 页：274
- 偈颂：29
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 29 [present] · PDF page 274

29. Rahu-Rahu: Imprisonment, disease, danger of injuries
from weapons.
@8253@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P274_B006_01

- 身份：正文
- PDF 页：274
- 偈颂：30
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 30 [present] · PDF page 274

30. Rahu-Guru: Reverence everywhere, acquisition of
conveyances like elephants, etc., gain of wealth.
@8273@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P274_B007_01

- 身份：正文
- PDF 页：274
- 偈颂：31
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 31 [present] · PDF page 274

31. Rahu-Shani: Rigorous imprisonment, loss of enjoyments,
danger from enemies, affliction with rheumatism.
@8243@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P274_B008_01

- 身份：正文
- PDF 页：274
- 偈颂：32
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 32 [present] · PDF page 274

32. Rahu-Buddh: Gain in all ventures, abnormal, gain
through wife.
@8293@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P274_B009_01

- 身份：正文
- PDF 页：274
- 偈颂：33
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 33 [present] · PDF page 274

33. Rahu-Ketu: Loss of intelligence, danger from enemies,
obstacles, loss of wealth, quarrels, excitement.
@8263@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P274_B010_01

- 身份：正文
- PDF 页：274
- 偈颂：34
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 34 [present] · PDF page 274

34. Rahu-Shukr: Danger from a Yogini, danger from the king,
loss of conveyances, availability of unpalatable food, loss
of a wife, sorrow in the family.
@8213@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P274_B011_01

- 身份：正文
- PDF 页：274
- 偈颂：35
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 35 [present] · PDF page 274

35. Rahu-Surya: Danger from enemies, fevers, distress to
children, fear of premature death, negligence.
@8223@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P274_B012_01

- 身份：正文
- PDF 页：274
- 偈颂：36
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 36 [present] · PDF page 274

36. Rahu-Chandr: Excitement, quarrels, worries, loss of
reputation, fear, distress to father.
@8233@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P274_B013_01

- 身份：正文
- PDF 页：274
- 偈颂：37
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 37 [present] · PDF page 274

37. Rahu-Mangal: Septic boil in the anus ('Bhagandhar'),
distress due to a bite and pollution of blood, loss of
wealth, excitement.
Dasha of Guru
@5253@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P274_B014_01

- 身份：正文
- PDF 页：274
- 偈颂：38
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 38 [present] · PDF page 274

38. Guru-Guru: Acquisition of gold, increase in wealth,
etc.
@5273@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P275_B001_01

- 身份：正文
- PDF 页：275
- 偈颂：39
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 39 [present] · PDF page 275

39. Guru-Shani: Increase in lands, conveyances, and grains
@5243@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P275_B002_01

- 身份：正文
- PDF 页：275
- 偈颂：40
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 40 [present] · PDF page 275

40. Guru-Buddh: Success in the educational sphere,
acquisition of clothes and gems like pearls, etc., visits
of friends.
@5293@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P275_B003_01

- 身份：正文
- PDF 页：275
- 偈颂：41
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 41 [present] · PDF page 275

41. Guru-Ketu: Danger from water and thieves.
@5263@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P275_B004_01

- 身份：正文
- PDF 页：275
- 偈颂：42
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 42 [present] · PDF page 275

42. Guru-Shukr: Several kinds of Iearning, gain a gold,
clothes, ornaments, well-being, and satisfaction.
@5213@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P275_B005_01

- 身份：正文
- PDF 页：275
- 偈颂：43
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 43 [present] · PDF page 275

43. Guru-Surya: Gain from the king (government), friends
and parents, reverence everywhere.
@5223@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P275_B006_01

- 身份：正文
- PDF 页：275
- 偈颂：44
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 44 [present] · PDF page 275

44. Guru-Chandr: No distress, gain of wealth and
conveyances, success in ventures.
@5233@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P275_B007_01

- 身份：正文
- PDF 页：275
- 偈颂：45
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 45 [present] · PDF page 275

45. Guru-Mangal: Danger from weapons, pain in anus, burning
in the stomach, indigestion, distress from enemies.
@5283@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P275_B008_01

- 身份：正文
- PDF 页：275
- 偈颂：46
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 46 [present] · PDF page 275

46. Guru-Rahu: Antagonism with menials ('Chandaldhi') and
loss of wealth and distress through them.
Dasha of Shani
@7273@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P275_B009_01

- 身份：正文
- PDF 页：275
- 偈颂：47
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 47 [present] · PDF page 275

47. Shani-Shani: Physical distress, quarrels, danger from
menials.
@7243@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P275_B010_01

- 身份：正文
- PDF 页：275
- 偈颂：48
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 48 [present] · PDF page 275

48. Shani-Buddh: Loss of intelligence, quarrels, dangers,
anxiety about availability of food, loss of wealth, danger
from enemy.
@7293@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P275_B011_01

- 身份：正文
- PDF 页：275
- 偈颂：49
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 49 [present] · PDF page 275

49. Shani-Ketu: Imprisonment in the camp of the enemy, loss
of luster, hunger, anxiety, and agony.
@7263@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P275_B012_01

- 身份：正文
- PDF 页：275
- 偈颂：50
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 50 [present] · PDF page 275

50. Shani-Shukr: Fulfillment of ambitions, well-being in
the family, success in ventures and gains there from.
@7213@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P275_B013_01

- 身份：正文
- PDF 页：275
- 偈颂：51
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 51 [present] · PDF page 275

51. Shani-Surya: Conferment of authority by the king,
quarrels in the family, fevers.
@7223@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P275_B014_01

- 身份：正文
- PDF 页：275
- 偈颂：52
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 52 [present] · PDF page 275

52. Shani-Chandr: Development of intelligence, inauguration
of big a venture, loss of luster, extravagant expenditure,
association with many women.
@7233@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P275_B015_01

- 身份：正文
- PDF 页：275
- 偈颂：53
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 53 [present] · PDF page 275

53. Shani-Mangal: Loss of valour, distress to son, danger
from fire and enemy, distress from bile and wind.
@7283@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P276_B001_01

- 身份：正文
- PDF 页：276
- 偈颂：54
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 54 [present] · PDF page 276

54. Shani-Rahu: Loss of wealth, clothes, land, going away
to foreign lands, fear of death.
@7253@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P276_B002_01

- 身份：正文
- PDF 页：276
- 偈颂：55
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 55 [present] · PDF page 276

55. Shani-Guru: Inability to prevent losses caused by
women, quarrels, excitement.
Dasha of Buddh
@4243@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P276_B003_01

- 身份：正文
- PDF 页：276
- 偈颂：56
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 56 [present] · PDF page 276

56. Buddh-Buddh: Gain of intelligence, education, wealth,
clothes, etc..
@4293@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P276_B004_01

- 身份：正文
- PDF 页：276
- 偈颂：57
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 57 [present] · PDF page 276

57. Buddh-Ketu: coarse food, stomach troubles, eye
troubles, distress from bilious and blood disorders.
@4263@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P276_B005_01

- 身份：正文
- PDF 页：276
- 偈颂：58
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 58 [present] · PDF page 276

58. Buddh-Shukr: Gains from a northern direction, loss of
cattle, acquisition of authority from government.
@4213@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P276_B006_01

- 身份：正文
- PDF 页：276
- 偈颂：59
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 59 [present] · PDF page 276

59. Buddh-Surya: Loss of splendour, and distress through
diseases, distress in the heart.
@4223@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P276_B007_01

- 身份：正文
- PDF 页：276
- 偈颂：60
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 60 [present] · PDF page 276

60. Buddh-Chandr: Marriage, gain of wealth and property,
birth of a daughter, enjoyments all round.
@4233@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P276_B008_01

- 身份：正文
- PDF 页：276
- 偈颂：61
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 61 [present] · PDF page 276

61. Buddh-Mangal: Religious mindedness, increase in wealth,
danger from fire and enemies, gain of red clothes, injury
from a weapon.
@4283@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P276_B009_01

- 身份：正文
- PDF 页：276
- 偈颂：62
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 62 [present] · PDF page 276

62. Buddh-Rahu: Quarrels, danger from wife or some other
woman, danger from the king (government).
@4253@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P276_B010_01

- 身份：正文
- PDF 页：276
- 偈颂：63
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 63 [present] · PDF page 276

63. Buddh-Guru: Acquisition of a kingdom, conferment of
authority by the king, reverence from the king, education,
intelligence.
@4273@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P276_B011_01

- 身份：正文
- PDF 页：276
- 偈颂：64
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 64 [present] · PDF page 276

64. Buddh-Shani: Bilious and windy troubles, injuries to
the body, loss of wealth.
Dasha of Ketu
@9293@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P276_B012_01

- 身份：正文
- PDF 页：276
- 偈颂：65
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 65 [present] · PDF page 276

65. Ketu-Ketu: Sudden disaster, going away to foreign
lands, loss of wealth.
@9263@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P276_B013_01

- 身份：正文
- PDF 页：276
- 偈颂：66
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 66 [present] · PDF page 276

66. Ketu-Shukr: Loss of wealth through a non-Hindu king,
eye troubles, headache, loss of cattle.
@9213@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P276_B014_01

- 身份：正文
- PDF 页：276
- 偈颂：67
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 67 [present] · PDF page 276

67. Ketu-Surya: Antagonism with friends, premature death,
defeat, exchange of arguments.
@9223@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P277_B001_01

- 身份：正文
- PDF 页：277
- 偈颂：68
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 68 [present] · PDF page 277

68. Ketu-Chandr: Loss of grains, physical distress,
misunderstanding, dysentery.
@9233@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P277_B002_01

- 身份：正文
- PDF 页：277
- 偈颂：69
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 69 [present] · PDF page 277

69. Ketu-Mangal: Injury from weapons, distress from fire,
danger from menials and enemies.
@9283@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P277_B003_01

- 身份：正文
- PDF 页：277
- 偈颂：70
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 70 [present] · PDF page 277

70. Ketu-Rahu: Danger from women and enemies, distress
caused by menials.
@9253@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P277_B004_01

- 身份：正文
- PDF 页：277
- 偈颂：71
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 71 [present] · PDF page 277

71. Ketu-Guru: Loss of friends, wealth and garments,
opprobrium (= abusive language, disgrace, dishonour)  in
the house, troubles from every-where.
@9273@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P277_B005_01

- 身份：正文
- PDF 页：277
- 偈颂：72
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 72 [present] · PDF page 277

72. Ketu-Shani: Death of cattle and friends, physical
distress, very meagre gain of wealth.
@9243@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P277_B006_01

- 身份：正文
- PDF 页：277
- 偈颂：73
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 73 [present] · PDF page 277

73. Ketu-Buddh: Loss of understanding, excitement, failure
in education, dangers, failure in all ventures.
Dasha of Shukr
@6263@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P277_B007_01

- 身份：正文
- PDF 页：277
- 偈颂：74
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 74 [present] · PDF page 277

74. Shukr-Shukr: Gains of white clothes, conveyances, gems
like pearls, etc., association with beautiful damsel.
@6213@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P277_B008_01

- 身份：正文
- PDF 页：277
- 偈颂：75
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 75 [present] · PDF page 277

75. Shukr-Surya: Rheumatic fever, headache, danger from the
king and enemies, and meagre gain of wealth.
@6223@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P277_B009_01

- 身份：正文
- PDF 页：277
- 偈颂：76
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 76 [present] · PDF page 277

76. Shukr-Chandr: Birth of a daughter, gain of clothes,
etc., from the king, acquisition of authority.
@6233@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P277_B010_01

- 身份：正文
- PDF 页：277
- 偈颂：77
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 77 [present] · PDF page 277

77. Shukr-Mangal: Blood and bile troubles, quarrels, many
kinds of distresses.
@6283@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P277_B011_01

- 身份：正文
- PDF 页：277
- 偈颂：78
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 78 [present] · PDF page 277

78. Shukr-Rahu: Quarrels with wife, danger, distress from
the king and enemies.
@6253@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P277_B012_01

- 身份：正文
- PDF 页：277
- 偈颂：79
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 79 [present] · PDF page 277

79. Shukr-Guru: Acquisition of kingdom, wealth, garments,
gems, ornaments and conveyance like elephants, etc..
@6273@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P277_B013_01

- 身份：正文
- PDF 页：277
- 偈颂：80
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 80 [present] · PDF page 277

80. Shukr-Shani: Acquisition of donkey, camel, goat, iron,
grains, sesame seeds, physical pains.
@6243@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P277_B014_01

- 身份：正文
- PDF 页：277
- 偈颂：81
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 81 [present] · PDF page 277

81. Shukr-Buddh: Gains of wealth, knowledge, authority from
the king, gain of money distributed by others.
@6293@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P277_B015_01

- 身份：正文
- PDF 页：277
- 偈颂：82
- 标题路径：CHAPTER 61 Effects of Pratyantar Dashas in the Antar › Dasha of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Pratyantar Dashas in the Antar · Sloka 82 [present] · PDF page 277

82. Shukr Ketu: Premature death, going away from homeland,
gains of wealth at times.
