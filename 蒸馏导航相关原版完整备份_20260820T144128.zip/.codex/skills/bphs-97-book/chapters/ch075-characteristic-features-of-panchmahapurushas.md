# 第 75 章：Characteristic Features of Panchmahapurushas

- 来源：BPHS 97 章版
- 原始卡片：6 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P321_B002_01

- 身份：正文
- PDF 页：321
- 偈颂：1-2
- 标题路径：CHAPTER 75 Characteristic Features of Panchmahapurushas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Characteristic Features of Panchmahapurushas · Sloka 1-2 [present] · PDF page 321

1-2. The sage said: O Maitreya! Now I will relate to you the
characteristic features of Panchmahapurushas (five types of
great personalities). When Mangal, Buddh, Guru, Shukr, and
Shani being in their own rashi or in their exaltation rashi,
be in kendra to Lagn, they give rise to Ruchaka, Bhadra,
Hamsa, Malavya, and Sasa Yogas respectively. These Yogas are
called Panchmahapurusha Yogas and the persons born in these
Yogas are known Panchmahapurushas (five types of great
personalities).
~3O*3K+3E*3K~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P321_B003_01

- 身份：正文
- PDF 页：321
- 偈颂：3-7
- 标题路径：CHAPTER 75 Characteristic Features of Panchmahapurushas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Characteristic Features of Panchmahapurushas · Sloka 3-7 [present] · PDF page 321

3-7. The Ruchaka native possesses a long face, he is very
enthusiastic, has spotless lustre, is powerful, has
attractive brows, black hair, and is fond of all things. He
loves to fight wars, is of dark red complexion, is victorious
over enemies, is discriminating, is protector of thieves and
has cruel temperament and slender thighs. He is a devotee of
Brahmins, has marks of veena, varg, dhanus, pasha, and vrasha
rashis in his hands along with chakr rekha. He is well versed
in occult sciences. He, is 100 anguls in height, his waste
has the circumference equal to the length of his face and is
1000 Karshas in weight. He as ruler of Sahyachala and Vindhya
Pradesh dies after attaining the age of 70 by fire or
weapons.
Notes: The old rupee had the weight of 1 karsha. 4 karshas
are equal to one pala and 300 palas make one tula, according
to Amarkosha. 20 Tulas are equal to one bhara. These are
ancient weights and measures.
~4O*4K+4E*4K~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P321_B004_01

- 身份：正文
- PDF 页：321
- 偈颂：8-12
- 标题路径：CHAPTER 75 Characteristic Features of Panchmahapurushas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Characteristic Features of Panchmahapurushas · Sloka 8-12 [present] · PDF page 321

8-12. The Bhadra native is splendorous like a lion, has very
developed chest (or chest with well developed muscles), has
the gait of an elephant, has long and thick arms, is learned
in all respects. He is well versed in Yog performance, is
satwa-guni and has beautiful feet, moustaches and head. He is
fond of luxuries and comforts and has marks of sankha
(conch), chakr, gada, arrow, elephant, dhwaja (flag), and
hala (plough) in his hands and feet. He is well versed in
shastras, has black and curly hair, possesses independent
nature, and is protector of his family. His friends share in
the enjoyment of his wealth. He is 20 tulas (one bhara) in
weight. He lives happily with his wife and children and as
ruler of Madhya Desha lives for one hundred years.
~5O*5K+5E*5K~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P321_B005_01

- 身份：正文
- PDF 页：321
- 偈颂：13-16
- 标题路径：CHAPTER 75 Characteristic Features of Panchmahapurushas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Characteristic Features of Panchmahapurushas · Sloka 13-16 [present] · PDF page 321

13-16. The Hamsa native has voice like a hamsa (swan), has a
handsome appearance and well developed nose. He is a king
with phlegmatic temperament, honey like tawny coloured eyes,
red coloured nails, sharp intelligence, sturdy cheeks, round
forehead and beautiful feet. He has marks of matsya (fish),
ankush (the iron hook with which elephants are driven),
dhanus (bow), sankh (conch), kamal (lotus) in his hands and
feet. He is very passionate and his lust remains unfulfilled.
He is 96 anguls in height. He is fond of swimming and playing
games in watery places. He enjoys life fully and as ruler of
a land situated between the Ganges and Yamuna dies after
attaining the age of 100 years.
~6O*6K+6E*6K~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P322_B001_01

- 身份：正文
- PDF 页：322
- 偈颂：17-19
- 标题路径：CHAPTER 75 Characteristic Features of Panchmahapurushas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Characteristic Features of Panchmahapurushas · Sloka 17-19 [present] · PDF page 322

17-19. The Malavya native has beautiful lips and a slender
waist. He is lustrous like Chandr and has fragrance in his
body. He is of ordinary red complexion, has a medium stature
and clean and beautiful teeth. His voice is like that of an
elephant and his arms are long enough to reach up to his
knees. His face is thirteen anguls in length and ten anguls
in breadth. He lives happily for seventy years as ruler of
Sindhu and Malwa and then leaves for his heavenly abode.
~7O*7K+7E*7K~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P322_B002_01

- 身份：正文
- PDF 页：322
- 偈颂：20-22
- 标题路径：CHAPTER 75 Characteristic Features of Panchmahapurushas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Characteristic Features of Panchmahapurushas · Sloka 20-22 [present] · PDF page 322

20-22. The Sasa native has small sized teeth and face but his
body is not small. He is valorous. He has a slender waist and
beautiful thighs. He is wise and enjoys wandering in forests
and mountains. He is well versed in the loopholes
(weaknesses) of the enemy. He is lively, virile, and fond of
women. He usurps other people's wealth. He has marks of mala
(garland), veena, mridanga (musical instruments) and weapons
in his hands and feet. He rules happily over several parts of
the earth and then leaves for his heavenly abode at the age
of 70.
