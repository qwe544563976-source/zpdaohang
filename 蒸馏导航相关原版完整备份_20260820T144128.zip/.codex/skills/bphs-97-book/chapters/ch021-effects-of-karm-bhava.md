# 第 21 章：Effects of Karm Bhava

- 来源：BPHS 97 章版
- 原始卡片：17 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P056_B002_01

- 身份：正文
- PDF 页：56
- 偈颂：1
- 标题路径：CHAPTER 21 Effects of Karm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karm Bhava · Sloka 1 [present] · PDF page 56

1. I now explain the effects of Karm Bhava. Listen to
these, O Maitreya, in the words of Brahma, Garga, and
others.
~L10X*L10E+L10X*L10O+L10X*L10NO+L10X*L10NE~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P056_B003_01

- 身份：正文
- PDF 页：56
- 偈颂：2
- 标题路径：CHAPTER 21 Effects of Karm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karm Bhava · Sloka 2 [present] · PDF page 56

2. Paternal Happiness: If Karm's lord is strong and in
exaltation or in its own Rashi/Navamsh, the native will
derive extreme paternal happiness, will enjoy fame, and
will perform good deeds.
~L10x~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P056_B004_01

- 身份：正文
- PDF 页：56
- 偈颂：3
- 标题路径：CHAPTER 21 Effects of Karm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karm Bhava · Sloka 3 [present] · PDF page 56

3. If Karm's lord is devoid of strength, the native will
face obstructions in his work.
~8K+8T~
If Rahu is in an angle or in a trine, he will perform
religious sacrifices like Jyotishtoma.
~L10YB+L10IJ~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P056_B005_01

- 身份：正文
- PDF 页：56
- 偈颂：4
- 标题路径：CHAPTER 21 Effects of Karm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karm Bhava · Sloka 4 [present] · PDF page 56

4. If Karm's lord is with a benefic or be in an auspicious
Bhava, one will always gain through royal patronage and in
business. In a contrary situation, only opposite results
will come to pass.
~mI10*mI11~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P056_B006_01

- 身份：正文
- PDF 页：56
- 偈颂：5
- 标题路径：CHAPTER 21 Effects of Karm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karm Bhava · Sloka 5 [present] · PDF page 56

5. Should Karm and Labh Bhava be both occupied by malefics
the native will indulge only in bad deeds and will defile
his own men.
~L10I8*L10Y8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P056_B007_01

- 身份：正文
- PDF 页：56
- 偈颂：6
- 标题路径：CHAPTER 21 Effects of Karm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karm Bhava · Sloka 6 [present] · PDF page 56

6. If the lord of Karm Bhava is relegated to Randhr Bhava
along with Rahu, the native will hate others; be a great
fool and will do bad deeds.
~7I7*L10I7*3I7*L7Ym~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P056_B008_01

- 身份：正文
- PDF 页：56
- 偈颂：7
- 标题路径：CHAPTER 21 Effects of Karm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karm Bhava · Sloka 7 [present] · PDF page 56

7. If Shani, Mangal, and Karm's lord are in Yuvati, as
Yuvati's lord is with a malefic, the native will be fond of
carnal pleasures and of filing his belly.
~L10E*L10Y5*L9I10~
8-10 Should Karm's lord be in exaltation and be in the
company of Guru as Dharm's lord is in Karm the native will
be endowed with honour, wealth, and valour.
~L11I10*L10I1+L10YL11*L10K~
One will lead a happy life if Labh's lord is in Karm and
Karm's lord is in Lagn, or if the lord of Karm Bhava is
yuti with the lord of Labh Bhava in an angle.
~L10X*L10IR12*L10Y5~
Should Karm's lord in strength be in Meen along Guru, the
native will doubtless obtain robes, ornaments, and
happiness.
~8I11*7I11*1I11*3I11~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P056_B009_01

- 身份：正文
- PDF 页：56
- 偈颂：11
- 标题路径：CHAPTER 21 Effects of Karm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karm Bhava · Sloka 11 [present] · PDF page 56

11. Should Rahu, Surya, Shani, and Mangal be in Labh Bhava,
the native will incur cessation of his duties.
~5I12*5Y6*L1X*2E~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P056_B010_01

- 身份：正文
- PDF 页：56
- 偈颂：12
- 标题路径：CHAPTER 21 Effects of Karm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karm Bhava · Sloka 12 [present] · PDF page 56

12. One will be learned and wealthy if Guru is in Meen
along with Shukr, while Lagn's lord is strong and Chandr is
in exaltation.
~L10I11*L11I1*6I10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P057_B001_01

- 身份：正文
- PDF 页：57
- 偈颂：13
- 标题路径：CHAPTER 21 Effects of Karm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karm Bhava · Sloka 13 [present] · PDF page 57

13. Should Karm's lord be in Labh, while Labh's lord is in
Tanu Bhava and Shukr is in Karm, the native will be endowed
with precious stones.
~L10E**L10K*L10Y5+L10K*L10D5+L10T*L10Y5+L10T*L10D5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P057_B002_01

- 身份：正文
- PDF 页：57
- 偈颂：14
- 标题路径：CHAPTER 21 Effects of Karm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karm Bhava · Sloka 14 [present] · PDF page 57

14. If the Karm's lord is exalted in an angle or a trine,
and is yuti with Guru, or receives a drishti from Guru,
one will be endowed with (worthy) deeds.
~L10I1*L1I1*2K+L10I1*L1I1*2T~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P057_B003_01

- 身份：正文
- PDF 页：57
- 偈颂：15
- 标题路径：CHAPTER 21 Effects of Karm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karm Bhava · Sloka 15 [present] · PDF page 57

15. Should Karm's lord be in Lagn along with Lagn's lord as
Chandr is in an angle or in a trine, the native will be
interested in good deeds.
~7I10*7Yt*mIN10~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P057_B004_01

- 身份：正文
- PDF 页：57
- 偈颂：16
- 标题路径：CHAPTER 21 Effects of Karm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karm Bhava · Sloka 16 [present] · PDF page 57

16. If Shani is in Karm Bhava along with a debilitated
grah, while Karm Bhava in the Navamsh Kundali is occupied
by a malefic, the native will be bereft of (virtuous)
acts.
~L10I8*L8I10*L8Ym~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P057_B005_01

- 身份：正文
- PDF 页：57
- 偈颂：17
- 标题路径：CHAPTER 21 Effects of Karm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karm Bhava · Sloka 17 [present] · PDF page 57

17. One will indulge in bad acts if Karm's lord is in
Randhr Bhava, while Randhr's lord is in Karm Bhava with a
malefic.
~L10d*mI10*mI7~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P057_B006_01

- 身份：正文
- PDF 页：57
- 偈颂：18
- 标题路径：CHAPTER 21 Effects of Karm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karm Bhava · Sloka 18 [present] · PDF page 57

18. Obstructions to the native's acts will crop up if
Karm's lord is in fall, as both Karm Bhava and the 10th
from Karm Bhava (i.e. Yuvati Bhava) have malefic
occupations.
~2I10*L10I2*L1K+2I10*L10I6*L1K+L11I10*L10X*L10D5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P057_B007_01

- 身份：正文
- PDF 页：57
- 偈颂：19-21
- 标题路径：CHAPTER 21 Effects of Karm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karm Bhava · Sloka 19-21 [present] · PDF page 57

19-21. Combinations for Fame: One will be endowed with fame
if Chandr is in Karm Bhava, while Karm's lord is in a trine
from Karm Bhava, and Lagn's lord is in Lagn's angle.
Similar effects will come to pass if Labh's lord is in Karm
Bhava, while Karm's lord is strong and gives a drishti to
Guru.
~L10I9*L1I10*2I5~
Fame will come to the native if Karm's lord is in Dharm
Bhava as Lagn's lord is in Karm Bhava, and Chandr is in
Putr Bhava.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P057_B008_01

- 身份：正文
- PDF 页：57
- 偈颂：22
- 标题路径：CHAPTER 21 Effects of Karm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karm Bhava · Sloka 22 [present] · PDF page 57

22. 0 excellent of the Brahmins, thus have been told about
the effects of Karm Bhava in a brief manner. Other related
effects be guessed by you based on the relationship of the
lords of Lagn and of Karm Bhava.
