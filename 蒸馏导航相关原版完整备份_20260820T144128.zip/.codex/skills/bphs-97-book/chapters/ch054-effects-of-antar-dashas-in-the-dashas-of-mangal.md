# 第 54 章：Effects of Antar Dashas in the Dashas of Mangal

- 来源：BPHS 97 章版
- 原始卡片：33 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P228_B002_01

- 身份：正文
- PDF 页：228
- 偈颂：—
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka unknown [unknown] · PDF page 228 · page_block BPHS_PL9_CHAP_97_P228_B002

@3132@
Effects of Antar Dashas of Mangal in the Dasha of Mangal
~3K+3I5+3I9+3I11+3I3+3I2+3AL1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P228_B003_01

- 身份：正文
- PDF 页：228
- 偈颂：1-2 1/2
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 1-2 1/2 [present] · PDF page 228

1-2 1/2. Effects like gains or wealth by the beneficence of
the king (government), beneficence of Goddess Lakshmi,
recovery of a lost kingdom (reinstatement in a high
position) and of wealth, birth of a son, will arise in the
Antar Dasha of Mangal in his own Dasha, if he is in a
Kendr, in Putr, in Dharm, in Labh, in Sahaj, or in Dhan
Bhava, or be associated with the lord of Lagn.
~3E*3X+3O*3X+3NO*3X~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P228_B004_01

- 身份：正文
- PDF 页：228
- 偈颂：3-4
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 3-4 [present] · PDF page 228

3-4. Fulfillment of ambitions by the beneficence of the
king (government) and acquisition of a house, land, cow,
buffalo, etc., will be the effects if Mangal is in his
Exaltation Rashi, in his own Rashi, or in his own Navamsh,
and is endowed with strength.
~3I8+3I12+3Am+3Dm~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P228_B005_01

- 身份：正文
- PDF 页：228
- 偈颂：5-5 1/2
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 5-5 1/2 [present] · PDF page 228

5-5 1/2. Urinary troubles, wounds, danger from snakes and
the king (government) will be the results, if Mangal is in
Randhr, or in Vyaya Bhava, or is associated with or
receives a drishti from malefics.
~3iL2+3iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P228_B006_01

- 身份：正文
- PDF 页：228
- 偈颂：6-8
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 6-8 [present] · PDF page 228

6-8. There will be mental agony and body pains if Mangal is
the lord of Dhan or Yuvati Bhava. Lord Shiva will give
relief by restoring health and providing gains of wealth
and happiness, if the person concerned performs Rudr Japa
and gives a red coloured bull in charity.
@3182@
Effects of the Antar Dasha of Rahu in the Dasha of Mangal
~8M*8AB+8E*8AB+8K*8AB+8I11*8AB+8I5*8AB+8I9*8AB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P228_B007_01

- 身份：正文
- PDF 页：228
- 偈颂：9-10 1/2
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 9-10 1/2 [present] · PDF page 228

9-10 1/2. Effects like recognition from government, gain of
house, land, etc., happiness from  son, extraordinary
profits in business, bathing in holy rivers like Ganges,
and foreign journeys, will be the auspicious effects in the
Antar Dasha of Rahu in the Dasha of Mangal, if Rahu is in
his Multrikon, in his Exaltation Rashi, in a Kendr, in
Labh, Putr, or Dharm Bhava and is associated with benefics.
~8I8+8I12+8Am+8Dm~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P228_B008_01

- 身份：正文
- PDF 页：228
- 偈颂：11-14
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 11-14 [present] · PDF page 228

11-14. Danger from snakes, wounds, destruction of cattle,
danger from animals, diseases due to imbalance of bile and
wind, imprisonment, etc., will be the results if Rahu is in
Randhr, or Vyaya Bhava, or receives a drishti from, or is
associated with malefics.
~8I2+8I7~
There will be loss of wealth if Rahu is in Dhan Bhava and
great danger of premature death if he is in Yuvati Bhava.
The remedial measure to be adopted to obtain relief from
the above evil effects are Naga Puja, offering food to
Brahmins and Mrityunjaya Japa. They will help in the
prolongation of longevity.
@3152@
Effects of the Antar Dasha of Guru in the Dasha of Mangal
~5I9+5I5+5K+5I11+5I2+5NE+5NO~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P229_B001_01

- 身份：正文
- PDF 页：229
- 偈颂：15-16
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 15-16 [present] · PDF page 229

15-16. Effects like good reputation and renown, honors by
government, increase in wealth and grains, happiness at
home, gain of property, happiness from wife and children,
etc., will be realized in the Antar Dasha of Guru in the
Dasha of Mangal, if Guru is in Dharm, or in Putr Bhava, in
a Kendr, or in Labh, or in Dhan Bhava, or if Guru is in his
exalted or own Navamsh.
~(5I!K)3+(5I!T)3+(5I11)3+5AL9+5AL10+5AL4+5AL1+N5IZ~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P229_B002_01

- 身份：正文
- PDF 页：229
- 偈颂：17-19 1/2
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 17-19 1/2 [present] · PDF page 229

17-19 1/2. Acquisition of a house, land, well being, gain
of property, sound health, good reputation, gains of
cattle, success in business, happiness to wife and
children, reverence from government, gain of wealth, etc.,
will be beneficial effects, if Guru is in a Kendr, in a
Trikon, or in the 11th from the lord of the Dasha (Mangal),
or if Guru is associated with the lord of Dharm, Karm, or
Bandhu Bhava, or Lagn, or if Guru is a benefic Navamsh,
etc..
~5I6+5I8+5I12+5d+5Am+5Dm+5v~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P229_B003_01

- 身份：正文
- PDF 页：229
- 偈颂：20-22
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 20-22 [present] · PDF page 229

20-22. Danger from thieves, snakes, wrath of the king
(government), bilious diseases, oppression by goblins
('Prot'), loss of servants and co-borns, will be evil
effects, if Guru is in Ari, Randhr, or in Vyaya Bhava, or
if Guru is in his Debilitation Rashi, or if Guru is
associated with or receives a drishti from malefics or if
Guru is otherwise weak.
~5iL2~
There will be suffering from fever or danger of premature
death if Guru is the lord of Dhan Bhava.
The remedial measure to be adopted to combat the above evil
effects is recitation of Shiva Sahasranam
@3172@
Effects of the Antar Dasha of Shani in the Dasha of Mangal
~7K+7T+7M+7NE+7NO+7AL1+7AB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P229_B004_01

- 身份：正文
- PDF 页：229
- 偈颂：23-25
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 23-25 [present] · PDF page 229

23-25. Effects like recognition from the king (government),
increase in reputation, gain of wealth and grains,
happiness from children and grand-children, increase in the
number of cows, etc., will be experienced in the Antar
Dasha of Shani in the Dasha of Mangal, if Shani is in a
Kendr, in a Trikon, in his Multrikon, in his exalted or his
own Navamsh, or if Shani is associated with the lord of
Lagn, or if Shani is associated with benefics. Results will
generally fructify on Saturdays in the month of Shani.
~7d+7e+7I8+7I12~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P229_B005_01

- 身份：正文
- PDF 页：229
- 偈颂：26-26 1/2
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 26-26 1/2 [present] · PDF page 229

26-26 1/2. Danger from Yavana kings (foreign dignitaries),
loss of wealth, imprisonment, possibility of affliction
with diseases, loss in agricultural production, will
result, if Shani is in his Debilitation Rashi or in an
enemy Rashi, or if Shani is in Randhr, or in Vyaya Bhava.
~7iL2+7iL7**7Am~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P230_B001_01

- 身份：正文
- PDF 页：230
- 偈颂：27-29 1/2
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 27-29 1/2 [present] · PDF page 230

27-29 1/2. Effects like great danger, loss of life, wrath
of king (government), mental agony, danger from thieves and
fire, punishment by the king (government), loss of
co-borns, dissensions amongst members of the family, loss
of cattle, fear of death, distress to wife and children,
imprisonment, etc., will be felt if Shani is Dhan's lord or
Yuvati's lord and is associated with malefics.
~(7I!K)3+(7I11)3+(7I5)3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P230_B002_01

- 身份：正文
- PDF 页：230
- 偈颂：30-32
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 30-32 [present] · PDF page 230

30-32. There will be journeys to foreign lands, loss of
reputation, violent actions, loss from sale of agricultural
lands, loss of position, agony, defeat in battle, urinary
troubles, etc., if Shani is in a Kendr, in the 11th, or in
the 5th from the lord of the Dasha (Mangal).
~(7I8)3*7Am+(7I12)3*7Am~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P230_B003_01

- 身份：正文
- PDF 页：230
- 偈颂：33-35
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 33-35 [present] · PDF page 230

33-35. Effects like death, danger from the king
(government) and thieves, rheumatism, pains, danger from
the enemy and members of the family, will be experienced if
Shani is in the 8th or the 12th from the lord of the Dasha
and is associated with malefics. There will be relief from
the evil effects by the beneficence of lord Shiva if
Mrityunjaya is performed in the prescribed manner.
@3142@
Effects of the Antar Dasha of Buddh in the Dasha of Mangal
~4K+4T~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P230_B004_01

- 身份：正文
- PDF 页：230
- 偈颂：36-37 1/2
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 36-37 1/2 [present] · PDF page 230

36-37 1/2. Effects like association with pious and holy
persons, performance of Ajaya Japa, charities, observance
of religious rites, gain of reputation, inclination towards
diplomacy, availability of sweetish preparations,
acquisition of conveyances, clothes and cattle, etc.,
conferment of authority in the king's retinue (attainment
of position of authority in government), success in
agricultural projects, etc., will be experienced in the
Antar Dasha of Buddh in the Dasha of Mangal, if Buddh is in
a Kendr or in a Trikon from Lagn.
~4d+4c+4I6+4I8+4I12~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P230_B005_01

- 身份：正文
- PDF 页：230
- 偈颂：38-39
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 38-39 [present] · PDF page 230

38-39. Diseases of heart, imprisonment, loss of kinsmen,
distress to wife and children, destruction of wealth and
cattle, etc., will result, if Buddh is in his Debilitation
Rashi, if Buddh is combust, or if Buddh is in Ari, in
Randhr, or in Vyaya Bhava.
~4A3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P230_B006_01

- 身份：正文
- PDF 页：230
- 偈颂：40-40 1/2
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 40-40 1/2 [present] · PDF page 230

40-40 1/2. There will be journeys to foreign lands,
increase in the number of enemies, affliction with many
kind of ailments, antagonism with the king (government),
quarrels with kinsmen etc., if Buddh be associated with the
lord of the Dasha. (Mangal).
~(4I!K)3+(4I!T)3+4E~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P231_B001_01

- 身份：正文
- PDF 页：231
- 偈颂：41-43 1/2
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 41-43 1/2 [present] · PDF page 231

41-43 1/2. Fulfillment of all ambitions, gain of wealth and
grains, recognition by the king (government), acquisition
of a kingdom (attainment of a high position in government),
gain of clothes and ornaments, attachment to many kind of
musical instruments, attainment of the position of a
commander of an army, discussions on Shastras and Puranas
(Vedic scripts), gain of riches to wife and children, and
beneficence of Goddess Lakshmi will be the very auspicious
results if Buddh is in a Kendr or Trikon from the lord of
the Dasha (Mangal), or if Buddh is in his exaltation Rashi.
~(4I6)3+(4I8)3+(4I12)3+4Am~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P231_B002_01

- 身份：正文
- PDF 页：231
- 偈颂：44-45 1/2
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 44-45 1/2 [present] · PDF page 231

44-45 1/2. Effects like defamation, sinful thinking, harsh
speech, danger from thieves, fir,e and the king
(government), quarrels without reason, fear of attacks by
thieves and dacoits (armed robber bands) during travels,
will be derived if Buddh is in the 6th, the 8th, or the
12th from Mangal or is associated with malefics.
~4iL2+4iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P231_B003_01

- 身份：正文
- PDF 页：231
- 偈颂：46-47
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 46-47 [present] · PDF page 231

46-47. There will be a possibility of critical illness in
the Antar Dasha of Buddh if he is Dhan's lord or Yuvati's
lord. Remedial measures to obtain relief from these evil
effects are recitation of Vishnu Sahasranam and giving a
horse in charity.
@3192@
Effects of the Antar Dasha of Ketu in the Dasha of Mangal
~9K+9T+9I3+9I11+9AB+9DB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P231_B004_01

- 身份：正文
- PDF 页：231
- 偈颂：48-49 1/2
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 48-49 1/2 [present] · PDF page 231

48-49 1/2. Beneficence of the king (government), gain of
wealth, little gains of land at the commencement of the
Dasha and substantial later, birth of a son, conferment of
authority by government, gain of cattle, etc., will be the
results in the Antar Dasha of Ketu in the Dasha of Mangal,
if Ketu is in a Kendr, in a Trikon, in Sahaj, or in Labh
Bhava, or if Ketu is associated with or receives a drishti
from benefics.
~9Yy*9X~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P231_B005_01

- 身份：正文
- PDF 页：231
- 偈颂：50-51 1/2
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 50-51 1/2 [present] · PDF page 231

50-51 1/2. Birth of a son, increase in reputation,
beneficence of Goddess Lakshmi, gains of wealth from
employees, attainment of the position of a commander of an
army, friendship with the king (cordial relations with high
government officials), performance of oblations, gains of
clothes and ornaments, etc. will be the beneficial effects,
if Ketu is  a Yog Karak and is endowed with strength.
(Ketu assumes the role of a Yog Karak if he is yuti
with a Yog Karak grah (lord of a Kendr and a Trikon)).
~(9I6)3+(9I8)3+(9I12)3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P231_B006_01

- 身份：正文
- PDF 页：231
- 偈颂：52-54
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 52-54 [present] · PDF page 231

52-54. Effects like quarrels, tooth trouble, distress from
thieves and tigers, fever, dysentery, leprosy, and distress
to wife and children, etc., will be experienced if Ketu is
in the 6th, the 8th, or the 12th from the lord of the Dasha
(Mangal).
~9I2+9I7~
If Ketu is in Dhan or in Yuvati Bhava, there will be
diseases, disgrace, agony and loss of wealth.
@3162@
Effects of the Antar Dasha of Shukr in the Dasha of Mangal
~6K+6E+6O+6iL1+6iL5+6iL9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P232_B001_01

- 身份：正文
- PDF 页：232
- 偈颂：55-56 1/2
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 55-56 1/2 [present] · PDF page 232

55-56 1/2. Effects like acquisition of a kingdom
(attainment of a high position in government), great
enjoyment and comfort of luxuries, gain of elephants,
horses, clothes, etc., will be derived in the Antar Dasha
of Shukr in the Dasha of Mangal, if Shukr is in a Kendr to
Lagn, if Shukr is in his exaltation Rashi, or in his own
Rashi, or if Shukr is Lagn's lord, Putr's lord, or Dharm's
lord.
~6rL1~
If Shukr is related to Lagn's lord, there will be happiness
to wife and children, opulence and glory, and increased
good fortune.
~(6I5)3+(6I9)3+(6I11)3+(6I2)3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P232_B002_01

- 身份：正文
- PDF 页：232
- 偈颂：57-60
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 57-60 [present] · PDF page 232

57-60. Gain of property, celebrations on the birth of a
son, gain of wealth from the employer, acquisition of a
house, land, villages, etc. by the beneficence of the
sovereign, will be the results if Shukr is in the 5th, the
9th, the 11th, or the 2nd from the lord of the Dasha
(Mangal). In the last part of the Dasha there will be
functions of songs and dances and bathing in holy water.
~6AL10+6YL10~
If Shukr is connected with or related to the lord of Karm
Bhava, there will be construction of wells, reservoirs,
etc., and performance of religious, charitable and pious
deeds.
~(6I6)3+(6I8)3+(6I12)3+6Am~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P232_B003_01

- 身份：正文
- PDF 页：232
- 偈颂：61-62
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 61-62 [present] · PDF page 232

61-62. There will be sorrows, physical distress, loss of
wealth, danger from thieves, and the king (government),
dissensions in the family, distress to wife and children
and destruction of cattle, if Shukr be in the 6th, the 8th
or the 12th from the lord of the Dasha (Mangal) or be
associated with malefics.
~6iL2+6iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P232_B004_01

- 身份：正文
- PDF 页：232
- 偈颂：63
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 63 [present] · PDF page 232

63. If Shukr be the lord of the 2nd or the 7th, there will
be pains in the body in his Antar Dasha. For regaining good
health, the remedial measure to be adopted is giving a cow
or female buffalo in charity.
@3112@
Effects of the Antar Dasha of Surya in the Dasha of Mangal
~1E+1O+1K+1T+1I11*1YL10*1YL11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P232_B005_01

- 身份：正文
- PDF 页：232
- 偈颂：64-66
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 64-66 [present] · PDF page 232

64-66. Effects like acquisition of conveyances, gain of
reputation, birth of a son, growth of wealth, amicable
atmosphere in the family, sound health, potency,
recognition by the the king (government), extraordinary
profits in business, and audience with the king (meeting
with high officials of the government), etc., will be
experienced in the Antar Dasha of Surya in the Dasha of
Mangal, if Surya is in his Exaltation Rashi, in his own
Rashi, or if Surya is in a Kendr, in a Trikon, or in Labh
Bhava along with Karm's lord and with Labh's lord.
~(1I6)3+(1I8)3+(1I12)3+1Am~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P233_B001_01

- 身份：正文
- PDF 页：233
- 偈颂：67-67 1/2
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 67-67 1/2 [present] · PDF page 233

67-67 1/2. Distress to the body, agony, failure in
ventures, possibilities of suffering from troubles in the
forehead, fever, dysentery, etc., will be the effects, if
Surya is in the 6th, the 8th, or the 12th from the lord of
the Dasha (Mangal) or if Surya is associated with malefics.
~1iL2+1iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P233_B002_01

- 身份：正文
- PDF 页：233
- 偈颂：68-69
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 68-69 [present] · PDF page 233

68-69. There will be attacks of fever, danger from snakes
and poison and distress to son if Surya be the lord of the
2nd or the 7th. The remedial measure to gain good health
and wealth is to perform worship of Surya in the prescribed
manner.
@3122@
Effects of the Antar Dasha of Chandr in the Dasha of
Mangal
~2E+2O+2K+2I9*2YL9+2I4*2YL4+2I10*2YL10+2I1*2YL1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P233_B003_01

- 身份：正文
- PDF 页：233
- 偈颂：70-73
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 70-73 [present] · PDF page 233

70-73. Acquisition of more kingdom(promotion to a higher
position in government), gain of perfumes, clothes,
construction of reservoirs, shelters for cows, etc.,
celebrations of auspicious functions like marriage, etc.,
happiness to wife and children, good relations with
parents, acquisition of property by the beneficence of the
sovereign, success in the desired projects, will be the
effects in the Antar Dasha of Chandr in the Dasha of Mangal
if Chandr is in her Exaltation Rashi or in her own Rashi,
or in a Kendr, or in Dharm, or in Bandhu, or in Karm Bhava,
or in Lagn along with the lords of those bhavas.
~2W**2E+2O+2K+2I9*2YL9+2I4*2YL4+2I10*2YL10+2I1*2YL1~
The good effects will be realized in full if Chandr is
waxing.
~2w**2E+2O+2K+2I9*2YL9+2I4*2YL4+2I10*2YL10+2I1*2YL1~
Waning Chandr will reduce the impact of the effects to some
extent.
~2d+2e+2I6+2I8+2I12+(2I6)3+(2I8)3+(2I12)3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P233_B004_01

- 身份：正文
- PDF 页：233
- 偈颂：74-76
- 标题路径：CHAPTER 54 Effects of Antar Dashas in the Dashas of Mangal › @3132@ Effects of Antar Dashas of Mangal in the Dasha of Mangal ~3K+3I5+3I9+3I11+3I3+3I2+3AL1~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Antar Dashas in the Dashas of Mangal · Sloka 74-76 [present] · PDF page 233

74-76. The effects like death, distress to wife and
children loss of lands, wealth and cattle, and danger of a
war, etc., will be experienced, if Chandr is in his
Debilitation Rashi, or if Chandr is in his enemy Rashi, or
if Chandr is in Ari, in Randhr, or in Vyaya Bhava from Lagn
of from the lord of the Dasha (Mangal).
~2iL2+2iL7~
There will be the possibility of premature death, distress
to the body and mental agony, if Chandr is Dhan's lord, or
if Chandr is Yuvati's lord.
The remedial measures to be adopted to obtain relief from
the above evil effects, are recitation of mantras of the
Goddess Durga and the Goddess Lakshmi.
