# 第 47 章：Effects of Dashas

- 来源：BPHS 97 章版
- 原始卡片：28 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P195_B003_01

- 身份：正文
- PDF 页：195
- 偈颂：1
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 1 [present] · PDF page 195

1. Maitreya said: O Maharishi Parashar! You have told me
about the different kinds of Dashas. Now, be kind enough to
enlighten me with the effects of Dashas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P195_B004_01

- 身份：正文
- PDF 页：195
- 偈颂：2
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 2 [present] · PDF page 195

2. Maharishi Parashar replied: O Brahmin! There are two
kinds of effects of Dashas: general and distinctive. The
natural characteristics of the grahas cause the general
effects and the distinctive effects are realized by their
placements, etc..

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P195_B005_01

- 身份：正文
- PDF 页：195
- 偈颂：3-4
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 3-4 [present] · PDF page 195

3-4. The effects of the Dashas of the grahas are in
accordance with their strength. The effects of a grah in
the first Dreshkan are realized at the commencement of the
Dasha. The grah in the second Dreshkan makes its effects
felt in the middle of the Dasha. The effects of the grah in
the third Dreshkan are experienced at the end of the Dasha.
If the grah is retrograde the effects would be in the
reverse order, that is, the effects of such a grah in the
3rd Dreshkan are felt at the commencement of the Dasha and
that of the retrograde grahas in the first Dreshkan are
experienced at the end of the Dasha. The Dasha effects of
Rahu and Ketu who are always retrograde will always be
realized in the reverse order described above.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P195_B006_01

- 身份：正文
- PDF 页：195
- 偈颂：5-6
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 5-6 [present] · PDF page 195

5-6. The effects are favourable if, at the commencement of
the Dasha, the Dasha lord is in Lagn, in his exaltation
Rashi , in his own Rashi, or in a Shant Rashi. The results
are unfavorable if the Dasha lord is in Ari, Randhr, or
Vyaya Bhava, in his debilitation Rashi, or in a inimical
Rashi.
@11  @
Effects of the Vimshottari Dasha of Surya
~1O+1E+1K+1I11+1AL9*1V+1AL10*1V~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P195_B007_01

- 身份：正文
- PDF 页：195
- 偈颂：7-11
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 7-11 [present] · PDF page 195

7-11. During the Dasha of Surya, there is acquisition of
wealth, great felicity and honours from the Government, if
at the time of birth Surya is in his own Rashi, in his
exaltation Rashi, in a Kendr, in Labh Bhava, be associated
with the lord of Dharm or the lord of Karm Bhava and strong
in his Varg.
~1YL5~
The native will be blessed with a son (children) if Surya
is with the lord of Putr Bhava.
~1AL2~
The native will acquire elephants and other kinds of wealth
if Surya is associated with the lord of Dhan Bhava.
~1AL4~
The native will enjoy comforts of conveyances if Surya is
associated with the lord of Bandhu Bhava. He attains a high
position like that of Army Chief by the beneficence of the
king (Government) and enjoys all kinds of happiness. Thus,
during the Dasha of a strong (and favourable) Surya there
are acquisitions of clothes, agricultural products, wealth,
honours,  conveyances, etc..
~1d+1I6*1w+1I8*1w+1I12*1w+1Am+1AL6+1AL8+1AL12~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P196_B001_01

- 身份：正文
- PDF 页：196
- 偈颂：12-15
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 12-15 [present] · PDF page 196

12-15. During the Dasha of Surya there will be a anxieties,
loss of wealth, punishment from Government, defamation,
opposition by kinsmen, distress to father, auspicious
happenings at home, distress to paternal and maternal
uncles, etc., anxiety and inimical relations with other
people for no reason whatsoever, should Surya be in his
Rashi of debilitation (Tula), be weak in Ari, Randhr, or
Vyaya Bhava, or be associated with malefic grahas or with
the lord of Ari, Randhr, or Vyaya Bhava.
~1d+1I6*1w+1I8*1w+1I12*1w+1Am+1AL6+1AL8+1AL12**1DB~
There will be some favourable effects at times if in the
above situations Surya receives a drishti from benefic
grahas.
~1d+1I6*1w+1I8*1w+1I12*1w+1Am+1AL6+1AL8+1AL12**1Dm~
The effects will always be unfavourable when malefic grahas
give a drishti to Surya.
@21  @
Effects of the Vimshottari Dasha of Chandr

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P196_B002_01

- 身份：正文
- PDF 页：196
- 偈颂：16-22
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 16-22 [present] · PDF page 196

16-22. 0 Brahmin! After describing the effects of the Dasha
of Surya in brief, I will now come to the effects
Vimshottari Dasha of Chandr.
~2E+2O+2K+2I11+2I9+2I5+2AB+2DB+2P*2AL9+2P*2AL4~
During the Dasha of Chandr from its commencement to the
end, there will be opulence and glory, good fortune, gain
of wealth, auspicious functions at home, dawn of fortune,
attainment of a high position in Government (acquisition of
Kingdom), acquisition of conveyances, clothes, birth of
children, and acquisition of cattle, should Chandr be in
her exaltation rashi, in her own rashi, in Kendr, in Labh,
Dharm, or Putr Bhava, be associated with or receives a
drishti from benefics, be fully powerful and is associated
with the lord of Karm, Dharm, or Bandhu Bhava.
~2I2**2AB+2DB+2P*2AL9+2P*2AL4~
There will be extra ordinary gains of wealth and luxuries
if such a Chandr is in Dhan Bhava.
~2d+2w~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P196_B003_01

- 身份：正文
- PDF 页：196
- 偈颂：23-26
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 23-26 [present] · PDF page 196

23-26. Should Chandr be waning or in her debilitation
rashi, there will be loss of wealth in her Dasha.
~2I3~
If Chandr is in Sahaj Bhava, there will be happiness off
and on.
~2Am~
If Chandr is associated with malefics there will be idiocy,
mental tension, trouble from employees and mother, and loss
of wealth.
~2w*2I6+2w*2I8+2w*2I12+2w*2Am~
If, waning Chandr is in Ari, Randhr, or Vyaya Bhava or is
associated with malefics, there will be inimical relations
with Government, loss of wealth, distress to mother, and
similar evil effects.
~2S*2I6+2S*2I8+2S*2I12~
If a strong Chandr is placed in Ari, Randhr, or Vyaya Bhava
there will be troubles and good times off and on.
@31  @
Effects of the Vimshottari Dasha of Mangal
~3E+3M+3O+3K+3I11*3X+3I2*3X+3NB*3AB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P197_B001_01

- 身份：正文
- PDF 页：197
- 偈颂：27-32
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 27-32 [present] · PDF page 197

27-32. If Mangal is in his exaltation rashi, in his
Multrikon, in his own rashi, in Kendr, in Labh or Dhan Bhava
with strength, in a benefic Amsh (Navamsh) and is associated
with a benefic, there will be during his Dasha acquisition
of kingdom (attainment of a high administrative or political
position in Government, gain of wealth and land, recognition
by Government), gain of wealth from foreign countries, and
acquisition of conveyances and ornaments.
There will also be happiness and good relations with
co-borns.
~3X*3K+3X*3I3~
If Mangal with strength is placed in a Kendr or in Sahaj
Bhava, there will be gain of wealth through valour, victory
over enemies, happiness from wife and children. There will,
however, be a possibility of some unfavourable effects at
the end of the Dasha.
~3d+3v+3I6+3I8+3I12+3Am+3Dm~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P197_B002_01

- 身份：正文
- PDF 页：197
- 偈颂：33
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 33 [present] · PDF page 197

33. If Mangal is in his debilitation rashi, weak, in an
inauspicious Bhava (Ari, Randhr, or Vyaya) or is associated
with or receives a drishti from malefics there will be, in
his Dasha, loss of wealth, distress and similar unfavourable
effects.
@81  @
Effects of the Vimshottari Dasha of Rahu

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P197_B003_01

- 身份：正文
- PDF 页：197
- 偈颂：34-391/2
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 34-391/2 [present] · PDF page 197

34-391/2. In order to clarify the effects of the Dasha of
Rahu, I shall first mention the exaltation and debilitation
rashis of Rahu and Ketu. The exaltation rashi of Rahu is
Vrishabh. The exaltation rashi of Ketu is Vrischik. The
Multrikonas of Rahu and Ketu are Mithun and Dhanu
respectively. The own rashis of Rahu and Ketu are Kumbh and
Vrischik in that order. Some sages have expressed the view
that Kanya is the own rashi of Rahu and Meen is the own
rashi of Ketu.
~8E+8O+8M~
Should Rahu be in his exaltation rashi, etc., there will
be, during the Dasha of Rahu, great happiness from
acquisition of wealth, agricultural products, etc.,
acquisition of conveyances with the help of friends and
Government, construction of a new house, birth of sons
(children), religious inclinations, recognition from
Government of foreign countries, and gain of wealth,
clothes, etc..
~8AB+8DB+8Z**8K+8I11+8I3~
If Rahu be associated with or receives a drishti from
benefics, be in a benefic Rashi and be in Tanu, Bandhu,
Yuvati, Karm, Labh, or Sahaj Bhava, there will be during
his Dasha all kinds of comforts by the beneficence of the
Government, acquisition of wealth through a foreign
Government or sovereign, and felicity at home.
~8I8+8I12~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P198_B001_01

- 身份：正文
- PDF 页：198
- 偈颂：40-43
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 40-43 [present] · PDF page 198

40-43. If Rahu is in Randhr or Vyaya Bhava, there will be
during his Dasha all kinds of troubles and distress.
~8Am+8Ak+8d~
If Rahu is associated with a malefic or a Marak (killer)
grah or is in his  debilitation rashi (Vrischik), there
will be loss of position, destruction of his residential
house, mental agony, trouble to wife and children and
misfortune of getting bad food. There will be loss of wealth
at the commencement of the Dasha, some relief and gain of
wealth in his own country, and distress and anxieties during
the last portion of the Dasha.
@51  @
Effects of the Vimshottari Dasha of Guru

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P198_B002_01

- 身份：正文
- PDF 页：198
- 偈颂：44
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 44 [present] · PDF page 198

44. Now, I am going to describe the effects of the Dasha of
Guru, the great benefic and preceptor of the Gods.
~5E+5O+5M+5I10+5I5+5I9+5NE+5NO~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P198_B003_01

- 身份：正文
- PDF 页：198
- 偈颂：45-48
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 45-48 [present] · PDF page 198

45-48. If Guru is in his exaltation rashi, in his own
rashi, in his Multrikon, in Karm, Putr, or Dharm Bhava, in
his own Navamsh, or in his exalted Navamsh, there will be
during his Dasha: acquisition of kingdom (attainment of a
high political or administrative position in Government),
great felicity, recognition by Government, acquisition of
conveyances and clothes, devotion to deities and Brahmins,
happiness in respect of his wife and children, and success
in the performance of religious sacrifices (oblations).
~5d+5c+5Am+5I6+5I8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P198_B004_01

- 身份：正文
- PDF 页：198
- 偈颂：49-51
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 49-51 [present] · PDF page 198

49-51. If Guru is in his debilitation rashi, combust,
associated with malefics or in Ari or Randhr Bhava, there
will be during his Dasha loss of residential premises,
anxiety, distress to children, loss of cattle and pilgrimage
(visit to religious places). The Dasha will give some
unfavourable effects at its commencement only. During the
later part of the Dasha there will be good effects like gain
of wealth, awards from and recognition by Government.
@71  @
Effects of the Vimshottari Dasha of Shani

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P198_B005_01

- 身份：正文
- PDF 页：198
- 偈颂：52
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 52 [present] · PDF page 198

52. Now, I will describe to you the effects of the Dasha of
Shani who is considered the vilest and most inferior
amongst all the grahas.
~7E+7O+7M+7F+7NE+7NO**7I3+7I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P198_B006_01

- 身份：正文
- PDF 页：198
- 偈颂：53-56
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 53-56 [present] · PDF page 198

53-56. If Shani is in his exaltation rashi, in his own
rashi, or in Multrikon or friendly rashi, in his own or
exalted Navamsh and in Sahaj or Labh Bhava, there will be
during his Dasha, recognition by Government, opulence and
glory, name and fame, success in the educational sphere,
acquisition of conveyances and ornaments, etc., gain of
wealth, favours from Government, attainment of a high
position like commander of an army, acquisition of a
kingdom, benevolence of goddess Lakshmi, gain of property
and birth of children.
~7I6+7I8+7I12+7d+7c~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P199_B001_01

- 身份：正文
- PDF 页：199
- 偈颂：57-60
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 57-60 [present] · PDF page 199

57-60. If Shani is in Ari, Randhr, or Vyaya Bhava, in his
debilitation rashi, or combust, there will be during his
Dasha, ill effects from poison, injury from weapons,
separation from father, distress to wife and children,
disaster as a result of displeasure of Government,
imprisonment, etc..
~7AB+7DB+7K+7T+7IR9+7IR12~
If Shani receives a drishti from or is associated with a
benefic, is placed in a Kendr or in a Trikon, in Dhanu or
in Meen, there will be acquisition of a kingdom (attainment
of a high position in Government), conveyances, and clothes.
@41  @
Effects of the Vimshottari Dasha of Buddh

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P199_B002_01

- 身份：正文
- PDF 页：199
- 偈颂：61
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 61 [present] · PDF page 199

61. Now, I am going to describe the effects of the Dasha of
Buddh who is called a Kumar (in his teens) amongst all
grahas.
~4E+4O+4F+4I11+4I5+4I9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P199_B003_01

- 身份：正文
- PDF 页：199
- 偈颂：62-65
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 62-65 [present] · PDF page 199

62-65. If Buddh is in his exaltation rashi, in his own
rashi, in a friendly rashi or in Labh, Putr, or Dharm
Bhava, there will be during his Dasha, acquisition of
wealth, gain of reputation, improvement in knowledge,
benevolence of Government, auspicious functions, happiness
from wife and children, good health, availability of
sweetish preparations, profits in business, etc..
~4DB+4I9+4iL10~
If Buddh receives a drishti from a benefic, is in Dharm
Bhava, or is the  lord of Karm Bhava, the aforesaid
beneficial results will be experienced in full and there
will be great felicity all round.
~4Am~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P199_B004_01

- 身份：正文
- PDF 页：199
- 偈颂：66-70
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 66-70 [present] · PDF page 199

66-70. If Buddh is associated with a malefic, there will
during his Dasha, punishment by Government, inimical
relations with kinsmen, journey to a foreign country,
dependence on others, and the possibility of urinary
troubles.
~4I6+4I8+4I12~
If Buddh is in Ari, Randhr, or Vyaya Bhava, there will be
loss of wealth due to indulgence in lascivious activities,
possibility of suffering from rheumatism and jaundice,
danger of thefts, and malevolence of Government, loss of
land and cattle, etc..
At the commencement of the Dasha of Buddh, there will be
gains of wealth, betterment in the educational sphere,
birth of children and, happiness.
In the middle of the Dasha, there will be recognition from
Government.
The last part of the Dasha will be distressful.
@91  @
Effects of the Vimshottari Dasha of Ketu

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P199_B005_01

- 身份：正文
- PDF 页：199
- 偈颂：71
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 71 [present] · PDF page 199

71. Now, I will tell you about the Dasha of Ketu who is a
headless trunk ('Kabandha') amongst all the grahas.
~9K+9T+9I11+9Z+9E+9O~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P200_B001_01

- 身份：正文
- PDF 页：200
- 偈颂：72-77
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 72-77 [present] · PDF page 200

72-77. If Ketu is in a Kendr,  a Trikon, or in Labh Bhava,
in a benefic rashi, in his exaltation rashi, or in his own
rashi, there will be during his Dasha, cordial relations
with the king (Government), desired headship of a country
or village, comforts of conveyances, happiness from
children, gain from foreign countries, happiness from wife,
and acquisition of cattle.
~9I3+9I6+9I11~
If Ketu is in Sahaj, Ari, or Labh Bhava, there will be in
his Dasha acquisition of a kingdom (attainment of a high
position in Government), good relations with friends and
opportunities for the acquisition of elephants. At the
commencement of the Ketu Dasha, there will be Raj Yog.
During the middle portion of the Dasha, there will be
possibilities of fearfulness and in the last part there
will be sufferings from ailments and journeys to distant
places.
~9I2+9I8+9I12+9Dm~
If Ketu is in Dhan, Randhr, or Vyaya Bhava, or receives a
drishti from a malefic, there will be imprisonment,
destruction of kinsmen and residential premises, and
anxieties, company of menials, and diseases.
@61  @
Effects of the Vimshottari Dasha of Shukr

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P200_B002_01

- 身份：正文
- PDF 页：200
- 偈颂：78
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 78 [present] · PDF page 200

78. Now, I will describe the effects of the Dasha of Shukr
who is the incarnate of intoxication, ecstasy delight, and
pride amongst all the grahas.
~6E+6O+6K+6T~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P200_B003_01

- 身份：正文
- PDF 页：200
- 偈颂：79-82
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 79-82 [present] · PDF page 200

79-82. If Shukr is in his exaltation rashi, in his own
rashi, or in a Kendr or a Trikon, there will be during his
Dasha, acquisition of fancy clothes, ornaments,
conveyances, cattle and land, etc., availability of sweet
preparations every day, recognition from the sovereign,
luxurious functions of songs and dances, etc., by the
benevolence of Goddess Lakshmi.
~6M~
If Shukr is in his Multrikon, during his Dasha, there will
definitely be acquisition of a kingdom (attainment of a
high position in Government), acquisition of a house, birth
of children and grandchildren, celebration of marriage in
the family, attainment of a high position like the
commander of an army, visits of friends, recovery of lost
wealth, property, or kingdom (reinstatement in a high
position).
~6I6+6I8+6I12~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P200_B004_01

- 身份：正文
- PDF 页：200
- 偈颂：83-841/2
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 83-841/2 [present] · PDF page 200

83-841/2. If Shukr is in Ari, Randhr, or Vyaya Bhava, there
will be during his Dasha, inimical relations with kinsmen,
distress to wife, losses in business, destruction of
cattle, and separation from relations.
~6I4*6L9+6I4*6L10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P200_B005_01

- 身份：正文
- PDF 页：200
- 偈颂：85-87
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 85-87 [present] · PDF page 200

85-87. If Shukr is in Bandhu, as lord of Dharm or Karm
Bhava, there will be during his Dasha, attainment of
rulership of a country or village, performance of pious
deeds like building of reservoirs and temples, and giving
grains, etc., in charity, availability of sweet
preparations every day, vigor in work, name and fame, and
happiness from wife and children.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P201_B001_01

- 身份：正文
- PDF 页：201
- 偈颂：88-89
- 标题路径：CHAPTER 47 Effects of Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas · Sloka 88-89 [present] · PDF page 201

88-89. Similar are the effects of Shukr in his sub-periods.
~6iL2+6iL7~
If Shukr is lord of Dhan or Yuvati Bhava (two Marak
Bhavas), there will be during his Dasha, physical pains and
troubles. To get alleviation from those troubles the native
should perform Shatarudriya or Mrityunjaya Japa in the
prescribed manner and give in charity a cow or female
buffalo.
