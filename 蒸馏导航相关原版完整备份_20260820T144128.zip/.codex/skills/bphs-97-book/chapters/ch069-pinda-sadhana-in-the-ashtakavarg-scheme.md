# 第 69 章：Pinda Sadhana in the Ashtakavarg Scheme

- 来源：BPHS 97 章版
- 原始卡片：2 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P307_B002_01

- 身份：正文
- PDF 页：307
- 偈颂：1-4
- 标题路径：CHAPTER 69 Pinda Sadhana in the Ashtakavarg Scheme
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Pinda Sadhana in the Ashtakavarg Scheme · Sloka 1-4 [present] · PDF page 307

1-4. The Sage said: O Brahmin! after completing the Trikon
and Ekadhipatya Shodhana in the Ashtakavargas of all the
grahas, the rectified number should be multiplied by the
measure of the rashi. If there be any grah in any rashi, the
rectified number should be multiplied by the measure of the
grah also. Then after multiplying the rectified number of
each rashi, the products should be added up. The total so
arrived at will be Pinda of that grah. The multiples of
rashis are: 10 for Vrishabh and Simh, 8 for Mithun and
Vrischik, 7 for Mesh and Tul, 6 for Makar and Kanya. The
multipliers of the remaining rashis are the same as their
numbers, namely 4 for Kark, 9 for Dhanu, 11 for Kumbh and 12
for Meen. The multipliers of grahas are; 10 for Guru, 3 for
Mangal, 7 for Shukr, 6 for Buddh, Surya, Chandr, and Shani.
Rashiman Chakr
-----------------------------------------------------------
Mesh Vris Mith Kark Simh Kany Tula Vrsk Dhan Maka Kumb Mina
-----------------------------------------------------------
7    10   8    4    10   6    7    8    9    5    11   12
-----------------------------------------------------------
Grahman Chakr
(Multipliers of grahas)
Graha       Surya  Chandr  Mangal  Buddh  Guru  Shukr Shani
-----------------------------------------------------------
Multiplier    5      5       8      5     10     7     5
-----------------------------------------------------------

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P307_B002_02

- 身份：正文
- PDF 页：307
- 偈颂：1-4
- 标题路径：CHAPTER 69 Pinda Sadhana in the Ashtakavarg Scheme
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Pinda Sadhana in the Ashtakavarg Scheme · Sloka 1-4 [present] · PDF page 307

1-4. The Sage said: O Brahmin! after completing the Trikon
and Ekadhipatya Shodhana in the Ashtakavargas of all the
grahas, the rectified number should be multiplied by the
measure of the rashi. If there be any grah in any rashi, the
rectified number should be multiplied by the measure of the
grah also. Then after multiplying the rectified number of
each rashi, the products should be added up. The total so
arrived at will be Pinda of that grah. The multiples of
rashis are: 10 for Vrishabh and Simh, 8 for Mithun and
Vrischik, 7 for Mesh and Tul, 6 for Makar and Kanya. The
multipliers of the remaining rashis are the same as their
numbers, namely 4 for Kark, 9 for Dhanu, 11 for Kumbh and 12
for Meen. The multipliers of grahas are; 10 for Guru, 3 for
Mangal, 7 for Shukr, 6 for Buddh, Surya, Chandr, and Shani.
Rashiman Chakr
-----------------------------------------------------------
Mesh Vris Mith Kark Simh Kany Tula Vrsk Dhan Maka Kumb Mina
-----------------------------------------------------------
7    10   8    4    10   6    7    8    9    5    11   12
-----------------------------------------------------------
Grahman Chakr
(Multipliers of grahas)
Graha       Surya  Chandr  Mangal  Buddh  Guru  Shukr Shani
-----------------------------------------------------------
Multiplier    5      5       8      5     10     7     5
-----------------------------------------------------------
