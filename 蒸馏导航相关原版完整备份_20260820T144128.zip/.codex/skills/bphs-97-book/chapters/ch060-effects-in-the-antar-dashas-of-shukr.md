# 第 60 章：Effects in the Antar Dashas of Shukr

- 来源：BPHS 97 章版
- 原始卡片：34 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P266_B002_01

- 身份：正文
- PDF 页：266
- 偈颂：—
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka unknown [unknown] · PDF page 266 · page_block BPHS_PL9_CHAP_97_P266_B002

@6162@
Effects of the Antar Dasha of Shukr in the Dasha of Shukr
~6X*6K+6X*6T+6X*6I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P266_B003_01

- 身份：正文
- PDF 页：266
- 偈颂：1-2 1/2
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 1-2 1/2 [present] · PDF page 266

1-2 1/2. Effects like gain of wealth, cattle, etc., through
Brahmins, celebrations in connection with the birth of a
son, well-being, recognition from the king (government),
acquisition of a kingdom (attainment of a high position in
government), will be derived in the Antar Dasha of Shukr in
his own Dasha, if Shukr is in a Kendr, in a Trikon, or in
Labh Bhava, and if Shukr is endowed with strength.
~6E+6O+6NE+6NO~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P266_B004_01

- 身份：正文
- PDF 页：266
- 偈颂：3-6
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 3-6 [present] · PDF page 266

3-6. Construction of a new house, availability of sweet
preparations, happiness to wife and children, companionship
with a friend, giving grains, etc. in charity, beneficence
of the king (government), gain of clothes, conveyances and
ornaments, success in business, increase in the number of
cattle, gain of garments by performing journeys in the
western direction, etc.,will be the results, if Shukr is in
his Exaltation Rashi, in his own Rashi, or if Shukr is in
his exalted or own Navamsh.
~6AB+6DB**6NF+6I3+6I6+6I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P266_B005_01

- 身份：正文
- PDF 页：266
- 偈颂：7-8
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 7-8 [present] · PDF page 266

7-8. There will be acquisition of a kingdom (high position
in government), enthusiasm, beneficence of the king
(government), well-being in the family, increase in the
number of wives, children, and wealth, etc., if Shukr is
associated with or receives a drishti from a benefic and is
in a friendly Navamsh, in Sahaj, in Ari, or in Labh Bhava.
~6Am+6Dm**6Ia~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P266_B006_01

- 身份：正文
- PDF 页：266
- 偈颂：9-10
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 9-10 [present] · PDF page 266

9-10. Danger from thieves, etc., antagonistic relations
with government officials, destruction of friends and
kinsmen, distress to wife and children, may be expected if
Shukr is associated with or receives a drishti from a
malefic in Ari, in Randhr, or in Vyaya Bhava.
~6L2+6L7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P266_B007_01

- 身份：正文
- PDF 页：266
- 偈颂：11
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 11 [present] · PDF page 266

11. There will be fear of death, if Shukr is Dhan's lord or
Yuvati's lord.
Remedial measures to obtain relief from the above evil
effects are, Durga Path and giving a cow in charity.
@6112@
Effects of the Antar Dasha of Surya in the Dasha of Shukr
~-1E*-1d~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P266_B008_01

- 身份：正文
- PDF 页：266
- 偈颂：12
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 12 [present] · PDF page 266

12. There will be a period of agony, wrath of the king
(government), quarrels with the coparceners, etc., in the
Antar Dasha of Surya in the Dasha of Shukr if Surya is in
any Rashi other than his Exaltation Rashi or his
Debilitation Rashi.
(This verse does not appear to be correctly worded
because Surya does produce good effects in a position other
than exaltation or debilitation. The position is correctly
stated in the Chowkambh version of this verse)
~1E+1O+1K+1T+1I2+1I11+(1I!K)6+(1I!T)6+(1I2)6+(1I11)6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P267_B001_01

- 身份：正文
- PDF 页：267
- 偈颂：13-15
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 13-15 [present] · PDF page 267

13-15. Effects like acquisition of a kingdom (attainment of
a high position in government), and wealth, happiness from
wife and children, happiness from employer, meeting with
friends, happiness from parents, marriage, name and fame,
betterment of fortune, birth of a son, etc., will be
experienced if Surya is in his Exaltation Rashi, in his own
Rashi, in a Kendr in a Trikon, in Dhan, or Labh Bhava (from
Lagn), or in Kendr, in a Trikon, in the 2nd or in the 11th
from the lord of he Dasha (Shukr).
~1I6+1I8+1I12+1d+1e~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P267_B002_01

- 身份：正文
- PDF 页：267
- 偈颂：16-18
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 16-18 [present] · PDF page 267

16-18. Distress, agony, distress to members of the family,
harsh language, distress to father, loss of kinsmen, wrath
of the king (government), danger at home, many diseases,
destruction of agricultural production, etc., will be the
results, if Surya is in Ari, Randhr, or in Vyaya Bhava, or
if Surya is in his Debilitation Rashi or in an enemy's
Rashi.
~1L2+1L7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P267_B003_01

- 身份：正文
- PDF 页：267
- 偈颂：19-20
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 19-20 [present] · PDF page 267

19-20. There will be evil influence of the grahas if Surya
is Dhan's lord or Yuvati's lord.
Worship of Surya is the remedial measure to obtain relief
from the above evil effects.
@6122@
Effects of the Antar Dasha of Chandr in the Dasha of Shukr
~2E+2O+2AL9+2AB+2AL10+2K+2T+2I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P267_B004_01

- 身份：正文
- PDF 页：267
- 偈颂：21-22
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 21-22 [present] · PDF page 267

21-22. Effects like gain of wealth, conveyances, clothes by
the beneficence of the king, happiness in the family, great
opulence and glory, devotion to deities and Brahmins, will
be derived in the Antar Dasha of Chandr in the Dasha of
Shukr if Chandr is in her Exaltation Rashi, or in her own
Rashi, or if Chandr is associated with the lord of Dharm
Bhava, benefics, or with Karm's lord, or if Chandr is in a
Kendr, in a Trikon or in Labh Bhava.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P267_B005_01

- 身份：正文
- PDF 页：267
- 偈颂：23-23 1/2
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 23-23 1/2 [present] · PDF page 267

23-23 1/2. In the above circumstances, there will also be
association with musicians and men of learning, and
receiving of decorations, gain of cows, buffaloes and other
cattle, abnormal profits in business, dining with brothers,
etc..
~2d+2c+2I6+2I8+2I12+(2I6)6+(2I8)6+(2I12)6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P267_B006_01

- 身份：正文
- PDF 页：267
- 偈颂：24-26 1/2
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 24-26 1/2 [present] · PDF page 267

24-26 1/2. Loss of wealth, fears, physical distress, agony,
wrath of the king (government), journeys to foreign lands
or pilgrimage, distress to wife and children and separation
from kinsmen, will be the results if Chandr is in her
Debilitation Rashi, if Chandr is combust, or if Chandr is
in Ari, in Randhr, or in Vyaya Bhava, or if Chandr is in
the 6th, in the 8th, or in the 12th from the lord of the
Dasha (Shukr).
~(2I!K)6+(2I!T)6+(2I3)6+(2I11)6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P268_B001_01

- 身份：正文
- PDF 页：268
- 偈颂：27-29
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 27-29 [present] · PDF page 268

27-29. There will be sovereignty over a province or village
by the beneficence of the king (government), clothes, etc.,
construction of a reservoir, increase in wealth, etc., if
Chandr is in a Kendr, or in a Trikon, or in the 3rd or in
the 11th from the lord of the Dasha (Shukr). There will be
physical fitness at the commencement of the Antar Dasha and
physical distress in its last portion.
@6132@
Effects of the Antar Dasha of Mangal in the Dasha of Shukr
~3K+3T+3I11+3E+3O+3AL1+3AL9+3AL10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P268_B002_01

- 身份：正文
- PDF 页：268
- 偈颂：30-31 1/2
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 30-31 1/2 [present] · PDF page 268

30-31 1/2. Effects like acquisition of kingdom (attainment
of a high position in government), property, clothes,
ornaments, land, and desired objects, will be derived in
the Antar Dasha of Mangal in the Dasha of Shukr, if Mangal
is in a Kendr, or in a Trikon, or in Labh Bhava, or if
Mangal is in his Exaltation Rashi, or if Mangal is in one
of his own rashis, or if Mangal is associated with the
Lagn's lord, Dharm's lord, or Karm's lord.
~3I6+3I12+3I8+(3I6)6+(3I12)6+(3I8)6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P268_B003_01

- 身份：正文
- PDF 页：268
- 偈颂：32-34
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 32-34 [present] · PDF page 268

32-34. There will be fever from cold, diseases (like fever)
to parents, loss of position, quarrels, antagonism with the
king (government) and government officials, extravagant
expenditure, etc., if Mangal is in Ari, in Randhr, or in
Vyaya Bhava, or if Mangal is in the 6th, the 8th, or the
12th from the lord of the Dasha (Shukr)
~3iL2+3iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P268_B004_01

- 身份：正文
- PDF 页：268
- 偈颂：35
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 35 [present] · PDF page 268

35. Physical distress, losses in profession, loss of
village, land, etc., will be the results, if Mangal is the
Dhan's lord or Yuvati's lord.
@6182@
Effects of the Antar Dasha of Rahu in the Dasha of Shukr
~8K+8T+8I11+8E+8O+8AB+8DB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P268_B005_01

- 身份：正文
- PDF 页：268
- 偈颂：36-37 1/2
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 36-37 1/2 [present] · PDF page 268

36-37 1/2. Effects like great enjoyment, gain of wealth,
visits of friends, successful journeys, gain of cattle and
land, etc., will be derived in the Antar Dasha of Rahu in
the Dasha of Shukr, if Rahu is in a Kendr, or in a Trikon,
or in Labh Bhava, or if Rahu is in his Exaltation Rashi, or
if Rahu is in his own Rashi, or if Rahu is associated with
or receives a drishti from benefics.
~8I3+8I6+8I10+8I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P268_B006_01

- 身份：正文
- PDF 页：268
- 偈颂：38-39
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 38-39 [present] · PDF page 268

38-39. Enjoyments, destruction of enemy, enthusiasm, and
beneficence of the king, will be the results, if Rahu is in
Sahaj, or in Ari, or in Karm, or in Labh Bhava. Good
effects will be experienced up to 5 months from the
commencement of the Antar Dasha, but at the end of the
Dasha there will be danger from fevers and indigestion.
~8I3+8I6+8I10+8I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P268_B007_01

- 身份：正文
- PDF 页：268
- 偈颂：40-41 1/2
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 40-41 1/2 [present] · PDF page 268

40-41 1/2. In the above circumstances except for obstacles
in ventures and journeys, and worries, there will be all
enjoyment like those of a king. Journeys to foreign lands
will bring, success and the person will return safely to
his homeland. There will also be blessings from Brahmins
and auspicious results consequent to visits to holy
places.
~8Am*(8I8)6+8Am*(8I12)6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P269_B001_01

- 身份：正文
- PDF 页：269
- 偈颂：42-44
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 42-44 [present] · PDF page 269

42-44. There will be inauspicious effects on oneself and
one's parents and antagonism with people, if Rahu be
associated with a malefic in the 8th or in the 12th from
the lord of the Dasha (Shukr).
~8iL2+8iL7~
Physical distress will be caused if Rahu is Dhan's lord or
Yuvati's lord.
The remedial measure to obtain relief from the above evil
effects is Mrityunjaya Japa.
@6152@
Effects of the Antar Dasha of Guru in the Dasha of Shukr
~5E+5O+5K+5T+(5I!K)6+(5I!T)6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P269_B002_01

- 身份：正文
- PDF 页：269
- 偈颂：45-48
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 45-48 [present] · PDF page 269

45-48. Effects like recovery of the lost kingdom
(reinstatement in a high position in government),
acquisition of desired grains, clothes, and property, etc.,
reverence from one's friend and the king (government), and
gain of wealth, recognition from the king, good reputation,
gain of conveyances, association with an employer and with
men of learning, industriousness in the study of Shastras,
birth of a son, satisfaction, visits of close friends,
happiness to parents and son, etc., will be derived in the
Antar Dasha of Guru in the Dasha of Shukr, if Guru is in
his Exaltation Rashi, in his own Rashi, or in a Kendr, or
in a Trikon to Lagn or to the lord of the Dasha (Shukr).
~5Am*(5I6)6+5Am*(5I8)6+5Am*(5I12)6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P269_B003_01

- 身份：正文
- PDF 页：269
- 偈颂：49-50
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 49-50 [present] · PDF page 269

49-50. There will be danger from the king (government), and
from thieves, distress to oneself and to kinsmen, quarrels,
mental agony, loss of position, going away to foreign
lands, and danger of many kinds of diseases, if Guru is in
the 6th, in the 8th, or in the 12th from the lord of the
Dasha (Shukr) and be associated with a malefic.
~5iL2+5iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P269_B004_01

- 身份：正文
- PDF 页：269
- 偈颂：51
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 51 [present] · PDF page 269

51. There will be physical distress if Guru is Dhan's lord
or Yuvati's lord.
The remedial measure to obtain relief from the above evil
effects is Mrityunjaya Japa.
@6172@
Effects of the Antar Dasha of Shani in the Dasha of Shukr
~7E+7O+7K+7T+7NO~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P269_B005_01

- 身份：正文
- PDF 页：269
- 偈颂：52-54
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 52-54 [present] · PDF page 269

52-54. Effects like great enjoyments, visits of friends and
kinsmen, recognition from the king (government), birth of a
daughter, visits to holy places and sacred shrines,
conferment of authority by the king (government), will be
derived in the Antar Dasha of Shani in the Dasha of Shukr,
if Shani is in his Exaltation Rashi, in his own Rashi, in a
Kendr, in a Trikon, or in his own Navamsh.
~7d~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P270_B001_01

- 身份：正文
- PDF 页：270
- 偈颂：55-57
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 55-57 [present] · PDF page 270

55-57. There will be lethargy and more expenditure than
income, if Shani is in his Debilitation Rashi.
~7I8+7I11+7I12+(7I8)6+(7I11)6+(7I12)6~
Many kinds of distresses and troubles at the commencement
of the Antar Dasha, like stress to parents, wife and
children, going away to foreign lands, losses in
profession, destruction of cattle, etc., will be the
results, if Shani is in Randhr, or in Labh, or in Vyaya
Bhava, or if Shani is in the 8th, in the 11th, or in the
12th from the lord of the Dasha (Shukr).
~7iL2+7iL7~
There will be physical distress if Shani is Dhan's lord or
Yuvati's lord.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P270_B002_01

- 身份：正文
- PDF 页：270
- 偈颂：58-59
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 58-59 [present] · PDF page 270

58-59. The remedial measures to obtain relief from the
above evil effects, are Havan with sesame seeds ('Til'),
Mrityunjaya Japa, Durga Saptashati Path (by oneself or
through a Brahmin).
@6142@
Effects of the Antar Dasha of Buddh in the Dasha of Shukr
~4K+4T+4I11+(4I!K)6+(4I!T)6+(4I11)6+4E+4O~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P270_B003_01

- 身份：正文
- PDF 页：270
- 偈颂：60-62
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 60-62 [present] · PDF page 270

60-62. Effects like dawn of fortune, birth of a son, gain
of wealth through judgement of court, listening to stories
from the Puranas, association with persons competent in
poetry, etc., visits of close friends, happiness from
employer, availability of sweetish preparations, etc., will
be derived in the Antar Dasha of Buddh in the Dasha of
Shukr, if Buddh is in a Kendr, or in a Trikon, or in Labh
Bhava (or from the lord of the Dasha Shukr), or if Buddh is
in his Exaltation Rashi, or if Buddh is in his own Rashi.
~(4I6)6+(4I8)6+(4I12)6+4v+4Am~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P270_B004_01

- 身份：正文
- PDF 页：270
- 偈颂：63-65
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 63-65 [present] · PDF page 270

63-65. If Buddh is in the 6th, in the 8th, or in the 12th
from the lord of Dasha (Shukr), or if Buddh is weak, or if
Buddh is assocated with a malefic, there will be agony, loss
of cattle, residence in other peoples houses, and losses in
business. There will be some good effects at the
commencement, moderate in the middle portion, and distress
from fever, etc., at the end of the Antar Dasha.
~4iL2+4iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P270_B005_01

- 身份：正文
- PDF 页：270
- 偈颂：66
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 66 [present] · PDF page 270

66. There will be physical distress if Buddh is Dhan's lord
or Yuvati's lord.
The remedial measure to obtain relief from the above evil
effects, is the recitation of Vishnu Sahasranam.
@6192@
Effects of the Antar Dasha of Ketu in the Dasha of Shukr
~9E+9O+9ry~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P270_B006_01

- 身份：正文
- PDF 页：270
- 偈颂：67-68
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 67-68 [present] · PDF page 270

67-68. Auspicious effects like availability of sweetish
preparations, abnormal gains in profession and increase in
cattle wealth, will be derived from the very commencement
of the Antar Dasha of Ketu in the Dasha of Shukr, if Ketu
is in his Exaltation Rashi, or in his own Rashi, or if Ketu
is related to a Yog Karak Grah or if Ketu is possessed of
positional strength.
(It is not laid down anywhere in which bhava Ketu
does get positional strength).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P271_B001_01

- 身份：正文
- PDF 页：271
- 偈颂：69-69 1/2
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 69-69 1/2 [present] · PDF page 271

69-69 1/2. In the above circumstances there will be
definite victory in war at the end of the Antar Dasha.
Moderate results will be experienced in the middle portion
of the Antar Dasha, and  sometimes there will also be the
feeling of distress.
~(9I8)6+(9I12)6+9Am~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P271_B002_01

- 身份：正文
- PDF 页：271
- 偈颂：70-72
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 70-72 [present] · PDF page 271

70-72. There will be danger from snakes, thieves, and
wounds, loss of power of thinking, headache, agony,
quarrels without any cause or reason, diabetes, excessive
expenditure, antagonism with wife and children, going away
to foreign land, loss in ventures, if Ketu is in the 8th or
in the 12th from the lord of the Dasha (Shukr), or if Ketu
is associated with a malefic.
~9iL2+9iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P271_B003_01

- 身份：正文
- PDF 页：271
- 偈颂：73-74
- 标题路径：CHAPTER 60 Effects in the Antar Dashas of Shukr › @6162@ Effects of the Antar Dasha of Shukr in the Dasha of Shukr ~6X*6K+6X*6T+6X*6I11~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas of Shukr · Sloka 73-74 [present] · PDF page 271

73-74. There will be physical distress if Ketu is Dhan's
lord or Yuvati's lord.
The remedial measures to obtain relief from the above
effects are Mrityunjaya Japa and giving a goat in charity.
Remedial measures for appeasing Shukr will also prove
beneficial.
