# 第 27 章：Evaluation Of Strengths

- 来源：BPHS 97 章版
- 原始卡片：44 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P084_B002_01

- 身份：正文
- PDF 页：84
- 偈颂：—
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka unknown [unknown] · PDF page 84 · page_block BPHS_PL9_CHAP_97_P084_B002

Shad Bal consists of the following:

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P084_B003_01

- 身份：正文
- PDF 页：84
- 偈颂：1
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 1 [present] · PDF page 84

1. Sthan Bal (or positional strength);

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P084_B004_01

- 身份：正文
- PDF 页：84
- 偈颂：2
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 2 [present] · PDF page 84

2. Dig Bal (or directional strength);

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P084_B005_01

- 身份：正文
- PDF 页：84
- 偈颂：3
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 3 [present] · PDF page 84

3. Kaal Bal (Temporal Strength) inclusive of Ayan Bal (or
equinoctial strength);

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P084_B006_01

- 身份：正文
- PDF 页：84
- 偈颂：4
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 4 [present] · PDF page 84

4. Chesht Bal (or motional strength);

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P084_B007_01

- 身份：正文
- PDF 页：84
- 偈颂：5
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 5 [present] · PDF page 84

5. Naisargika Bal (or natural strength);

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P084_B008_01

- 身份：正文
- PDF 页：84
- 偈颂：6
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 6 [present] · PDF page 84

6. Drik Bal (or aspectual strength).
These strengths are computed for the seven grahas from
Surya to Shani. The nodes are not considered.
Sthan Bal comprises of the following considerations:

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P084_B009_01

- 身份：正文
- PDF 页：84
- 偈颂：1
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 1 [present] · PDF page 84

1. Uchch Bal (or exaltation strength)

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P084_B010_01

- 身份：正文
- PDF 页：84
- 偈颂：2
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 2 [present] · PDF page 84

2. Sapt Vargaj Bal (or strength accruing out of positions
in Rashi, Hora, Dreshkan, Saptamsh, Navamsh,
Dvadashamsh, and Trimshamsh).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P084_B011_01

- 身份：正文
- PDF 页：84
- 偈颂：3
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 3 [present] · PDF page 84

3. Ojhayugmarashiamsh Bal (strength acquired by placement
in odd or even rashi and in odd or even Navamsh).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P084_B012_01

- 身份：正文
- PDF 页：84
- 偈颂：4
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 4 [present] · PDF page 84

4. Kendradi Bal (due to placement in Kon, or Panaphara, or
Apoklima Bhava).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P084_B013_01

- 身份：正文
- PDF 页：84
- 偈颂：5
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 5 [present] · PDF page 84

5. Dreshkan Bal (due to placement in first, second or
third decanate of a rashi).
Kaal Bal (or Temporal Strength) comprises of the
following sub divisions:
l) Nathonnata Bal (diurnal and nocturnal strengths).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P084_B014_01

- 身份：正文
- PDF 页：84
- 偈颂：2
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 2 [present] · PDF page 84

2) Paksh Bal (Paksh=fortnight).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P084_B015_01

- 身份：正文
- PDF 页：84
- 偈颂：3
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 3 [present] · PDF page 84

3) Tribhag Bal (strength due to day/night being made in 3
parts)

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P084_B016_01

- 身份：正文
- PDF 页：84
- 偈颂：4
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 4 [present] · PDF page 84

4) Varsh, Maas, Dina, and Hora Bal (Varsh = astrological
year, Maas = month, Dina = week day, and
Hora = planetary hour).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P084_B017_01

- 身份：正文
- PDF 页：84
- 偈颂：5
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 5 [present] · PDF page 84

5) Ayan Bal (equinoctural strength)

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P084_B018_01

- 身份：正文
- PDF 页：84
- 偈颂：6
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 6 [present] · PDF page 84

6) Yudhdh Bal (strength due to partaking in war between
grahas)
{strexs}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P085_B001_01

- 身份：正文
- PDF 页：85
- 偈颂：1-1 1/2
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 1-1 1/2 [present] · PDF page 85

1-1 1/2. Sthan Bal (up to sloka 6) Firstly Uchch Bal: Now,
about the strengths by classes positional, temporal, etc..
(Firstly, Uchch Bal forming part of positional strength or
Sthan Bal). Deduct from the longitude of the grah its
(deep) debilitation point. If the sum is less than 6
rashis, consider it as it is; if it exceeds 6 rashis,
deduct the same from 12 rashis. The sum so got be converted
into degrees, etc., and divided by 3 which is the grah's
Uchch Bal (or exaltation strength) in Virupas.
{strsap}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P085_B002_01

- 身份：正文
- PDF 页：85
- 偈颂：2-4
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 2-4 [present] · PDF page 85

2-4. Sapt Vargaj Bal: If a grah is in its Mooltrikon Rashi,
it gets 45 Virupas, in Svasth Rashi, 30 Virupas, in
Pramudit Rashi 20 Virupas, in Shant Rashi 15 Virupas, in
Din Rashi 10 Virupas, in Duhkhit Rashi 4 Virupas, and in
Khal Rashi 2 Virupas. Similarly, these values occur for the
other 6 divisional occupations, viz. Hora, Dreshkan,
Saptamsh, Navamsh, Dvadashamsh, and Trimshamsh. When all
these are added together the grah's  Sapt Vargaj Bal
emerges.
{strojh}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P085_B003_01

- 身份：正文
- PDF 页：85
- 偈颂：4 1/2
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 4 1/2 [present] · PDF page 85

4 1/2. Ojhayugmarashiamsh Bal: Each of Shukr and Chandr in
even rashis and others in odd rashis acquire a quarter of
Rupa (i.e. 15 Virupas). These are applicable to such
Navamshas also.
{strken}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P085_B004_01

- 身份：正文
- PDF 页：85
- 偈颂：5
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 5 [present] · PDF page 85

5. Kendradi Bal: A grah in a Kon gets full strength, while
one in Panaphara Bhava gets half, and the one in Apoklima
Bhava gets a quarter (of Rupa) as Kendradi Bal.
{strdre}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P085_B005_01

- 身份：正文
- PDF 页：85
- 偈颂：6
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 6 [present] · PDF page 85

6. Dreshkan Bal: Male, female, and hermaphrodite grahas
respectively get a quarter Rupa according to placements in
the first, second and third decanates.
{strdig}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P085_B006_01

- 身份：正文
- PDF 页：85
- 偈颂：7-7 1/2
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 7-7 1/2 [present] · PDF page 85

7-7 1/2. Dig Bal (or Directional Strength): Deduct Bandhu
Bhava (i.e. Nadir) from the longitudes of Surya and Mangal;
Yuvati Bhava (i.e. descendant) from that of Guru and Buddh;
Karm Bhava (i.e. meridian) from that of Shukr and Chandr;
and lastly Lagn from that of Shani. If the sum is above 180
degrees deduct the sum from 360. The sum arrived in either
way be divided by 3 which will be Dig Bal (or Directional
Strength ) of the grah.
{strnat}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P085_B007_01

- 身份：正文
- PDF 页：85
- 偈颂：8-9
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 8-9 [present] · PDF page 85

8-9. Kaal Bal (or Temporal Strength) (up to sloka 17):
Firstly, Nathonnata Bal:
Find out the difference between midnight and the apparent
birth time which is called Unnata. Deduct Unnata from 30
ghatis to obtain Nata. Double the Nata in ghatis which will
indicate identical Nata Bal for Chandr, Mangal, and Shani.
Deduct the Nata from 60 to know the Unnata Bal of Surya,
Guru, and Shukr. Buddh, irrespective of day and night, gets
full Nathonnata Bal (i.e. 1 Rupa or 60 Virupas).
{strpak}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P085_B008_01

- 身份：正文
- PDF 页：85
- 偈颂：10-11
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 10-11 [present] · PDF page 85

10-11. Paksh Bal: Deduct from Chandr's longitude that of
Surya. If the sum exceeds 6 rashis, deduct the same from

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P086_B001_01

- 身份：正文
- PDF 页：86
- 偈颂：12
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 12 [present] · PDF page 86

12. The product so obtained be converted into degrees,
etc., and divided by 3 which will indicate the Paksh Bal of
each of the benefic grahas. The Paksh Bal of benefic should
be deducted from 60 which will go to each malefic as Paksh
Bal.
{strtri}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P086_B002_01

- 身份：正文
- PDF 页：86
- 偈颂：12
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 12 [present] · PDF page 86

12. Tribagh Bal: One Rupa is obtained by Buddh (if birth
is) in the first one third part of day time, by Surya in
the second one third part of the day and by Shani in the
last third part of the day. Similarly, Chandr, Shukr, and
Mangal get full Bal (of one Rupa) in the first, second, and
last one third parts of the night. Guru gets this Bal at
all times.
{strvar}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P087_B001_01

- 身份：正文
- PDF 页：87
- 偈颂：13
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 13 [present] · PDF page 87

13. Varsh - Maas - Dina - Hora Bal:
15, 30, 45,  and 60 Virupas are in order given to Varsh
lord, Maas lord, Dina lord, and Hora lord. Naisargika
Bal (or natural strength) has already been explained.
(The Varsh lord is the lord of the day on which the
astrological year of birth starts. To calculate this we
first need the number of days past from the beginning of
Creation, the Ahargan. According to late Rev. Ebenezer
Burgess, who translated Surya Siddhanta in English, as on
January 1, 1860, the number of days past from the beginning
of Creation are 714,404,108,573.
Divide the number of days past from the day of Creation
till the day of birth by 60. Reject remainder and multiply
the quotient by 3. Increase the post-multiplied product by
1 and divide by 7. The remainder will indicate the week day
on which the astrological year giving birth to the native
opened. Remainder 1 indicates Sunday, 2 indicates Monday,
and so on and so forth.
Maas lord: Divide the same Ahargan by 30 and the quotient
(devoid of remainder) indicates months passed from Creation
to birth. The completed months be multiplied by 2 and
increased by 1. The latter sum should be divided by 7 and
the remainder indicates on which day the birth month began.
Continuing with the same case, we divide 65295 by 30.
Quotient is 2176. This sum multiplied by 2 and increased by
1 denotes 4353. Dividing 4353 by 7, we get a remainder of 6
denoting Friday. That is, the month of birth began on
Friday and the Maas Bal goes to Shukr, the lord of Friday.
Dina lord: Though the week day of birth can be known from
ephemeris or perpetual calendars, we better adopt the
method prescribed which will confirm if the Ahargan
followed is correct or is otherwise. The number of days as
arrived above indicating Ahargan be divided by 7 and the
remainder will indicate the week day of birth.
Hora Bal: Hora means planetary hour. Each day from sunrise
to sunrise is divided into 24 equal parts of one hour or
2.5 ghatikas. These Horas are ruled by the 7 grahas from
Surya to Shani. The first Hora of the day is ruled by the
lord of the week day. The 2nd one is ruled by the lord of
the 6th week day counted from the first ruler. The 3rd Hora
is ruled by the lord of the 6th week day counted from the
2nd Hora lord. Similarly, it proceeds in the same manner
till the first Hora of the next day is taken over by the
lord of that day himself. Whichever grah rules the birth
Hora gets the Hora Bal. Horas are to be calculated for mean
local time and not standard time of births).
{strnai}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P087_B001_02

- 身份：正文
- PDF 页：87
- 偈颂：13
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 13 [present] · PDF page 87

13. Varsh - Maas - Dina - Hora Bal:
15, 30, 45,  and 60 Virupas are in order given to Varsh
lord, Maas lord, Dina lord, and Hora lord. Naisargika
Bal (or natural strength) has already been explained.
(The Varsh lord is the lord of the day on which the
astrological year of birth starts. To calculate this we
first need the number of days past from the beginning of
Creation, the Ahargan. According to late Rev. Ebenezer
Burgess, who translated Surya Siddhanta in English, as on
January 1, 1860, the number of days past from the beginning
of Creation are 714,404,108,573.
Divide the number of days past from the day of Creation
till the day of birth by 60. Reject remainder and multiply
the quotient by 3. Increase the post-multiplied product by
1 and divide by 7. The remainder will indicate the week day
on which the astrological year giving birth to the native
opened. Remainder 1 indicates Sunday, 2 indicates Monday,
and so on and so forth.
Maas lord: Divide the same Ahargan by 30 and the quotient
(devoid of remainder) indicates months passed from Creation
to birth. The completed months be multiplied by 2 and
increased by 1. The latter sum should be divided by 7 and
the remainder indicates on which day the birth month began.
Continuing with the same case, we divide 65295 by 30.
Quotient is 2176. This sum multiplied by 2 and increased by
1 denotes 4353. Dividing 4353 by 7, we get a remainder of 6
denoting Friday. That is, the month of birth began on
Friday and the Maas Bal goes to Shukr, the lord of Friday.
Dina lord: Though the week day of birth can be known from
ephemeris or perpetual calendars, we better adopt the
method prescribed which will confirm if the Ahargan
followed is correct or is otherwise. The number of days as
arrived above indicating Ahargan be divided by 7 and the
remainder will indicate the week day of birth.
Hora Bal: Hora means planetary hour. Each day from sunrise
to sunrise is divided into 24 equal parts of one hour or
2.5 ghatikas. These Horas are ruled by the 7 grahas from
Surya to Shani. The first Hora of the day is ruled by the
lord of the week day. The 2nd one is ruled by the lord of
the 6th week day counted from the first ruler. The 3rd Hora
is ruled by the lord of the 6th week day counted from the
2nd Hora lord. Similarly, it proceeds in the same manner
till the first Hora of the next day is taken over by the
lord of that day himself. Whichever grah rules the birth
Hora gets the Hora Bal. Horas are to be calculated for mean
local time and not standard time of births).
{strnai}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P087_B001_03

- 身份：正文
- PDF 页：87
- 偈颂：13
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 13 [present] · PDF page 87

13. Varsh - Maas - Dina - Hora Bal:
15, 30, 45,  and 60 Virupas are in order given to Varsh
lord, Maas lord, Dina lord, and Hora lord. Naisargika
Bal (or natural strength) has already been explained.
(The Varsh lord is the lord of the day on which the
astrological year of birth starts. To calculate this we
first need the number of days past from the beginning of
Creation, the Ahargan. According to late Rev. Ebenezer
Burgess, who translated Surya Siddhanta in English, as on
January 1, 1860, the number of days past from the beginning
of Creation are 714,404,108,573.
Divide the number of days past from the day of Creation
till the day of birth by 60. Reject remainder and multiply
the quotient by 3. Increase the post-multiplied product by
1 and divide by 7. The remainder will indicate the week day
on which the astrological year giving birth to the native
opened. Remainder 1 indicates Sunday, 2 indicates Monday,
and so on and so forth.
Maas lord: Divide the same Ahargan by 30 and the quotient
(devoid of remainder) indicates months passed from Creation
to birth. The completed months be multiplied by 2 and
increased by 1. The latter sum should be divided by 7 and
the remainder indicates on which day the birth month began.
Continuing with the same case, we divide 65295 by 30.
Quotient is 2176. This sum multiplied by 2 and increased by
1 denotes 4353. Dividing 4353 by 7, we get a remainder of 6
denoting Friday. That is, the month of birth began on
Friday and the Maas Bal goes to Shukr, the lord of Friday.
Dina lord: Though the week day of birth can be known from
ephemeris or perpetual calendars, we better adopt the
method prescribed which will confirm if the Ahargan
followed is correct or is otherwise. The number of days as
arrived above indicating Ahargan be divided by 7 and the
remainder will indicate the week day of birth.
Hora Bal: Hora means planetary hour. Each day from sunrise
to sunrise is divided into 24 equal parts of one hour or
2.5 ghatikas. These Horas are ruled by the 7 grahas from
Surya to Shani. The first Hora of the day is ruled by the
lord of the week day. The 2nd one is ruled by the lord of
the 6th week day counted from the first ruler. The 3rd Hora
is ruled by the lord of the 6th week day counted from the
2nd Hora lord. Similarly, it proceeds in the same manner
till the first Hora of the next day is taken over by the
lord of that day himself. Whichever grah rules the birth
Hora gets the Hora Bal. Horas are to be calculated for mean
local time and not standard time of births).
{strnai}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P087_B002_01

- 身份：正文
- PDF 页：87
- 偈颂：14
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 14 [present] · PDF page 87

14. Naisargika Bal (Natural Strength): Divide one Rupa (or
60 Virupas) by 7 and multiply the resultant product by 1 to
7 separately, which will indicate the Naisargika Bal due to
Shani, Mangal, Buddh, Guru, Shukr, Chandr, and Surya,
respectively.
{straya}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P088_B001_01

- 身份：正文
- PDF 页：88
- 偈颂：15-17
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 15-17 [present] · PDF page 88

15-17. Ayan Bal: 45, 33, and 12 are the Khandas for
calculating Ayan Bal. Add Ayanamsh to the grah (for which
Ayan Bal is required) and find out the Bhuja (distance from
the nearest equinox). Add the figure corresponding to the
rashi (of the Bhuja) to the Bhuja. The degrees, etc., of
the Bhuja (devoid of rashi) should be multiplied by the
figure corresponding to the highest of the left out Khandas
and divided by 30. Add the resultant product to the sum
obtained earlier. Convert this to rashi, degrees, minutes,
and seconds. If Chandr and Shani are in Tula or ahead add
to this 3 Rashis, and if in Mesh to Kanya reduce from this
3 Rashis. Similarly, it is reverse for Surya, Mangal,
Shukr, and Guru (i.e. addition or deduction in converse).
For Buddh 3 Rashis are always additive. The resultant sum
in Rashi, degrees, and minutes be divided by 3 to get the
Ayan Bal in Rupas.
Notes: Ayan Bal can be found out on the following simple
formula.
23 degrees 27' + Kranti
Ayan Bal = ------------------------    x 60 =
46 degrees 54'
(23 degrees 27' plus or minus Kranti) x 1.2793
The following points have to be remembered in respect of
Krantis. When Chandr or Shani have Southern Kranti, or when
Surya, Mangal, Guru, or Shukr have Northern Kranti, take
plus. In a contrary situation in respect of these 6 grahas,
take minus. As far as Buddh is concerned, it is always plus
whether he has Southern Kranti or Northern Kranti. Krantis
(or declinations) can be ascertained from a standard modern
ephemeris.
Surya's Ayan Bal is again multiplied by 2 whereas for
others the product arrived in Virupas is considered as it
is.
{strche}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P088_B001_02

- 身份：正文
- PDF 页：88
- 偈颂：15-17
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 15-17 [present] · PDF page 88

15-17. Ayan Bal: 45, 33, and 12 are the Khandas for
calculating Ayan Bal. Add Ayanamsh to the grah (for which
Ayan Bal is required) and find out the Bhuja (distance from
the nearest equinox). Add the figure corresponding to the
rashi (of the Bhuja) to the Bhuja. The degrees, etc., of
the Bhuja (devoid of rashi) should be multiplied by the
figure corresponding to the highest of the left out Khandas
and divided by 30. Add the resultant product to the sum
obtained earlier. Convert this to rashi, degrees, minutes,
and seconds. If Chandr and Shani are in Tula or ahead add
to this 3 Rashis, and if in Mesh to Kanya reduce from this
3 Rashis. Similarly, it is reverse for Surya, Mangal,
Shukr, and Guru (i.e. addition or deduction in converse).
For Buddh 3 Rashis are always additive. The resultant sum
in Rashi, degrees, and minutes be divided by 3 to get the
Ayan Bal in Rupas.
Notes: Ayan Bal can be found out on the following simple
formula.
23 degrees 27' + Kranti
Ayan Bal = ------------------------    x 60 =
46 degrees 54'
(23 degrees 27' plus or minus Kranti) x 1.2793
The following points have to be remembered in respect of
Krantis. When Chandr or Shani have Southern Kranti, or when
Surya, Mangal, Guru, or Shukr have Northern Kranti, take
plus. In a contrary situation in respect of these 6 grahas,
take minus. As far as Buddh is concerned, it is always plus
whether he has Southern Kranti or Northern Kranti. Krantis
(or declinations) can be ascertained from a standard modern
ephemeris.
Surya's Ayan Bal is again multiplied by 2 whereas for
others the product arrived in Virupas is considered as it
is.
{strche}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P088_B002_01

- 身份：正文
- PDF 页：88
- 偈颂：18
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 18 [present] · PDF page 88

18. Motional Strength for Surya and Chandr: Surya's Chesht
Bal (or motional strength) will correspond to his Ayan Bal.
Chandr's Paksh Bal will itself be her Chesht Bal.
{strdri}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P088_B003_01

- 身份：正文
- PDF 页：88
- 偈颂：19
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 19 [present] · PDF page 88

19. Drik Bal  (Strength of Drishti): Reduce one fourth of
the Drishti Pinda if a grah receives malefic drishtis and
add a fourth if it receives a drishti from a benefic. Super
add the entire drishti of Buddh and Guru to get the net
strength of a grah.
{strwar}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P088_B004_01

- 身份：正文
- PDF 页：88
- 偈颂：20
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 20 [present] · PDF page 88

20. War Between Grahas: Should there be a war between the
starry grahas (i.e. between 2 grahas from Mangal to Shani,
in a given Janm Kundali), the difference between the Shad
Balas of the two should be added to the victor's Shad Bal
and deducted from the Shad Bal of the vanquished.
{strmot}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P089_B001_01

- 身份：正文
- PDF 页：89
- 偈颂：21-23
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 21-23 [present] · PDF page 89

21-23. Motions of Grahas (Mangal to Shani): Eight kinds of
motions are attributed to grahas. These are Vakr
(retrogression), Anuvakr (entering the previous rashi in
retrograde motion), Vikal (devoid of motion or in
stationary position), Mand (somewhat slower motion than
usual), Mandatar (slower than the previous mentioned
motion), Sama (somewhat increasing in motion as against
Mand), Char (faster than Sama) and Atichar (entering next
rashi in accelerated motion). The strengths allotted due to
such 8 motions are: 60, 30, 15, 30, 15, 7.5, 45, and 30.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P089_B002_01

- 身份：正文
- PDF 页：89
- 偈颂：24-25
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 24-25 [present] · PDF page 89

24-25. Motional Strength for Mangal, etc.: Add together the
mean and true longitudes of a grah and divide the one by
two. Reduce this sum from the Seeghroch (or apogee) of the
grah. The resultant product will indicate the Chesht Kendra
(or Seeghr kendra) of the Grah from 12 rashis. The rashi,
degrees ,and minutes so arrived should be converted into
degrees, minutes, etc., and divided by 3 which will denote
the motional strength of the grah. Thus, there are six
sources of strength called Sthan, Bal, Dig Bal, Kaal Bal,
Drik Bal, Chesht Bal, and Naisargika Bal.
{bhabal}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P089_B003_01

- 身份：正文
- PDF 页：89
- 偈颂：26-29
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 26-29 [present] · PDF page 89

26-29. Bhava Balas: Thus, I explained about the strengths
of the grahas. Deduct Yuvati Bhava (longitude of
descendant) from the bhava if the bhava happens to be in
Kanya, Mithun, Tula, Kumbh or the first half of Dhanu.
If Mesh, Vrishabh, Simh, or first half of Makar, or the
second half of Dhanu happen to be the bhava, deduct Bandhu
Bhava (Nadir) from it.
Should the bhava be in Kark or in Vrischik deduct from it
Lagn.
Deduct Karm Bhava (Meridian) from the bhava happening to
fall in Makar second half, or Meen.
Convert the product so obtained (in the respective case)
into degrees etc., and divide by 3 to get Bhava Bal. If the
balance in the process of deducting Nadir, Meridian, Lagn,
or Yuvati exceeds 6 rashis, deduct it again from 12 rashis
before converting into degrees and dividing by 3. The
product after division should be increased by one fourth if
the bhava in question receives a benefic  drishti. If the
bhava receives a malefic drishti one fourth should be
reduced. If Guru or Buddh give a drishti to a bhava, add
that grah's Drik Bal also. And then, super add the strength
acquired by the lord of that bhava. This will be the net
Bhava Bal.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P089_B004_01

- 身份：正文
- PDF 页：89
- 偈颂：30-31
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 30-31 [present] · PDF page 89

30-31. Special Rules: The bhavas occupied by Guru and Buddh
will each get an addition of 1 rupa, while each of the
bhavas occupied by Shani, Mangal, and Surya suffer 1 rupa
reduction. 15 Virupas will have to be added to the bhavas
falling in Seershodaya Rashis if birth happens to be in day
time, to the bhavas falling in dual (or common) rashis if
birth happens to be in twilight and to the bhavas falling
in Prishtodaya Rashis if birth be in night time.
{shareq}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P090_B001_01

- 身份：正文
- PDF 页：90
- 偈颂：32-33
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 32-33 [present] · PDF page 90

32-33. Shad Bal Requirements: 390, 360, 300, 420, 390, 330,
and 300 Virupas are the Shad Bal Pindas needed for Surya,
etc., (up to Shani) to be considered strong. If the
strength exceeds the above mentioned values, the grah is
deemed to be very strong.
(In rupas the minimum Shad Bal requirements of the grahas
are:
Surya = 6.5 Rupas
Chandr= 6.0 Rupas
Mangal = 5.0 Rupas
Buddh = 7.0 Rupas
Guru = 6.5 Rupas
Shukr = 5.5 Rupas
Shani = 5.0 Rupas )
If a Grah has the required Shad Bal, it will prove
favourable to the native by virtue of its strength.
However, Shani's extreme strength will give long life as
well as miseries (grief).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P090_B002_01

- 身份：正文
- PDF 页：90
- 偈颂：34-36
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 34-36 [present] · PDF page 90

34-36. Guru, Buddh, and Surya are strong if each of their
Sthan Bal, Dig Bal, Kaal Bal, Chesht Bal, and Ayan Bal are
respectively 165, 35, 50, 112 and 30 Virupas. The same
required for Chandr and Shukr are 133, 50, 30, 100, and 40.
For Mangal and Shani these are 96, 30, 40, 67, and 20.
Guru, Buddh,   Chandr, Shukr.  Mangal, Shani.
Surya
Sthan Bal       165           133            96
Dig Bal         35            50             30
Kaal Bal        50            30             40
Chesht Bal      112           100            67
Ayan Bal        30            40             20
{bhaeff}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P090_B003_01

- 身份：正文
- PDF 页：90
- 偈颂：37-38
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 37-38 [present] · PDF page 90

37-38. Bhava Effects: O Brahmin, thus the various sources
of strengths be gathered together and effects declared.
Whatever Yogas, or effects, have been stated with respect
to a bhava, will come to pass through the strongest grah.
{eligib}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P090_B004_01

- 身份：正文
- PDF 页：90
- 偈颂：39-40
- 标题路径：CHAPTER 27 Evaluation Of Strengths › Shad Bal consists of the following:
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Evaluation Of Strengths · Sloka 39-40 [present] · PDF page 90

39-40. Eligibility of Issue Fruitful Predictions: O
Maitreya, the words of one who has achieved skill in
mathematics, one who has put in industrious efforts in the
branch of grammar, one who has knowledge of justice, one
who is intelligent, one who has knowledge of geography,
space and time, one who has conquered his senses, one who
is skilfully logical (in estimation), and one who is
favourable to Jyotish, will doubtless be truthful.
