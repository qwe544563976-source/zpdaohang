# 第 90 章：Remedies from Sankranti Birth

- 来源：BPHS 97 章版
- 原始卡片：5 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P364_B002_01

- 身份：正文
- PDF 页：364
- 偈颂：1-2
- 标题路径：CHAPTER 90 Remedies from Sankranti Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from Sankranti Birth · Sloka 1-2 [present] · PDF page 364

1-2. The Sage said: O Brahmin! The names of the Sankranti on
the seven days of the week beginning from Sunday are Ghora,
Dhavankshi, Mahodari, Manda, Mandakini, Mishra, and Rakshasi,
in that order. The person born at the Sankranti (entry of
Surya in a new rashi) is poor and unhappy, but he becomes
well to do and happy if remedial measures are undertaken. I
am now going to describe the remedial measures to nullify
these evil effects.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P364_B003_01

- 身份：正文
- PDF 页：364
- 偈颂：3-6
- 标题路径：CHAPTER 90 Remedies from Sankranti Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from Sankranti Birth · Sloka 3-6 [present] · PDF page 364

3-6. The yagya of the nine grahas should be performed to
obtain relief from the evil effects of the birth at
Sankranti. A clean spot in the eastern part of the house
should be purified by besmearing with cow dung. Then prepare
three separate heaps of the following:
(1) 5 dronas (80 seers) of paddy (sadhi);
(2) 2 1/2 dronas (40 seers) of rice;
(3) 1 1/4 dronas (20 seers) of sesame seeds (til).
On these heaps of grains make a figure of lotus with eight
leaves (Ashtamdhal), and then decorate them with flowers.
After doing this, select and invite a priest who is well
versed in the performance of religious rites and recitation
of mantras.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P364_B004_01

- 身份：正文
- PDF 页：364
- 偈颂：7-18
- 标题路径：CHAPTER 90 Remedies from Sankranti Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from Sankranti Birth · Sloka 7-18 [present] · PDF page 364

7-18. The religious rites are then to be performed in the
following order:
(I) Instal Kalashas without any holes on all the three heaps
and put in each of them water from holy places,
Saptamrattika, Shataushadhi, Panchapallava, and Panchagavya.
Then wrap the Kalashas with pieces of cloth.
(2) Place small earthen pots wrapped with thin cloth on the
Kalashas.
(3) Then instal the idol of Sankranti along with the idol of
Adhideva and Pratyadhideva. (Here, Surya is Adhideva and
Chandr is Pratyadhideva. Their idols should be placed on
either side of the main idols of Sankranti.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P364_B005_01

- 身份：正文
- PDF 页：364
- 偈颂：4
- 标题路径：CHAPTER 90 Remedies from Sankranti Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from Sankranti Birth · Sloka 4 [present] · PDF page 364

4) Two robes may be given as offering to each of the idols.
(5) Perform worship of all the three idols according to the
prescribed procedure. The main idol should be worshipped with
the chanting of 'Trayambakam', 'Yajam hai', etc, the idol of
Surya with mantra 'Ut Surya' and the idol of Chandr with the
mantra 'Apayayashava', etc.. The worship should be performed
with Shodshopchar or Panchopchar as may be possible.
(6) After touching the main idol, Mrityunjaya Japa should be
recited. 1008, 108, or 28 times as may be possible.
(7) Make a small platform in the west of the installed
kalashas, kindle fire on it and perform the prescribed rites.
Then, perform havan 1008, 108, or 28 times with Samidha,
ghrit (ghee), and charu (powder of sesame seeds (til) within
one's means, along with chanting of 'Trayambakam', etc.,
mantra.
(8) Again perform havan, first with the fuel of sesame seeds
along with recitation of Mrityunjaya mantra.
(9) After performing another svistkrita havan, sprinkle the
holy water on the child born and his parents.
(10) Lastly feed as many Brahmins as one can afford. By
performing the remedial rites described above, the evil
effects are nullified and the native and his parents enjoy
happiness.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P364_B005_02

- 身份：正文
- PDF 页：364
- 偈颂：4
- 标题路径：CHAPTER 90 Remedies from Sankranti Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from Sankranti Birth · Sloka 4 [present] · PDF page 364

4) Two robes may be given as offering to each of the idols.
(5) Perform worship of all the three idols according to the
prescribed procedure. The main idol should be worshipped with
the chanting of 'Trayambakam', 'Yajam hai', etc, the idol of
Surya with mantra 'Ut Surya' and the idol of Chandr with the
mantra 'Apayayashava', etc.. The worship should be performed
with Shodshopchar or Panchopchar as may be possible.
(6) After touching the main idol, Mrityunjaya Japa should be
recited. 1008, 108, or 28 times as may be possible.
(7) Make a small platform in the west of the installed
kalashas, kindle fire on it and perform the prescribed rites.
Then, perform havan 1008, 108, or 28 times with Samidha,
ghrit (ghee), and charu (powder of sesame seeds (til) within
one's means, along with chanting of 'Trayambakam', etc.,
mantra.
(8) Again perform havan, first with the fuel of sesame seeds
along with recitation of Mrityunjaya mantra.
(9) After performing another svistkrita havan, sprinkle the
holy water on the child born and his parents.
(10) Lastly feed as many Brahmins as one can afford. By
performing the remedial rites described above, the evil
effects are nullified and the native and his parents enjoy
happiness.
