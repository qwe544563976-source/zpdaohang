# 第 30 章：Upa Pad

- 来源：BPHS 97 章版
- 原始卡片：20 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P097_B002_01

- 身份：正文
- PDF 页：97
- 偈颂：1-6
- 标题路径：CHAPTER 30 Upa Pad
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Upa Pad · Sloka 1-6 [present] · PDF page 97

1-6. 0 Brahmin, now I tell you about Upa Pad, the
auspiciousness of which will confer on the native happiness
from progeny, wife, etc.. The Pad of Lagn (i.e. Arudh Lagn)
as discussed earlier, is (of course) of prime importance.
Upa Pad is calculated for the bhava following the natal
Lagn. This Upa Pad is also called Gaun Pad.
~BILu+LuDB~
O excellent of the Brahmins, if Upa Pad is yuti with or
receives a drishti from a benefic grah, one will obtain
full happiness from progeny and spouse.
~LuIz+LuDm+LuYm~m
Should the Upa Pad be in a malefic's rashi or receives a
drishti from or is yuti with a malefic, one will become an
ascetic and go without a wife.
~LuIz+LuDm+LuYm**LuDB+BILu~
If (in the said circumstances) there be a benefic drishti
(on Upa Pad or the related malefic), or a yuti, deprival of
spouse will not come to pass. In this case, Surya being
exalted or in a friendly rashi, is not a malefic. He is a
malefic if in debilitation or in an enemy's rashi.
Notes: Regarding Upa Pad calculations, there are more than
two views on the same sloka of Maharishi Parashar, or an
identical Sutra from Jaimini. In this text, the word
'Anuchar' is used which denotes "the bhava following the
Lagn at birth. Normally this is Vyaya Bhava.
However, when we study other commentaries on Jaimini (for
example Chaukhambh Hindi edition), we are taught that it is
Vyaya Bhava in the case of an odd rashi ascending, and it
is Dhan Bhava in the case of an even rashi ascending.
Accordingly, the Pad for the 12th or the 2nd from Lagn is
called Upa Pad. In calculating Upa Pad, the rules mentioned
in verses 4 and 5 of the previous chapter be kept in mind.
~LUiZ+BILU+LUDB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P097_B002_02

- 身份：正文
- PDF 页：97
- 偈颂：1-6
- 标题路径：CHAPTER 30 Upa Pad
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Upa Pad · Sloka 1-6 [present] · PDF page 97

1-6. 0 Brahmin, now I tell you about Upa Pad, the
auspiciousness of which will confer on the native happiness
from progeny, wife, etc.. The Pad of Lagn (i.e. Arudh Lagn)
as discussed earlier, is (of course) of prime importance.
Upa Pad is calculated for the bhava following the natal
Lagn. This Upa Pad is also called Gaun Pad.
~BILu+LuDB~
O excellent of the Brahmins, if Upa Pad is yuti with or
receives a drishti from a benefic grah, one will obtain
full happiness from progeny and spouse.
~LuIz+LuDm+LuYm~m
Should the Upa Pad be in a malefic's rashi or receives a
drishti from or is yuti with a malefic, one will become an
ascetic and go without a wife.
~LuIz+LuDm+LuYm**LuDB+BILu~
If (in the said circumstances) there be a benefic drishti
(on Upa Pad or the related malefic), or a yuti, deprival of
spouse will not come to pass. In this case, Surya being
exalted or in a friendly rashi, is not a malefic. He is a
malefic if in debilitation or in an enemy's rashi.
Notes: Regarding Upa Pad calculations, there are more than
two views on the same sloka of Maharishi Parashar, or an
identical Sutra from Jaimini. In this text, the word
'Anuchar' is used which denotes "the bhava following the
Lagn at birth. Normally this is Vyaya Bhava.
However, when we study other commentaries on Jaimini (for
example Chaukhambh Hindi edition), we are taught that it is
Vyaya Bhava in the case of an odd rashi ascending, and it
is Dhan Bhava in the case of an even rashi ascending.
Accordingly, the Pad for the 12th or the 2nd from Lagn is
called Upa Pad. In calculating Upa Pad, the rules mentioned
in verses 4 and 5 of the previous chapter be kept in mind.
~LUiZ+BILU+LUDB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P097_B003_01

- 身份：正文
- PDF 页：97
- 偈颂：7-12
- 标题路径：CHAPTER 30 Upa Pad
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Upa Pad · Sloka 7-12 [present] · PDF page 97

7-12. Effect from the 2nd from Upa Pad: If the 2nd from Upa
Pad is a benefic rashi or receives a drishti from or is
yuti with a benefic, the same good results (as for wife and
sons) will come to pass.
~tILU+.tILU+mILU*.2ILU~n
If there is a grah in the 2nd from Upa Pad in its
debilitation rashi/debilitation amsh or is yuti with a
debilitated, or malefic grah, there will be destruction of
wife.
~EILU+.EILU+&ILU*LUD&~
If the said occupant be in its exaltation rashi, or Navamsh
or receives a drishti from another grah, there will be many
charming and virtuous wives.
~LuiR2~
Oh Brahmin, if Mithun happens to be the 2nd from Upa Pad,
then also there will be many wives.
~(L1O)LU+(L1O)Lu~
O excellent of the Brahmins, if the Upa Pad or the 2nd
there from be occupied by its own lord or if the said lord
is in his other own bhava, the death of wife will be at
advanced age.
~L7O+6O~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P098_B001_01

- 身份：正文
- PDF 页：98
- 偈颂：13-15
- 标题路径：CHAPTER 30 Upa Pad
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Upa Pad · Sloka 13-15 [present] · PDF page 98

13-15. Wife from the 2nd of Upa Pad (up to sloka 22): If a
grah being constant indicator of wife (i.e. the 7th lord,
or Shukr) is in its own bhava, there will be loss of wife
only at a later stage.
~LLuE+L7E+6E~
If the lord of Upa Pad, or the constant significator of
wife is in exaltation, the wife will be from a noble family;
~LLud+L7d+6d~m
reverse will be the case, if he is debilitated (i.e. the
wife will not be from a noble family).
~BILU+LUDB~
O Brahmin, if the 2nd from Upa Pad is related to a benefic,
the wife will be beautiful, fortunate, and virtuous.
~7ILU*7Y8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P098_B002_01

- 身份：正文
- PDF 页：98
- 偈颂：16
- 标题路径：CHAPTER 30 Upa Pad
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Upa Pad · Sloka 16 [present] · PDF page 98

16. Should Shani and Rahu be in the 2nd from Upa Pad, the
native will lose his wife on account of calumny or through
death.
~6ILU*6Y9~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P098_B003_01

- 身份：正文
- PDF 页：98
- 偈颂：17
- 标题路径：CHAPTER 30 Upa Pad
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Upa Pad · Sloka 17 [present] · PDF page 98

17. The native's wife will be troubled by disorder of
blood, leucorrhoea ('Pradar'), etc., if Shukr and Ketu are
in the 2nd from Upa Pad.
~4ILU*4Y9~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P098_B004_01

- 身份：正文
- PDF 页：98
- 偈颂：18
- 标题路径：CHAPTER 30 Upa Pad
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Upa Pad · Sloka 18 [present] · PDF page 98

18. Buddh with Ketu in the 2nd from Upa Pad will cause
breakage of bones
~1ILU*1Y8*1Y7~n
while Rahu, Shani, and Surya will cause distress of bones.
~4ILU*4Y8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P098_B005_01

- 身份：正文
- PDF 页：98
- 偈颂：19-22
- 标题路径：CHAPTER 30 Upa Pad
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Upa Pad · Sloka 19-22 [present] · PDF page 98

19-22. Buddh and Rahu in the 2nd from Upa Pad will give a
stout-bodied wife.
~R3ILU*3ILU*3Y7+R6ILU*3ILU*3Y7**-LUDB*-BILU~n
If the 2nd from Upa Pad happens to be one of Buddh's rashis
and is tenanted by Mangal and Shani, the wife of the native
will suffer from nasal disorders.
~R1ILU*3ILU*3Y7+R8ILU*3ILU*3Y7**-LUDB*-BILU~n
Similarly, a rashi of Mangal becoming the 2nd from Upa Pad
and occupied by Mangal and Shani will cause nasal disorders
to one's wife.
~5ILU*5Y7~n
Guru and Shani will, if be in the 2nd from Upa Pad, cause
disorders of ears, and/or eyes to the wife.
~4ILU*3Y4*-3O*-4O+8ILU*8Y5**-LUDB*-BILU~n
If Buddh and Mangal are placed in the 2nd from Upa Pad
other than their own rashis, or if Rahu is with Guru in the
2nd from Upa Pad, the native's wife will suffer from dental
disorders.
~7ILU*7Y8*7O**-LUDB*-BILU~n
Shani and Rahu together in one of Shani's rashis, which is
the 2nd from Upa Pad, will cause lameness or windy
disorders to the native's wife.
These evils will not come to pass if there happens to be a
yuti with or a drishti from a benefic (or from another
benefic in the case of affliction being caused by a benefic
himself).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P099_B001_01

- 身份：正文
- PDF 页：99
- 偈颂：23-23 1/2
- 标题路径：CHAPTER 30 Upa Pad
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Upa Pad · Sloka 23-23 1/2 [present] · PDF page 99

23-23 1/2. O Brahmin, all these effects be deduced from the
natal Lagn, Lagn Pad, the 7th from Upa Pad, and the lords
there of. So say Narada and others.
~7I9+(7I9)Lp+(7I9)Lu**7Y2*7Y4~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P099_B002_01

- 身份：正文
- PDF 页：99
- 偈颂：25-28
- 标题路径：CHAPTER 30 Upa Pad
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Upa Pad · Sloka 25-28 [present] · PDF page 99

25-28. About Sons: If Shani, Chandr, and Buddh are together
in the 9th from one of the said places (sloka 23), there
will be no son at all
~1I9+(1I9)Lp+(1I9)Lu**1Y5*1Y8~
while Surya, Guru, and Rahu so placed will give a number of
sons.
~2I9+(2I9)Lp+(2I9)Lu~
Chandr so placed will give a son,
~.^I9+(.^I9)Lp+(.^I9)Lu~m
while a mixture of grahas will delay the obtainment of a son.
~1I9+(1I9)Lp+(1I9)Lu**1Y5*1Y8~
The son caused by the yuti of Surya, Guru, and Rahu (as
mentioned above) will be strong, valorous, greatly
successful, and will destroy enemies.
~3I9+(3I9)Lp+(3I9)Lu**7Y3~m
If Mangal and Shani are in the said 9th , there will be no
son, or a son will be obtained by adoption or brother's son
will come in adoption.
In all these cases, odd rashis will yield many sons, while
even rashis will cause only a few.
~R5iLu*R5D2~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P099_B003_01

- 身份：正文
- PDF 页：99
- 偈颂：29-30
- 标题路径：CHAPTER 30 Upa Pad
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Upa Pad · Sloka 29-30 [present] · PDF page 99

29-30. Many Sons and Many Daughters: O Brahmin, if Simh
happens to be Upa Pad and receives a drishti from Chandr,
there will be a limited number of children.
~R6iLu*R5D2~
Similarly, Kanya will cause many daughters.
~(8I3)Lp*8Y7+(8I11)Lp*8Y7~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P099_B004_01

- 身份：正文
- PDF 页：99
- 偈颂：31
- 标题路径：CHAPTER 30 Upa Pad
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Upa Pad · Sloka 31 [present] · PDF page 99

31. Co-born form Lagn Pad (up to sloka 36): Rahu and Shani
in the 3rd or the 11th from Lagn Pad will destroy the
co-born of the native. Rahu and Shani in the 11th will
indicate the destruction of elder brothers and/or sisters,
and in the 3rd younger ones.
~(6I3)Lp+(6I11)Lp+6I8+(6I8)Lp~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P099_B005_01

- 身份：正文
- PDF 页：99
- 偈颂：32
- 标题路径：CHAPTER 30 Upa Pad
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Upa Pad · Sloka 32 [present] · PDF page 99

32. If Shukr is in the 3rd or the 11th from Lagn Pad, there
would have been an abortion to the mother earlier. Same is
the effect if Shukr is in the 8th from natal Lagn, or from
Lagn Pad.
~(2I3)Lp*2Y5*2Y4*2Y3+(2I11)Lp*2Y5*2Y4*2Y3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P100_B001_01

- 身份：正文
- PDF 页：100
- 偈颂：33-36
- 标题路径：CHAPTER 30 Upa Pad
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Upa Pad · Sloka 33-36 [present] · PDF page 100

33-36. These are the effects, O Brahmin, as stated by
Maharishis for the 3rd and the 11th from Lagn Pad. Should
Chandr, Guru, Buddh, and Mangal be in the 3rd or the 11th
from Lagn Pad, there will be many valorous co-born.
~(7I3)Lp*7Y3+(7I11)Lp*7Y3+!3#LpD7*!3#LpD3+!11#LpD7*!11#LpD3~n
Should Shani and Mangal be in the 3rd or the 11th from Lagn
Pad or give drishtis there to, younger and elder co-born
will respectively be destroyed.
~(7I3)Lp+(7I11)Lp~n
If Shani is alone in one of the said bhavas the native will
be spared, while the co-born will die.
~(9I3)Lp+(9I11)Lp~
Ketu in the 3rd or the 11th will give abundant happiness
from one's sisters.
~(mI6)Lp*-(BI6)Lp*-!6#LpDB~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P100_B002_01

- 身份：正文
- PDF 页：100
- 偈颂：37
- 标题路径：CHAPTER 30 Upa Pad
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Upa Pad · Sloka 37 [present] · PDF page 100

37. Other Matters from Lagn Pad (up to sloka 43): If the
6th from Lagn Pad is occupied by a malefic and is bereft of
a yuti with or a drishti from a benefic, the native will be
a thief.
~(8I7)Lp+(8I12)Lp+!7#LpD8+!12#LpD8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P100_B003_01

- 身份：正文
- PDF 页：100
- 偈颂：38
- 标题路径：CHAPTER 30 Upa Pad
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Upa Pad · Sloka 38 [present] · PDF page 100

38. If Rahu is in the 7th or the 12th from Lagn Pad or
gives a drishti to one of the said bhavas, the native will
be endowed with spiritual knowledge and be very fortunate.
~4ILp~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P100_B004_01

- 身份：正文
- PDF 页：100
- 偈颂：39
- 标题路径：CHAPTER 30 Upa Pad
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Upa Pad · Sloka 39 [present] · PDF page 100

39. If Buddh is in Lagn Pad, the native will lord over a
whole country,
~5ILp~
while Guru will make him a knower of all things
~6ILp~
Shukr in this context denotes a poet/speaker.
(Also see  ch. 29, verse 30).
~BILU+(BI2)Lp~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P100_B005_01

- 身份：正文
- PDF 页：100
- 偈颂：40
- 标题路径：CHAPTER 30 Upa Pad
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Upa Pad · Sloka 40 [present] · PDF page 100

40. 0 excellent of the Brahmins, if benefics occupy the 2nd
from  Upa Pad or from Lagn Pad, the native will be endowed
with all kinds of wealth and be intelligent.
~LLUI2*LLUYm~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P100_B006_01

- 身份：正文
- PDF 页：100
- 偈颂：41
- 标题路径：CHAPTER 30 Upa Pad
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Upa Pad · Sloka 41 [present] · PDF page 100

41. One will surely become a thief if the lord of the 2nd
from Upa Pad is in Dhan Bhava, and is there yuti with a
malefic grah.
~(8I2).u~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P100_B007_01

- 身份：正文
- PDF 页：100
- 偈颂：42-43
- 标题路径：CHAPTER 30 Upa Pad
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Upa Pad · Sloka 42-43 [present] · PDF page 100

42-43. 0 Brahmin, if Rahu is in the 2nd from the lord of
the 7th counted from Upa Pad, the native will have long and
projected teeth.
~(9I2).u~n
Ketu in the 2nd from the lord of the 7th counted from Upa
Pad, will cause stammering,
~(7I2).u~n
and Shani in the 2nd form the lord of the 7th counted from
Upa Pad will make one look ugly.
Mixed will be the effects if there are mixed grahas.
