# 第 33 章：Effects of Karakamsh

- 来源：BPHS 97 章版
- 原始卡片：30 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P108_B002_01

- 身份：正文
- PDF 页：108
- 偈颂：1
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 1 [present] · PDF page 108

1. O Brahmin, as laid down by Lord Brahma, I now tell you
about the effects of Karakamsh identical with Mesh etc.
(Karakamsh is the Navamsh occupied by the Atma Karak grah).
~N$IR1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P108_B003_01

- 身份：正文
- PDF 页：108
- 偈颂：2-8
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 2-8 [present] · PDF page 108

2-8. Karakamsh in Various Rashis: If Atma Karak happens to
be in Mesh Navamsh, there will be nuisance from rats and
cats at all times.
~N$IR1*NmY$~n
A malefic joining will further increase the nuisance.
~N$IR2~
Should Atma Karak be in Vrishabh Navamsh, happiness from
quadrupeds will result.
~N$IR3~n
Should Atma Karak be in Mithun Navamsh, the native will be
afflicted by itch, etc..
~N$IR4~n
Should Atma Karak be in Kark Navamsh, there will be fear
from water, etc..
~N$IR5~n
If Atma Karak happens to be in Simh Navamsh, fear will be
from tiger, etc..
~N$IR6~n
If Atma Karak happens to be in Kanya Navamsh, itch,
corpulence, fire, etc., will cause trouble,
~N$IR7~
while if Atma Karak is in Tula Navamsh, he will make one a
trader and skilful in making robes, etc..
~N$IR8~n
Vrischik Navamsh holding Atma Karak will bring troubles
from snakes etc., and also affliction to mother's breasts.
~N$IR9~n
There will be falls from height and conveyances, etc., if
it is in Dhanu Navamsh that is occupied by Atma Karak.
~N$IR10~
Makar Navamsh in this respect denotes gains from water
dwelling beings and conch, pearl, coral, etc..
~N$IR11~
If it is Kumbh Navamsh holding Atma Karak, the native will
construct tanks, etc..
~N$IR12~
And in Meen Navamsh the Atma Karak win grant final
emancipation.
~N$DB~
The drishti of a benefic will remove evils,
~N$Dm~n
while that of a malefic will cause no good.
~NKaDB+N!1DB**NBIKa*-NmIKa*NBI1*-NmI1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P108_B003_02

- 身份：正文
- PDF 页：108
- 偈颂：2-8
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 2-8 [present] · PDF page 108

2-8. Karakamsh in Various Rashis: If Atma Karak happens to
be in Mesh Navamsh, there will be nuisance from rats and
cats at all times.
~N$IR1*NmY$~n
A malefic joining will further increase the nuisance.
~N$IR2~
Should Atma Karak be in Vrishabh Navamsh, happiness from
quadrupeds will result.
~N$IR3~n
Should Atma Karak be in Mithun Navamsh, the native will be
afflicted by itch, etc..
~N$IR4~n
Should Atma Karak be in Kark Navamsh, there will be fear
from water, etc..
~N$IR5~n
If Atma Karak happens to be in Simh Navamsh, fear will be
from tiger, etc..
~N$IR6~n
If Atma Karak happens to be in Kanya Navamsh, itch,
corpulence, fire, etc., will cause trouble,
~N$IR7~
while if Atma Karak is in Tula Navamsh, he will make one a
trader and skilful in making robes, etc..
~N$IR8~n
Vrischik Navamsh holding Atma Karak will bring troubles
from snakes etc., and also affliction to mother's breasts.
~N$IR9~n
There will be falls from height and conveyances, etc., if
it is in Dhanu Navamsh that is occupied by Atma Karak.
~N$IR10~
Makar Navamsh in this respect denotes gains from water
dwelling beings and conch, pearl, coral, etc..
~N$IR11~
If it is Kumbh Navamsh holding Atma Karak, the native will
construct tanks, etc..
~N$IR12~
And in Meen Navamsh the Atma Karak win grant final
emancipation.
~N$DB~
The drishti of a benefic will remove evils,
~N$Dm~n
while that of a malefic will cause no good.
~NKaDB+N!1DB**NBIKa*-NmIKa*NBI1*-NmI1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P109_B001_01

- 身份：正文
- PDF 页：109
- 偈颂：9-11
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 9-11 [present] · PDF page 109

9-11. O Brahmin, if there be only benefics in Karakamsh and
the Navamsh of Lagn and receives a drishti from a
benefic, the native will undoubtedly become a king.
~N(BI!K)Ka*-N(mI!K)Ka+N(BI!T)Ka*-N(mI!T)Ka~
Should the Kendras/Konas from the Karakamsh be occupied by
benefics devoid of malefic association, the native will be
endowed with wealth and learning.
The combination of benefic and malefic influence will in
this context yield mixed results.
If the Upakheta (or Upa Grah, vide ch.32 sloka 5) is in its
exaltation , or own, or friendly rashi, and is devoid of a
drishti from a malefic, the native will go to heaven after
death.
~N$IR1+N$IR2+N$IR4+N$IR7+N$IR8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P109_B002_01

- 身份：正文
- PDF 页：109
- 偈颂：12
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 12 [present] · PDF page 109

12. If the Atma Karak is in the divisions of Chandr, Mangal
or Shukr, the native will go to others wives.
~-N$IR1*-N$IR2*-N$IR4*-N$IR7*-N$IR8~
Otherwise, the contrary will prevail (i.e. the native will
not go to others wives).
~N1IKa~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P109_B003_01

- 身份：正文
- PDF 页：109
- 偈颂：13-18
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 13-18 [present] · PDF page 109

13-18. Effects of Grahas in the Karakamsh: 0 Brahmin, if
Surya is in the Karakamsh, the native will be engaged in
royal assignments.
~N2IKa*2P~
If the full Chandr is there, he will enjoy pleasures and be
a scholar;
~N2IKa*2P*N2D6~
more so if Shukr gives a drishti to the Karakamsh.
~3X*N3IKa~m
If strong Mangal is in Karakamsh, he will use the weapon
spear, will live through fire and be an alchemist.
~4X*N4IKa~
Should strong Buddh be Karakamsh, he will be skilful in
arts and trading, be intelligent and educated.
~N5IKa~
Guru in Karakamsh denotes one doing good acts, endowed with
spiritualism and Vedic learning.
~N6IKa~
One will be endowed with a longevity of 100 years, be
sensuous and will look after state affairs if Shukr is in
Karakamsh.
~N7IKa~
Shani in Karakamsh will give such livelihood as due to the
natives family.
~N8IKa~m
Rahu in Karakamsh denotes a thief, a bowman, a machinery
maker, and a doctor treating poisonous afflictions.
~N9IKa~n
If Ketu be in Karakamsh, one will deal in elephants and be
a thief.
~N8IKa*N1IKa~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P110_B001_01

- 身份：正文
- PDF 页：110
- 偈颂：19-22
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 19-22 [present] · PDF page 110

19-22. Rahu-Surya in Karakamsh: Should Rahu and Surya be in
Karakamsh there will be fear from snakes;
~N8IKa*N1IKa*N1DB~
if a benefic gives a drishti to Rahu-Surya in Karakamsh
there will be no fear,
~N8IKa*N1IKa*N1Dm~n
but a malefic drishti will bring death (through serpents).
~@S1*@S8*N8IKa*N1IKa~
If Rahu and Surya occupy benefic Shad Vargas, being in
Karakamsh, one will be a doctor treating poisonous
afflictions,
~N8IKa*N1IKa*N1D3~n
while the drishti from Mangal on Rahu-Surya in Karakamsh
denotes that the native will burn either his own house or
that of others.
~N8IKa*N1IKa*N1D4~
Buddh's drishti on Rahu-Surya in Karakamsh will not cause
the burning of one's own house of that of others.
~N8Iz*N1Iz*N8IKa*N1IKa*N1D5*-N1D6~m
If Rahu and Surya happen to be in Karakamsh and are in a
malefic's rashi receiving a drishti from Guru, one will burn
a house in one's neigbourhood,                             .
while the drishti of Shukr will not cause such an event.
~N.GIKa*N.GDN2*2P~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P110_B002_01

- 身份：正文
- PDF 页：110
- 偈颂：23-24
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 23-24 [present] · PDF page 110

23-24. Gulik in Karakamsh: Should the full Chandr give a
drishti to Gulik placed in the Karakamsh, the native will
lose his wealth to thieves or will himself be a thief.
~N.GIKa*-N.GD&~n
If Gulik is in Karakamsh but does not receive a drishti
from others, one will administer poison to others or will
himself die of poisoning.
~.GIKa*.GDN4~
Buddh's drishti in this context will give large testicles.
~9IKa*mDN9~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P110_B003_01

- 身份：正文
- PDF 页：110
- 偈颂：25-29
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 25-29 [present] · PDF page 110

25-29. Effects of Drishtis on Ketu in Karakamsh: If Ketu is
in Karakamsh receiving a drishti from a malefic, ones ears
will be severed or one will suffer from diseases of the
ears.
~9IKa*9DN6~
Shukr giving a drishti to Ketu in Karakamsh denotes one
initiated into religions order.
~9IKa*9DN4*9DN7~n
One will be devoid of strength if Buddh and Shani give a
drishti to Ketu in Karakamsh.
~9IKa*9DN4*9DN6~n
If Buddh and Shukr give a drishti to Ketu in Karakamsh, one
will be the son of a female slave or of a female remarried.
~9IKa*9DN7~n
With Shani's drishti on Ketu in Karakamsh one will perform
penance or be a servant or will be a pseudo-ascetic;
~9IKa*9DN6*9DN1~
Shukr and Surya together giving a drishti to Ketu in
Karakamsh will make one serve the king. Thus, O Brahmin,
are told briefly the effects of Karakamsh.
~KaiR12+KaiR7+KaiR1+KaiR6~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P111_B001_01

- 身份：正文
- PDF 页：111
- 偈颂：30-31
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 30-31 [present] · PDF page 111

30-31. Effects of the 2nd from Karakamsh: If the 2nd from
Karakamsh falls in the divisions of Shukr or Mangal,
one will be addicted to others' wives,
~KaiR12+KaiR7+KaiR1+KaiR6**(!2D6)Ka+(!2D3)Ka~n
and if Shukr or Mangal give a drishti to the 2nd from
Karakamsh, the tendency will last till death.
~KaiR12+KaiR7+KaiR1+KaiR6**(9I2)Ka~
If Ketu is the 2nd from Karakamsh in a division of Shukr
or Mangal, addiction to other's wives will not prevail,
~KaiR12+KaiR7+KaiR1+KaiR6**(5I2)Ka~n
while the position of Guru will cause such an evil (i.e.
addiction to other's wives).
~(8I2)Ka~n
Rahu in the 2nd from Karakamsh will destroy wealth.
~(mI3)Ka~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P111_B002_01

- 身份：正文
- PDF 页：111
- 偈颂：32
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 32 [present] · PDF page 111

32. Effects of the 3rd from Karakamsh: A malefic in the 3rd
from Karakamsh will make one valorous,
~(BI3)Ka~n
while a benefic in the 3rd from Karakamsh will make one
timid.
~(6I4)Ka*(2I4)Ka+(NEI4)Ka~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P111_B003_01

- 身份：正文
- PDF 页：111
- 偈颂：33-35
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 33-35 [present] · PDF page 111

33-35. Effects of the 4th from Karakamsh: If the 4th from
Karakamsh happens to be occupied by Shukr and Chandr, one
will own large buildings, like palaces, etc.. Similar, is
the effect of an exalted grah in the said 4th.
~(8I4)Ka*(7I4)Ka~
A house made of stones is denoted by the occupation of the
4th from Karakamsh by Rahu and Shani.
~(3I4)Ka*(9I4)Ka~
Mangal and Ketu in the 4th from Karakamsh indicate a house
made of bricks,
~(5I4)Ka~
while Guru in the 4th from Karakamsh denotes a house made
of wood.
~(1I4)Ka~
Surya in the 4th from Karakamsh will give a house of
grass.
~(2I4)Ka~
If Chandr is in the 4th from Karakamsh, one will have union
with his wife in an uncompounded house.
~(8I5)Ka*(3I5)Ka~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P112_B001_01

- 身份：正文
- PDF 页：112
- 偈颂：36-40
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 36-40 [present] · PDF page 112

36-40. Effects of the 5th from Karakamsh :If Rahu and
Mangal are in the 5th from Karakamsh, one will suffer from
a pulmonary consumption,
~(8I5)Ka*(3I5)Ka*3DN2~n
more so if Chandr gives them a drishti.
~(!5D3)Ka~n
The drishti of Mangal on the 5th from Karakamsh will bring
boils or ulcers,
~(!5D9)Ka~n
Ketu's drishti on the 5th from Karakamsh will cause
dysentery and other diseases caused by (impure) water.
~(8I5)Ka*(.GI5)Ka~n
If Rahu and Gulik happen to be in the 5th from Karakamsh
there will be fear from mean people and poison.
~(4I5)Ka~
Should Buddh be in the 5th from Karakamsh , the native will
be an ascetic of the highest order or one holding staff.
~(1I5)Ka~m
Surya in the 5th from Karakamsh denotes one using a knife.
~(3I5)Ka~n
Mangal in the 5th from Karakamsh denotes one using a spear (Mangal).
~(7I5)Ka~n
Shani denotes a bowman if Shani is placed in the 5th from
Karakamsh.
~(8I5)Ka~
Rahu in the 5th from Karakamsh denotes a machinist.
~(9I5)Ka~
Ketu in the 5th from Karakamsh denotes a watch maker.
~(6I5)Ka~
Shukr in the 5th from Karakamsh will make one a poet and an
eloquent speaker.
~5IKa*2IKa+(5I5)Ka*(2I5)Ka~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P113_B001_01

- 身份：正文
- PDF 页：113
- 偈颂：41-45
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 41-45 [present] · PDF page 113

41-45. Effects of Karakamsh and the 5th from there: If Guru
and Chandr are in Karakamsh or the 5th there of, the native
will be an author.
~(6I5)Ka+6IKa~
Shukr in Karakamsh or in the 5th from there will make one
an ordinary writer,
~(4I5)Ka+4IKa~m
while Buddh in Karakamsh or in the 5th from there will
indicate that the writing skills are less than those of an
ordinary writer.
~(5I5)Ka+5IKa~
Should Guru be alone in Karakamsh or in the 5th from there,
one will be a knower of everything, be a writer, and be
versed in Vedas and Vedanta philosophy, but not an
oratorian or a grammarian.
~(3I5)Ka+3IKa~
Mangal in Karakamsh or in the 5th from there denotes a
logician,
~(4I5)Ka+4IKa~
Buddh in Karakamsh or in the 5th from there denotes a
Mimamsaka (follower of Karma Mimansa philosophy),
~(7I5)Ka+7IKa~n
Shani in Karakamsh or in the 5th from there indicates that
one is dull-witted in the assembly,
~(1I5)Ka+1IKa~
Surya in Karakamsh or in the 5th from there denotes that
one is a musician,
~(2I5)Ka+2IKa~
Chandr in Karakamsh or in the 5th from there denotes a
follower of Sankhya philosophy (of Maharishi Kapila who
enumerated 25 true principles with emphasis on final
bliss), and indicates that one is versed in rhetorics
and singing,
~(8I5)Ka+8IKa+(9I5)Ka+9IKa~
and Ketu or Rahu in Karakamsh or in the 5th from there
denotes that one is a Jyotishi.
~-5i$*5IKa+(5I5)Ka~
Should Guru be related to the positions of Karakamsh or the
5th from there, while the Karakamsh is caused by others
than him, the effects as stated will effectively come to
pass.
Some say that the 2nd from Karakamsh should also be
similarly considered.
~(mI6)Ka+(mI3)Ka~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P113_B001_02

- 身份：正文
- PDF 页：113
- 偈颂：41-45
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 41-45 [present] · PDF page 113

41-45. Effects of Karakamsh and the 5th from there: If Guru
and Chandr are in Karakamsh or the 5th there of, the native
will be an author.
~(6I5)Ka+6IKa~
Shukr in Karakamsh or in the 5th from there will make one
an ordinary writer,
~(4I5)Ka+4IKa~m
while Buddh in Karakamsh or in the 5th from there will
indicate that the writing skills are less than those of an
ordinary writer.
~(5I5)Ka+5IKa~
Should Guru be alone in Karakamsh or in the 5th from there,
one will be a knower of everything, be a writer, and be
versed in Vedas and Vedanta philosophy, but not an
oratorian or a grammarian.
~(3I5)Ka+3IKa~
Mangal in Karakamsh or in the 5th from there denotes a
logician,
~(4I5)Ka+4IKa~
Buddh in Karakamsh or in the 5th from there denotes a
Mimamsaka (follower of Karma Mimansa philosophy),
~(7I5)Ka+7IKa~n
Shani in Karakamsh or in the 5th from there indicates that
one is dull-witted in the assembly,
~(1I5)Ka+1IKa~
Surya in Karakamsh or in the 5th from there denotes that
one is a musician,
~(2I5)Ka+2IKa~
Chandr in Karakamsh or in the 5th from there denotes a
follower of Sankhya philosophy (of Maharishi Kapila who
enumerated 25 true principles with emphasis on final
bliss), and indicates that one is versed in rhetorics
and singing,
~(8I5)Ka+8IKa+(9I5)Ka+9IKa~
and Ketu or Rahu in Karakamsh or in the 5th from there
denotes that one is a Jyotishi.
~-5i$*5IKa+(5I5)Ka~
Should Guru be related to the positions of Karakamsh or the
5th from there, while the Karakamsh is caused by others
than him, the effects as stated will effectively come to
pass.
Some say that the 2nd from Karakamsh should also be
similarly considered.
~(mI6)Ka+(mI3)Ka~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P113_B002_01

- 身份：正文
- PDF 页：113
- 偈颂：46
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 46 [present] · PDF page 113

46. Effects of the 6th from Karakamsh: If the 6th from
Karakamsh is occupied by a malefic, the native will be an
agriculturist
~(BI6)Ka+(BI3)Ka~n
while he will be indolent if a benefic is in the 6th from
Karakamsh.
The 3rd from Karakamsh should also be similarly
considered.
~(2I7)Ka*(5I7)Ka~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P114_B001_01

- 身份：正文
- PDF 页：114
- 偈颂：47-48
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 47-48 [present] · PDF page 114

47-48. Effects of the 7th from Karakamsh: If Chandr and
Guru are in the 7th from Karakamsh, the native will beget a
very beautiful wife.
~(6I7)Ka~
Shukr in the 7th form Karakamsh denotes a sensuous wife,
~(4I7)Ka~
while Buddh in the 7th from Karakamsh indicates a wife
versed in arts.
~(1I7)Ka~
Surya in the 7th from Karakamsh will give a wife who will
be confining domestic core,
~(7I7)Ka~m
while Shani in the 7th from Karakamsh denotes a wife of a
higher age bracket, or a pious and/or sick wife.
~(8I7)Ka~n
Rahu in the 7th from Karakamsh will bring a widow in
marriage.
~(BI8)Ka+(L8I8)Ka~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P114_B002_01

- 身份：正文
- PDF 页：114
- 偈颂：49
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 49 [present] · PDF page 114

49. Effects of the 8th from Karakamsh: If a benefic or the
grah owning the 8th from Karakamsh happens to be in the 8th
from Karakamsh, the native will be long-lived,
~(mI8)Ka~n
while a malefic placed in the 8th from Karakamsh will
reduce the life span.
~(BI8)Ka+(!8DB)Ka**(mI8)Ka+(!8Dm)Ka~m
Drishti/yuti of both benefics and malefics will yield a
medium span of life.
~(BI9)Ka+(!9DB)Ka~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P114_B003_01

- 身份：正文
- PDF 页：114
- 偈颂：50-56
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 50-56 [present] · PDF page 114

50-56. Effects of the 9th from Karakamsh: If the 9th from
Karakamsh receives a drishti from or is occupied by a
benefic, the native will be truthful, devoted to elders and
attached to his own religion.
~(mI9)Ka+(!9Dm)Ka~m
If a malefic gives a drishti to or occupies the 9th from
Karakamsh, one will be attached to his religion in boyhood,
but will take to falsehood in old age.
~(7I9)Ka+(!9D7)Ka**(8I9)Ka+(!9D8)Ka~n
If Shani and Rahu give a drishti to or occupy the 9th from
Karakamsh, one will betray his elders and be adverse to
ancient learning.
~(5I9)Ka+(!9D5)Ka**(1I9)Ka+(!9D1)Ka~n
If Guru and Surya give a drishti to or occupy the 9th from
Karakamsh, one will betray his elders and will be
disobedient to them.
~(3I9)Ka+(!9D3)Ka**(6I9)Ka+(!9D6)Ka*@J16~n
Should Mangal and Shukr give a drishti to or occupy the 9th
from Karakamsh, and are joining in six identical vargas, a
female ill-related to the native will die.
~(4I9)Ka+(!9D4)Ka**(2I9)Ka+(!9D2)Ka*@J24~n
Buddh and Chandr giving a drishti to or occupying the 9th from
Karakamsh and joining in six identical vargas will cause
imprisonment of the native due to association with a female
not of his own.
~(5I9)Ka+(!9D5)Ka~n
If Guru is alone related to the 9th from Karakamsh by
drishti or by yuti, the native will be addicted to females
and be devoted to sensual enjoyments.
~(BI10)Ka+(!10DB)Ka~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P115_B001_01

- 身份：正文
- PDF 页：115
- 偈颂：57-60
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 57-60 [present] · PDF page 115

57-60. Effects of the 10th from Karakamsh: If the 10th from
Karakamsh receives a drishti from or is conjoined by a
benefic, the native will have firm riches, be sagacious,
strong, and intelligent.
~(mI10)Ka+(!10Dm)Ka~n
A malefic giving a drishti to the 10th from Karakamsh or
occupying this bhava will cause harm to his profession and
deprive him of paternal bliss.
~(4I10)Ka+(!10D4)Ka**(6I10)Ka+(!10D6)Ka~
Buddh and Shukr giving a drishti to the 10th from Karakamsh
or conjoining this bhava will confer many gains in business
(or profession) and will make him do many great deeds.
~lDN5*1YN2**(1I10)Ka+(1I4)Ka~
Surya and Chandr giving a drishti to the 10th from Karakamsh
or conjoining this place, and receiving a drishti from or be
in yuti with Guru the native will acquire a kingdom.
~(BI11)Ka+(!11DB)Ka~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P115_B002_01

- 身份：正文
- PDF 页：115
- 偈颂：61-62
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 61-62 [present] · PDF page 115

61-62. Effects of the 11th from Karakamsh: If the 11th from
Karakamsh receives a drishti from or is yuti with a
benefic, the native will enjoy happiness from co-born apart
from gaining in every undertaking of his.
~(mI11)Ka+(!11Dm)Ka~m
If a malefic is in the 11th from Karakamsh the native will
gain by questionable means, be famous and valorous.
~(BI12)Ka~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P116_B001_01

- 身份：正文
- PDF 页：116
- 偈颂：63-74
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 63-74 [present] · PDF page 116

63-74. Effects of the 12th from Karakamsh: If the 12th from
Karakamsh has a benefic, the expenses will be on good
account,
~(mI12)Ka~n
while a malefic in the 12th from Karakamsh will cause bad
expenses.
~-(&I12)Ka~
If the 12th from Karakamsh is vacant, then also good
effects (in respect of expenses) will follow.
~(BEI12)Ka+(BOI12)Ka+(9I12)Ka*N9DB+(9I12)Ka*(BI12)Ka~
If there happens to be a benefic grah in exaltation or in
own bhava in the 12th from Karakamsh or if Ketu is so
placed and receives a drishti from or is yuti with a
benefic one will attain heaven after death.
~(9I12)Ka*N9IR1*N9DB+(9I12)Ka*N9IR9*N9DB~
One will attain full enlightenment if Ketu is in the 12th
(from Karakamsh) identical with Mesh or Dhanu and receives
a drishti from a benefic.
~(9I12)Ka*N9Ym+(9I12)Ka*N9Dm~
If Ketu is in the 12th from Karakamsh receiving a drishti
from a malefic or is there yuti with a malefic one will not
attain full enlightenment.
~(1I12)Ka*(9I12)Ka~
If Surya and Ketu are in the 12th from Karakamsh the native
will worship Lord Shiva.
~(2I12)Ka*(9I12)Ka~
Chandr and Ketu in the 12th from Karakamsh denotes a
worshiper of Gauri (a consort of Lord Shiva).
~(6I12)Ka*(9I12)Ka~
Shukr and Ketu in the 12th from Karakamsh denotes a
worshiper of Lakshmi (a consort of Lord Vishnu) and a
wealthy person.
~(3I12)Ka*(9I12)Ka~
Mangal and Ketu in the 12th from Karakamsh denotes a
worshipper of Lord Subramanya (an offspring of Lord
Shiva).
~(8I12)Ka~
Rahu in the 12th from Karakamsh will make one worship Durga
or some mean deity.
~(9I12)Ka*-9YN&~
Ketu alone in the 12th from Karakamsh denotes Subramanya's
or Ganesh's worshipper.
~(7I12)Ka*N7Iz~n
If Shani is in the 12th from Karakamsh in a malefic's rashi
one will worship mean deities.
~(7I12)Ka*(6I12)Ka*N7Iz*(6I12)Ka~n
Shukr and Shani in the 12th from Karakamsh in a malefic's
rashi will also make one worship mean deities.
Similar inferences can be drawn from the 6th Navamsh
counted from Amatya Karak's Navamsh.
~(.:I5)Ka+(.:I9)Ka~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P116_B001_02

- 身份：正文
- PDF 页：116
- 偈颂：63-74
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 63-74 [present] · PDF page 116

63-74. Effects of the 12th from Karakamsh: If the 12th from
Karakamsh has a benefic, the expenses will be on good
account,
~(mI12)Ka~n
while a malefic in the 12th from Karakamsh will cause bad
expenses.
~-(&I12)Ka~
If the 12th from Karakamsh is vacant, then also good
effects (in respect of expenses) will follow.
~(BEI12)Ka+(BOI12)Ka+(9I12)Ka*N9DB+(9I12)Ka*(BI12)Ka~
If there happens to be a benefic grah in exaltation or in
own bhava in the 12th from Karakamsh or if Ketu is so
placed and receives a drishti from or is yuti with a
benefic one will attain heaven after death.
~(9I12)Ka*N9IR1*N9DB+(9I12)Ka*N9IR9*N9DB~
One will attain full enlightenment if Ketu is in the 12th
(from Karakamsh) identical with Mesh or Dhanu and receives
a drishti from a benefic.
~(9I12)Ka*N9Ym+(9I12)Ka*N9Dm~
If Ketu is in the 12th from Karakamsh receiving a drishti
from a malefic or is there yuti with a malefic one will not
attain full enlightenment.
~(1I12)Ka*(9I12)Ka~
If Surya and Ketu are in the 12th from Karakamsh the native
will worship Lord Shiva.
~(2I12)Ka*(9I12)Ka~
Chandr and Ketu in the 12th from Karakamsh denotes a
worshiper of Gauri (a consort of Lord Shiva).
~(6I12)Ka*(9I12)Ka~
Shukr and Ketu in the 12th from Karakamsh denotes a
worshiper of Lakshmi (a consort of Lord Vishnu) and a
wealthy person.
~(3I12)Ka*(9I12)Ka~
Mangal and Ketu in the 12th from Karakamsh denotes a
worshipper of Lord Subramanya (an offspring of Lord
Shiva).
~(8I12)Ka~
Rahu in the 12th from Karakamsh will make one worship Durga
or some mean deity.
~(9I12)Ka*-9YN&~
Ketu alone in the 12th from Karakamsh denotes Subramanya's
or Ganesh's worshipper.
~(7I12)Ka*N7Iz~n
If Shani is in the 12th from Karakamsh in a malefic's rashi
one will worship mean deities.
~(7I12)Ka*(6I12)Ka*N7Iz*(6I12)Ka~n
Shukr and Shani in the 12th from Karakamsh in a malefic's
rashi will also make one worship mean deities.
Similar inferences can be drawn from the 6th Navamsh
counted from Amatya Karak's Navamsh.
~(.:I5)Ka+(.:I9)Ka~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P117_B001_01

- 身份：正文
- PDF 页：117
- 偈颂：75-76
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 75-76 [present] · PDF page 117

75-76. Miscellaneous Matters (up to sloka 84): O Brahmin,
if there are two malefics in a Kon from Karakamsh, the
native will have knowledge of Mantras and Tantras (formulas
for the attainment of super-human powers).
~(.:I5)Ka*(!5Dm)Ka+(.:I9)Ka*(!9Dm)Ka~m
If a malefic simultaneously gives a drishti to two malefics
in a Kon  from Karakamsh, the native will use his learnings
of Mantras and Tantras for malevolent purposes.
~(.:I5)Ka*(!5DB)Ka+(.:I9)Ka*(!9DB)Ka~
while a benefic's drishti will make him use the learnings
of Mantras and Tantras for public good,
~2IKa*N2D6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P118_B001_01

- 身份：正文
- PDF 页：118
- 偈颂：77-84 1/2
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 77-84 1/2 [present] · PDF page 118

77-84 1/2. If Chandr is in the Karakamsh receiving a drishti
from Shukr the native will be an alchemist,
~2IKa*N2D4~
and if Chandr being in the Karakamsh receiving a drishti
from Buddh the native will be a doctor capable of curing all
diseases.
~(2I4)Ka*N2D6~n
If Chandr is in the 4th from Karakamsh and receives a
drishti from Shukr, the native will be afflicted by white
leprosy;
~(2I4)Ka*N2D3~n
if Chandr being in the 4th from Karakamsh receiving a
drishti from Mangal the native will have blood and bilious
disorders,
~(2I4)Ka*N2D9~n
and if Chandr being in the 4th from Karakamsh receiving a
drishti from Ketu the native will suffer from black leprosy.
~(8I4)Ka*(3I4)Ka+(8I5)Ka*(3I5)Ka~n
Should Rahu and Mangal be in the 4th or 5th from Karakamsh
the native will suffer from pulmonary consumption,
~(8I4)Ka*(3I4)Ka+(8I5)Ka*(3I5)Ka**N8D2~n
and if simultaneously there happens to be Chandr's drishti
on the 4th or the 5th from Karakamsh this affliction will
be certain.
~(3I4)Ka*-N3Y&+(3I5)Ka*-N3Y&~n
Mangal alone in the 4th or the 5th from Karakamsh will
cause ulcers.
~(9I4)Ka+(9I5)Ka~n
If Ketu is in the 4th or the 5th from Karakamsh one will
suffer from dysentery and afflictions due to (impure)
water.
~(8I4)Ka*(.GI4)Ka+(8I5)Ka*(.GI5)Ka~m
Rahu and Gulik in the 4th or the 5th from Karakamsh will
make one a doctor curing poisonous afflictions or will
cause troubles through poison.
~(7I4)Ka*-N7Y&+(7I5)Ka*-N7Y&~
Should Shani be alone in the 4th or 5th from Karakamsh, the
native will be skillful in archery.
~(9I4)Ka*-N9Y&+(9I5)Ka*-N9Y&~
Ketu lonely placed in the 4th or the 5th from Karakamsh
will make one a maker of watches, etc..
~(4I4)Ka*-N4Y&+(4I5)Ka*-N4Y&~
Buddh lonely placed in the 4th or the 5th from Karakamsh
will make one an ascetic of the highest order or an ascetic
holding staff.
~(8I4)Ka+(8I5)Ka+(1I4)Ka+(1I5)Ka+(3I4)Ka+(3I5)Ka~m
Rahu, Surya, and Mangal respectively in these places denote
a machinist, a knife user, and a spear or arrow user.
~2IKa*5IKa+(2I5)Ka*(5I5)Ka~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P118_B001_02

- 身份：正文
- PDF 页：118
- 偈颂：77-84 1/2
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 77-84 1/2 [present] · PDF page 118

77-84 1/2. If Chandr is in the Karakamsh receiving a drishti
from Shukr the native will be an alchemist,
~2IKa*N2D4~
and if Chandr being in the Karakamsh receiving a drishti
from Buddh the native will be a doctor capable of curing all
diseases.
~(2I4)Ka*N2D6~n
If Chandr is in the 4th from Karakamsh and receives a
drishti from Shukr, the native will be afflicted by white
leprosy;
~(2I4)Ka*N2D3~n
if Chandr being in the 4th from Karakamsh receiving a
drishti from Mangal the native will have blood and bilious
disorders,
~(2I4)Ka*N2D9~n
and if Chandr being in the 4th from Karakamsh receiving a
drishti from Ketu the native will suffer from black leprosy.
~(8I4)Ka*(3I4)Ka+(8I5)Ka*(3I5)Ka~n
Should Rahu and Mangal be in the 4th or 5th from Karakamsh
the native will suffer from pulmonary consumption,
~(8I4)Ka*(3I4)Ka+(8I5)Ka*(3I5)Ka**N8D2~n
and if simultaneously there happens to be Chandr's drishti
on the 4th or the 5th from Karakamsh this affliction will
be certain.
~(3I4)Ka*-N3Y&+(3I5)Ka*-N3Y&~n
Mangal alone in the 4th or the 5th from Karakamsh will
cause ulcers.
~(9I4)Ka+(9I5)Ka~n
If Ketu is in the 4th or the 5th from Karakamsh one will
suffer from dysentery and afflictions due to (impure)
water.
~(8I4)Ka*(.GI4)Ka+(8I5)Ka*(.GI5)Ka~m
Rahu and Gulik in the 4th or the 5th from Karakamsh will
make one a doctor curing poisonous afflictions or will
cause troubles through poison.
~(7I4)Ka*-N7Y&+(7I5)Ka*-N7Y&~
Should Shani be alone in the 4th or 5th from Karakamsh, the
native will be skillful in archery.
~(9I4)Ka*-N9Y&+(9I5)Ka*-N9Y&~
Ketu lonely placed in the 4th or the 5th from Karakamsh
will make one a maker of watches, etc..
~(4I4)Ka*-N4Y&+(4I5)Ka*-N4Y&~
Buddh lonely placed in the 4th or the 5th from Karakamsh
will make one an ascetic of the highest order or an ascetic
holding staff.
~(8I4)Ka+(8I5)Ka+(1I4)Ka+(1I5)Ka+(3I4)Ka+(3I5)Ka~m
Rahu, Surya, and Mangal respectively in these places denote
a machinist, a knife user, and a spear or arrow user.
~2IKa*5IKa+(2I5)Ka*(5I5)Ka~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P118_B002_01

- 身份：正文
- PDF 页：118
- 偈颂：85-86
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 85-86 [present] · PDF page 118

85-86. Chandr and Guru in the Karakamsh or in the 5th there
from denotes a writer well versed in all branches of
learning. The grade of writership will comparatively
descend in the case of Shukr and even further in the case
of Buddh if placed in the Karakamsh or in the 5th from
there.
~(6I5)Ka~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P119_B001_01

- 身份：正文
- PDF 页：119
- 偈颂：87-92 1/2
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 87-92 1/2 [present] · PDF page 119

87-92 1/2. Grahas in the 5th from Karakamsh: Should Shukr
be in the 5th from Karakamsh, the native will be eloquent
and a poet.
~(5I5)Ka~m
Guru in the 5th from Karakamsh denotes that he be an
exponent and be all knowing, but be unable to speak in an
assembly. He will be further a grammarian and a scholar in
Vedas and Upanishads.
~(7I5)Ka~n
Shani in the 5th from Karakamsh will make one ineffective
in an assembly,
~(4I5)Ka~
while Buddh in the 5th from Karakamsh will make him skilful
in Karma Mimansa (one of the six  Darshanas).
~(3I5)Ka+3IKa~
Mangal in Karakamsh or the 5th therefrom will make one
justice,
~(2I5)Ka+2IKa~
while Chandr in Karakamsh or the 5th from there denotes a
Sankhya Yogi, a rhetoric, or a singer.
~(1I5)Ka~
Surya in the 5th from Karakamsh will make one learned in
Vedanta and music.
~(9I5)Ka+N5r9~
Ketu in the 5th from Karakamsh will make one a
mathematician and skilful in Jyotish. Should Guru be
related to the said Ketu, these learnings will be by
inheritance.
All these as well apply to 2nd and 3rd from Karakamsh and
to the Karakamsh itself apart from applying to the 5th from
Karakamsh.
~(9I2)Ka+(9I3)Ka~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P119_B002_01

- 身份：正文
- PDF 页：119
- 偈颂：93-93 1/2
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 93-93 1/2 [present] · PDF page 119

93-93 1/2. Should Ketu be in the 2nd or 3rd from Karakamsh,
the native will be defective in speech, more so if a
malefic gives a drishti to Ketu as above.
~mIKa*mILa*(mI2)Ka*(mI8)Ka*(mI2)La*(mI8)La~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P119_B003_01

- 身份：正文
- PDF 页：119
- 偈颂：94-99
- 标题路径：CHAPTER 33 Effects of Karakamsh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Karakamsh · Sloka 94-99 [present] · PDF page 119

94-99. If malefics be in Karakamsh, Arudh Lagn, and the
2nd, and 8th from these places, there will be Kemadrum Yog;
the effects of which will be still severe if Chandr's
drishti happens to be there.
The effects due for these yogas will come to pass in the
Dasha periods of the rashis or grahas concerned.
Kemadrum Yog will operate additionally if there are
malefics in the 2nd and 8th from the rashi whose Dasha will
be in currency. The results of such Yog will also be
inauspicious.
If the 2nd and 8th in the Kundali cast for the beginning of
a Dasha have malefics, then also Kemadrum prevails
throughout the Dasha.
