# 第 8 章：Drishtis of the Rashis

- 来源：BPHS 97 章版
- 原始卡片：3 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P025_B002_01

- 身份：正文
- PDF 页：25
- 偈颂：1-3
- 标题路径：CHAPTER 8 Drishtis of the Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Drishtis of the Rashis · Sloka 1-3 [present] · PDF page 25

1-3. Rashi  Drishtis: O Maitreya, now detailed are the
drishtis emanating from the rashi Mesh, etc.. Every movable
rashi drishtis the 3 fixed rashis leaving the fixed rashi
adjacent to it. Every fixed rashi gives drishti to the 3
movable rashis barring the adjacent movable rashi. And a
common rashi gives a drishti to the other three common
rashis. The grah in a rashi gives the same drishti as the
rashi (in which the grah is) does.
{graasp}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P025_B003_01

- 身份：正文
- PDF 页：25
- 偈颂：4-5
- 标题路径：CHAPTER 8 Drishtis of the Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Drishtis of the Rashis · Sloka 4-5 [present] · PDF page 25

4-5. Dristhis of the Grahas: A grah in a movable rashi
gives a drishti to the other 3 fixed rashis leaving the
fixed rashi next to it. A grah in a fixed rashi does not
give a drishti to the next movable rashi, but the remaining
3 movable rashis. The one in a common rashi gives a drishti
to the remaining 3 common rashis. Simultaneously, a grah in
the rashi that receives a drishti is also subjected to the
drishti concerned.
{aspdia}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P025_B004_01

- 身份：正文
- PDF 页：25
- 偈颂：6-9
- 标题路径：CHAPTER 8 Drishtis of the Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Drishtis of the Rashis · Sloka 6-9 [present] · PDF page 25

6-9. Diagram of Dristhis: As depicted by Lord Brahma, I now
narrate the diagram of drishtis, so that drishtis are
easily understood by a mere sight of the diagram. Draw a
square or a circle marking the 8 directions (4 corners and
4 quarters thereof). Mark the zodiacal rashis as under:
Mesh and Vrishabh in east;
Mithun in the north-east;
Kark and Simh  in the north;
Kanya in the north-west;
Tula and Vrischik in the west;
Dhanu in the south-west;
Makar and Kumbh in the south; and
Meen in the south-east.
[addition Santhanam till chapter 9]:
The drishtis (as per the earlier slokas) can be shown in a
square diagram or cicular diagram (as per convenience).
