# 第 86 章：Remedial Measures for Birth on Amavasya

- 来源：BPHS 97 章版
- 原始卡片：2 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P360_B002_01

- 身份：正文
- PDF 页：360
- 偈颂：1-9
- 标题路径：CHAPTER 86 Remedial Measures for Birth on Amavasya
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedial Measures for Birth on Amavasya · Sloka 1-9 [present] · PDF page 360

1-9. The Sage Parasara said: O Maitreya! The person born on
Amavasya is always poverty stricken. It is therefore
essential to adopt remedial measures to obtain relief from
the evil effects of such births, which are as follows:
Take a Kalash (water vessel) and then put in it fresh leaves
of Goolar (a wild fig), Vata (banyan), pipal, mango, and
neema (mango) trees and cover it with two pieces of cloth.
Then, instal the Kalash in the South West direction after
reciting (.....), etc., and (......), etc., mantras. Then,
worship the idols of Surya and Chandr, ruling deities of
Amavasya made of gold and silver mixed with copper
respectively, by recitation of (.....), mantras etc., for
Surya, and (.....) etc, mantras etc., for Chandr 16 or 5
times. Thereafter, perform havan with 108 or 28 oblations of
the mixture of prescribed fuels (......) and cooked food
(charu) with recitation of mantras of Surya and Chandr.
Later, sprinkle the water on the child that is born and his
parents and offer in charity gold, silver, and a black cow
together with feeding the Brahmins according to one's means.
By performing these remedial rites the child born gains
freedom and protection from the evil effects of the birth on
Amavasya.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P360_B002_02

- 身份：正文
- PDF 页：360
- 偈颂：1-9
- 标题路径：CHAPTER 86 Remedial Measures for Birth on Amavasya
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedial Measures for Birth on Amavasya · Sloka 1-9 [present] · PDF page 360

1-9. The Sage Parasara said: O Maitreya! The person born on
Amavasya is always poverty stricken. It is therefore
essential to adopt remedial measures to obtain relief from
the evil effects of such births, which are as follows:
Take a Kalash (water vessel) and then put in it fresh leaves
of Goolar (a wild fig), Vata (banyan), pipal, mango, and
neema (mango) trees and cover it with two pieces of cloth.
Then, instal the Kalash in the South West direction after
reciting (.....), etc., and (......), etc., mantras. Then,
worship the idols of Surya and Chandr, ruling deities of
Amavasya made of gold and silver mixed with copper
respectively, by recitation of (.....), mantras etc., for
Surya, and (.....) etc, mantras etc., for Chandr 16 or 5
times. Thereafter, perform havan with 108 or 28 oblations of
the mixture of prescribed fuels (......) and cooked food
(charu) with recitation of mantras of Surya and Chandr.
Later, sprinkle the water on the child that is born and his
parents and offer in charity gold, silver, and a black cow
together with feeding the Brahmins according to one's means.
By performing these remedial rites the child born gains
freedom and protection from the evil effects of the birth on
Amavasya.
