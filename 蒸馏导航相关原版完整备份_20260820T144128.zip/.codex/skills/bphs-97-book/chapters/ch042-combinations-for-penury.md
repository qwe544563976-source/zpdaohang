# 第 42 章：Combinations for Penury

- 来源：BPHS 97 章版
- 原始卡片：16 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P147_B002_01

- 身份：正文
- PDF 页：147
- 偈颂：1
- 标题路径：CHAPTER 42 Combinations for Penury
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations for Penury · Sloka 1 [present] · PDF page 147

1. O Lord, you have stated many Yogas related to
acquisition of wealth. Please tell me such Yogas causing
utter poverty.
~L1I12*L12I1*L12Yk+L1I12*L12I1*kDL12~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P147_B003_01

- 身份：正文
- PDF 页：147
- 偈颂：2
- 标题路径：CHAPTER 42 Combinations for Penury
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations for Penury · Sloka 2 [present] · PDF page 147

2. The native will be penniless if Lagn's lord is in Vyaya
Bhava, while Vyaya's lord is in Lagn along with the lord of
a Marak (a death inflicting grah) or receives a drishti
from such a grah.
~L1I6*L6I1*L6Yk+L1I6*L6I1*L1Dk~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P147_B004_01

- 身份：正文
- PDF 页：147
- 偈颂：3
- 标题路径：CHAPTER 42 Combinations for Penury
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations for Penury · Sloka 3 [present] · PDF page 147

3. The native will be penniless if Lagn's lord is in Ari
Bhava, while Ari's lord is in Lagn, yuti with or receiving
a drishti from a Marak lord.
~9I1*L1I8+2Y9*L1I8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P147_B005_01

- 身份：正文
- PDF 页：147
- 偈颂：4
- 标题路径：CHAPTER 42 Combinations for Penury
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations for Penury · Sloka 4 [present] · PDF page 147

4. Should Lagn or Chandr be with Ketu, while Lagn's lord is
in Randhr Bhava, the person concerned will be penniless.
~L1I6+L1I8+L1I12**L1Ym*L2e+L1Ym*L2d~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P147_B006_01

- 身份：正文
- PDF 页：147
- 偈颂：5
- 标题路径：CHAPTER 42 Combinations for Penury
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations for Penury · Sloka 5 [present] · PDF page 147

5. If Lagn's lord along with a malefic is in Ari, Randhr,
or Vyaya Bhava, while Dhan's lord is in an enemy's rashi,
or in debilitation, even a native of royal scion will
become penniless.
~L1YL6*-L1DB+L1YL8*-L1DB+L1YL12*-L1DB+L1Y7*-L1DB~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P147_B007_01

- 身份：正文
- PDF 页：147
- 偈颂：6
- 标题路径：CHAPTER 42 Combinations for Penury
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations for Penury · Sloka 6 [present] · PDF page 147

6. If Lagn's lord is yuti with the lord of Ari, Randhr,
or Vyaya Bhava, or with Shani, and if Lagn's lord is
devoid of a drishti from a benefic the native will be
penniless.
~L5I6*L9I12*L5Dk*L9Dk~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P147_B008_01

- 身份：正文
- PDF 页：147
- 偈颂：7
- 标题路径：CHAPTER 42 Combinations for Penury
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations for Penury · Sloka 7 [present] · PDF page 147

7. Should Putr's and Dharm's lords be respectively found in
Ari and Vyaya Bhava, and receive a drishti from Marak
grahas, the native will be penniless.
~!1Rk**-3iL9*-3iL10*3I1+-1iL9*-1iL10*1I1+-7iL9*-7iL10*7I1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P147_B009_01

- 身份：正文
- PDF 页：147
- 偈颂：8
- 标题路径：CHAPTER 42 Combinations for Penury
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations for Penury · Sloka 8 [present] · PDF page 147

8. If malefics, excepting the lords of Karm and Dharm
Bhava, happen to be in Lagn associated with or receiving
a drishti from Marak grahas one will become penniless.
~ãL6Ia*ãL6Rm*ãL8Ia*ãL8Rm*ãL12Ia*ãL12Rm~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P147_B010_01

- 身份：正文
- PDF 页：147
- 偈颂：9
- 标题路径：CHAPTER 42 Combinations for Penury
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations for Penury · Sloka 9 [present] · PDF page 147

9. Note the grahas that are ruling the rashis occupied by
the lords of Ari, Randhr, and Vyaya Bhava. If the said
dispositors are in such evil bhavas in turn, and are
associated with or receive a drishti from malefics, the
native will be miserable and indigent.
~Nã2Yk+Nã2I2+Nã2I7~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P147_B011_01

- 身份：正文
- PDF 页：147
- 偈颂：10
- 标题路径：CHAPTER 42 Combinations for Penury
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations for Penury · Sloka 10 [present] · PDF page 147

10. The lord of the Navamsh occupied by Chandr, joining a
Marak grah or occupying a Marak Bhava will make one
penniless.
~L1Dk+L1Yk**NL1Dk+NL1Yk~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P147_B012_01

- 身份：正文
- PDF 页：147
- 偈颂：11
- 标题路径：CHAPTER 42 Combinations for Penury
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations for Penury · Sloka 11 [present] · PDF page 147

11. Should the lord of the natal Lagn and that of the
Navamsh Lagn be yuti with or receive a drishti from Marak
grahas, one will be penniless.
~-BK*-BT*BIa**mIK+mIT~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P148_B001_01

- 身份：正文
- PDF 页：148
- 偈颂：12
- 标题路径：CHAPTER 42 Combinations for Penury
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations for Penury · Sloka 12 [present] · PDF page 148

12. If inauspicious bhavas are occupied by benefics, while
auspicious bhavas are occupied by malefics, the native will
be indigent and will be distressed even in the matter of
food.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P148_B002_01

- 身份：正文
- PDF 页：148
- 偈颂：13
- 标题路径：CHAPTER 42 Combinations for Penury
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations for Penury · Sloka 13 [present] · PDF page 148

13. A grah associated with one of the lords of Ari, Randhr,
and Vyaya Bhava, being bereft of a drishti from the lord of
a Kon, will in its Dasha periods cause harm to the native's
financial aspects.
~@s6~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P148_B003_01

- 身份：正文
- PDF 页：148
- 偈颂：14
- 标题路径：CHAPTER 42 Combinations for Penury
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations for Penury · Sloka 14 [present] · PDF page 148

14. If the 8th/12th from Atma Karak, or Randhr/Vyaya Bhava
receive a drishti from the Atma Karak's Navamsh lord and
the lord of Janma Lagn, the native will be bereft of wealth.
~(!12Dã$)$+!12DL1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P148_B004_01

- 身份：正文
- PDF 页：148
- 偈颂：15
- 标题路径：CHAPTER 42 Combinations for Penury
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations for Penury · Sloka 15 [present] · PDF page 148

15. The native will be a spend thrift if the 12th from Atma
Karak receives a drishti from the dispositor of Atma Karak
or if Vyaya Bhava receives a drishti from the lord of Lagn.
~3I2*3Y7~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P148_B005_01

- 身份：正文
- PDF 页：148
- 偈颂：16-18
- 标题路径：CHAPTER 42 Combinations for Penury
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations for Penury · Sloka 16-18 [present] · PDF page 148

16-18. Now I tell you some Yogas for poverty along with
conditions of their nullifications. Should Mangal and Shani
be together in Dhan Bhava, the native's wealth will be
destroyed.
~3I2*3Y7*3D4~
Should Buddh give a drishti to Mangal and Shani in Dhan
Bhava, there will be great wealth. There is no doubt in
it.
~1I2*1D7~n
Surya in Dhan Bhava receiving a drishti from Shani will
cause penury;
~1I2*-1D7~
while if Surya is in Dhan Bhava and does not receive a
drishti from Shani,  riches and fame will be obtained.
~7I2*7D1~n
The same effects (i.e. poverty) will be declared if Shani
is in Dhan Bhava receiving a drishti from Surya.
