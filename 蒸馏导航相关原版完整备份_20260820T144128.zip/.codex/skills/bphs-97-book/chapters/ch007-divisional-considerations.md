# 第 7 章：Divisional Considerations

- 来源：BPHS 97 章版
- 原始卡片：13 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P022_B002_01

- 身份：正文
- PDF 页：22
- 偈颂：1-8
- 标题路径：CHAPTER 7 Divisional Considerations
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Divisional Considerations · Sloka 1-8 [present] · PDF page 22

1-8. Use of the 16 Divisions: Now, I will explain the use
of these sixteen divisions. The physique from Lagn, wealth
from Hora, happiness through co-born from Dreshkan,
fortunes from Chaturthamsh, sons and grandsons from
Saptamsh, spouse from Navamsh, power (and position) from
Dashamsh, parents from Dvadashamsh, benefits and
adversities through conveyances from Shodashamsh, worship
from Vimshamsh, learning from Chaturvimshamsh strength and
weakness from Saptavimshamsh, evil effects from Trimshamsh,
auspicious and inauspicious effects from Khavedamsh, and
all indications from both Akshavedamsh and Shashtiamsh:
these are the considerations to be made through the
respective vargas. The bhava whose lord is in a malefic
Shashtiamsh will diminish, so say Garga and others. The
bhava whose lord is in a benefic Shodashamsh flourish. This
is how the 16 vargas are to be evaluated.
{gravim}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P022_B003_01

- 身份：正文
- PDF 页：22
- 偈颂：9-12
- 标题路径：CHAPTER 7 Divisional Considerations
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Divisional Considerations · Sloka 9-12 [present] · PDF page 22

9-12. After assessing the 20 point strength of the
ascending degree, of other bhavas, and of the grahas, the
good and bad effects be declared. I explain below the
method of knowing the Vimsopak strength (20 point strength)
just by knowing which an idea of the results of actions of
this birth and of former birth will clearly emerge. The
grahas from Surya on get full strength when in exaltation
or in own rashi and are bereft of strength when in the 7th
(from exaltation). In between, the strength be known by the
rule of three process. In the case of a grah owning two
rashis, distinction of placement in odd/even rashi
identical with own rashi be made.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P022_B004_01

- 身份：正文
- PDF 页：22
- 偈颂：13-16
- 标题路径：CHAPTER 7 Divisional Considerations
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Divisional Considerations · Sloka 13-16 [present] · PDF page 22

13-16. Hora, Dreshkan, and Trimshamsh Effects: Guru, Surya,
and Mangal give (pronounced) effects in the Hora of Surya.
Chandr, Shukr, and Shani do so when in Chandr's Horas;
Buddh is effective in both the Horas. In the case of an
even rashi the hora of Chandr  will be powerful in effects
while Surya's hora in an odd rashi will be so. Full,
medium, and nil will be the effects respectively in the
beginning middle and the end of a hora. Similar
applications be made for a Dreshkan, Turyamsh, Navamsh,
etc.. As for Trimshamsh effects Surya is akin to Mangal and
Chandr is akin to Shukr. The effects applicable to Rashi
will apply to Trimshamsh.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P022_B005_01

- 身份：正文
- PDF 页：22
- 偈颂：17-19
- 标题路径：CHAPTER 7 Divisional Considerations
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Divisional Considerations · Sloka 17-19 [present] · PDF page 22

17-19. Vimshopak Bal: The Shad Vargas (six divisions)
consist of Rashi, Hora, Dreshkan, Navamsh, Dvadashamsh, and
Trimshamsh. The full Bal, for each of the divisions
respectively are 6, 2, 4, 5, 2, and 1. This is the
Vimshopak Bal relating to Shad Varg division. Adding the
Saptamsh to the Shad Vargas, we get Sapt Varg, the
Vimshopak Bal for which is: 5, 2, 3, 2 1/2, 4 1/2, 2, and

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P022_B006_01

- 身份：正文
- PDF 页：22
- 偈颂：1
- 标题路径：CHAPTER 7 Divisional Considerations
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Divisional Considerations · Sloka 1 [present] · PDF page 22

1. These are gross strengths, while subtle ones should be
understood by exact positions.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P023_B001_01

- 身份：正文
- PDF 页：23
- 偈颂：20
- 标题路径：CHAPTER 7 Divisional Considerations
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Divisional Considerations · Sloka 20 [present] · PDF page 23

20. Add Dashamsh, Shodashamsh, and Shashtiamsh to the said
Sapt Varg Divisions, to get the scheme of Dasha Varg (10
divisions). The Vimshopak Bal in this context is 3 for
Rashi, 5 for Shashtiamsh, and for the other 8 divisions, 1
1/2 each.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P023_B002_01

- 身份：正文
- PDF 页：23
- 偈颂：21-25
- 标题路径：CHAPTER 7 Divisional Considerations
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Divisional Considerations · Sloka 21-25 [present] · PDF page 23

21-25. When the 16 divisions (Shodash Varg Scheme) are
considered together, the Vimshopak score goes thus: Hora 1,
Trimsamsh 1, Dreshkan 1, Shodashamsh 2, Navamsh 3, Rashi 3
1/2,  Shashtiamsh 4, and the rest of the nine divisions
each a half. The Vimshopak Bal remains as 20 (in the above
computations) only when the grah is in own bhava vargas.
Otherwise, the total strength from 20 declines to 18 in
Pramudit vargas, to 15 in Shant vargas, to 10 in Svasth
divisions, to 7 in Duhkhit vargas and to 5 in Khal vargas.
(These figures are called Varg Vishwa.)

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P023_B003_01

- 身份：正文
- PDF 页：23
- 偈颂：26-27
- 标题路径：CHAPTER 7 Divisional Considerations
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Divisional Considerations · Sloka 26-27 [present] · PDF page 23

26-27. Vimshopak Proportional Evaluation. Multiply the
figure due to full strength for the division by the varg
Vishwa and divide by 20 to get the exact strength of the
grah. If the such total is below 5 the grah will not be
capable of giving auspicious results. If it is above 5 but
below 10, the grah will yield some good effects. Later on,
up to 15 it is indicative of mediocre effect. A grah with
above 15 will yield wholly favourable effects.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P023_B004_01

- 身份：正文
- PDF 页：23
- 偈颂：28-29
- 标题路径：CHAPTER 7 Divisional Considerations
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Divisional Considerations · Sloka 28-29 [present] · PDF page 23

28-29. Other Sources of Strength: Maitreya, there are other
kinds of sources as I explain below. Grahas in the 7th from
Surya will be fully effective. One with an identical
longitude in comparison to Surya's will destroy the good
effects. Rule of three process be applied to the grah in
between these positions.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P023_B005_01

- 身份：正文
- PDF 页：23
- 偈颂：30-32
- 标题路径：CHAPTER 7 Divisional Considerations
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Divisional Considerations · Sloka 30-32 [present] · PDF page 23

30-32. Dasha effects with Vimshopak Bal: Maitreya, after
assessing the Vimshopak Bal through the various divisions,
the rising and setting of the grahas be considered. The
Vimshopak Bal is classified under: Purna, Atipurna, Madhya,
Atimadhya, Heen, Atiheen, Swalpa, and Atiswalp. Thus,
should be classified the Vimshopak Bal and the Dasha period
results declared accordingly.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P023_B006_01

- 身份：正文
- PDF 页：23
- 偈颂：33-36
- 标题路径：CHAPTER 7 Divisional Considerations
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Divisional Considerations · Sloka 33-36 [present] · PDF page 23

33-36. Kendras, Konas, etc., Defined: O Maitreya, listen to
other matters which I am explaining. The Kendras are
specially known as Lagn (the ascendent), Bandhu Bhava,
Yuvati Bhava (the descendant), and Karm Bhava (mid-heaven).
Dhan, Putr, Randhr, and Labh Bhava are Panapharas (or
succedents), while Sahaj, Ari, Dharm, and Vyaya Bhava are
called Apoklimas (or cadents). Putr and Dharm Bhava are
known by the name Kon (or trine). Evil bhavas or Dusthan
Bhavas are Ari, Randhr, and Vyaya Bhava. Chaturasras are
Bandhu and Randhr Bhava. Sahaj, Ari, Karm, and Labh Bhava
are Upachaya Bhavas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P023_B007_01

- 身份：正文
- PDF 页：23
- 偈颂：37-38
- 标题路径：CHAPTER 7 Divisional Considerations
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Divisional Considerations · Sloka 37-38 [present] · PDF page 23

37-38. Names of Bhavas: Thanu, Dhan, Sahaj, Bandhu, Putr,
Ari, Yuvati, Randhr, Dharm, Karma, Labh, and Vyaya are in
order the names of bhavas. I explained these briefly and
leave it to you to grasp more according to your
intelligence. As delivered by Lord Brahma, some further
information is added thus (i.e. in the  following
verses.).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P024_B001_01

- 身份：正文
- PDF 页：24
- 偈颂：39-43
- 标题路径：CHAPTER 7 Divisional Considerations
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Divisional Considerations · Sloka 39-43 [present] · PDF page 24

39-43. Indications from Bhavas: Dharm Bhava and the 9th
from Surya deal with one's father. Whatever effects are to
be known from the Karm and Labh Bhava be also known from
similar bhavas counted from Surya. Whatever results are to
be known from Bandhu, Tanu, Dhan, Labh, and Dharm should
also be known from the 4th of Chandr, from Kark rashi
itself, and from the 2nd, 11th, and 9th from Chandr
respectively. Whatever has to be known through Sahaj Bhava
be also analyzed through the 3rd from Mangal. The 6th from
Buddh be also considered in  regard to indications
derivable from Ari Bhava. The 5th from Guru, the 7th from
Shukr, and both the 8th and 12th from Shani stand for
consideration respectively in respect of offspring, spouse,
and death. The lord of the bhava is equally important when
estimating the indications of a particular bhava.
