# 第 45 章：Avasthas of Grahas

- 来源：BPHS 97 章版
- 原始卡片：55 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P160_B002_01

- 身份：正文
- PDF 页：160
- 偈颂：1
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 1 [present] · PDF page 160

1. O Maharishi Parashar, you have earlier stated that the
Avasthas, or states, of the grahas are to be considered in
the context of the effects of the grahas. Be so kind to
tell me about this.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P160_B003_01

- 身份：正文
- PDF 页：160
- 偈颂：2
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 2 [present] · PDF page 160

2. 0 excellent of Brahmins, various kinds of Avasthas of
the grahas have been expounded. Out of these, I will give
you the summary of Baal (infant) and other states of the
grahas (in the first instance).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P160_B004_01

- 身份：正文
- PDF 页：160
- 偈颂：3
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 3 [present] · PDF page 160

3. Baal, Kumar, Yuv, Vriddh, and Mrit Avastha: Infant,
youthful, adolescent, old, and dead are the states of the
grahas placed in the ascending order at the rate of six
degrees in odd rashis.  In the case of even rashis this
arrangement is in reverse order.
(These five Avasthas are known as Baal Adi Avasthas.
For odd rashis, the placement concerned will denote the
Avastha as under:
Baal Avastha  (Infant state): O to 6 degrees
Kumar Avastha (Youthful state): 6 to 12 degrees
Yuv Avastha (Adolescent state): 12 to 18 degrees
Vriddh Avastha (Advanced state): 18 to 24 degrees
Mrit Avastha (In extremis): 24 to 30 degrees
The above order is to be reversed for placement in an even
rashi).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P160_B005_01

- 身份：正文
- PDF 页：160
- 偈颂：4
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 4 [present] · PDF page 160

4. Results: One fourth, half, full, negligible, and nil are
the grades of the results due to a grah in infant,
youthful, adolescent, old, and dead Avasthas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P160_B006_01

- 身份：正文
- PDF 页：160
- 偈颂：5
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 5 [present] · PDF page 160

5. Awakening,  Dreaming, and Sleeping States: If a grah is
in its own rashi, or in exaltation it is said to be in a
state of awakening (or alertness). In the rashi of a friend
or of a neutral rashi, it is in dreaming state, while in an
enemy's rashi, or in debilitation it is in a state of
sleeping.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P160_B007_01

- 身份：正文
- PDF 页：160
- 偈颂：6
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 6 [present] · PDF page 160

6. According to a grah being in Awakening, Dreaming or
Sleeping states, the results due to it will be full,
medium, or nil.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P160_B008_01

- 身份：正文
- PDF 页：160
- 偈颂：7
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 7 [present] · PDF page 160

7. Other Kinds of States: There are nine kinds of other
Avasthas, viz. Dipt, Swasth, Pramudit, Shanta, Din, Vikal,
Khal, and Kop.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P161_B001_01

- 身份：正文
- PDF 页：161
- 偈颂：8-10
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 8-10 [present] · PDF page 161

8-10. If a grah is in its exaltation rashi, it is in Dipt
Avastha;
if a grah is in its own rashi, it is in Swasth Avastha,
if a grah is in a great friend's rashi, it is in Pramudit
Avastha;
if a grah is in a friendly rashi, it is in Shanta Avastha;
if a grah is in a neutral rashi, it is in Din Avastha;
if a grah is  yuti with a malefic, it is in Vikal Avastha;
if a grah is in an enemy's rashi, it is in Duhkhit
Avastha;
if a grah is in a great enemy's rashi it is in Khal
Avastha;
and if a grah is being eclipsed by Surya, it is in Kop
Avastha.
Depending on such a state of the grah, the bhava occupied
by it will obtain corresponding effects.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P161_B002_01

- 身份：正文
- PDF 页：161
- 偈颂：8
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 8 [present] · PDF page 161

8. Yet Other Avasthas: Lajjit, Garvit, Kshudhit, Trushit,
Mudit, and Kshobhit are the (six) other kinds of Avasthas
due to the grahas.
Placed in Putr Bhava, if a grah is associated with Rahu or
Ketu, or with Surya, Shani, or Mangal, it is in Lajjit
Avastha.
If a grah is in exaltation or in Mooltrikon, it is Gavit
Avastha.
If a grah is in an enemy's rashi, or yuti with an enemy, or
receives a drishti from an enemy, or even if a grah is yuti
with Shani, the Avastha is Kshudhit.
If a grah is in a watery rashi and receives a drishti from
a malefic but does not receive a drishti from a benefic, the
Avastha is called Trushit.
If a grah is in a friendly rashi, or is yuti with, or
receives a drishti from a benefic, or is yuti with Guru, it
is said to be in Mudit Avastha.
If a grah is yuti with Surya and receives a drishti from,
or is yuti with a malefic, or receives a drishti from an
enemy, it is said to be in Kshobhit Avastha.
The bhavas occupied by a grah in Kshudhit Avastha or in
Kshobhit Avastha are destroyed.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P161_B003_01

- 身份：正文
- PDF 页：161
- 偈颂：19-23
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 19-23 [present] · PDF page 161

19-23. The learned should estimate the effects due to a
bhava in the manner cited above (i.e. with the help of
various kinds of Avasthas), after ascertaining the strength
and weakness (of the various grahas). Weak grahas cause
reduction in good effects ,while stronger ones give greater
effects.
If a grah posited in Karm Bhava is in Lajjit Avastha, in
Kshudhit Avastha, or in Kshobhit Avastha, the person will
always be subjected to miseries.
If a grah in Putr Bhava is in Lajjit Avastha, there will be
destruction of progeny, or there will be only one surviving
child.
Surely the wife of the native will die if there is a grah
in Yuvati Bhava in Kshobhit Avastha or in Trushit Avastha.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P162_B001_01

- 身份：正文
- PDF 页：162
- 偈颂：24-29
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 24-29 [present] · PDF page 162

24-29. Effects of Garvit, Mudit, Lajjit, Kshobhit,
Kshudhit, and Trushit Avastha: A grah in Garvit Avastha
will cause happiness through new houses and gardens,
regalhood, skill in arts, financial gains at all times, and
improvement in business.
A grah in Mudit Avastha will give residences, clothes,
ornaments, happiness from lands and wife, happiness from
relatives, living in royal places, destruction of enemies,
and acquisition of wisdom and learning.
A grah in Lajjit Avastha will give aversion to God, loss of
intelligence, loss of child, interest in evil speeches, and
listlessness in good things.
A grah in Kshobhit Avastha will give acute penury, evil
disposition, miseries, financial debacles, distress to feet
and obstruction to income due to royal wrath.
A grah in Kshudhit Avastha will cause downfall due to grief
and passion, grief on account of relatives, physical
decline, troubles from enemies, financial distress, loss of
physical strength and an eclipsed mind due to miseries.
A grah in Trushit Avastha will cause diseases through
association with females, leading over wicked (or evil)
deeds, loss of wealth due to ones own men, physical
weakness, miseries caused by evil people, and decline of
honour.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P162_B001_02

- 身份：正文
- PDF 页：162
- 偈颂：24-29
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 24-29 [present] · PDF page 162

24-29. Effects of Garvit, Mudit, Lajjit, Kshobhit,
Kshudhit, and Trushit Avastha: A grah in Garvit Avastha
will cause happiness through new houses and gardens,
regalhood, skill in arts, financial gains at all times, and
improvement in business.
A grah in Mudit Avastha will give residences, clothes,
ornaments, happiness from lands and wife, happiness from
relatives, living in royal places, destruction of enemies,
and acquisition of wisdom and learning.
A grah in Lajjit Avastha will give aversion to God, loss of
intelligence, loss of child, interest in evil speeches, and
listlessness in good things.
A grah in Kshobhit Avastha will give acute penury, evil
disposition, miseries, financial debacles, distress to feet
and obstruction to income due to royal wrath.
A grah in Kshudhit Avastha will cause downfall due to grief
and passion, grief on account of relatives, physical
decline, troubles from enemies, financial distress, loss of
physical strength and an eclipsed mind due to miseries.
A grah in Trushit Avastha will cause diseases through
association with females, leading over wicked (or evil)
deeds, loss of wealth due to ones own men, physical
weakness, miseries caused by evil people, and decline of
honour.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P163_B001_01

- 身份：正文
- PDF 页：163
- 偈颂：30-37
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 30-37 [present] · PDF page 163

30-37. Calculation of Shayan and Other Avasthas: Now, I
will  tell you of the  Avasthas viz. Shayan, Upavesan,
Netrapani, Prakash, Gaman, Agaman, Sabh, Agam, Bhojan,
Nritya Lips, Kautuk, and Nidr, and the Chesthas of such
Avasthas. Note the number of the stars (from Ashvini)
occupied by the grah for which an Avastha is to be
calculated. Multiply that number by the number denoted by
the grah (Surya 1, Chandr 2, Mangal 3, Buddh 4, Guru 5,
Shukr 6, and Shani 7). The figure so arrived at should
again be multiplied by the number of the Navamsh where the
grah is in. Add to this the number of the birth asterism,
the number of ghatis of birth, and the number of rashis
Lagn gained from Mesh. This figure should be divided by 12
and the remainder will indicate the corresponding Avastha
of the grah. The sub state in the said Avastha can be found
out in the following way: Multiply the figure denoted by
the Avastha concerned (i.e. Sayan 1, Upavesan 2, Netrapani
3, Prakash 4, Gaman 5, Agaman 6, Sabh 7, Agam 8, Bhojan 9,
Nritya Lips 10, Kautuk 11, and Nidr 12) by the same figure
and increase it by the figure denoted by the Anka value for
the first syllable of the native's personal name. Divide
the product so obtained by 12. The remainder there of
should be further increased by constant additives of the
grahas in the following way: Surya 5, Chandr 2, Mangal 2,
Buddh 3, Guru 5, Shukr 3, Shani 3, Rahu 4 (and Ketu 4).
(Here the grah means the one for whom the sub state is
being known.) The product so arrived at should be divided
by 3. In the process of calculation if it happens that the
remainder is 1, it is Drishti, if the remainder is 2, it is
Chesht, and if the remainder is 0, it is Vichesht.
Notes: So far narrated are three different groups of
Avasthas. The present Avasthas are called Shayan Adi
Avasthas. These are of supreme importance as compared to
the other kinds of  Avasthas..
The following formula may be adopted to know about the
grah's Avastha (Sayan Adi) at birth:
(s x p x n) + (a + g + r)
-------------------------    =  Avastha
12
Where as 's' denotes the serial number of the star occupied
by the grah, counted from Ashvini at birth; 'p' denotes the
status of the grah counted from Surya (i.e. Surya 1,
Chandr 2, Mangal 3, Buddh 4, Guru 5, Shukr 6, Shani 7); 'n'
denotes the grah's Navamsh position (i.e. 1 to 9
Navamshas); 'a' denotes Janm Nakshatr (or ruling star, i.e.
the one occupied by Chandr); 'g' denotes the ghati in which
birth took place (i. e. 20 ghatis 2 vighatis is 21 ghatis);
and 'r' denotes Lagn 's order counted from Mesh (i.e. Mesh
1, Vrishabh 2, Kark 4, Simh 5, and so on and so forth).
In place of 'n' given above, some translators interpret the
word 'Amsh' as degree occupied by the grah which is
obviously not correct. In this connection, the reader's
attention is drawn to Balabhadr's Hora Ratna, ch 3 wherein
the author Balabhadr himself gives an example for Surya
being in the 7th Navamsh of Simh and thus he considered
only 7 as multiplier. He has not taken in to account
Surya's degree. He quotes Adhibhut Sagara as his authority
for calculation of Sayan Adi Avasthas. It will thus be
clear that Amsh is Navamsh and not degree in this context.
Also please note that Agaman Avastha (the 6th one) is known
as Gamanechch Avastha by some exponents.
Take a case now as an example with the following data:
Surya in Kritika Nakshatr, 3rd Navamsh of Vrishabh (i.e. in
7 degrees 12' Vrishabh), the birth star is Kritika, birth
is at 30 ghatis 33 vighatis, and Lagn is in Vrischik. With
these we produce the following information, keeping the
formula given above.
s = 3, p = 1, n = 3; a = 3, g = 31, r = 8.
Hence to find out the  Avastha,
(3 x 1 x 3) + (3 + 31 + 8)   51
-----------------------  =  ---- ; the remainder = 3
12                          12
With the help of remainder 3, we count three Avasthas from
Sayan. This indicates Netrapani Avastha for Surya.
Similarly, for 9 grahas, such Avasthas can be found out. In
a given horoscope, the factors 'a', 'g', and 'r' will be
identical for all the 9 grahas, while factors 's', 'p', and
'n' will be variable.
After knowing the  Avasthas of various grahas, we have to
find out the sub-state of each Avastha. The formula for
knowing the sub-state is made in two stages, as under:
Stage 1:  (A x A) + fs
------------ = R
12
Stage 2:   (R + pa) : 3 = sub-state of an Avastha
Where 'A' is  Avastha, 'f' is first syllable's value with
reference to the native's personal name, R is remainder in
stage 1, and 'pa' is the additives of the grah denoted in
the above slokas, such as Surya 5, Shukr 3, etc.. The
remainder at stage 2 will denote the sub-state such as 1 is
Drishti, 2 is Chesht, and 0 is Vichesht.
We need information about the Anka value, or value for the
first syllable of the name of a person. This value is:
1 for a, ka, cha, da (retroflex), and va;
2 for i, kha, ja, da (dental), and sha;
3 for u, ga, jha, ta (dental), pa, ya, and sha;
4 for e, gha, ta (retroflex), tha (dental), pha,
ra, and ma;
5 for o, ca, tha (retroflex), da (dental), and
ha.
Now with the above data, find the sub-state for Surya in
Netrapani  Avastha as per the example given supra. First
syllable of the name is "Sa". Hence,
(3 x 3) + 4
Stage 1: ----------  = Remainder 1
12
(1 + 5)
Stage 2: -------  = 0
3
Remainder zero indicates sub-state as Vichesht, in
Netrapani Avastha.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P163_B001_02

- 身份：正文
- PDF 页：163
- 偈颂：30-37
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 30-37 [present] · PDF page 163

30-37. Calculation of Shayan and Other Avasthas: Now, I
will  tell you of the  Avasthas viz. Shayan, Upavesan,
Netrapani, Prakash, Gaman, Agaman, Sabh, Agam, Bhojan,
Nritya Lips, Kautuk, and Nidr, and the Chesthas of such
Avasthas. Note the number of the stars (from Ashvini)
occupied by the grah for which an Avastha is to be
calculated. Multiply that number by the number denoted by
the grah (Surya 1, Chandr 2, Mangal 3, Buddh 4, Guru 5,
Shukr 6, and Shani 7). The figure so arrived at should
again be multiplied by the number of the Navamsh where the
grah is in. Add to this the number of the birth asterism,
the number of ghatis of birth, and the number of rashis
Lagn gained from Mesh. This figure should be divided by 12
and the remainder will indicate the corresponding Avastha
of the grah. The sub state in the said Avastha can be found
out in the following way: Multiply the figure denoted by
the Avastha concerned (i.e. Sayan 1, Upavesan 2, Netrapani
3, Prakash 4, Gaman 5, Agaman 6, Sabh 7, Agam 8, Bhojan 9,
Nritya Lips 10, Kautuk 11, and Nidr 12) by the same figure
and increase it by the figure denoted by the Anka value for
the first syllable of the native's personal name. Divide
the product so obtained by 12. The remainder there of
should be further increased by constant additives of the
grahas in the following way: Surya 5, Chandr 2, Mangal 2,
Buddh 3, Guru 5, Shukr 3, Shani 3, Rahu 4 (and Ketu 4).
(Here the grah means the one for whom the sub state is
being known.) The product so arrived at should be divided
by 3. In the process of calculation if it happens that the
remainder is 1, it is Drishti, if the remainder is 2, it is
Chesht, and if the remainder is 0, it is Vichesht.
Notes: So far narrated are three different groups of
Avasthas. The present Avasthas are called Shayan Adi
Avasthas. These are of supreme importance as compared to
the other kinds of  Avasthas..
The following formula may be adopted to know about the
grah's Avastha (Sayan Adi) at birth:
(s x p x n) + (a + g + r)
-------------------------    =  Avastha
12
Where as 's' denotes the serial number of the star occupied
by the grah, counted from Ashvini at birth; 'p' denotes the
status of the grah counted from Surya (i.e. Surya 1,
Chandr 2, Mangal 3, Buddh 4, Guru 5, Shukr 6, Shani 7); 'n'
denotes the grah's Navamsh position (i.e. 1 to 9
Navamshas); 'a' denotes Janm Nakshatr (or ruling star, i.e.
the one occupied by Chandr); 'g' denotes the ghati in which
birth took place (i. e. 20 ghatis 2 vighatis is 21 ghatis);
and 'r' denotes Lagn 's order counted from Mesh (i.e. Mesh
1, Vrishabh 2, Kark 4, Simh 5, and so on and so forth).
In place of 'n' given above, some translators interpret the
word 'Amsh' as degree occupied by the grah which is
obviously not correct. In this connection, the reader's
attention is drawn to Balabhadr's Hora Ratna, ch 3 wherein
the author Balabhadr himself gives an example for Surya
being in the 7th Navamsh of Simh and thus he considered
only 7 as multiplier. He has not taken in to account
Surya's degree. He quotes Adhibhut Sagara as his authority
for calculation of Sayan Adi Avasthas. It will thus be
clear that Amsh is Navamsh and not degree in this context.
Also please note that Agaman Avastha (the 6th one) is known
as Gamanechch Avastha by some exponents.
Take a case now as an example with the following data:
Surya in Kritika Nakshatr, 3rd Navamsh of Vrishabh (i.e. in
7 degrees 12' Vrishabh), the birth star is Kritika, birth
is at 30 ghatis 33 vighatis, and Lagn is in Vrischik. With
these we produce the following information, keeping the
formula given above.
s = 3, p = 1, n = 3; a = 3, g = 31, r = 8.
Hence to find out the  Avastha,
(3 x 1 x 3) + (3 + 31 + 8)   51
-----------------------  =  ---- ; the remainder = 3
12                          12
With the help of remainder 3, we count three Avasthas from
Sayan. This indicates Netrapani Avastha for Surya.
Similarly, for 9 grahas, such Avasthas can be found out. In
a given horoscope, the factors 'a', 'g', and 'r' will be
identical for all the 9 grahas, while factors 's', 'p', and
'n' will be variable.
After knowing the  Avasthas of various grahas, we have to
find out the sub-state of each Avastha. The formula for
knowing the sub-state is made in two stages, as under:
Stage 1:  (A x A) + fs
------------ = R
12
Stage 2:   (R + pa) : 3 = sub-state of an Avastha
Where 'A' is  Avastha, 'f' is first syllable's value with
reference to the native's personal name, R is remainder in
stage 1, and 'pa' is the additives of the grah denoted in
the above slokas, such as Surya 5, Shukr 3, etc.. The
remainder at stage 2 will denote the sub-state such as 1 is
Drishti, 2 is Chesht, and 0 is Vichesht.
We need information about the Anka value, or value for the
first syllable of the name of a person. This value is:
1 for a, ka, cha, da (retroflex), and va;
2 for i, kha, ja, da (dental), and sha;
3 for u, ga, jha, ta (dental), pa, ya, and sha;
4 for e, gha, ta (retroflex), tha (dental), pha,
ra, and ma;
5 for o, ca, tha (retroflex), da (dental), and
ha.
Now with the above data, find the sub-state for Surya in
Netrapani  Avastha as per the example given supra. First
syllable of the name is "Sa". Hence,
(3 x 3) + 4
Stage 1: ----------  = Remainder 1
12
(1 + 5)
Stage 2: -------  = 0
3
Remainder zero indicates sub-state as Vichesht, in
Netrapani Avastha.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P163_B001_03

- 身份：正文
- PDF 页：163
- 偈颂：30-37
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 30-37 [present] · PDF page 163

30-37. Calculation of Shayan and Other Avasthas: Now, I
will  tell you of the  Avasthas viz. Shayan, Upavesan,
Netrapani, Prakash, Gaman, Agaman, Sabh, Agam, Bhojan,
Nritya Lips, Kautuk, and Nidr, and the Chesthas of such
Avasthas. Note the number of the stars (from Ashvini)
occupied by the grah for which an Avastha is to be
calculated. Multiply that number by the number denoted by
the grah (Surya 1, Chandr 2, Mangal 3, Buddh 4, Guru 5,
Shukr 6, and Shani 7). The figure so arrived at should
again be multiplied by the number of the Navamsh where the
grah is in. Add to this the number of the birth asterism,
the number of ghatis of birth, and the number of rashis
Lagn gained from Mesh. This figure should be divided by 12
and the remainder will indicate the corresponding Avastha
of the grah. The sub state in the said Avastha can be found
out in the following way: Multiply the figure denoted by
the Avastha concerned (i.e. Sayan 1, Upavesan 2, Netrapani
3, Prakash 4, Gaman 5, Agaman 6, Sabh 7, Agam 8, Bhojan 9,
Nritya Lips 10, Kautuk 11, and Nidr 12) by the same figure
and increase it by the figure denoted by the Anka value for
the first syllable of the native's personal name. Divide
the product so obtained by 12. The remainder there of
should be further increased by constant additives of the
grahas in the following way: Surya 5, Chandr 2, Mangal 2,
Buddh 3, Guru 5, Shukr 3, Shani 3, Rahu 4 (and Ketu 4).
(Here the grah means the one for whom the sub state is
being known.) The product so arrived at should be divided
by 3. In the process of calculation if it happens that the
remainder is 1, it is Drishti, if the remainder is 2, it is
Chesht, and if the remainder is 0, it is Vichesht.
Notes: So far narrated are three different groups of
Avasthas. The present Avasthas are called Shayan Adi
Avasthas. These are of supreme importance as compared to
the other kinds of  Avasthas..
The following formula may be adopted to know about the
grah's Avastha (Sayan Adi) at birth:
(s x p x n) + (a + g + r)
-------------------------    =  Avastha
12
Where as 's' denotes the serial number of the star occupied
by the grah, counted from Ashvini at birth; 'p' denotes the
status of the grah counted from Surya (i.e. Surya 1,
Chandr 2, Mangal 3, Buddh 4, Guru 5, Shukr 6, Shani 7); 'n'
denotes the grah's Navamsh position (i.e. 1 to 9
Navamshas); 'a' denotes Janm Nakshatr (or ruling star, i.e.
the one occupied by Chandr); 'g' denotes the ghati in which
birth took place (i. e. 20 ghatis 2 vighatis is 21 ghatis);
and 'r' denotes Lagn 's order counted from Mesh (i.e. Mesh
1, Vrishabh 2, Kark 4, Simh 5, and so on and so forth).
In place of 'n' given above, some translators interpret the
word 'Amsh' as degree occupied by the grah which is
obviously not correct. In this connection, the reader's
attention is drawn to Balabhadr's Hora Ratna, ch 3 wherein
the author Balabhadr himself gives an example for Surya
being in the 7th Navamsh of Simh and thus he considered
only 7 as multiplier. He has not taken in to account
Surya's degree. He quotes Adhibhut Sagara as his authority
for calculation of Sayan Adi Avasthas. It will thus be
clear that Amsh is Navamsh and not degree in this context.
Also please note that Agaman Avastha (the 6th one) is known
as Gamanechch Avastha by some exponents.
Take a case now as an example with the following data:
Surya in Kritika Nakshatr, 3rd Navamsh of Vrishabh (i.e. in
7 degrees 12' Vrishabh), the birth star is Kritika, birth
is at 30 ghatis 33 vighatis, and Lagn is in Vrischik. With
these we produce the following information, keeping the
formula given above.
s = 3, p = 1, n = 3; a = 3, g = 31, r = 8.
Hence to find out the  Avastha,
(3 x 1 x 3) + (3 + 31 + 8)   51
-----------------------  =  ---- ; the remainder = 3
12                          12
With the help of remainder 3, we count three Avasthas from
Sayan. This indicates Netrapani Avastha for Surya.
Similarly, for 9 grahas, such Avasthas can be found out. In
a given horoscope, the factors 'a', 'g', and 'r' will be
identical for all the 9 grahas, while factors 's', 'p', and
'n' will be variable.
After knowing the  Avasthas of various grahas, we have to
find out the sub-state of each Avastha. The formula for
knowing the sub-state is made in two stages, as under:
Stage 1:  (A x A) + fs
------------ = R
12
Stage 2:   (R + pa) : 3 = sub-state of an Avastha
Where 'A' is  Avastha, 'f' is first syllable's value with
reference to the native's personal name, R is remainder in
stage 1, and 'pa' is the additives of the grah denoted in
the above slokas, such as Surya 5, Shukr 3, etc.. The
remainder at stage 2 will denote the sub-state such as 1 is
Drishti, 2 is Chesht, and 0 is Vichesht.
We need information about the Anka value, or value for the
first syllable of the name of a person. This value is:
1 for a, ka, cha, da (retroflex), and va;
2 for i, kha, ja, da (dental), and sha;
3 for u, ga, jha, ta (dental), pa, ya, and sha;
4 for e, gha, ta (retroflex), tha (dental), pha,
ra, and ma;
5 for o, ca, tha (retroflex), da (dental), and
ha.
Now with the above data, find the sub-state for Surya in
Netrapani  Avastha as per the example given supra. First
syllable of the name is "Sa". Hence,
(3 x 3) + 4
Stage 1: ----------  = Remainder 1
12
(1 + 5)
Stage 2: -------  = 0
3
Remainder zero indicates sub-state as Vichesht, in
Netrapani Avastha.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P163_B001_04

- 身份：正文
- PDF 页：163
- 偈颂：30-37
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 30-37 [present] · PDF page 163

30-37. Calculation of Shayan and Other Avasthas: Now, I
will  tell you of the  Avasthas viz. Shayan, Upavesan,
Netrapani, Prakash, Gaman, Agaman, Sabh, Agam, Bhojan,
Nritya Lips, Kautuk, and Nidr, and the Chesthas of such
Avasthas. Note the number of the stars (from Ashvini)
occupied by the grah for which an Avastha is to be
calculated. Multiply that number by the number denoted by
the grah (Surya 1, Chandr 2, Mangal 3, Buddh 4, Guru 5,
Shukr 6, and Shani 7). The figure so arrived at should
again be multiplied by the number of the Navamsh where the
grah is in. Add to this the number of the birth asterism,
the number of ghatis of birth, and the number of rashis
Lagn gained from Mesh. This figure should be divided by 12
and the remainder will indicate the corresponding Avastha
of the grah. The sub state in the said Avastha can be found
out in the following way: Multiply the figure denoted by
the Avastha concerned (i.e. Sayan 1, Upavesan 2, Netrapani
3, Prakash 4, Gaman 5, Agaman 6, Sabh 7, Agam 8, Bhojan 9,
Nritya Lips 10, Kautuk 11, and Nidr 12) by the same figure
and increase it by the figure denoted by the Anka value for
the first syllable of the native's personal name. Divide
the product so obtained by 12. The remainder there of
should be further increased by constant additives of the
grahas in the following way: Surya 5, Chandr 2, Mangal 2,
Buddh 3, Guru 5, Shukr 3, Shani 3, Rahu 4 (and Ketu 4).
(Here the grah means the one for whom the sub state is
being known.) The product so arrived at should be divided
by 3. In the process of calculation if it happens that the
remainder is 1, it is Drishti, if the remainder is 2, it is
Chesht, and if the remainder is 0, it is Vichesht.
Notes: So far narrated are three different groups of
Avasthas. The present Avasthas are called Shayan Adi
Avasthas. These are of supreme importance as compared to
the other kinds of  Avasthas..
The following formula may be adopted to know about the
grah's Avastha (Sayan Adi) at birth:
(s x p x n) + (a + g + r)
-------------------------    =  Avastha
12
Where as 's' denotes the serial number of the star occupied
by the grah, counted from Ashvini at birth; 'p' denotes the
status of the grah counted from Surya (i.e. Surya 1,
Chandr 2, Mangal 3, Buddh 4, Guru 5, Shukr 6, Shani 7); 'n'
denotes the grah's Navamsh position (i.e. 1 to 9
Navamshas); 'a' denotes Janm Nakshatr (or ruling star, i.e.
the one occupied by Chandr); 'g' denotes the ghati in which
birth took place (i. e. 20 ghatis 2 vighatis is 21 ghatis);
and 'r' denotes Lagn 's order counted from Mesh (i.e. Mesh
1, Vrishabh 2, Kark 4, Simh 5, and so on and so forth).
In place of 'n' given above, some translators interpret the
word 'Amsh' as degree occupied by the grah which is
obviously not correct. In this connection, the reader's
attention is drawn to Balabhadr's Hora Ratna, ch 3 wherein
the author Balabhadr himself gives an example for Surya
being in the 7th Navamsh of Simh and thus he considered
only 7 as multiplier. He has not taken in to account
Surya's degree. He quotes Adhibhut Sagara as his authority
for calculation of Sayan Adi Avasthas. It will thus be
clear that Amsh is Navamsh and not degree in this context.
Also please note that Agaman Avastha (the 6th one) is known
as Gamanechch Avastha by some exponents.
Take a case now as an example with the following data:
Surya in Kritika Nakshatr, 3rd Navamsh of Vrishabh (i.e. in
7 degrees 12' Vrishabh), the birth star is Kritika, birth
is at 30 ghatis 33 vighatis, and Lagn is in Vrischik. With
these we produce the following information, keeping the
formula given above.
s = 3, p = 1, n = 3; a = 3, g = 31, r = 8.
Hence to find out the  Avastha,
(3 x 1 x 3) + (3 + 31 + 8)   51
-----------------------  =  ---- ; the remainder = 3
12                          12
With the help of remainder 3, we count three Avasthas from
Sayan. This indicates Netrapani Avastha for Surya.
Similarly, for 9 grahas, such Avasthas can be found out. In
a given horoscope, the factors 'a', 'g', and 'r' will be
identical for all the 9 grahas, while factors 's', 'p', and
'n' will be variable.
After knowing the  Avasthas of various grahas, we have to
find out the sub-state of each Avastha. The formula for
knowing the sub-state is made in two stages, as under:
Stage 1:  (A x A) + fs
------------ = R
12
Stage 2:   (R + pa) : 3 = sub-state of an Avastha
Where 'A' is  Avastha, 'f' is first syllable's value with
reference to the native's personal name, R is remainder in
stage 1, and 'pa' is the additives of the grah denoted in
the above slokas, such as Surya 5, Shukr 3, etc.. The
remainder at stage 2 will denote the sub-state such as 1 is
Drishti, 2 is Chesht, and 0 is Vichesht.
We need information about the Anka value, or value for the
first syllable of the name of a person. This value is:
1 for a, ka, cha, da (retroflex), and va;
2 for i, kha, ja, da (dental), and sha;
3 for u, ga, jha, ta (dental), pa, ya, and sha;
4 for e, gha, ta (retroflex), tha (dental), pha,
ra, and ma;
5 for o, ca, tha (retroflex), da (dental), and
ha.
Now with the above data, find the sub-state for Surya in
Netrapani  Avastha as per the example given supra. First
syllable of the name is "Sa". Hence,
(3 x 3) + 4
Stage 1: ----------  = Remainder 1
12
(1 + 5)
Stage 2: -------  = 0
3
Remainder zero indicates sub-state as Vichesht, in
Netrapani Avastha.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P163_B001_05

- 身份：正文
- PDF 页：163
- 偈颂：30-37
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 30-37 [present] · PDF page 163

30-37. Calculation of Shayan and Other Avasthas: Now, I
will  tell you of the  Avasthas viz. Shayan, Upavesan,
Netrapani, Prakash, Gaman, Agaman, Sabh, Agam, Bhojan,
Nritya Lips, Kautuk, and Nidr, and the Chesthas of such
Avasthas. Note the number of the stars (from Ashvini)
occupied by the grah for which an Avastha is to be
calculated. Multiply that number by the number denoted by
the grah (Surya 1, Chandr 2, Mangal 3, Buddh 4, Guru 5,
Shukr 6, and Shani 7). The figure so arrived at should
again be multiplied by the number of the Navamsh where the
grah is in. Add to this the number of the birth asterism,
the number of ghatis of birth, and the number of rashis
Lagn gained from Mesh. This figure should be divided by 12
and the remainder will indicate the corresponding Avastha
of the grah. The sub state in the said Avastha can be found
out in the following way: Multiply the figure denoted by
the Avastha concerned (i.e. Sayan 1, Upavesan 2, Netrapani
3, Prakash 4, Gaman 5, Agaman 6, Sabh 7, Agam 8, Bhojan 9,
Nritya Lips 10, Kautuk 11, and Nidr 12) by the same figure
and increase it by the figure denoted by the Anka value for
the first syllable of the native's personal name. Divide
the product so obtained by 12. The remainder there of
should be further increased by constant additives of the
grahas in the following way: Surya 5, Chandr 2, Mangal 2,
Buddh 3, Guru 5, Shukr 3, Shani 3, Rahu 4 (and Ketu 4).
(Here the grah means the one for whom the sub state is
being known.) The product so arrived at should be divided
by 3. In the process of calculation if it happens that the
remainder is 1, it is Drishti, if the remainder is 2, it is
Chesht, and if the remainder is 0, it is Vichesht.
Notes: So far narrated are three different groups of
Avasthas. The present Avasthas are called Shayan Adi
Avasthas. These are of supreme importance as compared to
the other kinds of  Avasthas..
The following formula may be adopted to know about the
grah's Avastha (Sayan Adi) at birth:
(s x p x n) + (a + g + r)
-------------------------    =  Avastha
12
Where as 's' denotes the serial number of the star occupied
by the grah, counted from Ashvini at birth; 'p' denotes the
status of the grah counted from Surya (i.e. Surya 1,
Chandr 2, Mangal 3, Buddh 4, Guru 5, Shukr 6, Shani 7); 'n'
denotes the grah's Navamsh position (i.e. 1 to 9
Navamshas); 'a' denotes Janm Nakshatr (or ruling star, i.e.
the one occupied by Chandr); 'g' denotes the ghati in which
birth took place (i. e. 20 ghatis 2 vighatis is 21 ghatis);
and 'r' denotes Lagn 's order counted from Mesh (i.e. Mesh
1, Vrishabh 2, Kark 4, Simh 5, and so on and so forth).
In place of 'n' given above, some translators interpret the
word 'Amsh' as degree occupied by the grah which is
obviously not correct. In this connection, the reader's
attention is drawn to Balabhadr's Hora Ratna, ch 3 wherein
the author Balabhadr himself gives an example for Surya
being in the 7th Navamsh of Simh and thus he considered
only 7 as multiplier. He has not taken in to account
Surya's degree. He quotes Adhibhut Sagara as his authority
for calculation of Sayan Adi Avasthas. It will thus be
clear that Amsh is Navamsh and not degree in this context.
Also please note that Agaman Avastha (the 6th one) is known
as Gamanechch Avastha by some exponents.
Take a case now as an example with the following data:
Surya in Kritika Nakshatr, 3rd Navamsh of Vrishabh (i.e. in
7 degrees 12' Vrishabh), the birth star is Kritika, birth
is at 30 ghatis 33 vighatis, and Lagn is in Vrischik. With
these we produce the following information, keeping the
formula given above.
s = 3, p = 1, n = 3; a = 3, g = 31, r = 8.
Hence to find out the  Avastha,
(3 x 1 x 3) + (3 + 31 + 8)   51
-----------------------  =  ---- ; the remainder = 3
12                          12
With the help of remainder 3, we count three Avasthas from
Sayan. This indicates Netrapani Avastha for Surya.
Similarly, for 9 grahas, such Avasthas can be found out. In
a given horoscope, the factors 'a', 'g', and 'r' will be
identical for all the 9 grahas, while factors 's', 'p', and
'n' will be variable.
After knowing the  Avasthas of various grahas, we have to
find out the sub-state of each Avastha. The formula for
knowing the sub-state is made in two stages, as under:
Stage 1:  (A x A) + fs
------------ = R
12
Stage 2:   (R + pa) : 3 = sub-state of an Avastha
Where 'A' is  Avastha, 'f' is first syllable's value with
reference to the native's personal name, R is remainder in
stage 1, and 'pa' is the additives of the grah denoted in
the above slokas, such as Surya 5, Shukr 3, etc.. The
remainder at stage 2 will denote the sub-state such as 1 is
Drishti, 2 is Chesht, and 0 is Vichesht.
We need information about the Anka value, or value for the
first syllable of the name of a person. This value is:
1 for a, ka, cha, da (retroflex), and va;
2 for i, kha, ja, da (dental), and sha;
3 for u, ga, jha, ta (dental), pa, ya, and sha;
4 for e, gha, ta (retroflex), tha (dental), pha,
ra, and ma;
5 for o, ca, tha (retroflex), da (dental), and
ha.
Now with the above data, find the sub-state for Surya in
Netrapani  Avastha as per the example given supra. First
syllable of the name is "Sa". Hence,
(3 x 3) + 4
Stage 1: ----------  = Remainder 1
12
(1 + 5)
Stage 2: -------  = 0
3
Remainder zero indicates sub-state as Vichesht, in
Netrapani Avastha.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P164_B001_01

- 身份：正文
- PDF 页：164
- 偈颂：38-39
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 38-39 [present] · PDF page 164

38-39. Effects of Chesht, etc. : If the sub-state is
Drishti in an  Avastha, the results being stated for the
Avastha will be medium; the effects will be full in Chesht,
and negligible in Vichesht. The good and bad effects of
grahas should be deciphered based on the strength and
weakness of the grahas. In exaltation, the grahas reveal
effects in a pronounced manner due to (good) Avasthas.
~1ISy~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P165_B001_01

- 身份：正文
- PDF 页：165
- 偈颂：40-51
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 40-51 [present] · PDF page 165

40-51. Effects of Surya's Avasthas at Birth: If Surya is in
Sayan Avastha, the native will incur digestive deficiency,
many diseases, stoutness of legs, bilious vitiation, ulcer
in the anus, and heart strokes.
~1ISu~n
If Surya is in Upavesan Avastha, the native will suffer
poverty, will carry loads, will indulge in litigations, be
hard-hearted, wicked, and will lose in his undertakings.
~1ISn~
If Surya is in Netrapani  Avastha, the native will always
be happy, wise, helpful to others, endowed with prowess,
and wealth, very happy, and will gain royal favours.
~1ISp~
If Surya is in Prakash Avastha, the native will be liberal
in disposition, will have plenty of wealth, will be a
significant speaker in the assembly, will perform many
meritorious acts, will be greatly strong, and will be
endowed with charming beauty.
~1ISg~n
If Surya is in Gaman Avastha the native will be disposed to
live in foreign places; he will be miserable, indolent,
bereft of intelligence and wealth; he will be distressed
due to fear and he will be short-tempered.
~1ISa~n
If Surya is in Agaman Avastha, the native will be
interested in others' wives; he will be devoid of his own
men, he will be interested in movements and skilful in
doing evil deeds; he will be dirty, ill-disposed and he
will be a tale bearer.
~1ISb~
If Surya is in Sabh Avastha, the native will be disposed to
help others; he will be always endowed with wealth and
gems; he will be virtuous, endowed with lands, new houses
and robes; he will be very strong, very affectionate to his
friends, and very kindly disposed.
~1ISv~n
If Surya is in Agam Avastha, the native will be distressed
due to enemies, fickle-minded, evil-minded, emaciated,
devoid of virtuous acts and intoxicated with pride.
~1ISh~n
If Surya is in Bhojan Avastha, the native will experience
pains in joints; he will lose money on account of others'
females, he will have strength declining off and on; he
will be untruthful, will incur head-aches, will eat remnant
food, and will take to bad ways.
~1ISt~
If Surya is in Nritya Lips Avastha, the native will be
honoured by the learned; he will be a scholar, will have
knowledge of poetry, etc., and he will be adored by kings
on the earth.
~1ISk~m
If Surya is in Kautuk Avastha, the native will always be
happy; he will be endowed with Vedic Knowledge and he will
perform Yagyas; he will move amidst kings, will have fear
from enemies; he will be charming-faced and he will be
endowed with knowledge of poetry.
~1ISi~n
If Surya is in Nidr Avastha, the native will  have a strong
tendency towards being drowsy; he will live in foreign (or
distant) places; he will incur harm to his wife and will
face financial destruction.
~1ISu~n
Surya in Upavesan Avastha will make one an artisan, black
in complexion, devoid of learning and miserable. One will
serve others.
~1ISn*1I5+1ISn*1I9+1ISn*1I7+1ISn*1I10~
In Netrapani Avastha there will be all kinds of happiness,
if Surya is in Putr, Dharm, Karm, or Yuvati Bhava.
~1ISn**-1I5*-1I9*-1I10+-1I7~n
In other bhavas (i.e. not in Putr, Dharm, Karm, or Yuvati
Bhava), Netrapani Avastha of Surya will give eye diseases
and enmity with all.
~1ISp~
If Surya is in Prakash Avastha, the native will be
meritorious, religious, and  liberal; he will enjoy
pleasures, will be equal to a prince, and will enjoy the
status of Kuber, the God of wealth.
~1ISp*1I7+1ISp*1I5~n
However, the Prakash Avastha of Surya placed in Yuvati, or
Putr Bhava will cause loss of the first child and will
produce many litigations.
~1ISg~n
If Surya is in Gaman Avastha, the native will incur disease
of the feet and he will be very mean.
~1ISa*1I12+1ISa*1I7~n
If in Agaman Avastha, Surya in Vyaya or in Yuvati Bhava
will destroy progeny and will give very limited wealth.
~1ISv~m
If in Agam Avastha, Surya will give many miseries, an ugly
appearance, and foolishness. However, he will give wealth.
~1ISh*1I9~n
Surya in Bhojan Avastha in Dharm Bhava will cause many
hindrances to spiritual and religious undertakings.
~1ISh*-1I9~n
In other bhavas (i.e. other than Dharm Bhava), Surya in
Bhojan Avastha will cause head and ear diseases, apart from
joint pains.
~1ISk*1I6~n
Though Maharishi Parashar states that the native with Surya
in Kautuk Avastha will have fear from enemies Bal Bhadr
exempts such evil effect for the Ari Bhava position.
~1ISk*-1I6~
Surya in Kautuk Avastha in other bhavas (i.e. not in Ari
Bhava), will give a number of daughters, two wives, itch,
excellence, liberality, etc..
~1ISi~n
If Surya is in Nidr Avastha, the native will be predisposed
to incur piles and elephantiasis; he will experience a lack
of peace; and he will be liable to lose his first child.
~2ISy~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P165_B001_02

- 身份：正文
- PDF 页：165
- 偈颂：40-51
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 40-51 [present] · PDF page 165

40-51. Effects of Surya's Avasthas at Birth: If Surya is in
Sayan Avastha, the native will incur digestive deficiency,
many diseases, stoutness of legs, bilious vitiation, ulcer
in the anus, and heart strokes.
~1ISu~n
If Surya is in Upavesan Avastha, the native will suffer
poverty, will carry loads, will indulge in litigations, be
hard-hearted, wicked, and will lose in his undertakings.
~1ISn~
If Surya is in Netrapani  Avastha, the native will always
be happy, wise, helpful to others, endowed with prowess,
and wealth, very happy, and will gain royal favours.
~1ISp~
If Surya is in Prakash Avastha, the native will be liberal
in disposition, will have plenty of wealth, will be a
significant speaker in the assembly, will perform many
meritorious acts, will be greatly strong, and will be
endowed with charming beauty.
~1ISg~n
If Surya is in Gaman Avastha the native will be disposed to
live in foreign places; he will be miserable, indolent,
bereft of intelligence and wealth; he will be distressed
due to fear and he will be short-tempered.
~1ISa~n
If Surya is in Agaman Avastha, the native will be
interested in others' wives; he will be devoid of his own
men, he will be interested in movements and skilful in
doing evil deeds; he will be dirty, ill-disposed and he
will be a tale bearer.
~1ISb~
If Surya is in Sabh Avastha, the native will be disposed to
help others; he will be always endowed with wealth and
gems; he will be virtuous, endowed with lands, new houses
and robes; he will be very strong, very affectionate to his
friends, and very kindly disposed.
~1ISv~n
If Surya is in Agam Avastha, the native will be distressed
due to enemies, fickle-minded, evil-minded, emaciated,
devoid of virtuous acts and intoxicated with pride.
~1ISh~n
If Surya is in Bhojan Avastha, the native will experience
pains in joints; he will lose money on account of others'
females, he will have strength declining off and on; he
will be untruthful, will incur head-aches, will eat remnant
food, and will take to bad ways.
~1ISt~
If Surya is in Nritya Lips Avastha, the native will be
honoured by the learned; he will be a scholar, will have
knowledge of poetry, etc., and he will be adored by kings
on the earth.
~1ISk~m
If Surya is in Kautuk Avastha, the native will always be
happy; he will be endowed with Vedic Knowledge and he will
perform Yagyas; he will move amidst kings, will have fear
from enemies; he will be charming-faced and he will be
endowed with knowledge of poetry.
~1ISi~n
If Surya is in Nidr Avastha, the native will  have a strong
tendency towards being drowsy; he will live in foreign (or
distant) places; he will incur harm to his wife and will
face financial destruction.
~1ISu~n
Surya in Upavesan Avastha will make one an artisan, black
in complexion, devoid of learning and miserable. One will
serve others.
~1ISn*1I5+1ISn*1I9+1ISn*1I7+1ISn*1I10~
In Netrapani Avastha there will be all kinds of happiness,
if Surya is in Putr, Dharm, Karm, or Yuvati Bhava.
~1ISn**-1I5*-1I9*-1I10+-1I7~n
In other bhavas (i.e. not in Putr, Dharm, Karm, or Yuvati
Bhava), Netrapani Avastha of Surya will give eye diseases
and enmity with all.
~1ISp~
If Surya is in Prakash Avastha, the native will be
meritorious, religious, and  liberal; he will enjoy
pleasures, will be equal to a prince, and will enjoy the
status of Kuber, the God of wealth.
~1ISp*1I7+1ISp*1I5~n
However, the Prakash Avastha of Surya placed in Yuvati, or
Putr Bhava will cause loss of the first child and will
produce many litigations.
~1ISg~n
If Surya is in Gaman Avastha, the native will incur disease
of the feet and he will be very mean.
~1ISa*1I12+1ISa*1I7~n
If in Agaman Avastha, Surya in Vyaya or in Yuvati Bhava
will destroy progeny and will give very limited wealth.
~1ISv~m
If in Agam Avastha, Surya will give many miseries, an ugly
appearance, and foolishness. However, he will give wealth.
~1ISh*1I9~n
Surya in Bhojan Avastha in Dharm Bhava will cause many
hindrances to spiritual and religious undertakings.
~1ISh*-1I9~n
In other bhavas (i.e. other than Dharm Bhava), Surya in
Bhojan Avastha will cause head and ear diseases, apart from
joint pains.
~1ISk*1I6~n
Though Maharishi Parashar states that the native with Surya
in Kautuk Avastha will have fear from enemies Bal Bhadr
exempts such evil effect for the Ari Bhava position.
~1ISk*-1I6~
Surya in Kautuk Avastha in other bhavas (i.e. not in Ari
Bhava), will give a number of daughters, two wives, itch,
excellence, liberality, etc..
~1ISi~n
If Surya is in Nidr Avastha, the native will be predisposed
to incur piles and elephantiasis; he will experience a lack
of peace; and he will be liable to lose his first child.
~2ISy~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P165_B001_03

- 身份：正文
- PDF 页：165
- 偈颂：40-51
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 40-51 [present] · PDF page 165

40-51. Effects of Surya's Avasthas at Birth: If Surya is in
Sayan Avastha, the native will incur digestive deficiency,
many diseases, stoutness of legs, bilious vitiation, ulcer
in the anus, and heart strokes.
~1ISu~n
If Surya is in Upavesan Avastha, the native will suffer
poverty, will carry loads, will indulge in litigations, be
hard-hearted, wicked, and will lose in his undertakings.
~1ISn~
If Surya is in Netrapani  Avastha, the native will always
be happy, wise, helpful to others, endowed with prowess,
and wealth, very happy, and will gain royal favours.
~1ISp~
If Surya is in Prakash Avastha, the native will be liberal
in disposition, will have plenty of wealth, will be a
significant speaker in the assembly, will perform many
meritorious acts, will be greatly strong, and will be
endowed with charming beauty.
~1ISg~n
If Surya is in Gaman Avastha the native will be disposed to
live in foreign places; he will be miserable, indolent,
bereft of intelligence and wealth; he will be distressed
due to fear and he will be short-tempered.
~1ISa~n
If Surya is in Agaman Avastha, the native will be
interested in others' wives; he will be devoid of his own
men, he will be interested in movements and skilful in
doing evil deeds; he will be dirty, ill-disposed and he
will be a tale bearer.
~1ISb~
If Surya is in Sabh Avastha, the native will be disposed to
help others; he will be always endowed with wealth and
gems; he will be virtuous, endowed with lands, new houses
and robes; he will be very strong, very affectionate to his
friends, and very kindly disposed.
~1ISv~n
If Surya is in Agam Avastha, the native will be distressed
due to enemies, fickle-minded, evil-minded, emaciated,
devoid of virtuous acts and intoxicated with pride.
~1ISh~n
If Surya is in Bhojan Avastha, the native will experience
pains in joints; he will lose money on account of others'
females, he will have strength declining off and on; he
will be untruthful, will incur head-aches, will eat remnant
food, and will take to bad ways.
~1ISt~
If Surya is in Nritya Lips Avastha, the native will be
honoured by the learned; he will be a scholar, will have
knowledge of poetry, etc., and he will be adored by kings
on the earth.
~1ISk~m
If Surya is in Kautuk Avastha, the native will always be
happy; he will be endowed with Vedic Knowledge and he will
perform Yagyas; he will move amidst kings, will have fear
from enemies; he will be charming-faced and he will be
endowed with knowledge of poetry.
~1ISi~n
If Surya is in Nidr Avastha, the native will  have a strong
tendency towards being drowsy; he will live in foreign (or
distant) places; he will incur harm to his wife and will
face financial destruction.
~1ISu~n
Surya in Upavesan Avastha will make one an artisan, black
in complexion, devoid of learning and miserable. One will
serve others.
~1ISn*1I5+1ISn*1I9+1ISn*1I7+1ISn*1I10~
In Netrapani Avastha there will be all kinds of happiness,
if Surya is in Putr, Dharm, Karm, or Yuvati Bhava.
~1ISn**-1I5*-1I9*-1I10+-1I7~n
In other bhavas (i.e. not in Putr, Dharm, Karm, or Yuvati
Bhava), Netrapani Avastha of Surya will give eye diseases
and enmity with all.
~1ISp~
If Surya is in Prakash Avastha, the native will be
meritorious, religious, and  liberal; he will enjoy
pleasures, will be equal to a prince, and will enjoy the
status of Kuber, the God of wealth.
~1ISp*1I7+1ISp*1I5~n
However, the Prakash Avastha of Surya placed in Yuvati, or
Putr Bhava will cause loss of the first child and will
produce many litigations.
~1ISg~n
If Surya is in Gaman Avastha, the native will incur disease
of the feet and he will be very mean.
~1ISa*1I12+1ISa*1I7~n
If in Agaman Avastha, Surya in Vyaya or in Yuvati Bhava
will destroy progeny and will give very limited wealth.
~1ISv~m
If in Agam Avastha, Surya will give many miseries, an ugly
appearance, and foolishness. However, he will give wealth.
~1ISh*1I9~n
Surya in Bhojan Avastha in Dharm Bhava will cause many
hindrances to spiritual and religious undertakings.
~1ISh*-1I9~n
In other bhavas (i.e. other than Dharm Bhava), Surya in
Bhojan Avastha will cause head and ear diseases, apart from
joint pains.
~1ISk*1I6~n
Though Maharishi Parashar states that the native with Surya
in Kautuk Avastha will have fear from enemies Bal Bhadr
exempts such evil effect for the Ari Bhava position.
~1ISk*-1I6~
Surya in Kautuk Avastha in other bhavas (i.e. not in Ari
Bhava), will give a number of daughters, two wives, itch,
excellence, liberality, etc..
~1ISi~n
If Surya is in Nidr Avastha, the native will be predisposed
to incur piles and elephantiasis; he will experience a lack
of peace; and he will be liable to lose his first child.
~2ISy~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P165_B001_04

- 身份：正文
- PDF 页：165
- 偈颂：40-51
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 40-51 [present] · PDF page 165

40-51. Effects of Surya's Avasthas at Birth: If Surya is in
Sayan Avastha, the native will incur digestive deficiency,
many diseases, stoutness of legs, bilious vitiation, ulcer
in the anus, and heart strokes.
~1ISu~n
If Surya is in Upavesan Avastha, the native will suffer
poverty, will carry loads, will indulge in litigations, be
hard-hearted, wicked, and will lose in his undertakings.
~1ISn~
If Surya is in Netrapani  Avastha, the native will always
be happy, wise, helpful to others, endowed with prowess,
and wealth, very happy, and will gain royal favours.
~1ISp~
If Surya is in Prakash Avastha, the native will be liberal
in disposition, will have plenty of wealth, will be a
significant speaker in the assembly, will perform many
meritorious acts, will be greatly strong, and will be
endowed with charming beauty.
~1ISg~n
If Surya is in Gaman Avastha the native will be disposed to
live in foreign places; he will be miserable, indolent,
bereft of intelligence and wealth; he will be distressed
due to fear and he will be short-tempered.
~1ISa~n
If Surya is in Agaman Avastha, the native will be
interested in others' wives; he will be devoid of his own
men, he will be interested in movements and skilful in
doing evil deeds; he will be dirty, ill-disposed and he
will be a tale bearer.
~1ISb~
If Surya is in Sabh Avastha, the native will be disposed to
help others; he will be always endowed with wealth and
gems; he will be virtuous, endowed with lands, new houses
and robes; he will be very strong, very affectionate to his
friends, and very kindly disposed.
~1ISv~n
If Surya is in Agam Avastha, the native will be distressed
due to enemies, fickle-minded, evil-minded, emaciated,
devoid of virtuous acts and intoxicated with pride.
~1ISh~n
If Surya is in Bhojan Avastha, the native will experience
pains in joints; he will lose money on account of others'
females, he will have strength declining off and on; he
will be untruthful, will incur head-aches, will eat remnant
food, and will take to bad ways.
~1ISt~
If Surya is in Nritya Lips Avastha, the native will be
honoured by the learned; he will be a scholar, will have
knowledge of poetry, etc., and he will be adored by kings
on the earth.
~1ISk~m
If Surya is in Kautuk Avastha, the native will always be
happy; he will be endowed with Vedic Knowledge and he will
perform Yagyas; he will move amidst kings, will have fear
from enemies; he will be charming-faced and he will be
endowed with knowledge of poetry.
~1ISi~n
If Surya is in Nidr Avastha, the native will  have a strong
tendency towards being drowsy; he will live in foreign (or
distant) places; he will incur harm to his wife and will
face financial destruction.
~1ISu~n
Surya in Upavesan Avastha will make one an artisan, black
in complexion, devoid of learning and miserable. One will
serve others.
~1ISn*1I5+1ISn*1I9+1ISn*1I7+1ISn*1I10~
In Netrapani Avastha there will be all kinds of happiness,
if Surya is in Putr, Dharm, Karm, or Yuvati Bhava.
~1ISn**-1I5*-1I9*-1I10+-1I7~n
In other bhavas (i.e. not in Putr, Dharm, Karm, or Yuvati
Bhava), Netrapani Avastha of Surya will give eye diseases
and enmity with all.
~1ISp~
If Surya is in Prakash Avastha, the native will be
meritorious, religious, and  liberal; he will enjoy
pleasures, will be equal to a prince, and will enjoy the
status of Kuber, the God of wealth.
~1ISp*1I7+1ISp*1I5~n
However, the Prakash Avastha of Surya placed in Yuvati, or
Putr Bhava will cause loss of the first child and will
produce many litigations.
~1ISg~n
If Surya is in Gaman Avastha, the native will incur disease
of the feet and he will be very mean.
~1ISa*1I12+1ISa*1I7~n
If in Agaman Avastha, Surya in Vyaya or in Yuvati Bhava
will destroy progeny and will give very limited wealth.
~1ISv~m
If in Agam Avastha, Surya will give many miseries, an ugly
appearance, and foolishness. However, he will give wealth.
~1ISh*1I9~n
Surya in Bhojan Avastha in Dharm Bhava will cause many
hindrances to spiritual and religious undertakings.
~1ISh*-1I9~n
In other bhavas (i.e. other than Dharm Bhava), Surya in
Bhojan Avastha will cause head and ear diseases, apart from
joint pains.
~1ISk*1I6~n
Though Maharishi Parashar states that the native with Surya
in Kautuk Avastha will have fear from enemies Bal Bhadr
exempts such evil effect for the Ari Bhava position.
~1ISk*-1I6~
Surya in Kautuk Avastha in other bhavas (i.e. not in Ari
Bhava), will give a number of daughters, two wives, itch,
excellence, liberality, etc..
~1ISi~n
If Surya is in Nidr Avastha, the native will be predisposed
to incur piles and elephantiasis; he will experience a lack
of peace; and he will be liable to lose his first child.
~2ISy~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P166_B001_01

- 身份：正文
- PDF 页：166
- 偈颂：52-63
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 52-63 [present] · PDF page 166

52-63. Effects of Chandr's Avasthas at Birth: If Chandr is
in Sayan Avastha, the native will be honourable, sluggish,
given to sexual lust, and he will face financial
destruction.
~2ISu~n
If Chandr is in Upavesan Avastha, the native will be
troubled by diseases, he will be dull-witted, not endowed
with mentionable wealth (i.e. will have only negligible
wealth); he will be hard-hearted, will do unworthy acts,
and will steal others' wealth.
~2ISn~n
If Chandr is in Netrapani Avastha, the native will be
troubled by great diseases (long lasting in nature), be
very garrulous, wicked, and he will indulge in bad deeds.
~2ISp~
Should Chandr be in Prakash Avastha, the native will be
famous in the world, he will have his virtues exposed
through royal patronage; he will be surrounded by horses,
elephants, females, and ornaments; he will visit shrines.
~2ISg*2w~n
If Chandr is in Gaman Avastha, with decreasing rays the
native will be sinful, cruel, and always troubled by
afflictions of sight;
~2ISg*2W~n
if Chandr is in Gaman Avastha with increasing rays, the
native will be distressed due to fear.
~2ISa~n
If Chandr is in Agaman Avastha, the native will be
honourable; he will suffer diseases of the feet; he will
secretly indulge in sinful acts; he will be poor and devoid
of intelligence and happiness.
~2ISb~
If Chandr is in Sabh Avastha, the native will be eminent
among men, honoured by kings, and kings of kings; he will
be very beautiful, will subdue the passion of women and he
will be skillful in sexual acts; he will be virtuous.
~2ISv~n
If Chandr is in Agam Avastha, the native will be garrulous,
and virtuous and if the said Chandr is of dark fortnight
the native will have two wives; he will be sick, highly
wicked, and he will be violent.
~2ISh~
If Chandr is in Bhojan Avastha, the native will be endowed
with honour, conveyances, attendants, social status, wife
and daughters, provided Chandr is Full 'Purna Chandr';
~2ISh*2x~n
if Chandr is in Bhojan Avastha and is of dark fortnight
auspicious effects (i.e. honour, conveyances, attendants,
social status, wife and daughters) will fail to come.
~2ISt*2X~
If Chandr  is in Nritya Lips Avastha and is endowed with
(fort nightly) strength, the native will be strong, he will
have knowledge of songs, and he will be a critic of beauty
of things.
~2INi*2x~n
If Chandr is in Nritya Lips Avastha and of dark fortnight,
i.e. not endowed with strength, the person will be sinful.
~2ISk~m
If Chandr  is in Kautuk Avastha, the native will attain
kinship, lordship over wealth, and skill in sexual acts and
in sporting with harlots.
~2W*2Y5*2ISi~
Should waxing Chandr being yuti with Guru be in Nidr
Avastha, the native will be quite eminent.
~2W*2I*2ISi~n
If waxing Chandr is in Nidr Avastha but devoid of Guru's
yuti, the native will lose his wealth on account of
females, and female jackals will be crying around his abode
(as though it were a cemetery).
~3ISy~n
64 75. Effects of the Avasthas of Mangal at Birth: If
Mangal is in Sayan Avastha, the native will be troubled by
wounds, itch, and ulcer.
~3ISu~n
If Mangal is placed in Upavesan Avastha,the native will be
strong, sinful, untruthful, eminent, wealthy, and bereft of
virtues.
~3I1*3ISn~n
If Mangal is placed in Lagn and happen to be in Netrapani
Avastha there will be penury;
~-3I1*3ISn~
if Mangal is placed in other bhavas (i.e. in one of the
bhavas other than Tanu Bhava), Netrapani Avastha will
confer rulership of a city.
~3ISp~
Should Mangal be in Prakash Avastha, the native will shine
with virtues and will be honoured by the king.
~3ISp*3I5~n
Mangal in Prakash Avastha in Putr Bhava will, cause loss of
children and of wife.
~3ISp*3I5*3Y8~n
If Mangal is in Prakash Avastha in Putr Bhava and happens
to be there with Rahu, a severe (positional) fall will
descend on the native.
~3ISg~n
Should Mangal be in Gaman Avastha the native will be always
roaming, will have fear of multiple ulcers, will incur
misunderstandings with females, will be afflicted by boils,
itches, etc., and will incur financial decline.
~3ISa~
If Mangal happens to be in Agaman Avastha, the native will
be virtuous, endowed with precious gems, will adore a sharp
sword, will walk with the (majestic) gait of an elephant
(imparting surprise in the onlooker), will destroy his
enemies, and will remove the miseries of his people.
~3ISb*3E~
If Mangal is placed in Sabh Avastha and happens to be in
exaltation the native will be skilful in conducting wars,
will hold the flag of righteousness aloft, and will be
wealthy;
~3ISb*3E*3I5+~3ISb*3E*3I9~n
if Mangal happens to be in Sabh Avastha in Putr, or Dharm
Bhava, the native will be bereft of learning;
~3ISb*3E*3I12~n
if Mangal is in Sabh Avastha in Vyaya Bhava childlessness
and no wife and no friends will result;
~-3I5*-3I9*-3I12*3ISb~
and if Mangal is in other bhavas (i.e. other than Putr,
Dharm, and Vyaya Bhava), in Sabh Avastha, the native will
be a scholar in a king's court (i.e. be a poet laureate),
be very wealthy, honourable, and charitable.
~3ISv~n
If Mangal is in Agam Avastha, the native will be devoid of
virtues and good deeds, will be distressed by diseases,
will acquire diseases of the root of the ears ('Karan
Mularogam' & 'Padamulam Urumulam', etc.), and severe gout
pains; he will be timid and will befriend evil lot.
~3X*3ISh~
If Mangal is with strength, while in Bhojan Avastha, the
native will eat sweet-food;
~3x*3ISh~n
if Mangal is devoid of strength, while in Bhojan Avastha,
the native will indulge in base acts and be dishonourable.
~3ISt~
If Mangal is in Nritya Lips Avastha, the native will earn
wealth through the king and will be endowed with fullness
of gold, diamonds, and corals in his house.
~3ISk~
If Mangal is in Kautuk Avastha the native will be curious
in disposition and will be endowed with friends and sons;
~3ISk*3E~
if Mangal is in Kautuk Avastha and simultaneously exalted,
the native will be honoured by the king and the virtuous
and he will be virtuous  himself.
~3ISi~n
If Mangal is in Nidr Avastha, the native will be
short-tempered, devoid of intelligence and wealth; he will
be wicked, fallen from virtuous path, and troubled by
diseases.
~3ISu*3I1~n
Should Mangal be in Upavesan Avastha in Lagn, the native
will be extremely sinful, and he will incur several
diseases; he will be indigent and not peaceful.
~3ISu*3I9~n
If Upavesan Avastha occurs for Mangal in Dharm Bhava, the
native will lose his whole wealth apart from his wife and
progeny.
~3ISn*3I1~n
Mangal in Netrapani  Avastha in Lagn will give poverty and
will destroy the native's wife and progeny;
~3ISn*-3I1~
If Mangal is in Netrapani Avastha in other bhavas (i.e. in
bhavas other than Tanu Bhava), this confers on the native
all kinds of wealth and happiness from wife and children.
~3ISn*3I2+3ISn*3I7~n
The Dhan Bhava position or Yuvati Bhava position of Mangal
in Netrapani Avastha will cause fear from lions and snakes,
apart from giving earnings from lands. Furthermore, the
native's wife will predecease him.
~3ISp*3I5+3ISp*3I5~n
Should Mangal be in Prakash Avastha in Putr or in Yuvati
Bhava, the native will lose his wife and all children.
~3ISp*3I5*3Y7~n
If Mangal is placed in Putr Bhava in Prakash Avastha, and
is yuti with Shani, the native will kill cows.
~3ISg*3I1~n
Should Mangal be in Gaman Avastha  in Lagn, the native will
be active in his assignments, will incur diseases of the
joints, burning pains in the eyes, and will obtain dental
afflictions and the like; he will have fear from dogs and
will adore the guise of a female.
~3ISg*-3I1~
In other bhavas, other than Tanu Bhava, Mangal in Gaman
Avastha will bring royal favours, leadership ,and luxuries
of life.
~3ISa~n
Mangal in Agaman Avastha will cause piles and diseases of
the rectum.
~3ISh*3I5+3ISy*3I5+3ISh*3I8+3ISy*3I8~n
If Mangal is in Bhojan Avastha or in Sayan Avastha in Putr
Bhava, or in Randhr Bhava, there will be untimely death for
the native.
~3ISh*-3I5+3ISy*-3I5+3ISh*-3I8+3ISy*-3I8~
In other bhavas, other than Putr and Randhr Bhava, Bhojan
Avastha of Mangal will confer wealth.
~3ISt*3I1+3ISt*3I2+3ISt*3I7+3ISt*3I10~
Should Mangal be in Nritya Lips Avastha and happens to be
in Lagn, Dhan, Yuvati, or Karm Bhava, the native will
receive all kinds of happiness;
~3ISt*3I8+3ISt*3I9~n
there will be miseries in abundance if Mangal is in Nritya
Lips Avastha and placed in Randhr or Dharm Bhava, apart
from incurring untimely death.
~3ISt*3I3+3ISt*3I4+3ISt*3I5+3ISt*3I6+3ISt*3I11+3ISt*3I12~
In other bhavas (i.e. Sahaj, Bandhu, Putr, Ari, Labh, or
Vyaya Bhava), Nritya Lips Avastha of Mangal will make the
native akin to Kuber.
~3ISk*3I7+3ISk*3I9~n
Mangal in Yuvati or in Dharm Bhava in Kautuk Avastha will
give several diseases and death of the first child and
wife.
~3ISk-*3I7+3ISk-*3I9~
In other bhavas (i.e. not in Yuvati or Dharm Bhava), Kautuk
Avastha will confer scholarship, various kinds of wealth,
two wives, and more female children.
~3ISi*3I1+3ISi*3I2+3ISi*3I3+3ISi*3I9+3ISi*3I10+3ISi*3I11~n
In Nidr Avastha, Mangal in Lagn, Dhan, Sahaj, Dharm, Karm,
or Labh Bhava will give scholarship, foolishness, and
poverty.
~3ISi*3I5+3ISi*3I7~n
Putr or Yuvati Bhava placement of Mangal in Nidr Avastha
will give many miseries and many male children.
~3ISi*3Y8~n
Should Rahu join Mangal in Nidr Avastha in any bhava the
native will have many wives, be miserable, and will suffer
from some diseases on the surface of the feet.
~4ISy*4I1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P166_B001_02

- 身份：正文
- PDF 页：166
- 偈颂：52-63
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 52-63 [present] · PDF page 166

52-63. Effects of Chandr's Avasthas at Birth: If Chandr is
in Sayan Avastha, the native will be honourable, sluggish,
given to sexual lust, and he will face financial
destruction.
~2ISu~n
If Chandr is in Upavesan Avastha, the native will be
troubled by diseases, he will be dull-witted, not endowed
with mentionable wealth (i.e. will have only negligible
wealth); he will be hard-hearted, will do unworthy acts,
and will steal others' wealth.
~2ISn~n
If Chandr is in Netrapani Avastha, the native will be
troubled by great diseases (long lasting in nature), be
very garrulous, wicked, and he will indulge in bad deeds.
~2ISp~
Should Chandr be in Prakash Avastha, the native will be
famous in the world, he will have his virtues exposed
through royal patronage; he will be surrounded by horses,
elephants, females, and ornaments; he will visit shrines.
~2ISg*2w~n
If Chandr is in Gaman Avastha, with decreasing rays the
native will be sinful, cruel, and always troubled by
afflictions of sight;
~2ISg*2W~n
if Chandr is in Gaman Avastha with increasing rays, the
native will be distressed due to fear.
~2ISa~n
If Chandr is in Agaman Avastha, the native will be
honourable; he will suffer diseases of the feet; he will
secretly indulge in sinful acts; he will be poor and devoid
of intelligence and happiness.
~2ISb~
If Chandr is in Sabh Avastha, the native will be eminent
among men, honoured by kings, and kings of kings; he will
be very beautiful, will subdue the passion of women and he
will be skillful in sexual acts; he will be virtuous.
~2ISv~n
If Chandr is in Agam Avastha, the native will be garrulous,
and virtuous and if the said Chandr is of dark fortnight
the native will have two wives; he will be sick, highly
wicked, and he will be violent.
~2ISh~
If Chandr is in Bhojan Avastha, the native will be endowed
with honour, conveyances, attendants, social status, wife
and daughters, provided Chandr is Full 'Purna Chandr';
~2ISh*2x~n
if Chandr is in Bhojan Avastha and is of dark fortnight
auspicious effects (i.e. honour, conveyances, attendants,
social status, wife and daughters) will fail to come.
~2ISt*2X~
If Chandr  is in Nritya Lips Avastha and is endowed with
(fort nightly) strength, the native will be strong, he will
have knowledge of songs, and he will be a critic of beauty
of things.
~2INi*2x~n
If Chandr is in Nritya Lips Avastha and of dark fortnight,
i.e. not endowed with strength, the person will be sinful.
~2ISk~m
If Chandr  is in Kautuk Avastha, the native will attain
kinship, lordship over wealth, and skill in sexual acts and
in sporting with harlots.
~2W*2Y5*2ISi~
Should waxing Chandr being yuti with Guru be in Nidr
Avastha, the native will be quite eminent.
~2W*2I*2ISi~n
If waxing Chandr is in Nidr Avastha but devoid of Guru's
yuti, the native will lose his wealth on account of
females, and female jackals will be crying around his abode
(as though it were a cemetery).
~3ISy~n
64 75. Effects of the Avasthas of Mangal at Birth: If
Mangal is in Sayan Avastha, the native will be troubled by
wounds, itch, and ulcer.
~3ISu~n
If Mangal is placed in Upavesan Avastha,the native will be
strong, sinful, untruthful, eminent, wealthy, and bereft of
virtues.
~3I1*3ISn~n
If Mangal is placed in Lagn and happen to be in Netrapani
Avastha there will be penury;
~-3I1*3ISn~
if Mangal is placed in other bhavas (i.e. in one of the
bhavas other than Tanu Bhava), Netrapani Avastha will
confer rulership of a city.
~3ISp~
Should Mangal be in Prakash Avastha, the native will shine
with virtues and will be honoured by the king.
~3ISp*3I5~n
Mangal in Prakash Avastha in Putr Bhava will, cause loss of
children and of wife.
~3ISp*3I5*3Y8~n
If Mangal is in Prakash Avastha in Putr Bhava and happens
to be there with Rahu, a severe (positional) fall will
descend on the native.
~3ISg~n
Should Mangal be in Gaman Avastha the native will be always
roaming, will have fear of multiple ulcers, will incur
misunderstandings with females, will be afflicted by boils,
itches, etc., and will incur financial decline.
~3ISa~
If Mangal happens to be in Agaman Avastha, the native will
be virtuous, endowed with precious gems, will adore a sharp
sword, will walk with the (majestic) gait of an elephant
(imparting surprise in the onlooker), will destroy his
enemies, and will remove the miseries of his people.
~3ISb*3E~
If Mangal is placed in Sabh Avastha and happens to be in
exaltation the native will be skilful in conducting wars,
will hold the flag of righteousness aloft, and will be
wealthy;
~3ISb*3E*3I5+~3ISb*3E*3I9~n
if Mangal happens to be in Sabh Avastha in Putr, or Dharm
Bhava, the native will be bereft of learning;
~3ISb*3E*3I12~n
if Mangal is in Sabh Avastha in Vyaya Bhava childlessness
and no wife and no friends will result;
~-3I5*-3I9*-3I12*3ISb~
and if Mangal is in other bhavas (i.e. other than Putr,
Dharm, and Vyaya Bhava), in Sabh Avastha, the native will
be a scholar in a king's court (i.e. be a poet laureate),
be very wealthy, honourable, and charitable.
~3ISv~n
If Mangal is in Agam Avastha, the native will be devoid of
virtues and good deeds, will be distressed by diseases,
will acquire diseases of the root of the ears ('Karan
Mularogam' & 'Padamulam Urumulam', etc.), and severe gout
pains; he will be timid and will befriend evil lot.
~3X*3ISh~
If Mangal is with strength, while in Bhojan Avastha, the
native will eat sweet-food;
~3x*3ISh~n
if Mangal is devoid of strength, while in Bhojan Avastha,
the native will indulge in base acts and be dishonourable.
~3ISt~
If Mangal is in Nritya Lips Avastha, the native will earn
wealth through the king and will be endowed with fullness
of gold, diamonds, and corals in his house.
~3ISk~
If Mangal is in Kautuk Avastha the native will be curious
in disposition and will be endowed with friends and sons;
~3ISk*3E~
if Mangal is in Kautuk Avastha and simultaneously exalted,
the native will be honoured by the king and the virtuous
and he will be virtuous  himself.
~3ISi~n
If Mangal is in Nidr Avastha, the native will be
short-tempered, devoid of intelligence and wealth; he will
be wicked, fallen from virtuous path, and troubled by
diseases.
~3ISu*3I1~n
Should Mangal be in Upavesan Avastha in Lagn, the native
will be extremely sinful, and he will incur several
diseases; he will be indigent and not peaceful.
~3ISu*3I9~n
If Upavesan Avastha occurs for Mangal in Dharm Bhava, the
native will lose his whole wealth apart from his wife and
progeny.
~3ISn*3I1~n
Mangal in Netrapani  Avastha in Lagn will give poverty and
will destroy the native's wife and progeny;
~3ISn*-3I1~
If Mangal is in Netrapani Avastha in other bhavas (i.e. in
bhavas other than Tanu Bhava), this confers on the native
all kinds of wealth and happiness from wife and children.
~3ISn*3I2+3ISn*3I7~n
The Dhan Bhava position or Yuvati Bhava position of Mangal
in Netrapani Avastha will cause fear from lions and snakes,
apart from giving earnings from lands. Furthermore, the
native's wife will predecease him.
~3ISp*3I5+3ISp*3I5~n
Should Mangal be in Prakash Avastha in Putr or in Yuvati
Bhava, the native will lose his wife and all children.
~3ISp*3I5*3Y7~n
If Mangal is placed in Putr Bhava in Prakash Avastha, and
is yuti with Shani, the native will kill cows.
~3ISg*3I1~n
Should Mangal be in Gaman Avastha  in Lagn, the native will
be active in his assignments, will incur diseases of the
joints, burning pains in the eyes, and will obtain dental
afflictions and the like; he will have fear from dogs and
will adore the guise of a female.
~3ISg*-3I1~
In other bhavas, other than Tanu Bhava, Mangal in Gaman
Avastha will bring royal favours, leadership ,and luxuries
of life.
~3ISa~n
Mangal in Agaman Avastha will cause piles and diseases of
the rectum.
~3ISh*3I5+3ISy*3I5+3ISh*3I8+3ISy*3I8~n
If Mangal is in Bhojan Avastha or in Sayan Avastha in Putr
Bhava, or in Randhr Bhava, there will be untimely death for
the native.
~3ISh*-3I5+3ISy*-3I5+3ISh*-3I8+3ISy*-3I8~
In other bhavas, other than Putr and Randhr Bhava, Bhojan
Avastha of Mangal will confer wealth.
~3ISt*3I1+3ISt*3I2+3ISt*3I7+3ISt*3I10~
Should Mangal be in Nritya Lips Avastha and happens to be
in Lagn, Dhan, Yuvati, or Karm Bhava, the native will
receive all kinds of happiness;
~3ISt*3I8+3ISt*3I9~n
there will be miseries in abundance if Mangal is in Nritya
Lips Avastha and placed in Randhr or Dharm Bhava, apart
from incurring untimely death.
~3ISt*3I3+3ISt*3I4+3ISt*3I5+3ISt*3I6+3ISt*3I11+3ISt*3I12~
In other bhavas (i.e. Sahaj, Bandhu, Putr, Ari, Labh, or
Vyaya Bhava), Nritya Lips Avastha of Mangal will make the
native akin to Kuber.
~3ISk*3I7+3ISk*3I9~n
Mangal in Yuvati or in Dharm Bhava in Kautuk Avastha will
give several diseases and death of the first child and
wife.
~3ISk-*3I7+3ISk-*3I9~
In other bhavas (i.e. not in Yuvati or Dharm Bhava), Kautuk
Avastha will confer scholarship, various kinds of wealth,
two wives, and more female children.
~3ISi*3I1+3ISi*3I2+3ISi*3I3+3ISi*3I9+3ISi*3I10+3ISi*3I11~n
In Nidr Avastha, Mangal in Lagn, Dhan, Sahaj, Dharm, Karm,
or Labh Bhava will give scholarship, foolishness, and
poverty.
~3ISi*3I5+3ISi*3I7~n
Putr or Yuvati Bhava placement of Mangal in Nidr Avastha
will give many miseries and many male children.
~3ISi*3Y8~n
Should Rahu join Mangal in Nidr Avastha in any bhava the
native will have many wives, be miserable, and will suffer
from some diseases on the surface of the feet.
~4ISy*4I1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P166_B001_03

- 身份：正文
- PDF 页：166
- 偈颂：52-63
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 52-63 [present] · PDF page 166

52-63. Effects of Chandr's Avasthas at Birth: If Chandr is
in Sayan Avastha, the native will be honourable, sluggish,
given to sexual lust, and he will face financial
destruction.
~2ISu~n
If Chandr is in Upavesan Avastha, the native will be
troubled by diseases, he will be dull-witted, not endowed
with mentionable wealth (i.e. will have only negligible
wealth); he will be hard-hearted, will do unworthy acts,
and will steal others' wealth.
~2ISn~n
If Chandr is in Netrapani Avastha, the native will be
troubled by great diseases (long lasting in nature), be
very garrulous, wicked, and he will indulge in bad deeds.
~2ISp~
Should Chandr be in Prakash Avastha, the native will be
famous in the world, he will have his virtues exposed
through royal patronage; he will be surrounded by horses,
elephants, females, and ornaments; he will visit shrines.
~2ISg*2w~n
If Chandr is in Gaman Avastha, with decreasing rays the
native will be sinful, cruel, and always troubled by
afflictions of sight;
~2ISg*2W~n
if Chandr is in Gaman Avastha with increasing rays, the
native will be distressed due to fear.
~2ISa~n
If Chandr is in Agaman Avastha, the native will be
honourable; he will suffer diseases of the feet; he will
secretly indulge in sinful acts; he will be poor and devoid
of intelligence and happiness.
~2ISb~
If Chandr is in Sabh Avastha, the native will be eminent
among men, honoured by kings, and kings of kings; he will
be very beautiful, will subdue the passion of women and he
will be skillful in sexual acts; he will be virtuous.
~2ISv~n
If Chandr is in Agam Avastha, the native will be garrulous,
and virtuous and if the said Chandr is of dark fortnight
the native will have two wives; he will be sick, highly
wicked, and he will be violent.
~2ISh~
If Chandr is in Bhojan Avastha, the native will be endowed
with honour, conveyances, attendants, social status, wife
and daughters, provided Chandr is Full 'Purna Chandr';
~2ISh*2x~n
if Chandr is in Bhojan Avastha and is of dark fortnight
auspicious effects (i.e. honour, conveyances, attendants,
social status, wife and daughters) will fail to come.
~2ISt*2X~
If Chandr  is in Nritya Lips Avastha and is endowed with
(fort nightly) strength, the native will be strong, he will
have knowledge of songs, and he will be a critic of beauty
of things.
~2INi*2x~n
If Chandr is in Nritya Lips Avastha and of dark fortnight,
i.e. not endowed with strength, the person will be sinful.
~2ISk~m
If Chandr  is in Kautuk Avastha, the native will attain
kinship, lordship over wealth, and skill in sexual acts and
in sporting with harlots.
~2W*2Y5*2ISi~
Should waxing Chandr being yuti with Guru be in Nidr
Avastha, the native will be quite eminent.
~2W*2I*2ISi~n
If waxing Chandr is in Nidr Avastha but devoid of Guru's
yuti, the native will lose his wealth on account of
females, and female jackals will be crying around his abode
(as though it were a cemetery).
~3ISy~n
64 75. Effects of the Avasthas of Mangal at Birth: If
Mangal is in Sayan Avastha, the native will be troubled by
wounds, itch, and ulcer.
~3ISu~n
If Mangal is placed in Upavesan Avastha,the native will be
strong, sinful, untruthful, eminent, wealthy, and bereft of
virtues.
~3I1*3ISn~n
If Mangal is placed in Lagn and happen to be in Netrapani
Avastha there will be penury;
~-3I1*3ISn~
if Mangal is placed in other bhavas (i.e. in one of the
bhavas other than Tanu Bhava), Netrapani Avastha will
confer rulership of a city.
~3ISp~
Should Mangal be in Prakash Avastha, the native will shine
with virtues and will be honoured by the king.
~3ISp*3I5~n
Mangal in Prakash Avastha in Putr Bhava will, cause loss of
children and of wife.
~3ISp*3I5*3Y8~n
If Mangal is in Prakash Avastha in Putr Bhava and happens
to be there with Rahu, a severe (positional) fall will
descend on the native.
~3ISg~n
Should Mangal be in Gaman Avastha the native will be always
roaming, will have fear of multiple ulcers, will incur
misunderstandings with females, will be afflicted by boils,
itches, etc., and will incur financial decline.
~3ISa~
If Mangal happens to be in Agaman Avastha, the native will
be virtuous, endowed with precious gems, will adore a sharp
sword, will walk with the (majestic) gait of an elephant
(imparting surprise in the onlooker), will destroy his
enemies, and will remove the miseries of his people.
~3ISb*3E~
If Mangal is placed in Sabh Avastha and happens to be in
exaltation the native will be skilful in conducting wars,
will hold the flag of righteousness aloft, and will be
wealthy;
~3ISb*3E*3I5+~3ISb*3E*3I9~n
if Mangal happens to be in Sabh Avastha in Putr, or Dharm
Bhava, the native will be bereft of learning;
~3ISb*3E*3I12~n
if Mangal is in Sabh Avastha in Vyaya Bhava childlessness
and no wife and no friends will result;
~-3I5*-3I9*-3I12*3ISb~
and if Mangal is in other bhavas (i.e. other than Putr,
Dharm, and Vyaya Bhava), in Sabh Avastha, the native will
be a scholar in a king's court (i.e. be a poet laureate),
be very wealthy, honourable, and charitable.
~3ISv~n
If Mangal is in Agam Avastha, the native will be devoid of
virtues and good deeds, will be distressed by diseases,
will acquire diseases of the root of the ears ('Karan
Mularogam' & 'Padamulam Urumulam', etc.), and severe gout
pains; he will be timid and will befriend evil lot.
~3X*3ISh~
If Mangal is with strength, while in Bhojan Avastha, the
native will eat sweet-food;
~3x*3ISh~n
if Mangal is devoid of strength, while in Bhojan Avastha,
the native will indulge in base acts and be dishonourable.
~3ISt~
If Mangal is in Nritya Lips Avastha, the native will earn
wealth through the king and will be endowed with fullness
of gold, diamonds, and corals in his house.
~3ISk~
If Mangal is in Kautuk Avastha the native will be curious
in disposition and will be endowed with friends and sons;
~3ISk*3E~
if Mangal is in Kautuk Avastha and simultaneously exalted,
the native will be honoured by the king and the virtuous
and he will be virtuous  himself.
~3ISi~n
If Mangal is in Nidr Avastha, the native will be
short-tempered, devoid of intelligence and wealth; he will
be wicked, fallen from virtuous path, and troubled by
diseases.
~3ISu*3I1~n
Should Mangal be in Upavesan Avastha in Lagn, the native
will be extremely sinful, and he will incur several
diseases; he will be indigent and not peaceful.
~3ISu*3I9~n
If Upavesan Avastha occurs for Mangal in Dharm Bhava, the
native will lose his whole wealth apart from his wife and
progeny.
~3ISn*3I1~n
Mangal in Netrapani  Avastha in Lagn will give poverty and
will destroy the native's wife and progeny;
~3ISn*-3I1~
If Mangal is in Netrapani Avastha in other bhavas (i.e. in
bhavas other than Tanu Bhava), this confers on the native
all kinds of wealth and happiness from wife and children.
~3ISn*3I2+3ISn*3I7~n
The Dhan Bhava position or Yuvati Bhava position of Mangal
in Netrapani Avastha will cause fear from lions and snakes,
apart from giving earnings from lands. Furthermore, the
native's wife will predecease him.
~3ISp*3I5+3ISp*3I5~n
Should Mangal be in Prakash Avastha in Putr or in Yuvati
Bhava, the native will lose his wife and all children.
~3ISp*3I5*3Y7~n
If Mangal is placed in Putr Bhava in Prakash Avastha, and
is yuti with Shani, the native will kill cows.
~3ISg*3I1~n
Should Mangal be in Gaman Avastha  in Lagn, the native will
be active in his assignments, will incur diseases of the
joints, burning pains in the eyes, and will obtain dental
afflictions and the like; he will have fear from dogs and
will adore the guise of a female.
~3ISg*-3I1~
In other bhavas, other than Tanu Bhava, Mangal in Gaman
Avastha will bring royal favours, leadership ,and luxuries
of life.
~3ISa~n
Mangal in Agaman Avastha will cause piles and diseases of
the rectum.
~3ISh*3I5+3ISy*3I5+3ISh*3I8+3ISy*3I8~n
If Mangal is in Bhojan Avastha or in Sayan Avastha in Putr
Bhava, or in Randhr Bhava, there will be untimely death for
the native.
~3ISh*-3I5+3ISy*-3I5+3ISh*-3I8+3ISy*-3I8~
In other bhavas, other than Putr and Randhr Bhava, Bhojan
Avastha of Mangal will confer wealth.
~3ISt*3I1+3ISt*3I2+3ISt*3I7+3ISt*3I10~
Should Mangal be in Nritya Lips Avastha and happens to be
in Lagn, Dhan, Yuvati, or Karm Bhava, the native will
receive all kinds of happiness;
~3ISt*3I8+3ISt*3I9~n
there will be miseries in abundance if Mangal is in Nritya
Lips Avastha and placed in Randhr or Dharm Bhava, apart
from incurring untimely death.
~3ISt*3I3+3ISt*3I4+3ISt*3I5+3ISt*3I6+3ISt*3I11+3ISt*3I12~
In other bhavas (i.e. Sahaj, Bandhu, Putr, Ari, Labh, or
Vyaya Bhava), Nritya Lips Avastha of Mangal will make the
native akin to Kuber.
~3ISk*3I7+3ISk*3I9~n
Mangal in Yuvati or in Dharm Bhava in Kautuk Avastha will
give several diseases and death of the first child and
wife.
~3ISk-*3I7+3ISk-*3I9~
In other bhavas (i.e. not in Yuvati or Dharm Bhava), Kautuk
Avastha will confer scholarship, various kinds of wealth,
two wives, and more female children.
~3ISi*3I1+3ISi*3I2+3ISi*3I3+3ISi*3I9+3ISi*3I10+3ISi*3I11~n
In Nidr Avastha, Mangal in Lagn, Dhan, Sahaj, Dharm, Karm,
or Labh Bhava will give scholarship, foolishness, and
poverty.
~3ISi*3I5+3ISi*3I7~n
Putr or Yuvati Bhava placement of Mangal in Nidr Avastha
will give many miseries and many male children.
~3ISi*3Y8~n
Should Rahu join Mangal in Nidr Avastha in any bhava the
native will have many wives, be miserable, and will suffer
from some diseases on the surface of the feet.
~4ISy*4I1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P166_B001_04

- 身份：正文
- PDF 页：166
- 偈颂：52-63
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 52-63 [present] · PDF page 166

52-63. Effects of Chandr's Avasthas at Birth: If Chandr is
in Sayan Avastha, the native will be honourable, sluggish,
given to sexual lust, and he will face financial
destruction.
~2ISu~n
If Chandr is in Upavesan Avastha, the native will be
troubled by diseases, he will be dull-witted, not endowed
with mentionable wealth (i.e. will have only negligible
wealth); he will be hard-hearted, will do unworthy acts,
and will steal others' wealth.
~2ISn~n
If Chandr is in Netrapani Avastha, the native will be
troubled by great diseases (long lasting in nature), be
very garrulous, wicked, and he will indulge in bad deeds.
~2ISp~
Should Chandr be in Prakash Avastha, the native will be
famous in the world, he will have his virtues exposed
through royal patronage; he will be surrounded by horses,
elephants, females, and ornaments; he will visit shrines.
~2ISg*2w~n
If Chandr is in Gaman Avastha, with decreasing rays the
native will be sinful, cruel, and always troubled by
afflictions of sight;
~2ISg*2W~n
if Chandr is in Gaman Avastha with increasing rays, the
native will be distressed due to fear.
~2ISa~n
If Chandr is in Agaman Avastha, the native will be
honourable; he will suffer diseases of the feet; he will
secretly indulge in sinful acts; he will be poor and devoid
of intelligence and happiness.
~2ISb~
If Chandr is in Sabh Avastha, the native will be eminent
among men, honoured by kings, and kings of kings; he will
be very beautiful, will subdue the passion of women and he
will be skillful in sexual acts; he will be virtuous.
~2ISv~n
If Chandr is in Agam Avastha, the native will be garrulous,
and virtuous and if the said Chandr is of dark fortnight
the native will have two wives; he will be sick, highly
wicked, and he will be violent.
~2ISh~
If Chandr is in Bhojan Avastha, the native will be endowed
with honour, conveyances, attendants, social status, wife
and daughters, provided Chandr is Full 'Purna Chandr';
~2ISh*2x~n
if Chandr is in Bhojan Avastha and is of dark fortnight
auspicious effects (i.e. honour, conveyances, attendants,
social status, wife and daughters) will fail to come.
~2ISt*2X~
If Chandr  is in Nritya Lips Avastha and is endowed with
(fort nightly) strength, the native will be strong, he will
have knowledge of songs, and he will be a critic of beauty
of things.
~2INi*2x~n
If Chandr is in Nritya Lips Avastha and of dark fortnight,
i.e. not endowed with strength, the person will be sinful.
~2ISk~m
If Chandr  is in Kautuk Avastha, the native will attain
kinship, lordship over wealth, and skill in sexual acts and
in sporting with harlots.
~2W*2Y5*2ISi~
Should waxing Chandr being yuti with Guru be in Nidr
Avastha, the native will be quite eminent.
~2W*2I*2ISi~n
If waxing Chandr is in Nidr Avastha but devoid of Guru's
yuti, the native will lose his wealth on account of
females, and female jackals will be crying around his abode
(as though it were a cemetery).
~3ISy~n
64 75. Effects of the Avasthas of Mangal at Birth: If
Mangal is in Sayan Avastha, the native will be troubled by
wounds, itch, and ulcer.
~3ISu~n
If Mangal is placed in Upavesan Avastha,the native will be
strong, sinful, untruthful, eminent, wealthy, and bereft of
virtues.
~3I1*3ISn~n
If Mangal is placed in Lagn and happen to be in Netrapani
Avastha there will be penury;
~-3I1*3ISn~
if Mangal is placed in other bhavas (i.e. in one of the
bhavas other than Tanu Bhava), Netrapani Avastha will
confer rulership of a city.
~3ISp~
Should Mangal be in Prakash Avastha, the native will shine
with virtues and will be honoured by the king.
~3ISp*3I5~n
Mangal in Prakash Avastha in Putr Bhava will, cause loss of
children and of wife.
~3ISp*3I5*3Y8~n
If Mangal is in Prakash Avastha in Putr Bhava and happens
to be there with Rahu, a severe (positional) fall will
descend on the native.
~3ISg~n
Should Mangal be in Gaman Avastha the native will be always
roaming, will have fear of multiple ulcers, will incur
misunderstandings with females, will be afflicted by boils,
itches, etc., and will incur financial decline.
~3ISa~
If Mangal happens to be in Agaman Avastha, the native will
be virtuous, endowed with precious gems, will adore a sharp
sword, will walk with the (majestic) gait of an elephant
(imparting surprise in the onlooker), will destroy his
enemies, and will remove the miseries of his people.
~3ISb*3E~
If Mangal is placed in Sabh Avastha and happens to be in
exaltation the native will be skilful in conducting wars,
will hold the flag of righteousness aloft, and will be
wealthy;
~3ISb*3E*3I5+~3ISb*3E*3I9~n
if Mangal happens to be in Sabh Avastha in Putr, or Dharm
Bhava, the native will be bereft of learning;
~3ISb*3E*3I12~n
if Mangal is in Sabh Avastha in Vyaya Bhava childlessness
and no wife and no friends will result;
~-3I5*-3I9*-3I12*3ISb~
and if Mangal is in other bhavas (i.e. other than Putr,
Dharm, and Vyaya Bhava), in Sabh Avastha, the native will
be a scholar in a king's court (i.e. be a poet laureate),
be very wealthy, honourable, and charitable.
~3ISv~n
If Mangal is in Agam Avastha, the native will be devoid of
virtues and good deeds, will be distressed by diseases,
will acquire diseases of the root of the ears ('Karan
Mularogam' & 'Padamulam Urumulam', etc.), and severe gout
pains; he will be timid and will befriend evil lot.
~3X*3ISh~
If Mangal is with strength, while in Bhojan Avastha, the
native will eat sweet-food;
~3x*3ISh~n
if Mangal is devoid of strength, while in Bhojan Avastha,
the native will indulge in base acts and be dishonourable.
~3ISt~
If Mangal is in Nritya Lips Avastha, the native will earn
wealth through the king and will be endowed with fullness
of gold, diamonds, and corals in his house.
~3ISk~
If Mangal is in Kautuk Avastha the native will be curious
in disposition and will be endowed with friends and sons;
~3ISk*3E~
if Mangal is in Kautuk Avastha and simultaneously exalted,
the native will be honoured by the king and the virtuous
and he will be virtuous  himself.
~3ISi~n
If Mangal is in Nidr Avastha, the native will be
short-tempered, devoid of intelligence and wealth; he will
be wicked, fallen from virtuous path, and troubled by
diseases.
~3ISu*3I1~n
Should Mangal be in Upavesan Avastha in Lagn, the native
will be extremely sinful, and he will incur several
diseases; he will be indigent and not peaceful.
~3ISu*3I9~n
If Upavesan Avastha occurs for Mangal in Dharm Bhava, the
native will lose his whole wealth apart from his wife and
progeny.
~3ISn*3I1~n
Mangal in Netrapani  Avastha in Lagn will give poverty and
will destroy the native's wife and progeny;
~3ISn*-3I1~
If Mangal is in Netrapani Avastha in other bhavas (i.e. in
bhavas other than Tanu Bhava), this confers on the native
all kinds of wealth and happiness from wife and children.
~3ISn*3I2+3ISn*3I7~n
The Dhan Bhava position or Yuvati Bhava position of Mangal
in Netrapani Avastha will cause fear from lions and snakes,
apart from giving earnings from lands. Furthermore, the
native's wife will predecease him.
~3ISp*3I5+3ISp*3I5~n
Should Mangal be in Prakash Avastha in Putr or in Yuvati
Bhava, the native will lose his wife and all children.
~3ISp*3I5*3Y7~n
If Mangal is placed in Putr Bhava in Prakash Avastha, and
is yuti with Shani, the native will kill cows.
~3ISg*3I1~n
Should Mangal be in Gaman Avastha  in Lagn, the native will
be active in his assignments, will incur diseases of the
joints, burning pains in the eyes, and will obtain dental
afflictions and the like; he will have fear from dogs and
will adore the guise of a female.
~3ISg*-3I1~
In other bhavas, other than Tanu Bhava, Mangal in Gaman
Avastha will bring royal favours, leadership ,and luxuries
of life.
~3ISa~n
Mangal in Agaman Avastha will cause piles and diseases of
the rectum.
~3ISh*3I5+3ISy*3I5+3ISh*3I8+3ISy*3I8~n
If Mangal is in Bhojan Avastha or in Sayan Avastha in Putr
Bhava, or in Randhr Bhava, there will be untimely death for
the native.
~3ISh*-3I5+3ISy*-3I5+3ISh*-3I8+3ISy*-3I8~
In other bhavas, other than Putr and Randhr Bhava, Bhojan
Avastha of Mangal will confer wealth.
~3ISt*3I1+3ISt*3I2+3ISt*3I7+3ISt*3I10~
Should Mangal be in Nritya Lips Avastha and happens to be
in Lagn, Dhan, Yuvati, or Karm Bhava, the native will
receive all kinds of happiness;
~3ISt*3I8+3ISt*3I9~n
there will be miseries in abundance if Mangal is in Nritya
Lips Avastha and placed in Randhr or Dharm Bhava, apart
from incurring untimely death.
~3ISt*3I3+3ISt*3I4+3ISt*3I5+3ISt*3I6+3ISt*3I11+3ISt*3I12~
In other bhavas (i.e. Sahaj, Bandhu, Putr, Ari, Labh, or
Vyaya Bhava), Nritya Lips Avastha of Mangal will make the
native akin to Kuber.
~3ISk*3I7+3ISk*3I9~n
Mangal in Yuvati or in Dharm Bhava in Kautuk Avastha will
give several diseases and death of the first child and
wife.
~3ISk-*3I7+3ISk-*3I9~
In other bhavas (i.e. not in Yuvati or Dharm Bhava), Kautuk
Avastha will confer scholarship, various kinds of wealth,
two wives, and more female children.
~3ISi*3I1+3ISi*3I2+3ISi*3I3+3ISi*3I9+3ISi*3I10+3ISi*3I11~n
In Nidr Avastha, Mangal in Lagn, Dhan, Sahaj, Dharm, Karm,
or Labh Bhava will give scholarship, foolishness, and
poverty.
~3ISi*3I5+3ISi*3I7~n
Putr or Yuvati Bhava placement of Mangal in Nidr Avastha
will give many miseries and many male children.
~3ISi*3Y8~n
Should Rahu join Mangal in Nidr Avastha in any bhava the
native will have many wives, be miserable, and will suffer
from some diseases on the surface of the feet.
~4ISy*4I1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P166_B001_05

- 身份：正文
- PDF 页：166
- 偈颂：52-63
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 52-63 [present] · PDF page 166

52-63. Effects of Chandr's Avasthas at Birth: If Chandr is
in Sayan Avastha, the native will be honourable, sluggish,
given to sexual lust, and he will face financial
destruction.
~2ISu~n
If Chandr is in Upavesan Avastha, the native will be
troubled by diseases, he will be dull-witted, not endowed
with mentionable wealth (i.e. will have only negligible
wealth); he will be hard-hearted, will do unworthy acts,
and will steal others' wealth.
~2ISn~n
If Chandr is in Netrapani Avastha, the native will be
troubled by great diseases (long lasting in nature), be
very garrulous, wicked, and he will indulge in bad deeds.
~2ISp~
Should Chandr be in Prakash Avastha, the native will be
famous in the world, he will have his virtues exposed
through royal patronage; he will be surrounded by horses,
elephants, females, and ornaments; he will visit shrines.
~2ISg*2w~n
If Chandr is in Gaman Avastha, with decreasing rays the
native will be sinful, cruel, and always troubled by
afflictions of sight;
~2ISg*2W~n
if Chandr is in Gaman Avastha with increasing rays, the
native will be distressed due to fear.
~2ISa~n
If Chandr is in Agaman Avastha, the native will be
honourable; he will suffer diseases of the feet; he will
secretly indulge in sinful acts; he will be poor and devoid
of intelligence and happiness.
~2ISb~
If Chandr is in Sabh Avastha, the native will be eminent
among men, honoured by kings, and kings of kings; he will
be very beautiful, will subdue the passion of women and he
will be skillful in sexual acts; he will be virtuous.
~2ISv~n
If Chandr is in Agam Avastha, the native will be garrulous,
and virtuous and if the said Chandr is of dark fortnight
the native will have two wives; he will be sick, highly
wicked, and he will be violent.
~2ISh~
If Chandr is in Bhojan Avastha, the native will be endowed
with honour, conveyances, attendants, social status, wife
and daughters, provided Chandr is Full 'Purna Chandr';
~2ISh*2x~n
if Chandr is in Bhojan Avastha and is of dark fortnight
auspicious effects (i.e. honour, conveyances, attendants,
social status, wife and daughters) will fail to come.
~2ISt*2X~
If Chandr  is in Nritya Lips Avastha and is endowed with
(fort nightly) strength, the native will be strong, he will
have knowledge of songs, and he will be a critic of beauty
of things.
~2INi*2x~n
If Chandr is in Nritya Lips Avastha and of dark fortnight,
i.e. not endowed with strength, the person will be sinful.
~2ISk~m
If Chandr  is in Kautuk Avastha, the native will attain
kinship, lordship over wealth, and skill in sexual acts and
in sporting with harlots.
~2W*2Y5*2ISi~
Should waxing Chandr being yuti with Guru be in Nidr
Avastha, the native will be quite eminent.
~2W*2I*2ISi~n
If waxing Chandr is in Nidr Avastha but devoid of Guru's
yuti, the native will lose his wealth on account of
females, and female jackals will be crying around his abode
(as though it were a cemetery).
~3ISy~n
64 75. Effects of the Avasthas of Mangal at Birth: If
Mangal is in Sayan Avastha, the native will be troubled by
wounds, itch, and ulcer.
~3ISu~n
If Mangal is placed in Upavesan Avastha,the native will be
strong, sinful, untruthful, eminent, wealthy, and bereft of
virtues.
~3I1*3ISn~n
If Mangal is placed in Lagn and happen to be in Netrapani
Avastha there will be penury;
~-3I1*3ISn~
if Mangal is placed in other bhavas (i.e. in one of the
bhavas other than Tanu Bhava), Netrapani Avastha will
confer rulership of a city.
~3ISp~
Should Mangal be in Prakash Avastha, the native will shine
with virtues and will be honoured by the king.
~3ISp*3I5~n
Mangal in Prakash Avastha in Putr Bhava will, cause loss of
children and of wife.
~3ISp*3I5*3Y8~n
If Mangal is in Prakash Avastha in Putr Bhava and happens
to be there with Rahu, a severe (positional) fall will
descend on the native.
~3ISg~n
Should Mangal be in Gaman Avastha the native will be always
roaming, will have fear of multiple ulcers, will incur
misunderstandings with females, will be afflicted by boils,
itches, etc., and will incur financial decline.
~3ISa~
If Mangal happens to be in Agaman Avastha, the native will
be virtuous, endowed with precious gems, will adore a sharp
sword, will walk with the (majestic) gait of an elephant
(imparting surprise in the onlooker), will destroy his
enemies, and will remove the miseries of his people.
~3ISb*3E~
If Mangal is placed in Sabh Avastha and happens to be in
exaltation the native will be skilful in conducting wars,
will hold the flag of righteousness aloft, and will be
wealthy;
~3ISb*3E*3I5+~3ISb*3E*3I9~n
if Mangal happens to be in Sabh Avastha in Putr, or Dharm
Bhava, the native will be bereft of learning;
~3ISb*3E*3I12~n
if Mangal is in Sabh Avastha in Vyaya Bhava childlessness
and no wife and no friends will result;
~-3I5*-3I9*-3I12*3ISb~
and if Mangal is in other bhavas (i.e. other than Putr,
Dharm, and Vyaya Bhava), in Sabh Avastha, the native will
be a scholar in a king's court (i.e. be a poet laureate),
be very wealthy, honourable, and charitable.
~3ISv~n
If Mangal is in Agam Avastha, the native will be devoid of
virtues and good deeds, will be distressed by diseases,
will acquire diseases of the root of the ears ('Karan
Mularogam' & 'Padamulam Urumulam', etc.), and severe gout
pains; he will be timid and will befriend evil lot.
~3X*3ISh~
If Mangal is with strength, while in Bhojan Avastha, the
native will eat sweet-food;
~3x*3ISh~n
if Mangal is devoid of strength, while in Bhojan Avastha,
the native will indulge in base acts and be dishonourable.
~3ISt~
If Mangal is in Nritya Lips Avastha, the native will earn
wealth through the king and will be endowed with fullness
of gold, diamonds, and corals in his house.
~3ISk~
If Mangal is in Kautuk Avastha the native will be curious
in disposition and will be endowed with friends and sons;
~3ISk*3E~
if Mangal is in Kautuk Avastha and simultaneously exalted,
the native will be honoured by the king and the virtuous
and he will be virtuous  himself.
~3ISi~n
If Mangal is in Nidr Avastha, the native will be
short-tempered, devoid of intelligence and wealth; he will
be wicked, fallen from virtuous path, and troubled by
diseases.
~3ISu*3I1~n
Should Mangal be in Upavesan Avastha in Lagn, the native
will be extremely sinful, and he will incur several
diseases; he will be indigent and not peaceful.
~3ISu*3I9~n
If Upavesan Avastha occurs for Mangal in Dharm Bhava, the
native will lose his whole wealth apart from his wife and
progeny.
~3ISn*3I1~n
Mangal in Netrapani  Avastha in Lagn will give poverty and
will destroy the native's wife and progeny;
~3ISn*-3I1~
If Mangal is in Netrapani Avastha in other bhavas (i.e. in
bhavas other than Tanu Bhava), this confers on the native
all kinds of wealth and happiness from wife and children.
~3ISn*3I2+3ISn*3I7~n
The Dhan Bhava position or Yuvati Bhava position of Mangal
in Netrapani Avastha will cause fear from lions and snakes,
apart from giving earnings from lands. Furthermore, the
native's wife will predecease him.
~3ISp*3I5+3ISp*3I5~n
Should Mangal be in Prakash Avastha in Putr or in Yuvati
Bhava, the native will lose his wife and all children.
~3ISp*3I5*3Y7~n
If Mangal is placed in Putr Bhava in Prakash Avastha, and
is yuti with Shani, the native will kill cows.
~3ISg*3I1~n
Should Mangal be in Gaman Avastha  in Lagn, the native will
be active in his assignments, will incur diseases of the
joints, burning pains in the eyes, and will obtain dental
afflictions and the like; he will have fear from dogs and
will adore the guise of a female.
~3ISg*-3I1~
In other bhavas, other than Tanu Bhava, Mangal in Gaman
Avastha will bring royal favours, leadership ,and luxuries
of life.
~3ISa~n
Mangal in Agaman Avastha will cause piles and diseases of
the rectum.
~3ISh*3I5+3ISy*3I5+3ISh*3I8+3ISy*3I8~n
If Mangal is in Bhojan Avastha or in Sayan Avastha in Putr
Bhava, or in Randhr Bhava, there will be untimely death for
the native.
~3ISh*-3I5+3ISy*-3I5+3ISh*-3I8+3ISy*-3I8~
In other bhavas, other than Putr and Randhr Bhava, Bhojan
Avastha of Mangal will confer wealth.
~3ISt*3I1+3ISt*3I2+3ISt*3I7+3ISt*3I10~
Should Mangal be in Nritya Lips Avastha and happens to be
in Lagn, Dhan, Yuvati, or Karm Bhava, the native will
receive all kinds of happiness;
~3ISt*3I8+3ISt*3I9~n
there will be miseries in abundance if Mangal is in Nritya
Lips Avastha and placed in Randhr or Dharm Bhava, apart
from incurring untimely death.
~3ISt*3I3+3ISt*3I4+3ISt*3I5+3ISt*3I6+3ISt*3I11+3ISt*3I12~
In other bhavas (i.e. Sahaj, Bandhu, Putr, Ari, Labh, or
Vyaya Bhava), Nritya Lips Avastha of Mangal will make the
native akin to Kuber.
~3ISk*3I7+3ISk*3I9~n
Mangal in Yuvati or in Dharm Bhava in Kautuk Avastha will
give several diseases and death of the first child and
wife.
~3ISk-*3I7+3ISk-*3I9~
In other bhavas (i.e. not in Yuvati or Dharm Bhava), Kautuk
Avastha will confer scholarship, various kinds of wealth,
two wives, and more female children.
~3ISi*3I1+3ISi*3I2+3ISi*3I3+3ISi*3I9+3ISi*3I10+3ISi*3I11~n
In Nidr Avastha, Mangal in Lagn, Dhan, Sahaj, Dharm, Karm,
or Labh Bhava will give scholarship, foolishness, and
poverty.
~3ISi*3I5+3ISi*3I7~n
Putr or Yuvati Bhava placement of Mangal in Nidr Avastha
will give many miseries and many male children.
~3ISi*3Y8~n
Should Rahu join Mangal in Nidr Avastha in any bhava the
native will have many wives, be miserable, and will suffer
from some diseases on the surface of the feet.
~4ISy*4I1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P166_B001_06

- 身份：正文
- PDF 页：166
- 偈颂：52-63
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 52-63 [present] · PDF page 166

52-63. Effects of Chandr's Avasthas at Birth: If Chandr is
in Sayan Avastha, the native will be honourable, sluggish,
given to sexual lust, and he will face financial
destruction.
~2ISu~n
If Chandr is in Upavesan Avastha, the native will be
troubled by diseases, he will be dull-witted, not endowed
with mentionable wealth (i.e. will have only negligible
wealth); he will be hard-hearted, will do unworthy acts,
and will steal others' wealth.
~2ISn~n
If Chandr is in Netrapani Avastha, the native will be
troubled by great diseases (long lasting in nature), be
very garrulous, wicked, and he will indulge in bad deeds.
~2ISp~
Should Chandr be in Prakash Avastha, the native will be
famous in the world, he will have his virtues exposed
through royal patronage; he will be surrounded by horses,
elephants, females, and ornaments; he will visit shrines.
~2ISg*2w~n
If Chandr is in Gaman Avastha, with decreasing rays the
native will be sinful, cruel, and always troubled by
afflictions of sight;
~2ISg*2W~n
if Chandr is in Gaman Avastha with increasing rays, the
native will be distressed due to fear.
~2ISa~n
If Chandr is in Agaman Avastha, the native will be
honourable; he will suffer diseases of the feet; he will
secretly indulge in sinful acts; he will be poor and devoid
of intelligence and happiness.
~2ISb~
If Chandr is in Sabh Avastha, the native will be eminent
among men, honoured by kings, and kings of kings; he will
be very beautiful, will subdue the passion of women and he
will be skillful in sexual acts; he will be virtuous.
~2ISv~n
If Chandr is in Agam Avastha, the native will be garrulous,
and virtuous and if the said Chandr is of dark fortnight
the native will have two wives; he will be sick, highly
wicked, and he will be violent.
~2ISh~
If Chandr is in Bhojan Avastha, the native will be endowed
with honour, conveyances, attendants, social status, wife
and daughters, provided Chandr is Full 'Purna Chandr';
~2ISh*2x~n
if Chandr is in Bhojan Avastha and is of dark fortnight
auspicious effects (i.e. honour, conveyances, attendants,
social status, wife and daughters) will fail to come.
~2ISt*2X~
If Chandr  is in Nritya Lips Avastha and is endowed with
(fort nightly) strength, the native will be strong, he will
have knowledge of songs, and he will be a critic of beauty
of things.
~2INi*2x~n
If Chandr is in Nritya Lips Avastha and of dark fortnight,
i.e. not endowed with strength, the person will be sinful.
~2ISk~m
If Chandr  is in Kautuk Avastha, the native will attain
kinship, lordship over wealth, and skill in sexual acts and
in sporting with harlots.
~2W*2Y5*2ISi~
Should waxing Chandr being yuti with Guru be in Nidr
Avastha, the native will be quite eminent.
~2W*2I*2ISi~n
If waxing Chandr is in Nidr Avastha but devoid of Guru's
yuti, the native will lose his wealth on account of
females, and female jackals will be crying around his abode
(as though it were a cemetery).
~3ISy~n
64 75. Effects of the Avasthas of Mangal at Birth: If
Mangal is in Sayan Avastha, the native will be troubled by
wounds, itch, and ulcer.
~3ISu~n
If Mangal is placed in Upavesan Avastha,the native will be
strong, sinful, untruthful, eminent, wealthy, and bereft of
virtues.
~3I1*3ISn~n
If Mangal is placed in Lagn and happen to be in Netrapani
Avastha there will be penury;
~-3I1*3ISn~
if Mangal is placed in other bhavas (i.e. in one of the
bhavas other than Tanu Bhava), Netrapani Avastha will
confer rulership of a city.
~3ISp~
Should Mangal be in Prakash Avastha, the native will shine
with virtues and will be honoured by the king.
~3ISp*3I5~n
Mangal in Prakash Avastha in Putr Bhava will, cause loss of
children and of wife.
~3ISp*3I5*3Y8~n
If Mangal is in Prakash Avastha in Putr Bhava and happens
to be there with Rahu, a severe (positional) fall will
descend on the native.
~3ISg~n
Should Mangal be in Gaman Avastha the native will be always
roaming, will have fear of multiple ulcers, will incur
misunderstandings with females, will be afflicted by boils,
itches, etc., and will incur financial decline.
~3ISa~
If Mangal happens to be in Agaman Avastha, the native will
be virtuous, endowed with precious gems, will adore a sharp
sword, will walk with the (majestic) gait of an elephant
(imparting surprise in the onlooker), will destroy his
enemies, and will remove the miseries of his people.
~3ISb*3E~
If Mangal is placed in Sabh Avastha and happens to be in
exaltation the native will be skilful in conducting wars,
will hold the flag of righteousness aloft, and will be
wealthy;
~3ISb*3E*3I5+~3ISb*3E*3I9~n
if Mangal happens to be in Sabh Avastha in Putr, or Dharm
Bhava, the native will be bereft of learning;
~3ISb*3E*3I12~n
if Mangal is in Sabh Avastha in Vyaya Bhava childlessness
and no wife and no friends will result;
~-3I5*-3I9*-3I12*3ISb~
and if Mangal is in other bhavas (i.e. other than Putr,
Dharm, and Vyaya Bhava), in Sabh Avastha, the native will
be a scholar in a king's court (i.e. be a poet laureate),
be very wealthy, honourable, and charitable.
~3ISv~n
If Mangal is in Agam Avastha, the native will be devoid of
virtues and good deeds, will be distressed by diseases,
will acquire diseases of the root of the ears ('Karan
Mularogam' & 'Padamulam Urumulam', etc.), and severe gout
pains; he will be timid and will befriend evil lot.
~3X*3ISh~
If Mangal is with strength, while in Bhojan Avastha, the
native will eat sweet-food;
~3x*3ISh~n
if Mangal is devoid of strength, while in Bhojan Avastha,
the native will indulge in base acts and be dishonourable.
~3ISt~
If Mangal is in Nritya Lips Avastha, the native will earn
wealth through the king and will be endowed with fullness
of gold, diamonds, and corals in his house.
~3ISk~
If Mangal is in Kautuk Avastha the native will be curious
in disposition and will be endowed with friends and sons;
~3ISk*3E~
if Mangal is in Kautuk Avastha and simultaneously exalted,
the native will be honoured by the king and the virtuous
and he will be virtuous  himself.
~3ISi~n
If Mangal is in Nidr Avastha, the native will be
short-tempered, devoid of intelligence and wealth; he will
be wicked, fallen from virtuous path, and troubled by
diseases.
~3ISu*3I1~n
Should Mangal be in Upavesan Avastha in Lagn, the native
will be extremely sinful, and he will incur several
diseases; he will be indigent and not peaceful.
~3ISu*3I9~n
If Upavesan Avastha occurs for Mangal in Dharm Bhava, the
native will lose his whole wealth apart from his wife and
progeny.
~3ISn*3I1~n
Mangal in Netrapani  Avastha in Lagn will give poverty and
will destroy the native's wife and progeny;
~3ISn*-3I1~
If Mangal is in Netrapani Avastha in other bhavas (i.e. in
bhavas other than Tanu Bhava), this confers on the native
all kinds of wealth and happiness from wife and children.
~3ISn*3I2+3ISn*3I7~n
The Dhan Bhava position or Yuvati Bhava position of Mangal
in Netrapani Avastha will cause fear from lions and snakes,
apart from giving earnings from lands. Furthermore, the
native's wife will predecease him.
~3ISp*3I5+3ISp*3I5~n
Should Mangal be in Prakash Avastha in Putr or in Yuvati
Bhava, the native will lose his wife and all children.
~3ISp*3I5*3Y7~n
If Mangal is placed in Putr Bhava in Prakash Avastha, and
is yuti with Shani, the native will kill cows.
~3ISg*3I1~n
Should Mangal be in Gaman Avastha  in Lagn, the native will
be active in his assignments, will incur diseases of the
joints, burning pains in the eyes, and will obtain dental
afflictions and the like; he will have fear from dogs and
will adore the guise of a female.
~3ISg*-3I1~
In other bhavas, other than Tanu Bhava, Mangal in Gaman
Avastha will bring royal favours, leadership ,and luxuries
of life.
~3ISa~n
Mangal in Agaman Avastha will cause piles and diseases of
the rectum.
~3ISh*3I5+3ISy*3I5+3ISh*3I8+3ISy*3I8~n
If Mangal is in Bhojan Avastha or in Sayan Avastha in Putr
Bhava, or in Randhr Bhava, there will be untimely death for
the native.
~3ISh*-3I5+3ISy*-3I5+3ISh*-3I8+3ISy*-3I8~
In other bhavas, other than Putr and Randhr Bhava, Bhojan
Avastha of Mangal will confer wealth.
~3ISt*3I1+3ISt*3I2+3ISt*3I7+3ISt*3I10~
Should Mangal be in Nritya Lips Avastha and happens to be
in Lagn, Dhan, Yuvati, or Karm Bhava, the native will
receive all kinds of happiness;
~3ISt*3I8+3ISt*3I9~n
there will be miseries in abundance if Mangal is in Nritya
Lips Avastha and placed in Randhr or Dharm Bhava, apart
from incurring untimely death.
~3ISt*3I3+3ISt*3I4+3ISt*3I5+3ISt*3I6+3ISt*3I11+3ISt*3I12~
In other bhavas (i.e. Sahaj, Bandhu, Putr, Ari, Labh, or
Vyaya Bhava), Nritya Lips Avastha of Mangal will make the
native akin to Kuber.
~3ISk*3I7+3ISk*3I9~n
Mangal in Yuvati or in Dharm Bhava in Kautuk Avastha will
give several diseases and death of the first child and
wife.
~3ISk-*3I7+3ISk-*3I9~
In other bhavas (i.e. not in Yuvati or Dharm Bhava), Kautuk
Avastha will confer scholarship, various kinds of wealth,
two wives, and more female children.
~3ISi*3I1+3ISi*3I2+3ISi*3I3+3ISi*3I9+3ISi*3I10+3ISi*3I11~n
In Nidr Avastha, Mangal in Lagn, Dhan, Sahaj, Dharm, Karm,
or Labh Bhava will give scholarship, foolishness, and
poverty.
~3ISi*3I5+3ISi*3I7~n
Putr or Yuvati Bhava placement of Mangal in Nidr Avastha
will give many miseries and many male children.
~3ISi*3Y8~n
Should Rahu join Mangal in Nidr Avastha in any bhava the
native will have many wives, be miserable, and will suffer
from some diseases on the surface of the feet.
~4ISy*4I1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P166_B001_07

- 身份：正文
- PDF 页：166
- 偈颂：52-63
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 52-63 [present] · PDF page 166

52-63. Effects of Chandr's Avasthas at Birth: If Chandr is
in Sayan Avastha, the native will be honourable, sluggish,
given to sexual lust, and he will face financial
destruction.
~2ISu~n
If Chandr is in Upavesan Avastha, the native will be
troubled by diseases, he will be dull-witted, not endowed
with mentionable wealth (i.e. will have only negligible
wealth); he will be hard-hearted, will do unworthy acts,
and will steal others' wealth.
~2ISn~n
If Chandr is in Netrapani Avastha, the native will be
troubled by great diseases (long lasting in nature), be
very garrulous, wicked, and he will indulge in bad deeds.
~2ISp~
Should Chandr be in Prakash Avastha, the native will be
famous in the world, he will have his virtues exposed
through royal patronage; he will be surrounded by horses,
elephants, females, and ornaments; he will visit shrines.
~2ISg*2w~n
If Chandr is in Gaman Avastha, with decreasing rays the
native will be sinful, cruel, and always troubled by
afflictions of sight;
~2ISg*2W~n
if Chandr is in Gaman Avastha with increasing rays, the
native will be distressed due to fear.
~2ISa~n
If Chandr is in Agaman Avastha, the native will be
honourable; he will suffer diseases of the feet; he will
secretly indulge in sinful acts; he will be poor and devoid
of intelligence and happiness.
~2ISb~
If Chandr is in Sabh Avastha, the native will be eminent
among men, honoured by kings, and kings of kings; he will
be very beautiful, will subdue the passion of women and he
will be skillful in sexual acts; he will be virtuous.
~2ISv~n
If Chandr is in Agam Avastha, the native will be garrulous,
and virtuous and if the said Chandr is of dark fortnight
the native will have two wives; he will be sick, highly
wicked, and he will be violent.
~2ISh~
If Chandr is in Bhojan Avastha, the native will be endowed
with honour, conveyances, attendants, social status, wife
and daughters, provided Chandr is Full 'Purna Chandr';
~2ISh*2x~n
if Chandr is in Bhojan Avastha and is of dark fortnight
auspicious effects (i.e. honour, conveyances, attendants,
social status, wife and daughters) will fail to come.
~2ISt*2X~
If Chandr  is in Nritya Lips Avastha and is endowed with
(fort nightly) strength, the native will be strong, he will
have knowledge of songs, and he will be a critic of beauty
of things.
~2INi*2x~n
If Chandr is in Nritya Lips Avastha and of dark fortnight,
i.e. not endowed with strength, the person will be sinful.
~2ISk~m
If Chandr  is in Kautuk Avastha, the native will attain
kinship, lordship over wealth, and skill in sexual acts and
in sporting with harlots.
~2W*2Y5*2ISi~
Should waxing Chandr being yuti with Guru be in Nidr
Avastha, the native will be quite eminent.
~2W*2I*2ISi~n
If waxing Chandr is in Nidr Avastha but devoid of Guru's
yuti, the native will lose his wealth on account of
females, and female jackals will be crying around his abode
(as though it were a cemetery).
~3ISy~n
64 75. Effects of the Avasthas of Mangal at Birth: If
Mangal is in Sayan Avastha, the native will be troubled by
wounds, itch, and ulcer.
~3ISu~n
If Mangal is placed in Upavesan Avastha,the native will be
strong, sinful, untruthful, eminent, wealthy, and bereft of
virtues.
~3I1*3ISn~n
If Mangal is placed in Lagn and happen to be in Netrapani
Avastha there will be penury;
~-3I1*3ISn~
if Mangal is placed in other bhavas (i.e. in one of the
bhavas other than Tanu Bhava), Netrapani Avastha will
confer rulership of a city.
~3ISp~
Should Mangal be in Prakash Avastha, the native will shine
with virtues and will be honoured by the king.
~3ISp*3I5~n
Mangal in Prakash Avastha in Putr Bhava will, cause loss of
children and of wife.
~3ISp*3I5*3Y8~n
If Mangal is in Prakash Avastha in Putr Bhava and happens
to be there with Rahu, a severe (positional) fall will
descend on the native.
~3ISg~n
Should Mangal be in Gaman Avastha the native will be always
roaming, will have fear of multiple ulcers, will incur
misunderstandings with females, will be afflicted by boils,
itches, etc., and will incur financial decline.
~3ISa~
If Mangal happens to be in Agaman Avastha, the native will
be virtuous, endowed with precious gems, will adore a sharp
sword, will walk with the (majestic) gait of an elephant
(imparting surprise in the onlooker), will destroy his
enemies, and will remove the miseries of his people.
~3ISb*3E~
If Mangal is placed in Sabh Avastha and happens to be in
exaltation the native will be skilful in conducting wars,
will hold the flag of righteousness aloft, and will be
wealthy;
~3ISb*3E*3I5+~3ISb*3E*3I9~n
if Mangal happens to be in Sabh Avastha in Putr, or Dharm
Bhava, the native will be bereft of learning;
~3ISb*3E*3I12~n
if Mangal is in Sabh Avastha in Vyaya Bhava childlessness
and no wife and no friends will result;
~-3I5*-3I9*-3I12*3ISb~
and if Mangal is in other bhavas (i.e. other than Putr,
Dharm, and Vyaya Bhava), in Sabh Avastha, the native will
be a scholar in a king's court (i.e. be a poet laureate),
be very wealthy, honourable, and charitable.
~3ISv~n
If Mangal is in Agam Avastha, the native will be devoid of
virtues and good deeds, will be distressed by diseases,
will acquire diseases of the root of the ears ('Karan
Mularogam' & 'Padamulam Urumulam', etc.), and severe gout
pains; he will be timid and will befriend evil lot.
~3X*3ISh~
If Mangal is with strength, while in Bhojan Avastha, the
native will eat sweet-food;
~3x*3ISh~n
if Mangal is devoid of strength, while in Bhojan Avastha,
the native will indulge in base acts and be dishonourable.
~3ISt~
If Mangal is in Nritya Lips Avastha, the native will earn
wealth through the king and will be endowed with fullness
of gold, diamonds, and corals in his house.
~3ISk~
If Mangal is in Kautuk Avastha the native will be curious
in disposition and will be endowed with friends and sons;
~3ISk*3E~
if Mangal is in Kautuk Avastha and simultaneously exalted,
the native will be honoured by the king and the virtuous
and he will be virtuous  himself.
~3ISi~n
If Mangal is in Nidr Avastha, the native will be
short-tempered, devoid of intelligence and wealth; he will
be wicked, fallen from virtuous path, and troubled by
diseases.
~3ISu*3I1~n
Should Mangal be in Upavesan Avastha in Lagn, the native
will be extremely sinful, and he will incur several
diseases; he will be indigent and not peaceful.
~3ISu*3I9~n
If Upavesan Avastha occurs for Mangal in Dharm Bhava, the
native will lose his whole wealth apart from his wife and
progeny.
~3ISn*3I1~n
Mangal in Netrapani  Avastha in Lagn will give poverty and
will destroy the native's wife and progeny;
~3ISn*-3I1~
If Mangal is in Netrapani Avastha in other bhavas (i.e. in
bhavas other than Tanu Bhava), this confers on the native
all kinds of wealth and happiness from wife and children.
~3ISn*3I2+3ISn*3I7~n
The Dhan Bhava position or Yuvati Bhava position of Mangal
in Netrapani Avastha will cause fear from lions and snakes,
apart from giving earnings from lands. Furthermore, the
native's wife will predecease him.
~3ISp*3I5+3ISp*3I5~n
Should Mangal be in Prakash Avastha in Putr or in Yuvati
Bhava, the native will lose his wife and all children.
~3ISp*3I5*3Y7~n
If Mangal is placed in Putr Bhava in Prakash Avastha, and
is yuti with Shani, the native will kill cows.
~3ISg*3I1~n
Should Mangal be in Gaman Avastha  in Lagn, the native will
be active in his assignments, will incur diseases of the
joints, burning pains in the eyes, and will obtain dental
afflictions and the like; he will have fear from dogs and
will adore the guise of a female.
~3ISg*-3I1~
In other bhavas, other than Tanu Bhava, Mangal in Gaman
Avastha will bring royal favours, leadership ,and luxuries
of life.
~3ISa~n
Mangal in Agaman Avastha will cause piles and diseases of
the rectum.
~3ISh*3I5+3ISy*3I5+3ISh*3I8+3ISy*3I8~n
If Mangal is in Bhojan Avastha or in Sayan Avastha in Putr
Bhava, or in Randhr Bhava, there will be untimely death for
the native.
~3ISh*-3I5+3ISy*-3I5+3ISh*-3I8+3ISy*-3I8~
In other bhavas, other than Putr and Randhr Bhava, Bhojan
Avastha of Mangal will confer wealth.
~3ISt*3I1+3ISt*3I2+3ISt*3I7+3ISt*3I10~
Should Mangal be in Nritya Lips Avastha and happens to be
in Lagn, Dhan, Yuvati, or Karm Bhava, the native will
receive all kinds of happiness;
~3ISt*3I8+3ISt*3I9~n
there will be miseries in abundance if Mangal is in Nritya
Lips Avastha and placed in Randhr or Dharm Bhava, apart
from incurring untimely death.
~3ISt*3I3+3ISt*3I4+3ISt*3I5+3ISt*3I6+3ISt*3I11+3ISt*3I12~
In other bhavas (i.e. Sahaj, Bandhu, Putr, Ari, Labh, or
Vyaya Bhava), Nritya Lips Avastha of Mangal will make the
native akin to Kuber.
~3ISk*3I7+3ISk*3I9~n
Mangal in Yuvati or in Dharm Bhava in Kautuk Avastha will
give several diseases and death of the first child and
wife.
~3ISk-*3I7+3ISk-*3I9~
In other bhavas (i.e. not in Yuvati or Dharm Bhava), Kautuk
Avastha will confer scholarship, various kinds of wealth,
two wives, and more female children.
~3ISi*3I1+3ISi*3I2+3ISi*3I3+3ISi*3I9+3ISi*3I10+3ISi*3I11~n
In Nidr Avastha, Mangal in Lagn, Dhan, Sahaj, Dharm, Karm,
or Labh Bhava will give scholarship, foolishness, and
poverty.
~3ISi*3I5+3ISi*3I7~n
Putr or Yuvati Bhava placement of Mangal in Nidr Avastha
will give many miseries and many male children.
~3ISi*3Y8~n
Should Rahu join Mangal in Nidr Avastha in any bhava the
native will have many wives, be miserable, and will suffer
from some diseases on the surface of the feet.
~4ISy*4I1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P166_B001_08

- 身份：正文
- PDF 页：166
- 偈颂：52-63
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 52-63 [present] · PDF page 166

52-63. Effects of Chandr's Avasthas at Birth: If Chandr is
in Sayan Avastha, the native will be honourable, sluggish,
given to sexual lust, and he will face financial
destruction.
~2ISu~n
If Chandr is in Upavesan Avastha, the native will be
troubled by diseases, he will be dull-witted, not endowed
with mentionable wealth (i.e. will have only negligible
wealth); he will be hard-hearted, will do unworthy acts,
and will steal others' wealth.
~2ISn~n
If Chandr is in Netrapani Avastha, the native will be
troubled by great diseases (long lasting in nature), be
very garrulous, wicked, and he will indulge in bad deeds.
~2ISp~
Should Chandr be in Prakash Avastha, the native will be
famous in the world, he will have his virtues exposed
through royal patronage; he will be surrounded by horses,
elephants, females, and ornaments; he will visit shrines.
~2ISg*2w~n
If Chandr is in Gaman Avastha, with decreasing rays the
native will be sinful, cruel, and always troubled by
afflictions of sight;
~2ISg*2W~n
if Chandr is in Gaman Avastha with increasing rays, the
native will be distressed due to fear.
~2ISa~n
If Chandr is in Agaman Avastha, the native will be
honourable; he will suffer diseases of the feet; he will
secretly indulge in sinful acts; he will be poor and devoid
of intelligence and happiness.
~2ISb~
If Chandr is in Sabh Avastha, the native will be eminent
among men, honoured by kings, and kings of kings; he will
be very beautiful, will subdue the passion of women and he
will be skillful in sexual acts; he will be virtuous.
~2ISv~n
If Chandr is in Agam Avastha, the native will be garrulous,
and virtuous and if the said Chandr is of dark fortnight
the native will have two wives; he will be sick, highly
wicked, and he will be violent.
~2ISh~
If Chandr is in Bhojan Avastha, the native will be endowed
with honour, conveyances, attendants, social status, wife
and daughters, provided Chandr is Full 'Purna Chandr';
~2ISh*2x~n
if Chandr is in Bhojan Avastha and is of dark fortnight
auspicious effects (i.e. honour, conveyances, attendants,
social status, wife and daughters) will fail to come.
~2ISt*2X~
If Chandr  is in Nritya Lips Avastha and is endowed with
(fort nightly) strength, the native will be strong, he will
have knowledge of songs, and he will be a critic of beauty
of things.
~2INi*2x~n
If Chandr is in Nritya Lips Avastha and of dark fortnight,
i.e. not endowed with strength, the person will be sinful.
~2ISk~m
If Chandr  is in Kautuk Avastha, the native will attain
kinship, lordship over wealth, and skill in sexual acts and
in sporting with harlots.
~2W*2Y5*2ISi~
Should waxing Chandr being yuti with Guru be in Nidr
Avastha, the native will be quite eminent.
~2W*2I*2ISi~n
If waxing Chandr is in Nidr Avastha but devoid of Guru's
yuti, the native will lose his wealth on account of
females, and female jackals will be crying around his abode
(as though it were a cemetery).
~3ISy~n
64 75. Effects of the Avasthas of Mangal at Birth: If
Mangal is in Sayan Avastha, the native will be troubled by
wounds, itch, and ulcer.
~3ISu~n
If Mangal is placed in Upavesan Avastha,the native will be
strong, sinful, untruthful, eminent, wealthy, and bereft of
virtues.
~3I1*3ISn~n
If Mangal is placed in Lagn and happen to be in Netrapani
Avastha there will be penury;
~-3I1*3ISn~
if Mangal is placed in other bhavas (i.e. in one of the
bhavas other than Tanu Bhava), Netrapani Avastha will
confer rulership of a city.
~3ISp~
Should Mangal be in Prakash Avastha, the native will shine
with virtues and will be honoured by the king.
~3ISp*3I5~n
Mangal in Prakash Avastha in Putr Bhava will, cause loss of
children and of wife.
~3ISp*3I5*3Y8~n
If Mangal is in Prakash Avastha in Putr Bhava and happens
to be there with Rahu, a severe (positional) fall will
descend on the native.
~3ISg~n
Should Mangal be in Gaman Avastha the native will be always
roaming, will have fear of multiple ulcers, will incur
misunderstandings with females, will be afflicted by boils,
itches, etc., and will incur financial decline.
~3ISa~
If Mangal happens to be in Agaman Avastha, the native will
be virtuous, endowed with precious gems, will adore a sharp
sword, will walk with the (majestic) gait of an elephant
(imparting surprise in the onlooker), will destroy his
enemies, and will remove the miseries of his people.
~3ISb*3E~
If Mangal is placed in Sabh Avastha and happens to be in
exaltation the native will be skilful in conducting wars,
will hold the flag of righteousness aloft, and will be
wealthy;
~3ISb*3E*3I5+~3ISb*3E*3I9~n
if Mangal happens to be in Sabh Avastha in Putr, or Dharm
Bhava, the native will be bereft of learning;
~3ISb*3E*3I12~n
if Mangal is in Sabh Avastha in Vyaya Bhava childlessness
and no wife and no friends will result;
~-3I5*-3I9*-3I12*3ISb~
and if Mangal is in other bhavas (i.e. other than Putr,
Dharm, and Vyaya Bhava), in Sabh Avastha, the native will
be a scholar in a king's court (i.e. be a poet laureate),
be very wealthy, honourable, and charitable.
~3ISv~n
If Mangal is in Agam Avastha, the native will be devoid of
virtues and good deeds, will be distressed by diseases,
will acquire diseases of the root of the ears ('Karan
Mularogam' & 'Padamulam Urumulam', etc.), and severe gout
pains; he will be timid and will befriend evil lot.
~3X*3ISh~
If Mangal is with strength, while in Bhojan Avastha, the
native will eat sweet-food;
~3x*3ISh~n
if Mangal is devoid of strength, while in Bhojan Avastha,
the native will indulge in base acts and be dishonourable.
~3ISt~
If Mangal is in Nritya Lips Avastha, the native will earn
wealth through the king and will be endowed with fullness
of gold, diamonds, and corals in his house.
~3ISk~
If Mangal is in Kautuk Avastha the native will be curious
in disposition and will be endowed with friends and sons;
~3ISk*3E~
if Mangal is in Kautuk Avastha and simultaneously exalted,
the native will be honoured by the king and the virtuous
and he will be virtuous  himself.
~3ISi~n
If Mangal is in Nidr Avastha, the native will be
short-tempered, devoid of intelligence and wealth; he will
be wicked, fallen from virtuous path, and troubled by
diseases.
~3ISu*3I1~n
Should Mangal be in Upavesan Avastha in Lagn, the native
will be extremely sinful, and he will incur several
diseases; he will be indigent and not peaceful.
~3ISu*3I9~n
If Upavesan Avastha occurs for Mangal in Dharm Bhava, the
native will lose his whole wealth apart from his wife and
progeny.
~3ISn*3I1~n
Mangal in Netrapani  Avastha in Lagn will give poverty and
will destroy the native's wife and progeny;
~3ISn*-3I1~
If Mangal is in Netrapani Avastha in other bhavas (i.e. in
bhavas other than Tanu Bhava), this confers on the native
all kinds of wealth and happiness from wife and children.
~3ISn*3I2+3ISn*3I7~n
The Dhan Bhava position or Yuvati Bhava position of Mangal
in Netrapani Avastha will cause fear from lions and snakes,
apart from giving earnings from lands. Furthermore, the
native's wife will predecease him.
~3ISp*3I5+3ISp*3I5~n
Should Mangal be in Prakash Avastha in Putr or in Yuvati
Bhava, the native will lose his wife and all children.
~3ISp*3I5*3Y7~n
If Mangal is placed in Putr Bhava in Prakash Avastha, and
is yuti with Shani, the native will kill cows.
~3ISg*3I1~n
Should Mangal be in Gaman Avastha  in Lagn, the native will
be active in his assignments, will incur diseases of the
joints, burning pains in the eyes, and will obtain dental
afflictions and the like; he will have fear from dogs and
will adore the guise of a female.
~3ISg*-3I1~
In other bhavas, other than Tanu Bhava, Mangal in Gaman
Avastha will bring royal favours, leadership ,and luxuries
of life.
~3ISa~n
Mangal in Agaman Avastha will cause piles and diseases of
the rectum.
~3ISh*3I5+3ISy*3I5+3ISh*3I8+3ISy*3I8~n
If Mangal is in Bhojan Avastha or in Sayan Avastha in Putr
Bhava, or in Randhr Bhava, there will be untimely death for
the native.
~3ISh*-3I5+3ISy*-3I5+3ISh*-3I8+3ISy*-3I8~
In other bhavas, other than Putr and Randhr Bhava, Bhojan
Avastha of Mangal will confer wealth.
~3ISt*3I1+3ISt*3I2+3ISt*3I7+3ISt*3I10~
Should Mangal be in Nritya Lips Avastha and happens to be
in Lagn, Dhan, Yuvati, or Karm Bhava, the native will
receive all kinds of happiness;
~3ISt*3I8+3ISt*3I9~n
there will be miseries in abundance if Mangal is in Nritya
Lips Avastha and placed in Randhr or Dharm Bhava, apart
from incurring untimely death.
~3ISt*3I3+3ISt*3I4+3ISt*3I5+3ISt*3I6+3ISt*3I11+3ISt*3I12~
In other bhavas (i.e. Sahaj, Bandhu, Putr, Ari, Labh, or
Vyaya Bhava), Nritya Lips Avastha of Mangal will make the
native akin to Kuber.
~3ISk*3I7+3ISk*3I9~n
Mangal in Yuvati or in Dharm Bhava in Kautuk Avastha will
give several diseases and death of the first child and
wife.
~3ISk-*3I7+3ISk-*3I9~
In other bhavas (i.e. not in Yuvati or Dharm Bhava), Kautuk
Avastha will confer scholarship, various kinds of wealth,
two wives, and more female children.
~3ISi*3I1+3ISi*3I2+3ISi*3I3+3ISi*3I9+3ISi*3I10+3ISi*3I11~n
In Nidr Avastha, Mangal in Lagn, Dhan, Sahaj, Dharm, Karm,
or Labh Bhava will give scholarship, foolishness, and
poverty.
~3ISi*3I5+3ISi*3I7~n
Putr or Yuvati Bhava placement of Mangal in Nidr Avastha
will give many miseries and many male children.
~3ISi*3Y8~n
Should Rahu join Mangal in Nidr Avastha in any bhava the
native will have many wives, be miserable, and will suffer
from some diseases on the surface of the feet.
~4ISy*4I1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P167_B001_01

- 身份：正文
- PDF 页：167
- 偈颂：76-86
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 76-86 [present] · PDF page 167

76-86. Effects of Buddh's Avasthas at Birth: Should Buddh
in Sayan Avastha be in Lagn, the native will be lame and
will have reddish eyes (like the black bee);
~4ISy*-4I1~n
if Buddh is in Sayan Avastha in other bhavas (i.e. other
than Tanu Bhava), the native will be addicted to licentious
(i.e. disregarding certain rules) pleasures and be wicked.
~4ISu*4I1~
If Buddh is in Upavesan Avastha in Lagn, the native will
possess (the seven principle) virtues;
~4ISu*4I1*4Dm~n
if Buddh in Upavesan Avastha is in Lagn, receiving a
drishti from a malefic, or drishtis from malefics, or is
yuti with malefics, penury will result;
~4ISu*4I1*4DB~
and if Buddh in Upavesan Avastha is in Lagn receiving a
drishti from a benefic, or drishtis from benefics, or is
yuti with benefics, financial happiness will follow.
~4ISn~m
If Buddh is in Netrapani Avastha, the native will be devoid
of learning, wisdom, well wishers, and satisfaction but he
will be honourable;
~4ISn*4I5~m
if Buddh is in Putr Bhava in Netrapani  Avastha, the
subject will be bereft of happiness from wife and sons; he
will be endowed with (more) female children and will gain
abundant finance through royal patronage.
~4ISp~
If Buddh is in Prakash Avastha, the native will be
charitable, merciful, and meritorious; he will cross the
boundaries of ocean in respect of many branches of
learning; he will be endowed with the great faculty of
discrimination, and he will destroy evil people.
~4ISg+4ISa~
If Buddh is in Gaman Avastha the native will visit the
courts of kings on many occasions and Goddess Lakshmi
(denoting wealth) will dwell in his abode.
~?~
If Buddh is in Agaman Avastha, the same effects due to his
being in Gaman Avastha will fructify, i.e. the native will
visit the courts of kings on many occasions and Goddess
Lakshmi (denoting wealth) will dwell in his abode.
~4ISb*4E~
If Buddh is in Sabh Avastha and happens to be in
exaltation, the native will be affluent and meritorious at
all times; he will be equal to Kuber (the lord of wealth);
or he will be a king or a minister; he will be devoted to
Lord Vishnu and Lord Shiva; he will be virtuous and will
attain full enlightenment.
~4ISv~
Should Buddh be in Agam Avastha the native will serve base
men and gain wealth thereby; and he will have two sons and
one fame bringing daughter.
~4ISh~n
If Buddh is in Bhojan Avastha, the native will face
financial losses through litigations, will physically lose
on account of fear from the king (i.e. he will become thin
due to royal wrath); he will be fickle-minded and will be
bereft of physical and conjugal felicity.
~4ISt~
If Buddh is in Nritya Lips Avastha, the native will be
endowed with honour, conveyances, corals (i.e. gems, etc.),
sons, friends, prowess, and recognition in assembly due to
his scholarship;
~4ISt*4z~n
if Buddh in Nritya Lips Avastha is in a malefic's rashi the
native will be addicted to prostitutes and will long for
licentious pleasures.
~4ISk*4I1~
If Buddh is in Kautuk Avastha in Lagn, the native will be
skilful in music;
~4ISk*4I7+4ISk*4I8~n
if Buddh is in Yuvati or Randhr Bhava with Kautuk Avastha
the native will be addicted to courtezans;
~4ISk*4I9~
and if Buddh in Kautuk Avastha is placed in Dharm Bhava,
the native will be meritorious and attain heavens after
death.
~4ISi~n
If Buddh is in Nidr Avastha, the native will not enjoy
comfortable sleep; he will be afflicted by neck or neck
joint 'Samadhi' diseases; he will be devoid of co-born,
afflicted by miseries galore (i.e. in abundance), will
enter into litigations with his own men, and he will lose
wealth and honour.
~5ISy~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P167_B001_02

- 身份：正文
- PDF 页：167
- 偈颂：76-86
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 76-86 [present] · PDF page 167

76-86. Effects of Buddh's Avasthas at Birth: Should Buddh
in Sayan Avastha be in Lagn, the native will be lame and
will have reddish eyes (like the black bee);
~4ISy*-4I1~n
if Buddh is in Sayan Avastha in other bhavas (i.e. other
than Tanu Bhava), the native will be addicted to licentious
(i.e. disregarding certain rules) pleasures and be wicked.
~4ISu*4I1~
If Buddh is in Upavesan Avastha in Lagn, the native will
possess (the seven principle) virtues;
~4ISu*4I1*4Dm~n
if Buddh in Upavesan Avastha is in Lagn, receiving a
drishti from a malefic, or drishtis from malefics, or is
yuti with malefics, penury will result;
~4ISu*4I1*4DB~
and if Buddh in Upavesan Avastha is in Lagn receiving a
drishti from a benefic, or drishtis from benefics, or is
yuti with benefics, financial happiness will follow.
~4ISn~m
If Buddh is in Netrapani Avastha, the native will be devoid
of learning, wisdom, well wishers, and satisfaction but he
will be honourable;
~4ISn*4I5~m
if Buddh is in Putr Bhava in Netrapani  Avastha, the
subject will be bereft of happiness from wife and sons; he
will be endowed with (more) female children and will gain
abundant finance through royal patronage.
~4ISp~
If Buddh is in Prakash Avastha, the native will be
charitable, merciful, and meritorious; he will cross the
boundaries of ocean in respect of many branches of
learning; he will be endowed with the great faculty of
discrimination, and he will destroy evil people.
~4ISg+4ISa~
If Buddh is in Gaman Avastha the native will visit the
courts of kings on many occasions and Goddess Lakshmi
(denoting wealth) will dwell in his abode.
~?~
If Buddh is in Agaman Avastha, the same effects due to his
being in Gaman Avastha will fructify, i.e. the native will
visit the courts of kings on many occasions and Goddess
Lakshmi (denoting wealth) will dwell in his abode.
~4ISb*4E~
If Buddh is in Sabh Avastha and happens to be in
exaltation, the native will be affluent and meritorious at
all times; he will be equal to Kuber (the lord of wealth);
or he will be a king or a minister; he will be devoted to
Lord Vishnu and Lord Shiva; he will be virtuous and will
attain full enlightenment.
~4ISv~
Should Buddh be in Agam Avastha the native will serve base
men and gain wealth thereby; and he will have two sons and
one fame bringing daughter.
~4ISh~n
If Buddh is in Bhojan Avastha, the native will face
financial losses through litigations, will physically lose
on account of fear from the king (i.e. he will become thin
due to royal wrath); he will be fickle-minded and will be
bereft of physical and conjugal felicity.
~4ISt~
If Buddh is in Nritya Lips Avastha, the native will be
endowed with honour, conveyances, corals (i.e. gems, etc.),
sons, friends, prowess, and recognition in assembly due to
his scholarship;
~4ISt*4z~n
if Buddh in Nritya Lips Avastha is in a malefic's rashi the
native will be addicted to prostitutes and will long for
licentious pleasures.
~4ISk*4I1~
If Buddh is in Kautuk Avastha in Lagn, the native will be
skilful in music;
~4ISk*4I7+4ISk*4I8~n
if Buddh is in Yuvati or Randhr Bhava with Kautuk Avastha
the native will be addicted to courtezans;
~4ISk*4I9~
and if Buddh in Kautuk Avastha is placed in Dharm Bhava,
the native will be meritorious and attain heavens after
death.
~4ISi~n
If Buddh is in Nidr Avastha, the native will not enjoy
comfortable sleep; he will be afflicted by neck or neck
joint 'Samadhi' diseases; he will be devoid of co-born,
afflicted by miseries galore (i.e. in abundance), will
enter into litigations with his own men, and he will lose
wealth and honour.
~5ISy~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P167_B001_03

- 身份：正文
- PDF 页：167
- 偈颂：76-86
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 76-86 [present] · PDF page 167

76-86. Effects of Buddh's Avasthas at Birth: Should Buddh
in Sayan Avastha be in Lagn, the native will be lame and
will have reddish eyes (like the black bee);
~4ISy*-4I1~n
if Buddh is in Sayan Avastha in other bhavas (i.e. other
than Tanu Bhava), the native will be addicted to licentious
(i.e. disregarding certain rules) pleasures and be wicked.
~4ISu*4I1~
If Buddh is in Upavesan Avastha in Lagn, the native will
possess (the seven principle) virtues;
~4ISu*4I1*4Dm~n
if Buddh in Upavesan Avastha is in Lagn, receiving a
drishti from a malefic, or drishtis from malefics, or is
yuti with malefics, penury will result;
~4ISu*4I1*4DB~
and if Buddh in Upavesan Avastha is in Lagn receiving a
drishti from a benefic, or drishtis from benefics, or is
yuti with benefics, financial happiness will follow.
~4ISn~m
If Buddh is in Netrapani Avastha, the native will be devoid
of learning, wisdom, well wishers, and satisfaction but he
will be honourable;
~4ISn*4I5~m
if Buddh is in Putr Bhava in Netrapani  Avastha, the
subject will be bereft of happiness from wife and sons; he
will be endowed with (more) female children and will gain
abundant finance through royal patronage.
~4ISp~
If Buddh is in Prakash Avastha, the native will be
charitable, merciful, and meritorious; he will cross the
boundaries of ocean in respect of many branches of
learning; he will be endowed with the great faculty of
discrimination, and he will destroy evil people.
~4ISg+4ISa~
If Buddh is in Gaman Avastha the native will visit the
courts of kings on many occasions and Goddess Lakshmi
(denoting wealth) will dwell in his abode.
~?~
If Buddh is in Agaman Avastha, the same effects due to his
being in Gaman Avastha will fructify, i.e. the native will
visit the courts of kings on many occasions and Goddess
Lakshmi (denoting wealth) will dwell in his abode.
~4ISb*4E~
If Buddh is in Sabh Avastha and happens to be in
exaltation, the native will be affluent and meritorious at
all times; he will be equal to Kuber (the lord of wealth);
or he will be a king or a minister; he will be devoted to
Lord Vishnu and Lord Shiva; he will be virtuous and will
attain full enlightenment.
~4ISv~
Should Buddh be in Agam Avastha the native will serve base
men and gain wealth thereby; and he will have two sons and
one fame bringing daughter.
~4ISh~n
If Buddh is in Bhojan Avastha, the native will face
financial losses through litigations, will physically lose
on account of fear from the king (i.e. he will become thin
due to royal wrath); he will be fickle-minded and will be
bereft of physical and conjugal felicity.
~4ISt~
If Buddh is in Nritya Lips Avastha, the native will be
endowed with honour, conveyances, corals (i.e. gems, etc.),
sons, friends, prowess, and recognition in assembly due to
his scholarship;
~4ISt*4z~n
if Buddh in Nritya Lips Avastha is in a malefic's rashi the
native will be addicted to prostitutes and will long for
licentious pleasures.
~4ISk*4I1~
If Buddh is in Kautuk Avastha in Lagn, the native will be
skilful in music;
~4ISk*4I7+4ISk*4I8~n
if Buddh is in Yuvati or Randhr Bhava with Kautuk Avastha
the native will be addicted to courtezans;
~4ISk*4I9~
and if Buddh in Kautuk Avastha is placed in Dharm Bhava,
the native will be meritorious and attain heavens after
death.
~4ISi~n
If Buddh is in Nidr Avastha, the native will not enjoy
comfortable sleep; he will be afflicted by neck or neck
joint 'Samadhi' diseases; he will be devoid of co-born,
afflicted by miseries galore (i.e. in abundance), will
enter into litigations with his own men, and he will lose
wealth and honour.
~5ISy~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P168_B001_01

- 身份：正文
- PDF 页：168
- 偈颂：87-8
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 87-8 [present] · PDF page 168

87- 8. Effects of Guru's Avasthas at Birth: If Guru is in
Sayan Avastha, the native will be strong but will speak in
whispers; he will be very tawny in complexion, will have
prominent cheeks, and will have fear from enemies.
~5ISu~n
If Guru is in Upavesan Avastha, the native will be
garrulous and very proud; he will be troubled by the king
and enemies; and he will have ulcers on the feet shanks,
face, and hands.
~5ISn~n
If Guru is in Netrapani Avastha the native will be
afflicted by diseases; he will be devoid of wealth, be fond
of music and dances, libidinous, tawny in complexion and he
will be attached to people of other castes.
~5ISp~
If Guru is in Prakash Avastha, the native will enjoy
virtues; he will be happy, splendorous, and will visit holy
places devoted to Lord Krishna;
~5ISp*5E~
if Guru in Prakash Avastha is exalted, the native will
attain greatness among men and will be equal to Kuber (the
lord of wealth).
~5ISg~
If Guru is in Gaman Avastha the native will be adventurous;
he will be happy on account of friends; he will be
scholarly and endowed with Vedic learning and with various
kinds of wealth.
~5ISa~
If Guru is in Agaman Avastha, serving force, excellent
women, and the goddess of wealth will never leave the
native's abode.
~5ISb~
If Guru is in Sabh Avastha, the native will attain
comparability with Guru (the God of speech) in the matter
of speech; he will be endowed with superior corals, rubies,
and wealth; he will be rich with elephants, horses, and
chariots; and he will be supremely learned.
~5ISv~
If Guru is in Agam Avastha, the native will be endowed with
various conveyances, honours, retinue (i.e. many persons
will take good care off him), children, wife, friends, and
learning; he will be equal to a king, extremely noble, fond
of literature, and he will take to the path of the
virtuous.
~5ISh~
If Guru is in Bhojan Avastha the native will always beget
excellent food and horses, elephants and chariots, while
Lakshmi, the Goddess of Wealth, will never leave his
house.
~5ISt~
If Guru is in Nritya Lips Avastha, the native will receive
royal honours; he will be wealthy, endowed with knowledge
of moral law 'Dharma' and Tantra (a branch of learning
dealing with magical formulas to attain super human
powers); he will be supreme among the learned and be a
great grammarian.
~5ISk~
If Guru is in Kautuk Avastha, the native will be curious in
disposition; he will be very rich; he will shine like Surya
in his circles; he will be exceedingly kind, happy,
honoured by the kings, endowed with sons, wealth, and just
disposition. He will be very strong and he will be a
scholar in the king's court.
~5ISi~n
If Guru is in Nidr Avastha, the native will be foolish in
all his undertakings; he will suffer irredeemable penury
and will be devoid of righteous acts.
~6ISy~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P168_B001_02

- 身份：正文
- PDF 页：168
- 偈颂：87-8
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 87-8 [present] · PDF page 168

87- 8. Effects of Guru's Avasthas at Birth: If Guru is in
Sayan Avastha, the native will be strong but will speak in
whispers; he will be very tawny in complexion, will have
prominent cheeks, and will have fear from enemies.
~5ISu~n
If Guru is in Upavesan Avastha, the native will be
garrulous and very proud; he will be troubled by the king
and enemies; and he will have ulcers on the feet shanks,
face, and hands.
~5ISn~n
If Guru is in Netrapani Avastha the native will be
afflicted by diseases; he will be devoid of wealth, be fond
of music and dances, libidinous, tawny in complexion and he
will be attached to people of other castes.
~5ISp~
If Guru is in Prakash Avastha, the native will enjoy
virtues; he will be happy, splendorous, and will visit holy
places devoted to Lord Krishna;
~5ISp*5E~
if Guru in Prakash Avastha is exalted, the native will
attain greatness among men and will be equal to Kuber (the
lord of wealth).
~5ISg~
If Guru is in Gaman Avastha the native will be adventurous;
he will be happy on account of friends; he will be
scholarly and endowed with Vedic learning and with various
kinds of wealth.
~5ISa~
If Guru is in Agaman Avastha, serving force, excellent
women, and the goddess of wealth will never leave the
native's abode.
~5ISb~
If Guru is in Sabh Avastha, the native will attain
comparability with Guru (the God of speech) in the matter
of speech; he will be endowed with superior corals, rubies,
and wealth; he will be rich with elephants, horses, and
chariots; and he will be supremely learned.
~5ISv~
If Guru is in Agam Avastha, the native will be endowed with
various conveyances, honours, retinue (i.e. many persons
will take good care off him), children, wife, friends, and
learning; he will be equal to a king, extremely noble, fond
of literature, and he will take to the path of the
virtuous.
~5ISh~
If Guru is in Bhojan Avastha the native will always beget
excellent food and horses, elephants and chariots, while
Lakshmi, the Goddess of Wealth, will never leave his
house.
~5ISt~
If Guru is in Nritya Lips Avastha, the native will receive
royal honours; he will be wealthy, endowed with knowledge
of moral law 'Dharma' and Tantra (a branch of learning
dealing with magical formulas to attain super human
powers); he will be supreme among the learned and be a
great grammarian.
~5ISk~
If Guru is in Kautuk Avastha, the native will be curious in
disposition; he will be very rich; he will shine like Surya
in his circles; he will be exceedingly kind, happy,
honoured by the kings, endowed with sons, wealth, and just
disposition. He will be very strong and he will be a
scholar in the king's court.
~5ISi~n
If Guru is in Nidr Avastha, the native will be foolish in
all his undertakings; he will suffer irredeemable penury
and will be devoid of righteous acts.
~6ISy~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P168_B001_03

- 身份：正文
- PDF 页：168
- 偈颂：87-8
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 87-8 [present] · PDF page 168

87- 8. Effects of Guru's Avasthas at Birth: If Guru is in
Sayan Avastha, the native will be strong but will speak in
whispers; he will be very tawny in complexion, will have
prominent cheeks, and will have fear from enemies.
~5ISu~n
If Guru is in Upavesan Avastha, the native will be
garrulous and very proud; he will be troubled by the king
and enemies; and he will have ulcers on the feet shanks,
face, and hands.
~5ISn~n
If Guru is in Netrapani Avastha the native will be
afflicted by diseases; he will be devoid of wealth, be fond
of music and dances, libidinous, tawny in complexion and he
will be attached to people of other castes.
~5ISp~
If Guru is in Prakash Avastha, the native will enjoy
virtues; he will be happy, splendorous, and will visit holy
places devoted to Lord Krishna;
~5ISp*5E~
if Guru in Prakash Avastha is exalted, the native will
attain greatness among men and will be equal to Kuber (the
lord of wealth).
~5ISg~
If Guru is in Gaman Avastha the native will be adventurous;
he will be happy on account of friends; he will be
scholarly and endowed with Vedic learning and with various
kinds of wealth.
~5ISa~
If Guru is in Agaman Avastha, serving force, excellent
women, and the goddess of wealth will never leave the
native's abode.
~5ISb~
If Guru is in Sabh Avastha, the native will attain
comparability with Guru (the God of speech) in the matter
of speech; he will be endowed with superior corals, rubies,
and wealth; he will be rich with elephants, horses, and
chariots; and he will be supremely learned.
~5ISv~
If Guru is in Agam Avastha, the native will be endowed with
various conveyances, honours, retinue (i.e. many persons
will take good care off him), children, wife, friends, and
learning; he will be equal to a king, extremely noble, fond
of literature, and he will take to the path of the
virtuous.
~5ISh~
If Guru is in Bhojan Avastha the native will always beget
excellent food and horses, elephants and chariots, while
Lakshmi, the Goddess of Wealth, will never leave his
house.
~5ISt~
If Guru is in Nritya Lips Avastha, the native will receive
royal honours; he will be wealthy, endowed with knowledge
of moral law 'Dharma' and Tantra (a branch of learning
dealing with magical formulas to attain super human
powers); he will be supreme among the learned and be a
great grammarian.
~5ISk~
If Guru is in Kautuk Avastha, the native will be curious in
disposition; he will be very rich; he will shine like Surya
in his circles; he will be exceedingly kind, happy,
honoured by the kings, endowed with sons, wealth, and just
disposition. He will be very strong and he will be a
scholar in the king's court.
~5ISi~n
If Guru is in Nidr Avastha, the native will be foolish in
all his undertakings; he will suffer irredeemable penury
and will be devoid of righteous acts.
~6ISy~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P169_B001_01

- 身份：正文
- PDF 页：169
- 偈颂：99-110
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 99-110 [present] · PDF page 169

99-110. Effects of Shukr's Avasthas at Birth: If Shukr is
in Sayan Avastha, the native although strong, will incur
dental disease; he will be very short-tempered; he will be
bereft of wealth, will seek union with courtezans, and be
licentious.
~6ISu~
If Shukr is in Upavesan Avastha, the native will be endowed
with a multitude of nine gems ('Navamin Vraja') and golden
ornaments; he will be ever happy, will destroy enemies, and
will be honoured by the king. He will have highly increased
honours.
~6ISn*6I1+6ISn*6I7+6ISn*6I10~n
If Shukr is in Netrapani Avastha in Lagn, Yuvati, or Karm
Bhava, there will be loss of wealth on account of
afflictions of the sense of sight (i.e. heavy medical
expenses due to severe eye diseases).
~-6I1*-6I7*-6I10*6ISn~
and if Netrapani Avastha occurs when Shukr is in other
bhavas (i.e. bhavas other than Tanu, Yuvati, and Karm
Bhava), the native will own large houses.
~6ISp*6O+6ISp*6E+6ISp*6F~
Should Shukr be in Prakash Avastha in its own rashi, in its
exaltation rashi, or in a friendly rashi, the native will
sport like a lofty elephant; he will be equal to a king;
and he will be skilful in poetry and music.
~6ISg~n
If Shukr is in Gaman Avastha, the native will not have a
long living mother, will lament over separation from his
own people and will have fear from enemies.
~6ISa~m
If Shukr is in Agaman Avastha, the native will command
abundant wealth; he will undertake to visit superior
shrines; he will be ever enthusiastic; and he will contract
diseases of the hand and foot.
~6ISb~
If Shukr is in Sabh Avastha the native will earn eminence
in the king's court; he will be very virtuous; he will
destroy enemies; he will be equal to Kuber in wealth; he
will be charitable, will ride on horses, and will be
excellent among men.
~6ISv~n
If Shukr is in Agam Avastha, there will be no advent of
wealth, but there will be troubles from enemies, separation
from children and relatives, diseases, and lack of
pleasures from the wife.
~6ISh~n
Should Shukr be in Bhojan Avastha, the native will be
distressed due to hunger, diseases, and many kinds of fear
from enemies;
~6ISh*6I6~
and if Shukr is in Kanya in Bhojan Avastha, the native will
be very rich and will be honoured by scholars.
~6ISt~
If Shukr is in Nritya lips Avastha, the native will be
skilful in literature and intelligent; he will play musical
instruments like lute, tabla, etc.; he will be meritorious
and very affluent.
~6ISk~
If Shukr is in Kautuk Avastha, the native will be equal to
Lord Indra. He will attain greatness in the assembly; he
will be learned and will have Lakshmi always dwelling in
his abode.
~6ISi~m
If Shukr is in Nidr Avastha, the native will be interested
in serving others; he will blame others; he will be heroic,
garrulous, and he will be wandering all over the earth.
~7ISy~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P169_B001_02

- 身份：正文
- PDF 页：169
- 偈颂：99-110
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 99-110 [present] · PDF page 169

99-110. Effects of Shukr's Avasthas at Birth: If Shukr is
in Sayan Avastha, the native although strong, will incur
dental disease; he will be very short-tempered; he will be
bereft of wealth, will seek union with courtezans, and be
licentious.
~6ISu~
If Shukr is in Upavesan Avastha, the native will be endowed
with a multitude of nine gems ('Navamin Vraja') and golden
ornaments; he will be ever happy, will destroy enemies, and
will be honoured by the king. He will have highly increased
honours.
~6ISn*6I1+6ISn*6I7+6ISn*6I10~n
If Shukr is in Netrapani Avastha in Lagn, Yuvati, or Karm
Bhava, there will be loss of wealth on account of
afflictions of the sense of sight (i.e. heavy medical
expenses due to severe eye diseases).
~-6I1*-6I7*-6I10*6ISn~
and if Netrapani Avastha occurs when Shukr is in other
bhavas (i.e. bhavas other than Tanu, Yuvati, and Karm
Bhava), the native will own large houses.
~6ISp*6O+6ISp*6E+6ISp*6F~
Should Shukr be in Prakash Avastha in its own rashi, in its
exaltation rashi, or in a friendly rashi, the native will
sport like a lofty elephant; he will be equal to a king;
and he will be skilful in poetry and music.
~6ISg~n
If Shukr is in Gaman Avastha, the native will not have a
long living mother, will lament over separation from his
own people and will have fear from enemies.
~6ISa~m
If Shukr is in Agaman Avastha, the native will command
abundant wealth; he will undertake to visit superior
shrines; he will be ever enthusiastic; and he will contract
diseases of the hand and foot.
~6ISb~
If Shukr is in Sabh Avastha the native will earn eminence
in the king's court; he will be very virtuous; he will
destroy enemies; he will be equal to Kuber in wealth; he
will be charitable, will ride on horses, and will be
excellent among men.
~6ISv~n
If Shukr is in Agam Avastha, there will be no advent of
wealth, but there will be troubles from enemies, separation
from children and relatives, diseases, and lack of
pleasures from the wife.
~6ISh~n
Should Shukr be in Bhojan Avastha, the native will be
distressed due to hunger, diseases, and many kinds of fear
from enemies;
~6ISh*6I6~
and if Shukr is in Kanya in Bhojan Avastha, the native will
be very rich and will be honoured by scholars.
~6ISt~
If Shukr is in Nritya lips Avastha, the native will be
skilful in literature and intelligent; he will play musical
instruments like lute, tabla, etc.; he will be meritorious
and very affluent.
~6ISk~
If Shukr is in Kautuk Avastha, the native will be equal to
Lord Indra. He will attain greatness in the assembly; he
will be learned and will have Lakshmi always dwelling in
his abode.
~6ISi~m
If Shukr is in Nidr Avastha, the native will be interested
in serving others; he will blame others; he will be heroic,
garrulous, and he will be wandering all over the earth.
~7ISy~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P169_B001_03

- 身份：正文
- PDF 页：169
- 偈颂：99-110
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 99-110 [present] · PDF page 169

99-110. Effects of Shukr's Avasthas at Birth: If Shukr is
in Sayan Avastha, the native although strong, will incur
dental disease; he will be very short-tempered; he will be
bereft of wealth, will seek union with courtezans, and be
licentious.
~6ISu~
If Shukr is in Upavesan Avastha, the native will be endowed
with a multitude of nine gems ('Navamin Vraja') and golden
ornaments; he will be ever happy, will destroy enemies, and
will be honoured by the king. He will have highly increased
honours.
~6ISn*6I1+6ISn*6I7+6ISn*6I10~n
If Shukr is in Netrapani Avastha in Lagn, Yuvati, or Karm
Bhava, there will be loss of wealth on account of
afflictions of the sense of sight (i.e. heavy medical
expenses due to severe eye diseases).
~-6I1*-6I7*-6I10*6ISn~
and if Netrapani Avastha occurs when Shukr is in other
bhavas (i.e. bhavas other than Tanu, Yuvati, and Karm
Bhava), the native will own large houses.
~6ISp*6O+6ISp*6E+6ISp*6F~
Should Shukr be in Prakash Avastha in its own rashi, in its
exaltation rashi, or in a friendly rashi, the native will
sport like a lofty elephant; he will be equal to a king;
and he will be skilful in poetry and music.
~6ISg~n
If Shukr is in Gaman Avastha, the native will not have a
long living mother, will lament over separation from his
own people and will have fear from enemies.
~6ISa~m
If Shukr is in Agaman Avastha, the native will command
abundant wealth; he will undertake to visit superior
shrines; he will be ever enthusiastic; and he will contract
diseases of the hand and foot.
~6ISb~
If Shukr is in Sabh Avastha the native will earn eminence
in the king's court; he will be very virtuous; he will
destroy enemies; he will be equal to Kuber in wealth; he
will be charitable, will ride on horses, and will be
excellent among men.
~6ISv~n
If Shukr is in Agam Avastha, there will be no advent of
wealth, but there will be troubles from enemies, separation
from children and relatives, diseases, and lack of
pleasures from the wife.
~6ISh~n
Should Shukr be in Bhojan Avastha, the native will be
distressed due to hunger, diseases, and many kinds of fear
from enemies;
~6ISh*6I6~
and if Shukr is in Kanya in Bhojan Avastha, the native will
be very rich and will be honoured by scholars.
~6ISt~
If Shukr is in Nritya lips Avastha, the native will be
skilful in literature and intelligent; he will play musical
instruments like lute, tabla, etc.; he will be meritorious
and very affluent.
~6ISk~
If Shukr is in Kautuk Avastha, the native will be equal to
Lord Indra. He will attain greatness in the assembly; he
will be learned and will have Lakshmi always dwelling in
his abode.
~6ISi~m
If Shukr is in Nidr Avastha, the native will be interested
in serving others; he will blame others; he will be heroic,
garrulous, and he will be wandering all over the earth.
~7ISy~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P170_B001_01

- 身份：正文
- PDF 页：170
- 偈颂：111-122
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 111-122 [present] · PDF page 170

111-122. Effects of Shani's Avasthas at Birth: If Shani is
in Sayan Avastha, the native will be troubled by hunger and
thirst; he will incur diseases in boyhood; and later on he
will become wealthy.
~7ISu~n
If Shani is in Upavesan Avastha the native will be troubled
greatly by enemies; he will contract dangers; he will have
ulcers all over the body; he will be self-respected; and he
will be punished by the king.
~7ISn~
If Shani is in Netrapani Avastha, the native will be
endowed with a charming female, wealth, royal favour, and
friends; he will have knowledge of many arts;  and he will
be an eloquent speaker.
~7ISp~
If Shani is in Prakash Avastha, the native will be very
virtuous, very wealthy, intelligent, sportive, splendorous,
merciful, and devoted to Lord Shiva.
~7ISg~
If Shani is in Gaman Avastha the native will be very rich,
and endowed with sons; he will grab enemy's lands; and he
will be a scholar at royal court.
~7ISa~n
If Shani is in Agaman Avastha, the native will be akin to a
donkey (i.e. foolish) and bereft of happiness from wife and
children; he will always roam pitiably without anybody's
patronage.
~7ISb~
If Shani is in Sabh Avastha the native will have surprising
(i.e. great) possessions of abundant precious stones and
gold; he will be endowed with great judicial (or political)
knowledge;  and he will be extremely brilliant.
~7ISv~n
If Shani is in Agam Avastha, the native will incur
diseases, and will not be skilful in earning royal
patronage.
~7ISh~n
If Shani is in Bhojan Avastha, the native will enjoy tastes
of food; he will be weak-sighted and he will be
fickle-minded due to mental delusion.

~7ISt~
If Shani is in Nritya Lips Avastha, the native will be
righteous, extremely opulent, honoured by the king, and
brave; he will be heroic in the field of war.
~7ISk~
If Shani is in Kautuk Avastha the native will be endowed
with lands and wealth; he will be happy, endowed with
pleasures through charming females; and he will be learned
in poetry, arts, etc..
~7ISi~
If Shani is in Nidr Avastha the native will be rich,
endowed with charming virtues, and valorous; he will
destroy even fierce enemies and he will be skilful in
seeking pleasures through harlots.
~8ISy~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P170_B001_02

- 身份：正文
- PDF 页：170
- 偈颂：111-122
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 111-122 [present] · PDF page 170

111-122. Effects of Shani's Avasthas at Birth: If Shani is
in Sayan Avastha, the native will be troubled by hunger and
thirst; he will incur diseases in boyhood; and later on he
will become wealthy.
~7ISu~n
If Shani is in Upavesan Avastha the native will be troubled
greatly by enemies; he will contract dangers; he will have
ulcers all over the body; he will be self-respected; and he
will be punished by the king.
~7ISn~
If Shani is in Netrapani Avastha, the native will be
endowed with a charming female, wealth, royal favour, and
friends; he will have knowledge of many arts;  and he will
be an eloquent speaker.
~7ISp~
If Shani is in Prakash Avastha, the native will be very
virtuous, very wealthy, intelligent, sportive, splendorous,
merciful, and devoted to Lord Shiva.
~7ISg~
If Shani is in Gaman Avastha the native will be very rich,
and endowed with sons; he will grab enemy's lands; and he
will be a scholar at royal court.
~7ISa~n
If Shani is in Agaman Avastha, the native will be akin to a
donkey (i.e. foolish) and bereft of happiness from wife and
children; he will always roam pitiably without anybody's
patronage.
~7ISb~
If Shani is in Sabh Avastha the native will have surprising
(i.e. great) possessions of abundant precious stones and
gold; he will be endowed with great judicial (or political)
knowledge;  and he will be extremely brilliant.
~7ISv~n
If Shani is in Agam Avastha, the native will incur
diseases, and will not be skilful in earning royal
patronage.
~7ISh~n
If Shani is in Bhojan Avastha, the native will enjoy tastes
of food; he will be weak-sighted and he will be
fickle-minded due to mental delusion.

~7ISt~
If Shani is in Nritya Lips Avastha, the native will be
righteous, extremely opulent, honoured by the king, and
brave; he will be heroic in the field of war.
~7ISk~
If Shani is in Kautuk Avastha the native will be endowed
with lands and wealth; he will be happy, endowed with
pleasures through charming females; and he will be learned
in poetry, arts, etc..
~7ISi~
If Shani is in Nidr Avastha the native will be rich,
endowed with charming virtues, and valorous; he will
destroy even fierce enemies and he will be skilful in
seeking pleasures through harlots.
~8ISy~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P171_B001_01

- 身份：正文
- PDF 页：171
- 偈颂：123-134
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 123-134 [present] · PDF page 171

123-134. Effects of Rahu's Avasthas at Birth: If Rahu is in
Sayan Avastha, the native will experience miseries in
abundance;
~8ISy*8IR2+8ISy*8IR3+8ISy*8IR6+8ISy*8IR1~
but if Rahu in Sayan Avastha is placed in Vrishabh, Mithun,
Kanya, or Mesh the native will be endowed with wealth and
grains.
~8ISu~m
If Rahu is in Upavesan Avastha the native will be
distressed due to ulcers; he will be endowed with royal
association; he will be highly honourable and ever devoid
of financial happiness.
~8ISn~n
If Rahu is in Netrapani Avastha, the native will be
troubled by eye diseases, will have fear from wicked
people, snakes, and thieves and will incur financial
decline.
~8ISp~
If Rahu is in Prakash Avastha, the native will acquire a
high position, will perform auspicious acts, and will
obtain elevation of his financial state; he will be highly
virtuous; he will be a chief in the king's court, charming
like freshly formed clouds (that will cause soon rain), and
he will be very prosperous in foreign places.
~8ISg~
If Rahu is in Gaman Avastha the native will be endowed with
numerous children; he will be scholarly, wealthy,
charitable, and honoured by the king.
~8ISa~n
If Rahu is in Agaman Avastha, the native will be very
irritable, bereft of intelligence and wealth, crooked,
miserly, and libidinous.
~8ISb~
If Rahu is in Sabh Avastha the native will be scholarly,
miserly, and endowed with many virtues, wealth, and
happiness.
~8ISv~n
If Rahu is in Agam Avastha, the native will be always
mentally distressed, will have fear from enemies and
litigations with enemies; he will be bereft of his own men;
he will face financial destruction; and he will be crafty
and emaciated.
~8ISh~n
If Rahu is in Bhojan Avastha, the native will be distressed
without food, and dull-witted; he will not be bold in his
acts, and he will be bereft of conjugal and progenic
happiness.
~8ISt~n
If Rahu is in Nritya Lips Avastha, the native will contract
a serious disease which seems difficult to subdue, will
have afflicted eyes, and will have fear from enemies. He
will decline financially and righteously.
~8ISk~n
If Rahu is in Kautuk Avastha, the native will be devoid of
a position (or a place); he will be interested in others'
females, and he will steal others' wealth.
~8ISi~
If Rahu is in Nidr Avastha the native will be a repository
of virtues; he will be endowed with wife and children; he
will be bold, proud, and very affluent.
~9ISy*9IR1+9ISy*9IR2+9ISy*9IR3+9ISy*9IR6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P171_B001_02

- 身份：正文
- PDF 页：171
- 偈颂：123-134
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 123-134 [present] · PDF page 171

123-134. Effects of Rahu's Avasthas at Birth: If Rahu is in
Sayan Avastha, the native will experience miseries in
abundance;
~8ISy*8IR2+8ISy*8IR3+8ISy*8IR6+8ISy*8IR1~
but if Rahu in Sayan Avastha is placed in Vrishabh, Mithun,
Kanya, or Mesh the native will be endowed with wealth and
grains.
~8ISu~m
If Rahu is in Upavesan Avastha the native will be
distressed due to ulcers; he will be endowed with royal
association; he will be highly honourable and ever devoid
of financial happiness.
~8ISn~n
If Rahu is in Netrapani Avastha, the native will be
troubled by eye diseases, will have fear from wicked
people, snakes, and thieves and will incur financial
decline.
~8ISp~
If Rahu is in Prakash Avastha, the native will acquire a
high position, will perform auspicious acts, and will
obtain elevation of his financial state; he will be highly
virtuous; he will be a chief in the king's court, charming
like freshly formed clouds (that will cause soon rain), and
he will be very prosperous in foreign places.
~8ISg~
If Rahu is in Gaman Avastha the native will be endowed with
numerous children; he will be scholarly, wealthy,
charitable, and honoured by the king.
~8ISa~n
If Rahu is in Agaman Avastha, the native will be very
irritable, bereft of intelligence and wealth, crooked,
miserly, and libidinous.
~8ISb~
If Rahu is in Sabh Avastha the native will be scholarly,
miserly, and endowed with many virtues, wealth, and
happiness.
~8ISv~n
If Rahu is in Agam Avastha, the native will be always
mentally distressed, will have fear from enemies and
litigations with enemies; he will be bereft of his own men;
he will face financial destruction; and he will be crafty
and emaciated.
~8ISh~n
If Rahu is in Bhojan Avastha, the native will be distressed
without food, and dull-witted; he will not be bold in his
acts, and he will be bereft of conjugal and progenic
happiness.
~8ISt~n
If Rahu is in Nritya Lips Avastha, the native will contract
a serious disease which seems difficult to subdue, will
have afflicted eyes, and will have fear from enemies. He
will decline financially and righteously.
~8ISk~n
If Rahu is in Kautuk Avastha, the native will be devoid of
a position (or a place); he will be interested in others'
females, and he will steal others' wealth.
~8ISi~
If Rahu is in Nidr Avastha the native will be a repository
of virtues; he will be endowed with wife and children; he
will be bold, proud, and very affluent.
~9ISy*9IR1+9ISy*9IR2+9ISy*9IR3+9ISy*9IR6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P171_B001_03

- 身份：正文
- PDF 页：171
- 偈颂：123-134
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 123-134 [present] · PDF page 171

123-134. Effects of Rahu's Avasthas at Birth: If Rahu is in
Sayan Avastha, the native will experience miseries in
abundance;
~8ISy*8IR2+8ISy*8IR3+8ISy*8IR6+8ISy*8IR1~
but if Rahu in Sayan Avastha is placed in Vrishabh, Mithun,
Kanya, or Mesh the native will be endowed with wealth and
grains.
~8ISu~m
If Rahu is in Upavesan Avastha the native will be
distressed due to ulcers; he will be endowed with royal
association; he will be highly honourable and ever devoid
of financial happiness.
~8ISn~n
If Rahu is in Netrapani Avastha, the native will be
troubled by eye diseases, will have fear from wicked
people, snakes, and thieves and will incur financial
decline.
~8ISp~
If Rahu is in Prakash Avastha, the native will acquire a
high position, will perform auspicious acts, and will
obtain elevation of his financial state; he will be highly
virtuous; he will be a chief in the king's court, charming
like freshly formed clouds (that will cause soon rain), and
he will be very prosperous in foreign places.
~8ISg~
If Rahu is in Gaman Avastha the native will be endowed with
numerous children; he will be scholarly, wealthy,
charitable, and honoured by the king.
~8ISa~n
If Rahu is in Agaman Avastha, the native will be very
irritable, bereft of intelligence and wealth, crooked,
miserly, and libidinous.
~8ISb~
If Rahu is in Sabh Avastha the native will be scholarly,
miserly, and endowed with many virtues, wealth, and
happiness.
~8ISv~n
If Rahu is in Agam Avastha, the native will be always
mentally distressed, will have fear from enemies and
litigations with enemies; he will be bereft of his own men;
he will face financial destruction; and he will be crafty
and emaciated.
~8ISh~n
If Rahu is in Bhojan Avastha, the native will be distressed
without food, and dull-witted; he will not be bold in his
acts, and he will be bereft of conjugal and progenic
happiness.
~8ISt~n
If Rahu is in Nritya Lips Avastha, the native will contract
a serious disease which seems difficult to subdue, will
have afflicted eyes, and will have fear from enemies. He
will decline financially and righteously.
~8ISk~n
If Rahu is in Kautuk Avastha, the native will be devoid of
a position (or a place); he will be interested in others'
females, and he will steal others' wealth.
~8ISi~
If Rahu is in Nidr Avastha the native will be a repository
of virtues; he will be endowed with wife and children; he
will be bold, proud, and very affluent.
~9ISy*9IR1+9ISy*9IR2+9ISy*9IR3+9ISy*9IR6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P172_B001_01

- 身份：正文
- PDF 页：172
- 偈颂：135-146
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 135-146 [present] · PDF page 172

135-146. Effects of Ketu's Avasthas at Birth: If Ketu is in
Sayan Avastha in Mesh, Vrishabh, Mithun, or Kanya, there
will be plenty of wealth;
~-9IR1*-9IR2*-9IR3*-9IR6*9ISy~n
while if Ketu is in Sayan Avastha in other rashis (i.e.
other rashis than Mesh, Vrishabh, Mithun, or Kanya),
increased diseases will follow.
~9ISu~n
If Ketu is in Upavesan Avastha the native will suffer from
ulcers and will have fear from enemies, windy diseases,
snakes, and thieves.
~9ISn~n
Should Ketu be in Netrapani Avastha, the native will
contract eye diseases, and will have fear from wicked
people, snakes, enemies, and people of royal family.
~9ISp~
If Ketu is in Prakash Avastha, the native will be wealthy
and righteous; he will live in foreign places; he will be
enthusiastic and genuine; and he will serve the king.
~9ISg~
If Ketu is in Gaman Avastha, the native will be endowed
with many sons, and abundant wealth; he will be scholarly,
virtuous, charitable, and he will be excellent among men.
~9ISa~n
If Ketu is in Agaman Avastha, the native will incur many
diseases, will face loss of wealth, will hurt (others) with
his teeth ('Danta Ghatin'); he will be a tale bearer and
will blame others.
~9ISb~n
If Ketu is in Sabh Avastha the native will be garrulous,
very proud, miserly, licentious, and skilful in evil
branches of learning.
~9ISv~n
If Ketu is in Agam Avastha, the native will be a notorious
sinner; he will enter into litigations with his relatives;
he will be wicked, and he will be troubled by diseases and
enemies.
~9ISh~n
If Ketu is in Bhojan Avastha, the native will always be
distressed with hunger, penury and diseases, and he will
roam all over the earth.
~9ISt~n
If Ketu is in Nritya Lips Avastha, the native will be
distressed due to diseases, will have a floral mark on the
eye (i.e. white of the pupil); he will be impertinent and
wicked; and he will plan evils.
~9ISk~n
If Ketu is in Kautuk Avastha, the native will seek union
with dancing females (i.e. prostitutes); he will suffer
positional displacement; he will take to evil paths and
will roam all over.
~9ISi~
If Ketu is in Nidr Avastha the native will be endowed with
wealth and corns; he will be virtuous and will spend his
time sportively.
~BISy~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P172_B001_02

- 身份：正文
- PDF 页：172
- 偈颂：135-146
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 135-146 [present] · PDF page 172

135-146. Effects of Ketu's Avasthas at Birth: If Ketu is in
Sayan Avastha in Mesh, Vrishabh, Mithun, or Kanya, there
will be plenty of wealth;
~-9IR1*-9IR2*-9IR3*-9IR6*9ISy~n
while if Ketu is in Sayan Avastha in other rashis (i.e.
other rashis than Mesh, Vrishabh, Mithun, or Kanya),
increased diseases will follow.
~9ISu~n
If Ketu is in Upavesan Avastha the native will suffer from
ulcers and will have fear from enemies, windy diseases,
snakes, and thieves.
~9ISn~n
Should Ketu be in Netrapani Avastha, the native will
contract eye diseases, and will have fear from wicked
people, snakes, enemies, and people of royal family.
~9ISp~
If Ketu is in Prakash Avastha, the native will be wealthy
and righteous; he will live in foreign places; he will be
enthusiastic and genuine; and he will serve the king.
~9ISg~
If Ketu is in Gaman Avastha, the native will be endowed
with many sons, and abundant wealth; he will be scholarly,
virtuous, charitable, and he will be excellent among men.
~9ISa~n
If Ketu is in Agaman Avastha, the native will incur many
diseases, will face loss of wealth, will hurt (others) with
his teeth ('Danta Ghatin'); he will be a tale bearer and
will blame others.
~9ISb~n
If Ketu is in Sabh Avastha the native will be garrulous,
very proud, miserly, licentious, and skilful in evil
branches of learning.
~9ISv~n
If Ketu is in Agam Avastha, the native will be a notorious
sinner; he will enter into litigations with his relatives;
he will be wicked, and he will be troubled by diseases and
enemies.
~9ISh~n
If Ketu is in Bhojan Avastha, the native will always be
distressed with hunger, penury and diseases, and he will
roam all over the earth.
~9ISt~n
If Ketu is in Nritya Lips Avastha, the native will be
distressed due to diseases, will have a floral mark on the
eye (i.e. white of the pupil); he will be impertinent and
wicked; and he will plan evils.
~9ISk~n
If Ketu is in Kautuk Avastha, the native will seek union
with dancing females (i.e. prostitutes); he will suffer
positional displacement; he will take to evil paths and
will roam all over.
~9ISi~
If Ketu is in Nidr Avastha the native will be endowed with
wealth and corns; he will be virtuous and will spend his
time sportively.
~BISy~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P172_B002_01

- 身份：正文
- PDF 页：172
- 偈颂：147
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 147 [present] · PDF page 172

147. General Effects (up to sloka 155): O Brahmin, if a
benefic grah is in Sayan Avastha, there will be benefic
effects at all times according to the learned.
~mISh~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P173_B001_01

- 身份：正文
- PDF 页：173
- 偈颂：148
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 148 [present] · PDF page 173

148. If a malefic is in Bhojan Avastha, everything (related
to the bhava concerned) will be destroyed and there is no
need of a second thought.
~mI7*mISi~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P173_B002_01

- 身份：正文
- PDF 页：173
- 偈颂：149
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 149 [present] · PDF page 173

149. Should a malefic in Yuvati Bhava be in Nidr Avastha
auspicious effects will follow, provided that there is no
drishti from another malefic.
~mI5*mISi+mI5*mISy~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P173_B003_01

- 身份：正文
- PDF 页：173
- 偈颂：150
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 150 [present] · PDF page 173

150. Declare without a second thought auspicious effects
following the location of a malefic in Putr Bhava, but only
with Nidr Avastha or in Sayan Avastha.
~mI8*mISi+mI8*mISy~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P173_B004_01

- 身份：正文
- PDF 页：173
- 偈颂：151
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 151 [present] · PDF page 173

151. Untimely death due to royal wrath will come to pass if
there is a malefic in Randhr Bhava in Nidr Avastha or in
Sayan Avastha.
~mI8*mISd*!8DB+mI8*mISy*!8DB+mI8*mISd*BI8+mI8*mISy*BI8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P173_B005_01

- 身份：正文
- PDF 页：173
- 偈颂：152
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 152 [present] · PDF page 173

152. If in the case of a malefic in Randhr Bhava in Nidr
Avastha or Sayan Avastha, there happen to be a benefic
drishti or the yuti of a benefic.  (untimely) death will be
in the river Ganges, i.e. Gangetic belt, shrines, etc..
~mI10*mISy+mI10*mISh~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P173_B006_01

- 身份：正文
- PDF 页：173
- 偈颂：153
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 153 [present] · PDF page 173

153. If there is a malefic in Karm Bhava in Sayan Avastha
or Bhojan Avastha, the native will face many miseries on
account of his own deeds.
~2I10*2ISk+2I10*2ISp~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P173_B007_01

- 身份：正文
- PDF 页：173
- 偈颂：154
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 154 [present] · PDF page 173

154. 0 excellent of the Brahmins, doubtlessly a Raj Yog
will come to pass, if Chandr is in Karm Bhava in Kautuk
Avastha or Prakash Avastha.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P173_B008_01

- 身份：正文
- PDF 页：173
- 偈颂：155
- 标题路径：CHAPTER 45 Avasthas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Avasthas of Grahas · Sloka 155 [present] · PDF page 173

155. Thus, the good and bad effects should be guessed
assessing the strength and weakness of the grahas
concerning all the bhavas.
