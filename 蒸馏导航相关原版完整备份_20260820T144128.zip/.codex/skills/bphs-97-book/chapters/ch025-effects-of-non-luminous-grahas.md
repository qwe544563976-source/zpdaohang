# 第 25 章：Effects of Non-Luminous Grahas

- 来源：BPHS 97 章版
- 原始卡片：85 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P074_B002_01

- 身份：正文
- PDF 页：74
- 偈颂：1
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 1 [present] · PDF page 74

1. Thus, I have explained the effects of the seven grahas,
viz. Surya, Chandr, Mangal, Buddh, Guru, Shukr, Shani,
Rahu, and Ketu. Now, I tell you about the effects of
non-luminous grahas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P074_B003_01

- 身份：正文
- PDF 页：74
- 偈颂：2
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 2 [present] · PDF page 74

2. Effects of Dhum in Various Bhavas (up to sloka 13): If
Dhum is in Lagn, the native will be valiant, endowed with
beautiful eyes. stupefied in disposition, unkind, wicked
and highly short-tempered.
~10I2~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P074_B004_01

- 身份：正文
- PDF 页：74
- 偈颂：3
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 3 [present] · PDF page 74

3. If Dhum is in Dhan Bhava, the native will be sickly,
wealthy, devoid of a limb, will incur humiliation at royal
level, be dull witted and be a eunuch.
~10I3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P074_B005_01

- 身份：正文
- PDF 页：74
- 偈颂：4
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 4 [present] · PDF page 74

4. Dhum is in Sahaj Bhava, the native will be intelligent,
very bold, delighted, eloquent, and be endowed with men and
wealth.
~10I4~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P074_B006_01

- 身份：正文
- PDF 页：74
- 偈颂：5
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 5 [present] · PDF page 74

5. If Dhum is in Bandhu Bhava, the native will be grieved
on account of being given up by his female, but will be
learned in all Shastras.
~10I5~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P074_B007_01

- 身份：正文
- PDF 页：74
- 偈颂：6
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 6 [present] · PDF page 74

6. If Dhum is in Putr Bhava, the native will have limited
progeny, be devoid of wealth, be great, will eat anything
and be bereft of friends and Mantras.
~10I6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P074_B008_01

- 身份：正文
- PDF 页：74
- 偈颂：7
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 7 [present] · PDF page 74

7. If Dhum is in Ari Bhava, the native will be strong, will
conquer his enemies, be very brilliant, famous and free
from diseases.
~10I7~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P074_B009_01

- 身份：正文
- PDF 页：74
- 偈颂：8
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 8 [present] · PDF page 74

8. If Dhum is in Yuvati Bhava, the native will be
penniless, be ever sensuous, skilful in going to others'
females, and be always devoid of brilliance.
~10I8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P074_B010_01

- 身份：正文
- PDF 页：74
- 偈颂：9
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 9 [present] · PDF page 74

9. If Dhum is in Randhr Bhava, the native will be bereft of
courage, but be enthusiastic, be truthful, disagreeable,
hardhearted, and selfish.
~10I9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P074_B011_01

- 身份：正文
- PDF 页：74
- 偈颂：10
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 10 [present] · PDF page 74

10. If Dhum is in Dharm Bhava, the native will be endowed
sons and fortunes, be rich, honourable, kind, religious,
and well disposed to his relatives.
~10I10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P074_B012_01

- 身份：正文
- PDF 页：74
- 偈颂：11
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 11 [present] · PDF page 74

11. If Dhum is in Karm Bhava, the native will be endowed
with sons and fortunes, be delighted, intelligent, happy,
and truthful.
~10I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P075_B001_01

- 身份：正文
- PDF 页：75
- 偈颂：12
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 12 [present] · PDF page 75

12. If Dhum is in Labh Bhava, the native will be endowed
with wealth, grains and gold, be beautiful, will have
knowledge of arts, be modest, and be skilful in singing.
~10I12~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P075_B002_01

- 身份：正文
- PDF 页：75
- 偈颂：13
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 13 [present] · PDF page 75

13. If Dhum is in Vyaya Bhava, the native will be morally
fallen, will indulge in sinful acts, be interested in
others' wives, addicted to vices, unkind, and crafty.
~11I1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P075_B003_01

- 身份：正文
- PDF 页：75
- 偈颂：14
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 14 [present] · PDF page 75

14. Effects of Vyatipat in Various Bhavas (up to sloka 25):
If Vyatipat (also known in short as Pat) is in Tanu Bhava,
the native will be troubled by miseries,be cruel, will
indulge in destructive acts, be foolish, and will be
disposed to his relatives.
~11I2~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P075_B004_01

- 身份：正文
- PDF 页：75
- 偈颂：15
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 15 [present] · PDF page 75

15. If Vyatipat is in Dhan Bhava, the native will be
morally crooked, be bilious, will enjoy pleasures, be
unkind, but grateful, be wicked, and sinful.
~11I3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P075_B005_01

- 身份：正文
- PDF 页：75
- 偈颂：16
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 16 [present] · PDF page 75

16. If Vyatipat is in Sahaj Bhava, the native will be firm
in disposition, be a warrior, be liberal, very rich, dear
to the king, and be head of an army.
~11I4~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P075_B006_01

- 身份：正文
- PDF 页：75
- 偈颂：17
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 17 [present] · PDF page 75

17. If Vyatipat is in Bandhu Bhava, the native will be
endowed with relatives, etc., but not sons and fortunes.
~11I5~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P075_B007_01

- 身份：正文
- PDF 页：75
- 偈颂：18
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 18 [present] · PDF page 75

18. If Vyatipat is in Putr Bhava, the native will be poor,
be charming in appearance, will have imbalances of phlegm,
bile, and wind, be hard-hearted, and shameless.
~11I6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P075_B008_01

- 身份：正文
- PDF 页：75
- 偈颂：19
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 19 [present] · PDF page 75

19. If Vyatipat is in Ari Bhava, the native will destroy
his, enemies, be physically mighty, skilful in use of all
kinds of weapons and in arts, and be peaceful in
disposition.
~11I7~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P075_B009_01

- 身份：正文
- PDF 页：75
- 偈颂：20
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 20 [present] · PDF page 75

20. If Vyatipat is in Yuvati Bhava, the native will be
bereft of wealth, wife and sons, will subdue to females, be
miserable, sensuous, shameless, and friendly to others.
~11I8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P075_B010_01

- 身份：正文
- PDF 页：75
- 偈颂：21
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 21 [present] · PDF page 75

21. If Vyatipat is in Randhr Bhava, the native will have
deformity of eyes, be ugly, unfortunate, spiteful to
Brahmins, and be troubled by disorders of blood.
~11I9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P075_B011_01

- 身份：正文
- PDF 页：75
- 偈颂：22
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 22 [present] · PDF page 75

22. If Vyatipat is in Dharm Bhava, the native will have
many kinds of business and many friends; he will be very
learned, well disposed to his wife, and he will be
eloquent.
~11I10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P076_B001_01

- 身份：正文
- PDF 页：76
- 偈颂：23
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 23 [present] · PDF page 76

23. If Vyatipat is in Karm Bhava, the native will be
religious, peaceful, skilful in religious acts, very
learned, and far-sighted.
~11I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P076_B002_01

- 身份：正文
- PDF 页：76
- 偈颂：24
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 24 [present] · PDF page 76

24. If Vyatipat is in Labh Bhava, the native will be
extremely opulent, be honourable, truthful, firm in policy,
endowed with many horses and be interested in singing.
~11I12~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P076_B003_01

- 身份：正文
- PDF 页：76
- 偈颂：25
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 25 [present] · PDF page 76

25. If Vyatipat is in Vyaya Bhava, the native will be given
to anger, associated with many activities, disabled,
irreligious and hate his own relatives.
~12I1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P076_B004_01

- 身份：正文
- PDF 页：76
- 偈颂：26
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 26 [present] · PDF page 76

26. Effects of Paridhi (or Parivesh) in Various Bhavas:
(up to sloka 37): If Paridhi is in Tanu Bhava , the native
will be learned, truthful, peaceful, rich, endowed with
sons, pure, charitable, and dear to elders.
~12I2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P076_B005_01

- 身份：正文
- PDF 页：76
- 偈颂：27
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 27 [present] · PDF page 76

27. If Paridhi is in Dhan Bhava, the native will be
wealthy, charming, will enjoy pleasures, be happy, very
religious, and be a lord.
~12I3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P076_B006_01

- 身份：正文
- PDF 页：76
- 偈颂：28
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 28 [present] · PDF page 76

28. If Paridhi is in Sahaj Bhava, the native will be fond
of his wife, be very charming, pious, well disposed to his
men, be a servant, and be respectful of his elders.
~12I4~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P076_B007_01

- 身份：正文
- PDF 页：76
- 偈颂：29
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 29 [present] · PDF page 76

29. If Paridhi is in Bandhu Bhava, the native will be
wonder-struck, helpful to enemies as well, kind, endowed
with everything and be skilful in singing.
~12I5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P076_B008_01

- 身份：正文
- PDF 页：76
- 偈颂：30
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 30 [present] · PDF page 76

30. If Paridhi is in Putr Bhava, the native will be
affluent, virtuous, splendorous, affectionate, religious,
and dear to his wife.
~12I6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P076_B009_01

- 身份：正文
- PDF 页：76
- 偈颂：31
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 31 [present] · PDF page 76

31. If Paridhi is in Ari Bhava, the native will be famous
and wealthy, be endowed with sons and pleasures, be helpful
to all, and will conquer his enemies.
~12I7~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P076_B010_01

- 身份：正文
- PDF 页：76
- 偈颂：32
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 32 [present] · PDF page 76

32. If Paridhi is in Yuvati Bhava, the native will have
limited number of children, be devoid of happiness, be of
mediocre intelligence, very hard-head, and will have a
sickly wife.
~12I8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P076_B011_01

- 身份：正文
- PDF 页：76
- 偈颂：33
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 33 [present] · PDF page 76

33. If Paridhi is in Randhr Bhava, the native will be
spiritually disposed, peaceful, strong-bodied, firm in
decision, religious and gentle.
~12I9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P077_B001_01

- 身份：正文
- PDF 页：77
- 偈颂：34
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 34 [present] · PDF page 77

34. If Paridhi is in Dharm Bhava, the native will be
endowed with sons, be happy, brilliant, very affluent, be
devoid of excessive passion, be honourable and be happy
with even an iota.
~12I10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P077_B002_01

- 身份：正文
- PDF 页：77
- 偈颂：35
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 35 [present] · PDF page 77

35. If Paridhi is in Karm Bhava, the native will be versed
in arts, will enjoy pleasures, be strong-bodied, and be
learned in all Shastras.
~12I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P077_B003_01

- 身份：正文
- PDF 页：77
- 偈颂：6
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 6 [present] · PDF page 77

6. If Paridhi is in Labh Bhava, the native will enjoy
pleasures through women, be virtuous, intelligent, dear to
his people, and will suffer disorders of digestive fire.
~12I12~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P077_B004_01

- 身份：正文
- PDF 页：77
- 偈颂：37
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 37 [present] · PDF page 77

37. If Paridhi is in Vyaya Bhava, the native will always be
a spend thrift, be miserable, firm, and will dishonour
elders.
~13I1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P077_B005_01

- 身份：正文
- PDF 页：77
- 偈颂：38
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 38 [present] · PDF page 77

38. Effects of Chap (Indr Dhanus or Kodanda) (up to sloka
49): If Chap is in Tanu  Bhava, the native will be endowed
with wealth, grains and gold, be grateful, agreeable, and
devoid of all actions.
~13I2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P077_B006_01

- 身份：正文
- PDF 页：77
- 偈颂：39
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 39 [present] · PDF page 77

39. If Chap is in Dhan Bhava, the native will speak
affably, be very rich, modest, learned, charming, and
religious.
~13I3~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P077_B007_01

- 身份：正文
- PDF 页：77
- 偈颂：40
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 40 [present] · PDF page 77

40. If Chap is in Sahaj Bhava, the native will be a miser,
be versed in many arts, will indulge in thieving, be devoid
of some limb, and be unfriendly.
~13I4~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P077_B008_01

- 身份：正文
- PDF 页：77
- 偈颂：41
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 41 [present] · PDF page 77

41. If Chap is in Bandhu Bhava, the native will be happy,
endowed with quadrupeds, wealth, grains, etc., be honoured
by the king, and be devoid of sickness.
~13I5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P077_B009_01

- 身份：正文
- PDF 页：77
- 偈颂：42
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 42 [present] · PDF page 77

42. If Chap is in Putr Bhava, the native will be
splendorous, far-sighted, pious, affable, and will acquire
prosperity in all his undertakings.
~13I6~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P077_B010_01

- 身份：正文
- PDF 页：77
- 偈颂：43
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 43 [present] · PDF page 77

43. If Chap is in Ari Bhava, the native will destroy his
enemies, be happy, affectionate, pure, and will achieve
plentifulness in all his undertakings.
~13I7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P077_B011_01

- 身份：正文
- PDF 页：77
- 偈颂：44
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 44 [present] · PDF page 77

44. If Chap is in Yuvati Bhava, the native will be wealthy,
endowed with all virtues, learned in Shastras, religious,
and agreeable.
~13I8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P077_B012_01

- 身份：正文
- PDF 页：77
- 偈颂：45
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 45 [present] · PDF page 77

45. If Chap is in Randhr Bhava, the native will be
interested in others' [213] jobs, be cruel, interested in
others' wives, and have a defective limb.
~13I9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P078_B001_01

- 身份：正文
- PDF 页：78
- 偈颂：46
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 46 [present] · PDF page 78

46. If Chap is in Dharm Bhava, the native will perform,
penance, will take to religious observations, be highly
learned, and be famous among men.
~13I10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P078_B002_01

- 身份：正文
- PDF 页：78
- 偈颂：47
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 47 [present] · PDF page 78

47. If Chap is in Karm Bhava, the native will be endowed
with many sons, abundant wealth, cows, buffaloes, etc., and
will be famous among men.
~13I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P078_B003_01

- 身份：正文
- PDF 页：78
- 偈颂：48
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 48 [present] · PDF page 78

48. If Chap is in Labh Bhava, the native will gain many
treasures, will be free from diseases, very fiery in
disposition, affectionate to his wife, and will have
knowledge of mantras and weapons (or missiles).
~13I12~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P078_B004_01

- 身份：正文
- PDF 页：78
- 偈颂：49
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 49 [present] · PDF page 78

49. If Chap is in Vyaya Bhava, the native will be wicked,
very honourable, evil in disposition, shameless, will go to
other's females, and be ever poor.
~14I1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P078_B005_01

- 身份：正文
- PDF 页：78
- 偈颂：50
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 50 [present] · PDF page 78

50. Effects of Dhwaj (or Sikhi, or Upaketu) in Various
Bhavas (up to sloka 61): If Dhwaj is in Tanu Bhava, the
native will be skilful in all branches of learning, be
happy, efficient in speech, agreeable, and be very
affectionate.
~14I2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P078_B006_01

- 身份：正文
- PDF 页：78
- 偈颂：51
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 51 [present] · PDF page 78

51. If Dhwaj is in Dhan Bhava, the native will be a good
and affable speaker, be splendorous, will write poetry, be
scholarly, honourable, modest and endowed with
conveyances.
~14I3~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P078_B007_01

- 身份：正文
- PDF 页：78
- 偈颂：52
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 52 [present] · PDF page 78

52. If Dhwaj is in Sahaj Bhava, the native will be miserly,
cruel acts, thin-bodied, poor, and will incur severe
diseases.
~14I4~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P078_B008_01

- 身份：正文
- PDF 页：78
- 偈颂：53
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 53 [present] · PDF page 78

53. If Dhwaj is in Bandhu Bhava, the native will be
charming, very virtuous, gentle, interested in Vedic
Knowledge, and be always happy.
~14I5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P078_B009_01

- 身份：正文
- PDF 页：78
- 偈颂：54
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 54 [present] · PDF page 78

54. If Dhwaj is in Putr Bhava, the native will be happy,
will enjoy pleasures, be versed in arts, skilled in
expedients, intelligent, eloquent and will respect elders.
~14I6~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P078_B010_01

- 身份：正文
- PDF 页：78
- 偈颂：55
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 55 [present] · PDF page 78

55. If Dhwaj is in Ari Bhava, the native will be ominous
for material relatives, will win over his enemies, be
endowed with many relatives, valiant, splendorous, and
skilful.
~14I7~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P078_B011_01

- 身份：正文
- PDF 页：78
- 偈颂：56
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 56 [present] · PDF page 78

56. If Dhwaj is in Yuvati Bhava, the native will be
interested in gambling, be sensuous, will enjoy pleasures,
and will befriend prostitutes.
~14I8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P079_B001_01

- 身份：正文
- PDF 页：79
- 偈颂：57
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 57 [present] · PDF page 79

57. If Dhwaj is in Randhr Bhava, the native will be
interested in base acts, be sinful, shameless, will blame
others, will lack in marital happiness, and will take
other's side.
~14I9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P079_B002_01

- 身份：正文
- PDF 页：79
- 偈颂：58
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 58 [present] · PDF page 79

58. If Dhwaj is in Dharm Bhava, the native will wear
(religious) badges, be delighted, helpfully disposed to
all, and he will be skilled in religious deeds.
~14I10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P079_B003_01

- 身份：正文
- PDF 页：79
- 偈颂：59
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 59 [present] · PDF page 79

59. O Brahmin, if Dhwaj is in Karm Bhava, the native will
be endowed with happiness and fortunes, be fond of
females,be charitable, and will befriend Brahmins.
~14I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P079_B004_01

- 身份：正文
- PDF 页：79
- 偈颂：60
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 60 [present] · PDF page 79

60. If Dhwaj is in Labh Bhava, the native will ever acquire
gains, be very religious honourable, affluent, fortunate,
valiant, and skilled in sacrificial rites.
~14I12~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P079_B005_01

- 身份：正文
- PDF 页：79
- 偈颂：61
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 61 [present] · PDF page 79

61. If Dhwaj is in Vyaya Bhava, the native will be
interested in sinful acts, be valiant, untrustworthy,
unkind, interested in others' females, and be
short-tempered.
~15I1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P079_B006_01

- 身份：正文
- PDF 页：79
- 偈颂：62
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 62 [present] · PDF page 79

62. Effects of Gulik in Various Bhavas (up to sloka 73): If
Gulik is in Tanu Bhava, the native will be afflicted by
diseases, be lustful, sinful, crafty, wicked, and very
miserable.
~15I2~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P079_B007_01

- 身份：正文
- PDF 页：79
- 偈颂：63
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 63 [present] · PDF page 79

63. If Gulik is in Dhan Bhava, the native will be unsightly
in appearance, miserable, mean, given to vices, shameless,
and penniless.
~15I3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P079_B008_01

- 身份：正文
- PDF 页：79
- 偈颂：64
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 64 [present] · PDF page 79

64. If Gulik is in Sahaj Bhava, the native will be charming
in appearance, will head a village,be fond of virtuous men,
and be honoured by the king.
~15I4~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P079_B009_01

- 身份：正文
- PDF 页：79
- 偈颂：65
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 65 [present] · PDF page 79

65. If Gulik is in Bandhu Bhava, the native will be sickly,
devoid of happiness, sinful, and afflicted due to windy and
billious excesses.
~15I5~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P079_B010_01

- 身份：正文
- PDF 页：79
- 偈颂：66
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 66 [present] · PDF page 79

66. If Gulik is in Putr Bhava, the native will not be
praise-worthy, be poor, short-lived, spiteful, mean, be a
eunuch, be subdued by his wife and be a heterodox.
~15I6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P079_B011_01

- 身份：正文
- PDF 页：79
- 偈颂：67
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 67 [present] · PDF page 79

67. If Gulik is in Ari Bhava, the native will be devoid of
enemies, be strong-bodied, splendorous, liked by his wife,
enthusiastic, very friendly, and helpful in disposition.
~15I7~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P080_B001_01

- 身份：正文
- PDF 页：80
- 偈颂：68
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 68 [present] · PDF page 80

68. If Gulik is in Yuvati Bhava, the native will subdue to
his spouse, be sinful, will go to others' females, be
emaciated, devoid of friendship and will live on his wife's
(or a female's) wealth.
~15I8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P080_B002_01

- 身份：正文
- PDF 页：80
- 偈颂：69
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 69 [present] · PDF page 80

69. If Gulik is in Randhr Bhava, the native will be
troubled by hunger, be miserable, cruel, very much
short-tempered, very unkind, poor, and bereft of good
qualities.
~15I9~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P080_B003_01

- 身份：正文
- PDF 页：80
- 偈颂：70
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 70 [present] · PDF page 80

70. If Gulik is in Dharm Bhava, the native will undergo
many ordeals, be emaciated, will perform evil acts, be very
unkind, sluggish, and be a tale-bearer.
~15I10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P080_B004_01

- 身份：正文
- PDF 页：80
- 偈颂：71
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 71 [present] · PDF page 80

71. If Gulik is in Karm Bhava, the native will be endowed
with sons, be happy, will enjoy many things, be fond of
worshipping gods and fire, and will practice meditation and
religion.
~15I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P080_B005_01

- 身份：正文
- PDF 页：80
- 偈颂：72
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 72 [present] · PDF page 80

72. If Gulik is in Labh Bhava, the native will enjoy women
of class, be a leader of men, be helpful to his relatives,
be short stature, and be an emperor.
~15I12~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P080_B006_01

- 身份：正文
- PDF 页：80
- 偈颂：73
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 73 [present] · PDF page 80

73. If Gulik is in Vyaya Bhava, the native will indulge in
base deeds, be sinful, defective-limbed, unfortunate,
indolent, and will join mean people.
~16I1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P080_B007_01

- 身份：正文
- PDF 页：80
- 偈颂：74
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 74 [present] · PDF page 80

74. Effects of Pranapad's Position with reference to
Lagn and in Various Bhavas (up to sloka 85): If Pranapad is
in Tanu Bhava, the native will be weak, sickly, dumb,
lunatic,  dull witted, defective-limbed, miserable, and
emaciated.
~16I2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P080_B008_01

- 身份：正文
- PDF 页：80
- 偈颂：75
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 75 [present] · PDF page 80

75. If Pranapad is in Dhan Bhava, the native will be
endowed with abundant grains (rice and wheat ,etc.)
abundant wealth, abundant attendants, abundant children,
and be fortunate.
~16I3~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P080_B009_01

- 身份：正文
- PDF 页：80
- 偈颂：76
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 76 [present] · PDF page 80

76. If Pranapad is in Sahaj Bhava, the native will be
injurious, (or mischievous), proud, hard-hearted, very
dirty, and be devoid of respect for elders.
~16I4~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P080_B010_01

- 身份：正文
- PDF 页：80
- 偈颂：77
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 77 [present] · PDF page 80

77. If Pranapad is in Bandhu Bhava, the native will be
happy, friendly, attached to females and elders, soft, and
truthful.
~16I5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P080_B011_01

- 身份：正文
- PDF 页：80
- 偈颂：78
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 78 [present] · PDF page 80

78. If Pranapad is in Putr Bhava, the native will be happy,
will do good acts, be kind, and very affectionate.
~16I6~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P081_B001_01

- 身份：正文
- PDF 页：81
- 偈颂：79
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 79 [present] · PDF page 81

79. If Pranapad is in Ari Bhava, the native will be subdued
by his relatives and enemies, be sharp, will have defective
digestive fire, be wicked, sickly, affluent, and
short-lived.
~16I7~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P081_B002_01

- 身份：正文
- PDF 页：81
- 偈颂：80
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 80 [present] · PDF page 81

80. If Pranapad is in Yuvati Bhava, the native will be
green eyed, ever libidinous, fierce in appearance, be not
worth respect, and be ill-disposed.
~16I8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P081_B003_01

- 身份：正文
- PDF 页：81
- 偈颂：81
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 81 [present] · PDF page 81

81. If Pranapad is in Randhr Bhava, the native will be
afflicted by diseases, be troubled and will incur misery on
account of the king, relatives, servants and sons.
~16I9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P081_B004_01

- 身份：正文
- PDF 页：81
- 偈颂：82
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 82 [present] · PDF page 81

82. If Pranapad is in Dharm Bhava, the native will be
endowed with sons, be very rich, fortunate, charming, will
serve others, and be not wicked but be skilful.
~16I10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P081_B005_01

- 身份：正文
- PDF 页：81
- 偈颂：83
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 83 [present] · PDF page 81

83. If Pranapad is in Karm Bhava, the native will be
heroic, intelligent, skilful, be an expert in carrying out
royal orders, and all worship gods.
~16I11~
84 If Pranapad is in Labh Bhava, the native will be famous,
virtuous, learned, wealthy, fair-complexioned, and attached
to mother.
~16I12~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P081_B006_01

- 身份：正文
- PDF 页：81
- 偈颂：85
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 85 [present] · PDF page 81

85. If Pranapad is in Vyaya Bhava, the native will be mean,
wicked, defective-limbed, will hate Brahmins and relatives,
and suffer from eye diseases or be one-eyed.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P081_B007_01

- 身份：正文
- PDF 页：81
- 偈颂：86-87
- 标题路径：CHAPTER 25 Effects of Non-Luminous Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Non-Luminous Grahas · Sloka 86-87 [present] · PDF page 81

86-87. 0 Brahmin, these are the effects for Dhum, etc.,
(and Pranapad Lagn). Before declaring these results, the
effects of Surya and other grahas should be wisely
conceived by their positions, relations, and drishtis apart
from their strength or weakness.
