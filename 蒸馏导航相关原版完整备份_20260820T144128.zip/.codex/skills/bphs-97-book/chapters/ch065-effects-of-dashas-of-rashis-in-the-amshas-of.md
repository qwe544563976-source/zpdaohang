# 第 65 章：Effects of Dashas of Rashis in the Amshas of

- 来源：BPHS 97 章版
- 原始卡片：14 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P296_B002_01

- 身份：正文
- PDF 页：296
- 偈颂：—
- 标题路径：CHAPTER 65 Effects of Dashas of Rashis in the Amshas of › the Various Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas of Rashis in the Amshas of · Sloka unknown [unknown] · PDF page 296 · page_block BPHS_PL9_CHAP_97_P296_B002

the Various Rashis

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P296_B003_01

- 身份：正文
- PDF 页：296
- 偈颂：1-3
- 标题路径：CHAPTER 65 Effects of Dashas of Rashis in the Amshas of › the Various Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas of Rashis in the Amshas of · Sloka 1-3 [present] · PDF page 296

1-3. The following will be the effects in the Dashas of
Rashis in Mesh Amsh:
Mesh    : Distress from diseases caused by blood pollution.
Vrishabh: Increase in grain production.
Mithun  : Dawn of knowledge ('Gyanodaya').
Kark    : Increase in wealth.
Simh    : Danger from enemies.
Kanya   : Happiness from wife.
Tula    : Ministership.
Vrischik: Danger of death.
Dhanu   : Gains of wealth.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P296_B004_01

- 身份：正文
- PDF 页：296
- 偈颂：4-5 1/2
- 标题路径：CHAPTER 65 Effects of Dashas of Rashis in the Amshas of › the Various Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas of Rashis in the Amshas of · Sloka 4-5 1/2 [present] · PDF page 296

4-5 1/2. The following will be the effects in the Dashas of
Rashis in Vrishabh Amsh:
Makar   : Tendency to indulge in sinful actions.
Kumbh   : Profits in business.
Meen    : Success in all ventures.
Vrischik: Danger from fire.
Tula    : Honours from the king.
Kanya   : Danger from enemies.
Kark    : Distress to wife.
Simh    : Eye troubles.
Mithun  : Danger from poison.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P296_B005_01

- 身份：正文
- PDF 页：296
- 偈颂：6-8
- 标题路径：CHAPTER 65 Effects of Dashas of Rashis in the Amshas of › the Various Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas of Rashis in the Amshas of · Sloka 6-8 [present] · PDF page 296

6-8. The following will be the effects in the Dashas of
Rashis in Mithun Amsh:
Vrishabh: Gains of wealth.
Mesh    : Fever.
Meen    : Affectionate relations with maternal uncle.
Kumbh   : Increase in enemies.
Makar   : Danger from thieves.
Dhanu   : Progress in education.
Mesh    : Assaults from enemies.
Vrishabh: Quarrels.
Mithun  : Happiness.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P296_B006_01

- 身份：正文
- PDF 页：296
- 偈颂：9-10 1/2
- 标题路径：CHAPTER 65 Effects of Dashas of Rashis in the Amshas of › the Various Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas of Rashis in the Amshas of · Sloka 9-10 1/2 [present] · PDF page 296

9-10 1/2. The following effects will be experienced in the
Dashas of Rashis in Kark Amsh:
Kark    : Enjoyments.
Simh    : Danger from the king.
Kanya   : Happiness from kinsmen.
Tula    : Good reputation.
Vrischik: Distress from father.
Dhanu   : Gain of knowledge and wealth.
Makar   : Disgrace in public.
Kumbh   : Loss in business.
Meen    : Travels to distant lands.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P297_B001_01

- 身份：正文
- PDF 页：297
- 偈颂：11-13
- 标题路径：CHAPTER 65 Effects of Dashas of Rashis in the Amshas of › the Various Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas of Rashis in the Amshas of · Sloka 11-13 [present] · PDF page 297

11-13. The following will be the effects in the Dashas of
Rashis in Simh Amsh:
Vrischik: Quarrels, distress.
Tula    : Gain of wealth, happiness.
Kanya   : Increase in wealth and grains.
Kark    : Danger from animals.
Simh    : Both happiness and sorrows.
Mithun  : Increase in enemies.
Vrishabh: Gain of property, happiness.
Mesh    : Distress.
Meen    : Long journey.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P297_B002_01

- 身份：正文
- PDF 页：297
- 偈颂：14-15 1/2
- 标题路径：CHAPTER 65 Effects of Dashas of Rashis in the Amshas of › the Various Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas of Rashis in the Amshas of · Sloka 14-15 1/2 [present] · PDF page 297

14-15 1/2. The following will be the effects in the Dashas
of Rashis in Kanya Amsh:
Kumbh   : Gain of wealth.
Makar   : Increase in wealth.
Dhanu   : Happiness from brothers.
Mesh    : Happiness from mother.
Vrishabh: Happiness from sons.
Mithun  : Danger from enemies.
Kark    : Affectionate relation with wife.
Simh    : Increase in ill health.
Kanya   : Birth of a son.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P297_B003_01

- 身份：正文
- PDF 页：297
- 偈颂：16-18
- 标题路径：CHAPTER 65 Effects of Dashas of Rashis in the Amshas of › the Various Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas of Rashis in the Amshas of · Sloka 16-18 [present] · PDF page 297

16-18. The following will be the effects in the Dashas of
Rashis in Tula Amsh:
Tula    : Gain of wealth.
Vrischik: Happiness from brothers.
Dhanu   : Happiness from brothers and uncles.
Makar   : Distress to mother.
Kumbh   : Profits in business.
Meen    : Gain of property, happiness.
Vrischik: istress to wife.
Tula    : Danger from water.
Kanya   :Increase in property and happiness.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P297_B004_01

- 身份：正文
- PDF 页：297
- 偈颂：19-20 1/2
- 标题路径：CHAPTER 65 Effects of Dashas of Rashis in the Amshas of › the Various Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas of Rashis in the Amshas of · Sloka 19-20 1/2 [present] · PDF page 297

19-20 1/2. The following will be the effects in the Dashas
of Rashis in Vrischik Amsh:
Kark    : Loss of wealth.
Simh    : Danger from government.
Mithun  : Gain of lands.
Vrishabh: Increase in wealth.
Mesh    : Distress on account of blood pollution.
Meen    : Happiness.
Kumbh   : Profits in business.
Makar   : Loss of wealth.
Dhanu   : Gain of property, happiness.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P297_B005_01

- 身份：正文
- PDF 页：297
- 偈颂：21-23
- 标题路径：CHAPTER 65 Effects of Dashas of Rashis in the Amshas of › the Various Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas of Rashis in the Amshas of · Sloka 21-23 [present] · PDF page 297

21-23. The following will be the effects of the Dashas of
Rashis in Dhanu Amsh:
Mesh    : Gain of wealth.
Vrishabh: Gain of lands.
Mithun  : Success in all ventures.
Kark    : Gain of property, happiness.
Simh    : All comforts.
Kanya   : Quarrels
Tula    : Profits in business.
Vrischik: Danger from diseases.
Dhanu   : Happiness to sons.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P298_B001_01

- 身份：正文
- PDF 页：298
- 偈颂：24-25 1/2
- 标题路径：CHAPTER 65 Effects of Dashas of Rashis in the Amshas of › the Various Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas of Rashis in the Amshas of · Sloka 24-25 1/2 [present] · PDF page 298

24-25 1/2. The following will be the effects in the Dashas
of Rashis in Makar Amsh:
Makar   : Birth of a son.
Kumbh   : Increase in wealth.
Meen    : Well-being.
Vrischik: Danger from animals.
Tula    : Gain of wealth.
Kanya   : Danger from enemies.
Kark    : Gain of wealth.
Simh    : Danger from enemies.
Mithun  : Danger from poison.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P298_B002_01

- 身份：正文
- PDF 页：298
- 偈颂：26-28
- 标题路径：CHAPTER 65 Effects of Dashas of Rashis in the Amshas of › the Various Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas of Rashis in the Amshas of · Sloka 26-28 [present] · PDF page 298

26-28. The following will be the effects in the Dashas of
Rashis in Kumbh Amsh:
Vrishabh: Increase in wealth.
Mesh    : Eye troubles.
Meen    : Travels to distant lands.
Kumbh   : Increase in wealth.
Makar   : Success in all ventures.
Dhanu   : Increase in knowledge and learning.
Mesh    : Loss of happiness.
Vrishabh: Danger of death.
Mithun  : Gains of property, happiness.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P298_B003_01

- 身份：正文
- PDF 页：298
- 偈颂：29-31
- 标题路径：CHAPTER 65 Effects of Dashas of Rashis in the Amshas of › the Various Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas of Rashis in the Amshas of · Sloka 29-31 [present] · PDF page 298

29-31. The following will be the effects in the Dashas of
Rashis in Meen Amsh:
Kark    : Increase in wealth.
Simh    : Assistance from the king.
Kanya   : Increase in wealth and grains.
Tula    : Profits in business.
Vrischik: Distress from fever.
Dhanu   : Increase in knowledge and wealth.
Makar   : Antagonism with wife.
Kumbh   : Danger from water.
Meen    : All kinds of enjoyments.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P298_B004_01

- 身份：正文
- PDF 页：298
- 偈颂：32
- 标题路径：CHAPTER 65 Effects of Dashas of Rashis in the Amshas of › the Various Rashis
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dashas of Rashis in the Amshas of · Sloka 32 [present] · PDF page 298

32. There is no doubt that observance of remedial measures
in the form of prescribed Maharishi Yagyas destroys the
evil effects of the inauspicious Dashas and yield
happiness.
