# 第 71 章：Determination of Longevity through the Ashtakavarg

- 来源：BPHS 97 章版
- 原始卡片：1 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P312_B002_01

- 身份：正文
- PDF 页：312
- 偈颂：1-4
- 标题路径：CHAPTER 71 Determination of Longevity through the Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Determination of Longevity through the Ashtakavarg · Sloka 1-4 [present] · PDF page 312

1-4. The sage said: I will now describe the method of
determining longevity from the Ashtakavarg. For this purpose
the Ashtakavargas of Lagn and all the grahas have to be
studied. The rekhas in all the rashis have been allotted
specific spans of life. The rashi which has no rekhas has
been allotted 2 days, that with one rekha gets l 1/2 days,
one day for rashi with 2 rekhas, half day for rashi with 3
rekhas, 7 1/2 days for rashi with 4 rekhas, 2 years for rashi
with 5 rekhas, 4 years for rashi with 6 rekhas, 6 years for
rashi with 7 rekhas and 8 years for rashi with 8 rekhas. In
this manner the spans of life should be worked from rekhas in
all the Ashtakavargas. Half of the sum total of all will be
the longevity based on Ashtakavarg.
