# 第 83 章：Effects of curses in the previous birth

- 来源：BPHS 97 章版
- 原始卡片：27 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P347_B002_01

- 身份：正文
- PDF 页：347
- 偈颂：1-3
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 1-3 [present] · PDF page 347

1-3. Maitreya said: O Venerable Sage! You have acquainted me
with effects experienced by men and women in a number of
ways. According to Shastras the soul of a person does not
rest in peace after his death if he is not blessed with a
son. What sin does a person commit to remain without a son?
And what are the remedial measures to be adopted by him to
get a son? Kindly enlighten me about this.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P347_B003_01

- 身份：正文
- PDF 页：347
- 偈颂：4
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 4 [present] · PDF page 347

4. Maharishi Parasara replied: I will now tell you whatever
Lord Shiva told Goddess Parvati in this respect.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P347_B004_01

- 身份：正文
- PDF 页：347
- 偈颂：5
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 5 [present] · PDF page 347

5. Goddess Parvati said to Lord Shiva: O my Lord! what is the
sin which causes destruction of children amongst men. Please
tell me what are the Yogas (planetary combinations for such
an effect and what are the remedial measures to protect the
children?

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P347_B005_01

- 身份：正文
- PDF 页：347
- 偈颂：6
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 6 [present] · PDF page 347

6. Lord Shiva replied: O Davi! You have asked a very relevant
question. Now I will tell you the Yogas for loss of children
and the requisite remedial measures.
Yogas for childlessness (son-lessness)
~5x*L1x*L5x~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P347_B006_01

- 身份：正文
- PDF 页：347
- 偈颂：7
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 7 [present] · PDF page 347

7. A person will be without a son if Guru, the lord of Lagn
and the lord of the 5th are all devoid of strength.
~1X*3X*8X*7X*1I5*3I5*8I5*7I5*5x*L5x~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P347_B007_01

- 身份：正文
- PDF 页：347
- 偈颂：8
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 8 [present] · PDF page 347

8. The same will happen if Surya, Mangal, Rahu, and Shani
endowed with strength be in the 5th bhava and the
significator for children (Putra karaka) namely Guru and lord
of the 5th etc., be bereft of strength.
Yogas for various kinds of curses culminating in son-lessness
~8I5*8D3~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P348_B001_01

- 身份：正文
- PDF 页：348
- 偈颂：9-16
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 9-16 [present] · PDF page 348

9-16. There will be no male issue due to the curse of a
serpent if at birth:
(1) Rahu is in the 5th bhava aspected by Mangal;
~L5D8+L5Y8**2I5*2D7~n
There will be no male issue due to the curse of a serpent if
at birth:
(2) the lord of 5th is associated with Rahu, and Chandr is in
the 5th bhava and is aspected by Shani;
~5D8+5Y8**L5x*L1Y3~n
There will be no male issue due to the curse of a serpent if
at birth:
(3) the significator for children (Guru) is associated with
Rahu, the lord of the 5th is devoid of strength, and the lord
of Lagn is with Mangal;
~5A3*8I1*L5Ia~n
There will be no male issue due to the curse of a serpent if
at birth:
(4) the significator for children (Guru) is associated with
Mangal, Lagn is occupied by Rahu, and the lord of the 5th
bhava is in 6th, the 8th, or the 12th bhava;
~4iL5*N4IR1+4iL5*N4IR8**4A3*8I1*.GI1~n
There will be no male issue due to the curse of a serpent if
at birth:
(5) Buddh as lord of the 5th being in the Navams of Mangal is
associated with Mangal, and Lagn is occupied by Rahu and
gulika;
~3iL5**L5A8+L5A4~n
There will be no male issue due to the curse of a serpent if
at birth:
(6) the 5th bhava is Mesh or Vrischik and the lord of the 5th
is associated with Rahu or Buddh;
~1I5*7I5*3I5*8I5*4I5*5I5*L5x*L1x~n
There will be no male issue due to the curse of a serpent if
at birth:
(7) the 5th is occupied by Surya, Shani, Mangal, Rahu, Buddh,
and Guru and the lords of the 5th and Lagn are devoid of
strength;
~L5Y3**L1A8+5A8~n
There will be no male issue due to the curse of a serpent if
at birth:
(8) the lord of Lagn or Guru is associated with Rahu and the
lord of the 5th is in conjunction with Mangal.
Remedial measures

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P348_B001_02

- 身份：正文
- PDF 页：348
- 偈颂：9-16
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 9-16 [present] · PDF page 348

9-16. There will be no male issue due to the curse of a
serpent if at birth:
(1) Rahu is in the 5th bhava aspected by Mangal;
~L5D8+L5Y8**2I5*2D7~n
There will be no male issue due to the curse of a serpent if
at birth:
(2) the lord of 5th is associated with Rahu, and Chandr is in
the 5th bhava and is aspected by Shani;
~5D8+5Y8**L5x*L1Y3~n
There will be no male issue due to the curse of a serpent if
at birth:
(3) the significator for children (Guru) is associated with
Rahu, the lord of the 5th is devoid of strength, and the lord
of Lagn is with Mangal;
~5A3*8I1*L5Ia~n
There will be no male issue due to the curse of a serpent if
at birth:
(4) the significator for children (Guru) is associated with
Mangal, Lagn is occupied by Rahu, and the lord of the 5th
bhava is in 6th, the 8th, or the 12th bhava;
~4iL5*N4IR1+4iL5*N4IR8**4A3*8I1*.GI1~n
There will be no male issue due to the curse of a serpent if
at birth:
(5) Buddh as lord of the 5th being in the Navams of Mangal is
associated with Mangal, and Lagn is occupied by Rahu and
gulika;
~3iL5**L5A8+L5A4~n
There will be no male issue due to the curse of a serpent if
at birth:
(6) the 5th bhava is Mesh or Vrischik and the lord of the 5th
is associated with Rahu or Buddh;
~1I5*7I5*3I5*8I5*4I5*5I5*L5x*L1x~n
There will be no male issue due to the curse of a serpent if
at birth:
(7) the 5th is occupied by Surya, Shani, Mangal, Rahu, Buddh,
and Guru and the lords of the 5th and Lagn are devoid of
strength;
~L5Y3**L1A8+5A8~n
There will be no male issue due to the curse of a serpent if
at birth:
(8) the lord of Lagn or Guru is associated with Rahu and the
lord of the 5th is in conjunction with Mangal.
Remedial measures

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P348_B002_01

- 身份：正文
- PDF 页：348
- 偈颂：17-19
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 17-19 [present] · PDF page 348

17-19. Remedial measures should be adopted to obtain
protection from the evil effects of the above Yogas. These
are getting an idol of Naga Raja (Serpent Lord) made in gold
and after worshipping it in accordance with prescribed
procedure, giving in charity a cow, some land, sesame seeds
and gold, etc.. By adopting these measures the Lord of
Serpents (Naga Raja) will be gratified and by his beneficence
the person concerned will be blessed with a son and the
lineage of his family will be prolonged.

Yogas for lack of a male issue as a result of the curse of
the father in the previous birth

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P349_B001_01

- 身份：正文
- PDF 页：349
- 偈颂：20-30
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 20-30 [present] · PDF page 349

20-30. There will be no male issue as a result of the curse
of the father in the previous birth, if at birth of the
native:
~1d*1h*1I5**N1IR10+N1IR11~n
(l) Surya in his debilitation rashi and in the Navams of
Shani, is hemmed in between malefics in the 5th bhava;
~1iL5*1T*1Ym*1Dm~n
(2) Surya as lord of the 5th posited in a Trikon with a
malefic, is hemmed in between malefics and is also aspected
by a malefic;
~5IR5*L5Y1*mI1*mI5~n
(3) Guru occupies the rashi of Surya, the lord of the 5th is
with Surya, and Lagn and the 5th are occupied by malefics;
~L1x*L1I5*L5c*mI1*mI5~n
(4) the lord of Lagn devoid of strength is in the 5th and the
lord of the 5th is combust and Lagn and the 5th are occupied
by malefics;
~L5lL10*mI1*mI5~n
(5) there is exchange of bhavas between lords of the 5th and
the 10th and Lagn and the 5th are occupied by malefics;
~3AL5*3iL10*mI1*mI5*mI10~n
(6) Mangal as the lord of the 10th is associated with the
lord of the 5th, and Lagn, the 5th, and the 10th bhavas are
occupied by malefics;
~L10Ia*5IRa*L1Am*L5Am~n
(7) the lord of the 10th is in the 6th, the 8th, or the 12th,
Guru is in a malefic rashi and the lord of Lagn and the 5th
are associated with malefics
~1I!T*-1I9*3I!T*-3I9*7I!T*-7I!9*8Ia*-8I6*5Ia*-5I6~n
(8) Surya, Mangal, and Shani are in Lagn and the 5th, and
Rahu and Guru are in the 8th and the 12th (In this Yog it is
not stated which amongst Surya, Mangal, and Shani should be
in Lagn and the 5th and which amongst Rahu and Guru should be
in the 8th and the 12th. We presume the purpose of the Yog
will be fulfilled if any amongst Surya, Mangal, and Shani are
in Lagn and the 5th, and amongst Rahu and Guru are in the 8th
and the 12th. However, the most logical interpretation should
be for Surya to be in Lagn, and Mangal and Shani in the 5th,
Rahu in the 8th, and Guru in the 12th);
~1I8*7I5*L5A8*mI1~n
(9) Surya is in the 8th, Shani is in the 5th, the lord of the
5th is associated with Rahu and Lagn is occupied by a
malefic;
~L12I1*L8I5*L10I6~n
(10) the lord of the 12th is in Lagn, the lord of the 8th is
in the 5th and the lord of the 10th is in the 8th;
~L6I5*L10I6*5A8~n
(11) the lord of the 6th is in the 5th, the lord of the 10th
is in the 6th, and Guru is associated with Rahu.
Remedial measures

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P349_B001_02

- 身份：正文
- PDF 页：349
- 偈颂：20-30
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 20-30 [present] · PDF page 349

20-30. There will be no male issue as a result of the curse
of the father in the previous birth, if at birth of the
native:
~1d*1h*1I5**N1IR10+N1IR11~n
(l) Surya in his debilitation rashi and in the Navams of
Shani, is hemmed in between malefics in the 5th bhava;
~1iL5*1T*1Ym*1Dm~n
(2) Surya as lord of the 5th posited in a Trikon with a
malefic, is hemmed in between malefics and is also aspected
by a malefic;
~5IR5*L5Y1*mI1*mI5~n
(3) Guru occupies the rashi of Surya, the lord of the 5th is
with Surya, and Lagn and the 5th are occupied by malefics;
~L1x*L1I5*L5c*mI1*mI5~n
(4) the lord of Lagn devoid of strength is in the 5th and the
lord of the 5th is combust and Lagn and the 5th are occupied
by malefics;
~L5lL10*mI1*mI5~n
(5) there is exchange of bhavas between lords of the 5th and
the 10th and Lagn and the 5th are occupied by malefics;
~3AL5*3iL10*mI1*mI5*mI10~n
(6) Mangal as the lord of the 10th is associated with the
lord of the 5th, and Lagn, the 5th, and the 10th bhavas are
occupied by malefics;
~L10Ia*5IRa*L1Am*L5Am~n
(7) the lord of the 10th is in the 6th, the 8th, or the 12th,
Guru is in a malefic rashi and the lord of Lagn and the 5th
are associated with malefics
~1I!T*-1I9*3I!T*-3I9*7I!T*-7I!9*8Ia*-8I6*5Ia*-5I6~n
(8) Surya, Mangal, and Shani are in Lagn and the 5th, and
Rahu and Guru are in the 8th and the 12th (In this Yog it is
not stated which amongst Surya, Mangal, and Shani should be
in Lagn and the 5th and which amongst Rahu and Guru should be
in the 8th and the 12th. We presume the purpose of the Yog
will be fulfilled if any amongst Surya, Mangal, and Shani are
in Lagn and the 5th, and amongst Rahu and Guru are in the 8th
and the 12th. However, the most logical interpretation should
be for Surya to be in Lagn, and Mangal and Shani in the 5th,
Rahu in the 8th, and Guru in the 12th);
~1I8*7I5*L5A8*mI1~n
(9) Surya is in the 8th, Shani is in the 5th, the lord of the
5th is associated with Rahu and Lagn is occupied by a
malefic;
~L12I1*L8I5*L10I6~n
(10) the lord of the 12th is in Lagn, the lord of the 8th is
in the 5th and the lord of the 10th is in the 8th;
~L6I5*L10I6*5A8~n
(11) the lord of the 6th is in the 5th, the lord of the 10th
is in the 6th, and Guru is associated with Rahu.
Remedial measures

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P350_B001_01

- 身份：正文
- PDF 页：350
- 偈颂：31-33
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 31-33 [present] · PDF page 350

31-33. To get deliverance form the curse of the father the
remedial measures are:
(l) Performance of Shraddha at Gaya;
(2) to feed ten thousand, one thousand, or 100 Brahmins, as
one can afford;
(3) Kanyadana (to perform the marriage of a girl);
(4) giving a cow in charity.
By observing these remedial measures, the person concerned
becomes free from the curse and the family lineage is
prolonged _ by the birth of sons, grandsons, etc..
Important note: In this chapter where the words
'childlessness' and issue-lessness' are used they should be
interpreted to mean want of male issue, because it is the
male issue who by performing the last rites of his father and
mother ensures eternal peace to their souls.
Yogas for lack of male issue as a result of the curse of the
mother in the previous birth

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P351_B001_01

- 身份：正文
- PDF 页：351
- 偈颂：34-50
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 34-50 [present] · PDF page 351

34-50. A person will be without a male issue as a result of
curse of the mother, if at birth:
~2d+2h**mI4*mI5~n
(I) Chandr as lord of the 5th is in her debilitation rashi or
is hemmed in between malefics, and the 4th and the 5th are
occupied by malefics.
~7I11*mI4*2I5*2d~n
(2) Shani is in the 11th, the 4th is occupied by malefics,
and Chandr is posited in the 5th, in her debilitation rashi;
~L5Ia*L1d*2Am~n
(3) the lord of the 5th is in the 6th, the 8th, or the 12th,
the lord of Lagn is in his debilitation rashi and Chandr is
associated with malefics;
~L5Ia*N2IRa*mI1*mI5~n
(4) the lord of the 5th is in the 8th, the 6th, or the 12th,
Chandr is in a malefic Navams, and there are malefics in Lagn
and in the 5th;
~L5A7*L5A8*L5A3*2A7*2A8*2A3*L5I!T*-L5I1*2I!T*-2I1~n
(5) the lord of the 5th and Chandr associated with Shani,
Rahu, and Mangal, are in the 5th or the 9th;
~3iL4*3A7*3A8*1I5*2I1~n
(6) Mangal as lord of the 4th is associated with Shani and
Rahu, and the 5th and Lagn are occupied by Surya and Chandr
respectively;
~L1I6*L5I6*L4I8*L8I1*L10I1~n
(7) the lords of Lagn and the 5th are in the 6th, the lord of
the 4th is in the 8th and Lagn is occupied by the lord of the
8th and the 10th;
~L6I1*L8I1*L4I12*2Am*5Am*2I5*5I5~n
(8) Lagn is occupied by the lords of the 6th and the 8th, the
lord of the 4th is in the 12th and Chandr and Guru,
associated with malefics, are in the 5th;
~Lnh*2w*2I7*8I4*7I5~n
(9) Lagn is hemmed in between malefics, waning Chandr is in
the 7th, and the 4th and the 5th are occupied by Rahu and
Shani respectively;
~L5lL8*L4Ia*2Ia~n
(10) there is exchange of bhavas between lords of the 5th and
the 8th and the lord of the 4th and Chandr are in the 6th,
the 8th, or the 12th;
~3d*3Y8*2I5*7I5~n
(11) Kark Lagn is occupied by Mangal and Rahu, and Chandr and
Shani are in the 5th;
~3I1*8I5*1I8*7I12*L1Ia*L4Ia~n
(12) Mangal, Rahu, Surya, and Shani are in Lagn, the 5th, the
8th, and the 12th respectively and the lords of Lagn and the
4th are in the 6th, the 8th, or the 12th;
~3I8*8I8*5I8*7I5*2I5~n
(13) Mangal, Rahu, and Guru are in the 8th, and Shani and
Chandr are in the 5th.
Remedial measures
For release from this curse and to beget a male issue, the
person concerned should take bath in the sea with bridge of
rocks between India and Sri Lanka, recite one lakh Gayatri
mantras, give in charity things connected with evil grahas,
feed Brahmins and go round a pipal tree 1008 times. By
performing these remedial measures he will not only beget a
son, the lineage of family will also be prolonged.
Yogas for lack of male issue as result of the curse of the
brother in the previous birth
~L3Y3*L3Y8*L3I5*L1I8*L5I8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P351_B001_02

- 身份：正文
- PDF 页：351
- 偈颂：34-50
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 34-50 [present] · PDF page 351

34-50. A person will be without a male issue as a result of
curse of the mother, if at birth:
~2d+2h**mI4*mI5~n
(I) Chandr as lord of the 5th is in her debilitation rashi or
is hemmed in between malefics, and the 4th and the 5th are
occupied by malefics.
~7I11*mI4*2I5*2d~n
(2) Shani is in the 11th, the 4th is occupied by malefics,
and Chandr is posited in the 5th, in her debilitation rashi;
~L5Ia*L1d*2Am~n
(3) the lord of the 5th is in the 6th, the 8th, or the 12th,
the lord of Lagn is in his debilitation rashi and Chandr is
associated with malefics;
~L5Ia*N2IRa*mI1*mI5~n
(4) the lord of the 5th is in the 8th, the 6th, or the 12th,
Chandr is in a malefic Navams, and there are malefics in Lagn
and in the 5th;
~L5A7*L5A8*L5A3*2A7*2A8*2A3*L5I!T*-L5I1*2I!T*-2I1~n
(5) the lord of the 5th and Chandr associated with Shani,
Rahu, and Mangal, are in the 5th or the 9th;
~3iL4*3A7*3A8*1I5*2I1~n
(6) Mangal as lord of the 4th is associated with Shani and
Rahu, and the 5th and Lagn are occupied by Surya and Chandr
respectively;
~L1I6*L5I6*L4I8*L8I1*L10I1~n
(7) the lords of Lagn and the 5th are in the 6th, the lord of
the 4th is in the 8th and Lagn is occupied by the lord of the
8th and the 10th;
~L6I1*L8I1*L4I12*2Am*5Am*2I5*5I5~n
(8) Lagn is occupied by the lords of the 6th and the 8th, the
lord of the 4th is in the 12th and Chandr and Guru,
associated with malefics, are in the 5th;
~Lnh*2w*2I7*8I4*7I5~n
(9) Lagn is hemmed in between malefics, waning Chandr is in
the 7th, and the 4th and the 5th are occupied by Rahu and
Shani respectively;
~L5lL8*L4Ia*2Ia~n
(10) there is exchange of bhavas between lords of the 5th and
the 8th and the lord of the 4th and Chandr are in the 6th,
the 8th, or the 12th;
~3d*3Y8*2I5*7I5~n
(11) Kark Lagn is occupied by Mangal and Rahu, and Chandr and
Shani are in the 5th;
~3I1*8I5*1I8*7I12*L1Ia*L4Ia~n
(12) Mangal, Rahu, Surya, and Shani are in Lagn, the 5th, the
8th, and the 12th respectively and the lords of Lagn and the
4th are in the 6th, the 8th, or the 12th;
~3I8*8I8*5I8*7I5*2I5~n
(13) Mangal, Rahu, and Guru are in the 8th, and Shani and
Chandr are in the 5th.
Remedial measures
For release from this curse and to beget a male issue, the
person concerned should take bath in the sea with bridge of
rocks between India and Sri Lanka, recite one lakh Gayatri
mantras, give in charity things connected with evil grahas,
feed Brahmins and go round a pipal tree 1008 times. By
performing these remedial measures he will not only beget a
son, the lineage of family will also be prolonged.
Yogas for lack of male issue as result of the curse of the
brother in the previous birth
~L3Y3*L3Y8*L3I5*L1I8*L5I8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P352_B001_01

- 身份：正文
- PDF 页：352
- 偈颂：51-61
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 51-61 [present] · PDF page 352

51-61. A person will be without a male issue as result of the
curse of the brother, if at birth:
(I) the lord of the 3rd with Rahu and Mangal is in the 5th
and the lords of Lagn and the 5th are in the 8th;
~3I1+3I8***7I5*L3I9~n
(2) Lagn and the 5th are occupied by Mangal and Shani
respectively, the lord of the 3rd is in the 9th, and Mangal,
the significator for brothers is in the 8th;
~5d*5I3*7I5*2I8*3I8~n
(3) Guru in his debilitation rashi is in the 3rd, Shani is in
the 5th and Chandr and Mangal are in the 8th;
~L1I12*3I5*L5Am*L5I8~n
(4) the lord of Lagn is in the 12th, Mangal is in the  5th,
and the lord of the 5th associated with a malefic is in the
8th;
~@s8*L1Ia*L5Ia~n
(5) Lagn and the 5th bhava are hemmed in between malefics and
the lord of Lagn and the 5th are in the 6th, the 8th, or the
12th;
~L10I3*L10Ym*3I5*3YB~n
(6) the 3rd is occupied by the lord of the 10th along with a
malefic, and a benefic is with Mangal in the 5th;
~L5i4*7I5*8I5*4I12*3I12~n
(7) the 5th bhava in a rashi of Buddh is occupied by Shani
and Rahu, and Buddh and Mangal are in the 12th;
~L1I3*L3I5*mI1*mI3*mI5~n
(8) the 3rd is occupied by the lord of Lagn, the lord of the
3rd occupies the 5th, and Lagn, the 3rd, and the 5th bhavas
are with malefics;
~L3I8*5A7*5I5~n
(9) the lord of the 3rd is in the 8th, and Guru is associated
with Shani in the 5th;
~L8I5*L3I5*3I8*7I8~n
(10) the lord of the 8th is in the 5th along with the lord of
the 3rd, and Mangal and Shani are in the 8th.

Remedial measures for getting deliverance from the brother's
curse

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P352_B001_02

- 身份：正文
- PDF 页：352
- 偈颂：51-61
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 51-61 [present] · PDF page 352

51-61. A person will be without a male issue as result of the
curse of the brother, if at birth:
(I) the lord of the 3rd with Rahu and Mangal is in the 5th
and the lords of Lagn and the 5th are in the 8th;
~3I1+3I8***7I5*L3I9~n
(2) Lagn and the 5th are occupied by Mangal and Shani
respectively, the lord of the 3rd is in the 9th, and Mangal,
the significator for brothers is in the 8th;
~5d*5I3*7I5*2I8*3I8~n
(3) Guru in his debilitation rashi is in the 3rd, Shani is in
the 5th and Chandr and Mangal are in the 8th;
~L1I12*3I5*L5Am*L5I8~n
(4) the lord of Lagn is in the 12th, Mangal is in the  5th,
and the lord of the 5th associated with a malefic is in the
8th;
~@s8*L1Ia*L5Ia~n
(5) Lagn and the 5th bhava are hemmed in between malefics and
the lord of Lagn and the 5th are in the 6th, the 8th, or the
12th;
~L10I3*L10Ym*3I5*3YB~n
(6) the 3rd is occupied by the lord of the 10th along with a
malefic, and a benefic is with Mangal in the 5th;
~L5i4*7I5*8I5*4I12*3I12~n
(7) the 5th bhava in a rashi of Buddh is occupied by Shani
and Rahu, and Buddh and Mangal are in the 12th;
~L1I3*L3I5*mI1*mI3*mI5~n
(8) the 3rd is occupied by the lord of Lagn, the lord of the
3rd occupies the 5th, and Lagn, the 3rd, and the 5th bhavas
are with malefics;
~L3I8*5A7*5I5~n
(9) the lord of the 3rd is in the 8th, and Guru is associated
with Shani in the 5th;
~L8I5*L3I5*3I8*7I8~n
(10) the lord of the 8th is in the 5th along with the lord of
the 3rd, and Mangal and Shani are in the 8th.

Remedial measures for getting deliverance from the brother's
curse

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P352_B002_01

- 身份：正文
- PDF 页：352
- 偈颂：62-64
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 62-64 [present] · PDF page 352

62-64. The person concerned will, without doubt, get release
from the curse, will be blessed with a son, and the
prolongation of his family lineage will be ensured if the
following remedial measures are adopted:
(l) he should observe the Chandryana fast after listening to
Haribansa Puran;
(2) he should plant a sapling of pipal in front of Saligram
on the banks of the Caveri river or on the Ganga or Mahanadi
and offer prayers to it;
(3) he should give 10 cows in charity through his wife;
(4) he should give in charity land with mango trees planted
on it.

Yogas for lack of male issue as a result of the curse of
maternal uncle in the previous birth
~4I5*5I5*3I5*8I5*7I1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P353_B001_01

- 身份：正文
- PDF 页：353
- 偈颂：65-68
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 65-68 [present] · PDF page 353

65-68. A person will be without a male issue as a result of
the curse of the maternal uncle, if at birth:
(I) the 5th bhava is occupied by Buddh, Guru, Mangal, and
Rahu, and Shani is in Lagn;
~L1I5*L5I5*7I5*3I5*4I5~n
(2) the 5th is occupied by the lords of Lagn and of the 5th
along with Shani, Mangal, and Buddh;
~L6I1*L6c*7I7*L1A4~n
(3) Lagn is occupied by a combust lord of the 6th (perhaps
Surya will also be there), Shani is in the 7th, and the lord
of Lagn is associated with Buddh;
~L1I1*L4I1*2I5*4I5*3I5~n
(4) Lords of Lagn and the 4th are in Lagn, and Chandr, Buddh,
and Mangal are in the 5th.
Remedial measures

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P353_B002_01

- 身份：正文
- PDF 页：353
- 偈颂：69-70
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 69-70 [present] · PDF page 353

69-70. To get release from the curse and for being blessed
with a son and for ensuring the prolongation of the lineage
of the family, the following remedial measures are too be
adopted:
(I) Installation of an idol of lord Vishnu;
(2) Construction of a deep or ordinary well, dam, or
reservoir, or all of them.
Yogas for lack of male issue as a result of curse of Brahmins
in the previous birth
~8IR9+8IR12**5I5~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P353_B003_01

- 身份：正文
- PDF 页：353
- 偈颂：71-78
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 71-78 [present] · PDF page 353

71-78. If a person mad with power and wealth, insults a
Brahmin, he remains without a male issue in the next birth. A
person will he without a male issue as a result of the curse
of a Brahmin, if at birth:
(1) Rahu is in Guru's rashi, and Guru is in the 5th;
~L9I5*L5I8*5I8*3I8*8I8~n
(2) the lord of the 9th is in the 5th, and the lord of the
5th is in the 8th along with Guru, Mangal, and Rahu;
~L9d*L12A8*L12I5~n
(3) the lord of the 9th is in his debilitation rashi, and the
lord of the 12th associated with Rahu is in the 5th;
~8I1+8I5**5d*L5Ia~n
(4) Guru is in his debilitation rashi, Rahu is in Lagn or the
5th, and the lord of the 5th is in the 6th, the 8th, or the
12th;
~L5Am*5Am*L5I8*5I8+L5A1*L5A2*L5I8~n
(5) the lord of the 5th and Guru associated with malefics,
are in the 8th, or the lord of the 5th associated with Surya
and Chandr is in the 8th;
~Nã5i7*5A7*5A3*L5I12~n
(6) Guru being in the Navams of Shani is associated with
Shani and Mangal, and the lord of the 5th is in the 12th;
~5A7*5I1*8I9+8I12*5I12~n
(7) Guru is associated with Shani in Lagn and Rahu is in the
9th, or Rahu  is with Guru in the 12th.
These are Yogas which reveal the curse of Brahmin in the
previous birth.
Remedial measures

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P354_B001_01

- 身份：正文
- PDF 页：354
- 偈颂：79-81
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 79-81 [present] · PDF page 354

79-81. To obtain relief from the evil effects of the above
Yogas the remedial measures are:
(I) to observe Chandrayana fast and to do penance three
times; and
(2) to give in charity a cow and five gems with gold after
feeding Brahmins according to one's means and giving them
presents in cash.
Then the person will be released from the curse and will be
endowed with happiness after performing the above remedial
measures.
Yogas for lack of male issue as a result of the curse of the
wife in the previous birth
~L1I5*L7iNã7*L5I8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P354_B002_01

- 身份：正文
- PDF 页：354
- 偈颂：82-92
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 82-92 [present] · PDF page 354

82-92. A person does not beget a male issue, as a result of
the curse of the wife, if at birth:
(I) the lord of Lagn is in the 5th, Shani is in the Navams of
the lord of the 7th, and the lord of the 5th is in the 8th;
~L7I8*L12I12*5Am~n
(2) the lord of the 7th is in the 8th, the lord of the 12th
is in the 5th, and Guru is associated with a malefic;
~6I5*L7I8*mI5~n
(3) Shukr is in the 5th, the lord of the 7th is in the 8th
and the 5th is occupied by a malefic;
~mI2*mI5*L7I8~n
(4) the 2nd and the 5th are occupied by a malefic and the
lord of the 7th is in the 8th;
~6I9*L7I8*mI1*mI5~n
(5) Shukr is in the 9th, the lord of the 7th is in the 8th
and Lagn and the 5th are occupied by malefics;
~L9i6*L5e*L1Ia*L7Ia*5Ia~n
(6) Shukr is lord of the 9th, lord of the 5th is an inimical
rashi and the lord of Lagn and the 7th and Guru are in the
6th, the 8th, or the 12th;
~L5i6*1I5*2I5*mI1*mI2*mI12~n
(7) the 5th is Vrishabh or Tul occupied by Surya and Chandr,
and the 12th, Lagn, and the 2nd are occupied by malefics;
~7I7*6I7*L8I5*1I1*8I1~n
(8) Shani and Shukr are in the 7th, the lord of the 8th is in
the 5th, and Lagn is occupied by Surya and Rahu;
~3I2*5I12*6I5*8I5~n
(9) Mangal occupies the 2nd, Guru is in the 12th, and Shukr
and Rahu are in the 5th;
~L2I8*L7I8*3I5*7I1*5Am~n
(10) the lords of the 2nd and the 7th are in the 8th, Mangal
and Shani occupy the 5th and Lagn respectively and Guru is
associated with a malefic;
~8I1*7I5*3I9*L5I8*L7I8~n
(11) Rahu is in Lagn, Shani is in the 5th, Mangal is in the
9th, and the lords of the 5th and the 7th are in the 8th.

Remedial measures

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P354_B002_02

- 身份：正文
- PDF 页：354
- 偈颂：82-92
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 82-92 [present] · PDF page 354

82-92. A person does not beget a male issue, as a result of
the curse of the wife, if at birth:
(I) the lord of Lagn is in the 5th, Shani is in the Navams of
the lord of the 7th, and the lord of the 5th is in the 8th;
~L7I8*L12I12*5Am~n
(2) the lord of the 7th is in the 8th, the lord of the 12th
is in the 5th, and Guru is associated with a malefic;
~6I5*L7I8*mI5~n
(3) Shukr is in the 5th, the lord of the 7th is in the 8th
and the 5th is occupied by a malefic;
~mI2*mI5*L7I8~n
(4) the 2nd and the 5th are occupied by a malefic and the
lord of the 7th is in the 8th;
~6I9*L7I8*mI1*mI5~n
(5) Shukr is in the 9th, the lord of the 7th is in the 8th
and Lagn and the 5th are occupied by malefics;
~L9i6*L5e*L1Ia*L7Ia*5Ia~n
(6) Shukr is lord of the 9th, lord of the 5th is an inimical
rashi and the lord of Lagn and the 7th and Guru are in the
6th, the 8th, or the 12th;
~L5i6*1I5*2I5*mI1*mI2*mI12~n
(7) the 5th is Vrishabh or Tul occupied by Surya and Chandr,
and the 12th, Lagn, and the 2nd are occupied by malefics;
~7I7*6I7*L8I5*1I1*8I1~n
(8) Shani and Shukr are in the 7th, the lord of the 8th is in
the 5th, and Lagn is occupied by Surya and Rahu;
~3I2*5I12*6I5*8I5~n
(9) Mangal occupies the 2nd, Guru is in the 12th, and Shukr
and Rahu are in the 5th;
~L2I8*L7I8*3I5*7I1*5Am~n
(10) the lords of the 2nd and the 7th are in the 8th, Mangal
and Shani occupy the 5th and Lagn respectively and Guru is
associated with a malefic;
~8I1*7I5*3I9*L5I8*L7I8~n
(11) Rahu is in Lagn, Shani is in the 5th, Mangal is in the
9th, and the lords of the 5th and the 7th are in the 8th.

Remedial measures

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P355_B001_01

- 身份：正文
- PDF 页：355
- 偈颂：93-94
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 93-94 [present] · PDF page 355

93-94. The person concerned gets release from the curse and
is blessed with a son, if he performs the marriage of an
unmarried girl (Kanyadana), or if such a girl is not
available a gold idol of the Lakshminarayana, fertile cow, a
bed, ornaments, and garments to a Brahmin couple.
Notes: According to our view 'Kanyadana' does not mean giving
a girl in charity but helping in the performance of the
marriage of an unmarried girl not his own daughter.
Yogas for lack of male issue as a result of the curse of a
departed soul
~7I5*1I5*2w*2I7*8I12*5I12~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P355_B002_01

- 身份：正文
- PDF 页：355
- 偈颂：95-105
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 95-105 [present] · PDF page 355

95-105. If the person whose duty is to do so does not perform
Shraddha of his father or mother in his previous birth, the
departed soul is formed into an evil spirit and he is
deprived of a male issue in the next birth. This is revealed
by the following Yogas at birth:
(1) Shani and Surya in the 5th, waning Chandr in the 7th, and
Rahu and Guru in the 12th;
~7iL5*7I8*3I1*5I8~n
(2) Shani as lord of the 5th in the 8th, Mangal in Lagn, and
Guru in the 8th;
~mI1*1I12*3I5*7I5*4I5*L5I8~n
(3) Malefics are in Lagn, Surya is in the 12th, Mangal,
Shani, and Buddh are in the 5th, and the lord of the 5th is
in the 8th;
~8I1*7I5*5I8~n
(4) Rahu is in Lagn, Shani is in the 5th, and Guru is in the
8th;
~6I1*5I1*8I1*8A2*7I8*L1I8~n
(5) Shukr, Guru, and Rahu are in Lagn associated with Chandr,
and Shani and the lord of Lagn are in the 8th;
L5d*5d*L5Dt*5Dt~n
(6) the lord of the 5th and Guru are in their debilitation
rashis aspected by debilitated grahas;
~7I1*8I5*1I8*3I12~
(7) Shani is in Lagn, Rahu is in the 5th, Surya is in the
8th, and Mangal is in the 12th;
~L7Ia*2I5*7I1*.GI1~n
(8) the lord of the 7th is in the 6th, the 8th, or the 12th,
Chandr is in the 5th, Shani and Gulika are in Lagn;
~L8I5*7I5*6I5*5d~n
(9) the lord of the 8th along with Shani and Shukr is in the
5th and Guru is in his debilitation rashi.

Remedial measures

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P355_B003_01

- 身份：正文
- PDF 页：355
- 偈颂：106-108
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 106-108 [present] · PDF page 355

106-108. The person concerned gets release from the curse and
is blessed with a son if he undertakes the following remedial
measures:
(I) Performance of a Pinda dana;
(2) Rudra abhisheka;
(3) Giving in charity a gold idol of Brahma, a cow, a vessel
made of silver and a neelamani;
(4) Feeding Brahmins and giving them presents in cash.
Remedial measures for male issue as a result of malevolence
of grahas at birth

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P356_B001_01

- 身份：正文
- PDF 页：356
- 偈颂：109-111
- 标题路径：CHAPTER 83 Effects of curses in the previous birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of curses in the previous birth · Sloka 109-111 [present] · PDF page 356

109-111. If a person is deprived of a male issue as a result
of malevolence of grahas at birth, he will be blessed with a
son if he undertakes the following remedial measures:
(1) worshipping lord Shiva if the harm is as a result of the
malevolence of Buddh and Shukr;
(2) reciting of Santan Gopal mantra, wearing and worshipping
appropriate yantra and taking suitable medicines, if the
childlessness is a result of the malevolence of Guru and
Chandr;
(3) Kanya dana if the childlessness is due to malevolence of
Rahu;
(4) worshipping of lord Vishnu if it is due to malevolence of
Surya;
(5) Rudriya Japa if it is due to the malevolence of Mangal
and Shani;
Listening with devotion to Haribansh Puran removes all kinds
of blemishes and blesses the person concerned with a son.
