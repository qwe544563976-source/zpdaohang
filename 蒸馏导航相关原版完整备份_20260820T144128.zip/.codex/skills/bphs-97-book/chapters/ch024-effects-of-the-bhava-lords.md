# 第 24 章：Effects of the Bhava Lords

- 来源：BPHS 97 章版
- 原始卡片：142 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P060_B002_01

- 身份：正文
- PDF 页：60
- 偈颂：1
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 1 [present] · PDF page 60

1. Effects of Lagn's Lord in  Various Bhavas (up to sloka
12): Should Lagn's lord be in Lagn itself, the native will
be endowed with physical happiness (i.e. good health) and
prowess. He will be intelligent, fickle-minded, will have
two wives and will unite with  other females.
~L1I2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P060_B003_01

- 身份：正文
- PDF 页：60
- 偈颂：2
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 2 [present] · PDF page 60

2. If the Lagn's lord is in Dhan, he will be gainful,
scholarly, happy, endowed with good qualities, be
religious, honourable, and will have many wives.
~L1I3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P060_B004_01

- 身份：正文
- PDF 页：60
- 偈颂：3
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 3 [present] · PDF page 60

3. If Lagn's lord is in Sahaj Bhava, the native will equal
a lion in valour, be endowed with all kinds of wealth, be
honorable, will have two wives, be intelligent, and happy.
~L1I4~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P060_B005_01

- 身份：正文
- PDF 页：60
- 偈颂：4
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 4 [present] · PDF page 60

4. If Lagn's lord is in Bandhu Bhava, the native will be
endowed with paternal and maternal happiness, will have
many brothers, be lustful, virtuous and charming.
~L1I5~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P060_B006_01

- 身份：正文
- PDF 页：60
- 偈颂：5
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 5 [present] · PDF page 60

5. If Lagn's lord is in Putr Bhava, the native will have
mediocre progenic happiness, will lose his first child, be
honourable, given to anger, and be dear to king.
~L1I6*L1rm~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P060_B007_01

- 身份：正文
- PDF 页：60
- 偈颂：6
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 6 [present] · PDF page 60

6. If Lagn's lord is in Ari Bhava and related to a malefic
the native will be devoid of physical happiness, and will
be troubled by enemies if there is no benefic drishti.
~L1I7*L1im~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P060_B008_01

- 身份：正文
- PDF 页：60
- 偈颂：7
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 7 [present] · PDF page 60

7. If Lagn's lord is a malefic and is placed in
Yuvati Bhava, the natives wife will not live (long).
~L1I7*L1iB~n
If the grah in question is a benefic, one will wander
aimlessly, face penury and be dejected. He will
alternatively become a king (if the said grah is strong).
~L1I8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P060_B009_01

- 身份：正文
- PDF 页：60
- 偈颂：8
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 8 [present] · PDF page 60

8. If Lagn's lord is in Randhr Bhava, the native will be an
accomplished scholar, be sickly, thievish, be given to much
anger, be a gambler, and will join others' wives.
~L1I9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P060_B010_01

- 身份：正文
- PDF 页：60
- 偈颂：9
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 9 [present] · PDF page 60

9. If Lagn's lord is in Dharm Bhava, the native will be
fortunate, dear to people, be a devotee of Shri Vishnu, be
skilful, eloquent in speech, and be endowed with wife,
sons, and wealth.
~L1I10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P060_B011_01

- 身份：正文
- PDF 页：60
- 偈颂：10
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 10 [present] · PDF page 60

10. If Lagn's lord is in Karm Bhava, the native will be
endowed with paternal happiness, royal honour (or
patronage), fame among men and will doubtlessly have
self-earned wealth.
~L1I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P061_B001_01

- 身份：正文
- PDF 页：61
- 偈颂：11
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 11 [present] · PDF page 61

11. If Lagn's lord is in Labh Bhava, the native will always
be endowed with gains, good qualities, fame, and many
wives.
~L1I12*-L1YB+L1I12*-L1DB~n
If Lagn's lord is in Vyaya Bhava and is devoid of benefic
drishti and / or yuti the native will be bereft of physical
happiness, will spend unfruitfully and be given to much
anger.
~L2I1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P061_B002_01

- 身份：正文
- PDF 页：61
- 偈颂：13
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 13 [present] · PDF page 61

13. Effects of Dhan's Lord in Various Bhavas (up to sloka
24): If Dhan's lord is in Tanu Bhava, the native will be
endowed with sons and wealth, be inimical to his family,
lustful, hard-hearted, and will do others' jobs.
~L2I2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P061_B003_01

- 身份：正文
- PDF 页：61
- 偈颂：14
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 14 [present] · PDF page 61

14. If Dhan's lord is in Dhan Bhava, the native will be
wealthy, proud, will have two or more wives and be bereft
of progeny.
~L2I3~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P061_B004_01

- 身份：正文
- PDF 页：61
- 偈颂：15
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 15 [present] · PDF page 61

15. If Dhan's lord is in Sahaj Bhava, the native will be
valorous, wise, virtuous, lustful, and miserly; all these
when related to a benefic. If related to a malefic, the
native will be a heterodox.
~L2I4~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P061_B005_01

- 身份：正文
- PDF 页：61
- 偈颂：16
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 16 [present] · PDF page 61

16. If Dhan's lord is in Bandhu Bhava, the native will
acquire all kinds of wealth.
~L2I4*L2E*L2Y5~
If Dhan's lord is exalted and is yuti with Guru one will be
equal to a king.
~L2I5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P061_B006_01

- 身份：正文
- PDF 页：61
- 偈颂：17
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 17 [present] · PDF page 61

17. If Dhan's lord is in Putr Bhava the native will be
wealthy. Not only the native, but also his sons, will be
intent on earning wealth.
~L2I6*L2YB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P061_B007_01

- 身份：正文
- PDF 页：61
- 偈颂：18
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 18 [present] · PDF page 61

18. If Dhan's lord is in Ari Bhava along with a benefic the
native will gain wealth through his enemies;
~L2I6*L2Ym~
if Dhan's lord is yuti with a malefic, there will be loss
through enemies apart from mutilation of shanks.
~L2I7~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P061_B008_01

- 身份：正文
- PDF 页：61
- 偈颂：19
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 19 [present] · PDF page 61

19. If Dhan's lord is in Yuvati Bhava, the native will be
addicted to others' wives; and he will be a doctor.
~L2I7*L2Ym+L2I7*L2Dm~
If a malefic is related to the said placement by yuti with
Dhan's lord or by drishti, the native's wife will (also) be
of questionable character.
~L2I8~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P061_B009_01

- 身份：正文
- PDF 页：61
- 偈颂：20
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 20 [present] · PDF page 61

20. If Dhan's lord is in Randhr Bhava, the native will be
endowed with abundant land and wealth. But he will have
limited marital felicity and be bereft of happiness from
his elder brother.
~L2I9~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P062_B001_01

- 身份：正文
- PDF 页：62
- 偈颂：21
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 21 [present] · PDF page 62

21. If Dhan's lord is in Dharm Bhava, the native will be
wealthy, diligent, skilful, sick during childhood, and will
later on be happy (i.e. healthy), and will visit shrines,
observing religious code, etc..
~L2I10~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P062_B002_01

- 身份：正文
- PDF 页：62
- 偈颂：22
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 22 [present] · PDF page 62

22. If Dhan's lord is in Karm Bhava, the native will be
libidinous, honourable, and learned; he will have many
wives and much wealth, but he will be bereft of filial
happiness.
~L2I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P062_B003_01

- 身份：正文
- PDF 页：62
- 偈颂：23
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 23 [present] · PDF page 62

23. If Dhan's lord is in Labh Bhava, the native will have
all kinds of wealth, be ever diligent, honourable, and
famous.
~L2I12~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P062_B004_01

- 身份：正文
- PDF 页：62
- 偈颂：24
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 24 [present] · PDF page 62

24. If Dhan's lord is in Vyaya Bhava, the native will be
adventurous, be devoid of wealth, and be interested in
other's wealth, while his eldest child will not keep him
happy.
~L3I1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P062_B005_01

- 身份：正文
- PDF 页：62
- 偈颂：25
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 25 [present] · PDF page 62

25. Effects of Sahaj's Lord in Various Bhavas (up to sloka
36): If Sahaj's lord is in Tanu Bhava, the native will have
self-made wealth, be disposed to worship, be valorous, and
be intelligent, although devoid of learning.
~L3I2~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P062_B006_01

- 身份：正文
- PDF 页：62
- 偈颂：26
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 26 [present] · PDF page 62

26. If Sahaj's lord is in Dhan Bhava, the native will be
corpulent, devoid of valour, will not make much efforts, be
not happy, and will have an eye on others' wives and
others' wealth.
~L3I3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P062_B007_01

- 身份：正文
- PDF 页：62
- 偈颂：27
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 27 [present] · PDF page 62

27. If Sahaj's lord is in Sahaj Bhava, the native will be
endowed with happiness through co-born and will have wealth
and sons, be cheerful, and extremely happy.
~L3I4~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P062_B008_01

- 身份：正文
- PDF 页：62
- 偈颂：28
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 28 [present] · PDF page 62

28. If Sahaj's lord is in Bandhu Bhava, the native will be
happy, wealthy and intelligent, but will acquire a wicked
spouse.
~L3I5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P062_B009_01

- 身份：正文
- PDF 页：62
- 偈颂：29
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 29 [present] · PDF page 62

29. If Sahaj's lord is in Putr Bhava, the native will have
sons, and be virtuous.
~L3I5*L3Ym+L3I5*L3Dm~m
If in the process Sahaj's lord be yuti with or receives a
drishti from a malefic, the native will have a formidable
wife.
~L3I6~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P062_B010_01

- 身份：正文
- PDF 页：62
- 偈颂：30
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 30 [present] · PDF page 62

30. If Sahaj's lord is in Ari Bhava, the native will be
inimical to his co-born, be affluent, will not be
well-disposed to his maternal uncle and be dear to his
maternal aunt.
~L3I7~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P063_B001_01

- 身份：正文
- PDF 页：63
- 偈颂：31
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 31 [present] · PDF page 63

31. If Sahaj's lord is in Yuvati Bhava, the native will be
interested in serving the king. He will not be happy during
boyhood, but the end of his life he will be happy.
~L3I8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P063_B002_01

- 身份：正文
- PDF 页：63
- 偈颂：32
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 32 [present] · PDF page 63

32. If Sahaj's lord is in Randhr Bhava, the native will be
a thief, will derive his livelihood serving others, and
will die at the gate of the royal palace.
~L3I9~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P063_B003_01

- 身份：正文
- PDF 页：63
- 偈颂：33
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 33 [present] · PDF page 63

33. If Sahaj's lord is in Dharm Bhava, the native will lack
paternal bliss, will make fortunes through wife, and will
enjoy progenic and other pleasures.
~L3I10~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P063_B004_01

- 身份：正文
- PDF 页：63
- 偈颂：34
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 34 [present] · PDF page 63

34. If Sahaj's lord is in Karm Bhava, the native will have
all lands of happiness and self-made wealth, and be
interested in nurturing wicked females.
~L3I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P063_B005_01

- 身份：正文
- PDF 页：63
- 偈颂：35
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 35 [present] · PDF page 63

35. If Sahaj's lord is in Labh Bhava, then native will
always gain in trading, be intelligent although not
literate, be adventurous, and will serve others.
~L3I12~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P063_B006_01

- 身份：正文
- PDF 页：63
- 偈颂：36
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 36 [present] · PDF page 63

36. If Sahaj's lord is in Vyaya, the native will spend on
evil deeds, will have a wicked father and will be fortunate
through a female (or wife).
~L4I1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P063_B007_01

- 身份：正文
- PDF 页：63
- 偈颂：37
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 37 [present] · PDF page 63

37. Effects of Bandhu's Lord in Various Bhavas (up to sloka
48): If Bandhu's lord is in Tanu Bhava, the native will be
endowed with learning, virtues, ornaments, lands,
conveyances, and maternal happiness.
~L4I2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P063_B008_01

- 身份：正文
- PDF 页：63
- 偈颂：38
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 38 [present] · PDF page 63

38. If Bandhu's lord is in Dhan Bhava, the native will
enjoy pleasures, all kinds of wealth, family life and
honour, and be adventurous. He will be cunning in
disposition.
~L4I3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P063_B009_01

- 身份：正文
- PDF 页：63
- 偈颂：39
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 39 [present] · PDF page 63

39. If Bandhu's lord is in Sahaj Bhava, the native will be
valorous, will have servants, be liberal, virtuous and
charitable, and will possess self-earned wealth. He will be
free from diseases.
~L4I4~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P063_B010_01

- 身份：正文
- PDF 页：63
- 偈颂：40
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 40 [present] · PDF page 63

40. If Bandhu's lord is in Bandhu, the native will be a
minister and will possess all kinds of wealth. He will be
skilful, virtuous, honourable, learned, happy and be well
disposed to his spouse.
~L4I5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P063_B011_01

- 身份：正文
- PDF 页：63
- 偈颂：41
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 41 [present] · PDF page 63

41. If Bandhu's lord is in Putr Bhava, the native will be
happy and be liked by all. He will be devoted to Shri
Vishnu, be virtuous, honourable, and will have self-earned
wealth.
~L4I6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P064_B001_01

- 身份：正文
- PDF 页：64
- 偈颂：42
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 42 [present] · PDF page 64

42. If Bandhu's lord is in Ari Bhava, the native will be
devoid of maternal happiness, be given to anger, be a thief
and a conjurer (or magician), be independent in action and
be indisposed.
~L4I7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P064_B002_01

- 身份：正文
- PDF 页：64
- 偈颂：43
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 43 [present] · PDF page 64

43. If Bandhu's lord is in Yuvati Bhava, the native will be
endowed with a high degree of education, will sacrifice his
patrimony and be akin to the dumb in an assembly.
~L4I8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P064_B003_01

- 身份：正文
- PDF 页：64
- 偈颂：44
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 44 [present] · PDF page 64

44. If Bandhu's lord is in Randhr Bhava, the native will be
devoid of domestic and other comforts, will not enjoy much
parental happiness and be equal to a neuter.
~L4I9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P064_B004_01

- 身份：正文
- PDF 页：64
- 偈颂：45
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 45 [present] · PDF page 64

45. If Bandhu's lord is in Dharm Bhava, the native will be
dear to one and all, be devoted to God, be virtuous,
honourable, and endowed with every land of happiness.
~L4I10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P064_B005_01

- 身份：正文
- PDF 页：64
- 偈颂：46
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 46 [present] · PDF page 64

46. If Bandhu's lord is in Karm Bhava, the native will
enjoy royal honours, be an alchemist, be extremely pleased,
will enjoy pleasures and will conquer his five senses.
~L4I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P064_B006_01

- 身份：正文
- PDF 页：64
- 偈颂：47
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 47 [present] · PDF page 64

47. If Bandhu's lord is in Labh Bhava, the native will have
fear of secret disease; he will be liberal, virtuous,
charitable, and helpful to others.
~L4I12~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P064_B007_01

- 身份：正文
- PDF 页：64
- 偈颂：48
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 48 [present] · PDF page 64

48. If Bandhu's lord is in Vyaya Bhava the native will be
devoid of domestic and other comforts, will have vices and
be foolish and indolent.
~L5I1~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P064_B008_01

- 身份：正文
- PDF 页：64
- 偈颂：49
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 49 [present] · PDF page 64

49. Effects of Putr's Lord in Various Bhavas (up to sloka
60): If Putr's lord is in Lagn, the native will be
scholarly, be endowed with progenic happiness, be a miser,
be crooked, and will steal others' wealth.
~L5I2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P064_B009_01

- 身份：正文
- PDF 页：64
- 偈颂：50
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 50 [present] · PDF page 64

50. If Putr's lord is in Dhan Bhava, the native will have
many sons and wealth, be a pater familiaris, be honourable,
be attached to his spouse, and be famous in the world.
~L5I3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P064_B010_01

- 身份：正文
- PDF 页：64
- 偈颂：51
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 51 [present] · PDF page 64

51. If Putr's lord is in Sahaj, the native will be attached
to his co-born, be a tale bearer and a miser, and be always
interested in his own work.
~L5I4~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P064_B011_01

- 身份：正文
- PDF 页：64
- 偈颂：52
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 52 [present] · PDF page 64

52. If Putr's lord is in Bandhu Bhava, the native will be
happy, endowed with maternal happiness, wealth and
intelligence, and be a king or a minister or a preceptor.
~L5I5*L5rB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P065_B001_01

- 身份：正文
- PDF 页：65
- 偈颂：53
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 53 [present] · PDF page 65

53. If Putr's lord is in Putr Bhava, the native will have
progeny if related to a benefic;
~L5I5*L5rm~n
there will be no issues if malefic is related to Putr's
lord placed in Putr Bhava.
~L5I5~
Putr's lord in Putr Bhava will, however, make one virtuous
and dear to friends.
~L5I6~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P065_B002_01

- 身份：正文
- PDF 页：65
- 偈颂：54
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 54 [present] · PDF page 65

54. If Putr's lord is in Ari Bhava, the native will obtain
such sons who will be equal to his enemies, or will lose
them, or will acquire an adopted or purchased son.
~L5I7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P065_B003_01

- 身份：正文
- PDF 页：65
- 偈颂：55
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 55 [present] · PDF page 65

55. If Putr's lord is in Yuvati Bhava, the native will be
honourable, very religious, endowed with progenic
happiness, and be helpful to others.
~L5I8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P065_B004_01

- 身份：正文
- PDF 页：65
- 偈颂：56
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 56 [present] · PDF page 65

56. If Putr's lord is in Randhr Bhava, the native will not
have much progenic happiness, be troubled by cough and
pulmonary disorders, be given to anger and be devoid of
happiness.
~L5I9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P065_B005_01

- 身份：正文
- PDF 页：65
- 偈颂：57
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 57 [present] · PDF page 65

57. If Putr's lord is in Dharm Bhava, the native will be a
prince or equal to him, will author treatises, be famous,
and will shine in his race.
~L5I10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P065_B006_01

- 身份：正文
- PDF 页：65
- 偈颂：58
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 58 [present] · PDF page 65

58. If Putr's lord is in Karm Bhava, the native will enjoy
a Raj Yog and various pleasures, and be very famous.
~L5I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P065_B007_01

- 身份：正文
- PDF 页：65
- 偈颂：59
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 59 [present] · PDF page 65

59. If Putr's lord is in Labh Bhava, the native will be
learned, dear to people, be an author of treatises, be very
skilful, and be endowed with many sons and wealth.
~L5I12~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P065_B008_01

- 身份：正文
- PDF 页：65
- 偈颂：60
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 60 [present] · PDF page 65

60. If Putr's lord is in Vyaya Bhava, the native will be
bereft of happiness from his own sons, will have an adopted
or purchased son.
~L6I1~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P065_B009_01

- 身份：正文
- PDF 页：65
- 偈颂：61
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 61 [present] · PDF page 65

61. Effects of Ari's Lord in Various Bhavas (up to sloka
72): If Ari's lord is in Tanu Bhava, the native will be
sickly, famous, inimical to his own men, rich, honourable,
adventurous, and virtuous.
~L6I2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P065_B010_01

- 身份：正文
- PDF 页：65
- 偈颂：62
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 62 [present] · PDF page 65

62. If Ari's lord is in Dhan Bhava, the native will be
adventurous, famous among his people, will live in alien
countries (or places), be happy, be a skilful speaker ,and
be always interested in his own work.
~L6I3~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P065_B011_01

- 身份：正文
- PDF 页：65
- 偈颂：63
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 63 [present] · PDF page 65

63. If Ari's lord is in Sahaj Bhava, the native will be
given to anger, be bereft of courage, inimical to all of
his co-born, and will have disobedient servants.
~L6I4~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P066_B001_01

- 身份：正文
- PDF 页：66
- 偈颂：64
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 64 [present] · PDF page 66

64. If Ari's lord is in Bandhu Bhava, the native will be
devoid maternal happiness, be intelligent, be a tale
bearer, be jealous, evil-minded, and very rich.
~L6I5~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P066_B002_01

- 身份：正文
- PDF 页：66
- 偈颂：65
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 65 [present] · PDF page 66

65. If Ari's lord is in Putr Bhava, the native will have
fluctuating finances. He will incur enmity with his sons
and friends. He will be happy, selfish, and kind.
~L6I6~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P066_B003_01

- 身份：正文
- PDF 页：66
- 偈颂：66
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 66 [present] · PDF page 66

66. If Ari's lord is in Ari Bhava, the native will have
enmity with the group of his kinsmen, but be friendly to
others and will enjoy mediocre happiness in matters like
wealth.
~L6I7~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P066_B004_01

- 身份：正文
- PDF 页：66
- 偈颂：67
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 67 [present] · PDF page 66

67. If Ari's lord is in Yuvati Bhava, the native will be
deprived of happiness through wedlock. He will be famous,
virtuous, honourable, adventurous, and wealthy.
~L6I8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P066_B005_01

- 身份：正文
- PDF 页：66
- 偈颂：68
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 68 [present] · PDF page 66

68. If Ari's lord is in Randhr Bhava, the native will be
sickly, inimical, will desire others' wealth, be interested
in others' wives, and be impure (or degraded).
~L6I9~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P066_B006_01

- 身份：正文
- PDF 页：66
- 偈颂：69
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 69 [present] · PDF page 66

69. If Ari's lord is in Dharm Bhava, the native will trade
in wood and stones ('Pashan' also means poison), and will
have fluctuating professional fortunes.
~L6I10~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P066_B007_01

- 身份：正文
- PDF 页：66
- 偈颂：70
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 70 [present] · PDF page 66

70. If Ari's lord is in Karm Bhava, the native will be well
known among his men, will not be respectfully disposed to
his father and will be happy in foreign countries. He will
be a gifted speaker.
~L6I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P066_B008_01

- 身份：正文
- PDF 页：66
- 偈颂：71
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 71 [present] · PDF page 66

71. If Ari's lord is in Labh Bhava, the native will gain
wealth through his enemies, be virtuous, adventurous, and
will be somewhat bereft of progenic happiness.
~L6I12~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P066_B009_01

- 身份：正文
- PDF 页：66
- 偈颂：72
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 72 [present] · PDF page 66

72. If Ari's lord is in Vyaya Bhava the native will always
spend on vices, be hostile to learned people and will
torture living beings.
~L7I1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P066_B010_01

- 身份：正文
- PDF 页：66
- 偈颂：73
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 73 [present] · PDF page 66

73. Effects of Yuvati's Lord in Various Bhavas (up to sloka
84): If Yuvati's lord is in Tanu Bhava, the native will go
to others' wives, be wicked, skilful, devoid of courage,
and afflicted by windy diseases.
~L7I2~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P066_B011_01

- 身份：正文
- PDF 页：66
- 偈颂：74
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 74 [present] · PDF page 66

74. If Yuvati's lord is in Dhan Bhava, the native will have
many wives, will gain wealth through his wife and be
procrastinating in nature.
~L7I3~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P067_B001_01

- 身份：正文
- PDF 页：67
- 偈颂：75
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 75 [present] · PDF page 67

75. If Yuvati's lord is in Sahaj Bhava, the native will
face loss of children and sometimes, with great difficulty,
there will exist a living son. There is also the
possibility of birth of a daughter (who will sustain).
~L7I4~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P067_B002_01

- 身份：正文
- PDF 页：67
- 偈颂：76
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 76 [present] · PDF page 67

76. If Yuvati's lord is in Bandhu Bhava, the wife of the
native will not be under his control. He will be fond of
truth, intelligent, and religious. He will suffer from
dental diseases.
~L7I5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P067_B003_01

- 身份：正文
- PDF 页：67
- 偈颂：77
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 77 [present] · PDF page 67

77. If Yuvati's lord is in Putr Bhava, the native will be
honourable, endowed with all (i.e. seven principal)
virtues, always delighted, and endowed with all kinds of
wealth.
~L7I6~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P067_B004_01

- 身份：正文
- PDF 页：67
- 偈颂：78
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 78 [present] · PDF page 67

78. If Yuvati's lord is in Ari Bhava, the native will beget
a sickly wife and he will be inimical to her. He will be
given to anger and will be devoid of happiness.
~L7I7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P067_B005_01

- 身份：正文
- PDF 页：67
- 偈颂：79
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 79 [present] · PDF page 67

79. If Yuvati's lord is in Yuvati Bhava, the native will be
endowed with happiness through wife, be courageous,
skilful, and intelligent, but only afflicted by windy
diseases.
~L7I8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P067_B006_01

- 身份：正文
- PDF 页：67
- 偈颂：80
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 80 [present] · PDF page 67

80. If Yuvati's lord is in Randhr Bhava, the native will be
deprived of marital happiness. His wife will be troubled by
diseases, be devoid of good disposition and will not obey
the native.
~L7I9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P067_B007_01

- 身份：正文
- PDF 页：67
- 偈颂：81
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 81 [present] · PDF page 67

81. If Yuvati's lord is in Dharm Bhava, the native will
have union with many women, be well-disposed to his own
wife and will have many undertakings (or assignments).
~L7I10~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P067_B008_01

- 身份：正文
- PDF 页：67
- 偈颂：82
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 82 [present] · PDF page 67

82. If Yuvati's lord is in Karm Bhava, the native will
beget a disobedient wife, will be religious and endowed
with wealth, sons, etc..
~L7I11~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P067_B009_01

- 身份：正文
- PDF 页：67
- 偈颂：83
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 83 [present] · PDF page 67

83. If Yuvati's lord is in Labh Bhava, the native will gain
wealth through his wife, be endowed with less happiness
from sons, etc., and will have daughters.
~L7I12~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P067_B010_01

- 身份：正文
- PDF 页：67
- 偈颂：84
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 84 [present] · PDF page 67

84. If Yuvati's lord is in Vyaya Bhava, the native will
incur penury, be a miser, and his livelihood will be
related to clothes. His wife will be a spend thrift.
~L8I1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P067_B011_01

- 身份：正文
- PDF 页：67
- 偈颂：85
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 85 [present] · PDF page 67

85. Effects of Randhr's Lord in Various Bhavas (up to sloka
96): If Randhr's lord is in Tanu Bhava. the native will be
devoid of physical felicity and will suffer from wounds. He
will be hostile to gods and brahmins (or religious
people).
~L8I2~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P068_B001_01

- 身份：正文
- PDF 页：68
- 偈颂：86
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 86 [present] · PDF page 68

86. If Randhr's lord is in Dhan Bhava, the native will be
devoid of bodily vigour, will enjoy a little wealth, and
will not regain lost wealth.
~L8I3~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P068_B002_01

- 身份：正文
- PDF 页：68
- 偈颂：87
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 87 [present] · PDF page 68

87. If Randhr's lord is in Sahaj Bhava, the native will be
devoid of fraternal happiness, be indolent, and devoid of
servants and strength.
~L8I4~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P068_B003_01

- 身份：正文
- PDF 页：68
- 偈颂：88
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 88 [present] · PDF page 68

88. If Randhr's lord is in Bandhu Bhava, the child will be
deprived of its mother. He will be devoid of a house,
lands, and happiness and will doubtlessly betray his
friends.
~L8I5~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P068_B004_01

- 身份：正文
- PDF 页：68
- 偈颂：89
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 89 [present] · PDF page 68

89. If Randhr's lord is in Putr Bhava, the native will be
dull witted, will have limited number of children, be
long-lived, and wealthy.
~L8I6~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P068_B005_01

- 身份：正文
- PDF 页：68
- 偈颂：90
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 90 [present] · PDF page 68

90. If Randhr's lord is in Ari Bhava, the native will win
over his enemies, be afflicted by diseases and during
childhood will incur danger through snakes and water.
~L8I7~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P068_B006_01

- 身份：正文
- PDF 页：68
- 偈颂：91
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 91 [present] · PDF page 68

91. If Randhr's lord is in Yuvati Bhava, the native will
have two wives. If Randhr's lord is yuti with a malefic in
Yuvati Bhava there will surely be downfall in his business
(or livelihood).
~L8I8~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P068_B007_01

- 身份：正文
- PDF 页：68
- 偈颂：92
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 92 [present] · PDF page 68

92. If Randhr's lord is in Randhr Bhava, the native will be
long-lived. If the said grah is weak being in Randhr Bhava,
the longevity will be medium, while the native will be a
thief, be blame worthy and will blame others as well.
~L8I9~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P068_B008_01

- 身份：正文
- PDF 页：68
- 偈颂：93
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 93 [present] · PDF page 68

93. If Randhr's lord is in Dharm Bhava, the native will
betray his religion, be a heterodox, will beget a wicked
wife, and will steal others' wealth.
~L8I10~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P068_B009_01

- 身份：正文
- PDF 页：68
- 偈颂：94
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 94 [present] · PDF page 68

94. If Randhr's lord is in Karm Bhava the native will be
devoid of paternal bliss, be a tale-bearer and be bereft of
livelihood. If there is a drishti in the process from a
benefic, then these evils will not mature.
~L8I11*L8Ym~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P068_B010_01

- 身份：正文
- PDF 页：68
- 偈颂：95
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 95 [present] · PDF page 68

95. If Randhr's lord along with a malefic is in Labh Bhava,
the native will be devoid of wealth and will be miserable
in boyhood but happy later on.
~L8I11*L8YB~
Should Randhr's lord be yuti with with a benefic and be in
Labh Bhava, the native will be long-lived.
~L8I12~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P068_B011_01

- 身份：正文
- PDF 页：68
- 偈颂：96
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 96 [present] · PDF page 68

96. If Randhr's lord is in Vyaya Bhava, the native will
spend on evil deeds and will incur a short life. More so,
if there be additionally a malefic in the said bhava.
~L9I1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P069_B001_01

- 身份：正文
- PDF 页：69
- 偈颂：97
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 97 [present] · PDF page 69

97. Effects of Dharm's Lord in Various Bhavas (up to sloka
103): If Dharm's lord is in Lagn, the native will be
fortunate (or prosperous), will be honoured by the king, be
virtuous, charming, learned, and honoured by the public.
~L9I2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P069_B002_01

- 身份：正文
- PDF 页：69
- 偈颂：98
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 98 [present] · PDF page 69

98. If Dharm's lord is in Dhan Bhava,the native will be a
scholar, be dear to all, wealthy, sensuous, and endowed
with happiness from wife, sons, etc..
~L9I3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P069_B003_01

- 身份：正文
- PDF 页：69
- 偈颂：99
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 99 [present] · PDF page 69

99. If Dharm's lord is in Sahaj Bhava, the native will be
endowed with fraternal bliss, be wealthy, virtuous, and
charming.
~L9I4~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P069_B004_01

- 身份：正文
- PDF 页：69
- 偈颂：100
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 100 [present] · PDF page 69

100. If Dharm's lord is in Bandhu Bhava, the native will
enjoy houses, conveyances, and happiness, will have all
kinds of wealth and be devoted to his mother.
~L9I5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P069_B005_01

- 身份：正文
- PDF 页：69
- 偈颂：101
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 101 [present] · PDF page 69

101. If Dharm's lord is in Putr Bhava the native will be
endowed with sons and prosperity, devoted to elders, bold,
charitable, and learned.
~L9I6~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P069_B006_01

- 身份：正文
- PDF 页：69
- 偈颂：102
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 102 [present] · PDF page 69

102. If Dharm's lord is in Ari Bhava, the native will enjoy
meagre prosperity, be devoid of happiness from maternal
relatives, and be always troubled by enemies.
~L9I7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P069_B007_01

- 身份：正文
- PDF 页：69
- 偈颂：103
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 103 [present] · PDF page 69

103. 0 Brahmin, If Dharm's lord is in Yuvati Bhava, the
native beget happiness after marriage, be virtuous, and
famous.
~L9I8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P069_B008_01

- 身份：正文
- PDF 页：69
- 偈颂：104
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 104 [present] · PDF page 69

104. If Dharm's lord is in Randhr Bhava, the native will
not be prosperous and will not enjoy happiness from his
elder brother.
~L9I9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P069_B009_01

- 身份：正文
- PDF 页：69
- 偈颂：105
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 105 [present] · PDF page 69

105. If Dharm's lord is in Dharm Bhava, the native will be
endowed with abundant fortunes, virtues, and beauty, and
will enjoy much happiness from co-born.
~L9I10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P069_B010_01

- 身份：正文
- PDF 页：69
- 偈颂：106
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 106 [present] · PDF page 69

106. If Dharm's lord is in Karm Bhava, the native will be a
king or equal to him or be a minister or an army chief, be
virtuous and dear to all.
~L9I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P069_B011_01

- 身份：正文
- PDF 页：69
- 偈颂：107
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 107 [present] · PDF page 69

107. If Dharm's lord is in Labh Bhava, the native will
enjoy financial gains day by day, be devoted to elders,
virtuous, and meritorious in acts.
~L9I12~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P069_B012_01

- 身份：正文
- PDF 页：69
- 偈颂：108
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 108 [present] · PDF page 69

108. If Dharm's lord is in Vyaya Bhava, the native will
incur loss of fortunes, will always spend on auspicious
acts, and will become poor on account of entertaining
guests.
~L10I1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P070_B001_01

- 身份：正文
- PDF 页：70
- 偈颂：109
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 109 [present] · PDF page 70

109. Effects of Karm's Lord in Various Bhavas (up to sloka
120): If Karm's lord is in Tanu Bhava, the native will be
scholarly, famous, be a poet, will incur diseases in
boyhood, and be happy later on. His wealth will increase
day by day.
~L10I2~
110 If Karm's lord is in Dhan Bhava, the native will be
wealthy, virtuous, honoured by the king, charitable, and
will enjoy happiness from father and others.
~L10I3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P070_B002_01

- 身份：正文
- PDF 页：70
- 偈颂：111
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 111 [present] · PDF page 70

111. If Karm's lord is in Sahaj Bhava, the native will
enjoy happiness from brothers and servants, be valorous,
virtuous, eloquent, and truthful.
~L10I4~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P070_B003_01

- 身份：正文
- PDF 页：70
- 偈颂：112
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 112 [present] · PDF page 70

112. If Karm's lord is in Bandhu Bhava, the native will be
happy, be always interested in his mother's welfare, will
lord over conveyances, lands and houses, be virtuous, and
wealthy.
~L10I5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P070_B004_01

- 身份：正文
- PDF 页：70
- 偈颂：113
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 113 [present] · PDF page 70

113. If Karm's lord is in Putr Bhava, the native will be
endowed with all kinds of learning; he will be always
delighted, and he will be wealthy and endowed with sons.
~L10I6~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P070_B005_01

- 身份：正文
- PDF 页：70
- 偈颂：114
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 114 [present] · PDF page 70

114. If Karm's lord is in Ari Bhava, the native will be
bereft of paternal bliss. Although he may be skilful he
will be bereft of wealth and be troubled by enemies.
~L10I7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P070_B006_01

- 身份：正文
- PDF 页：70
- 偈颂：115
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 115 [present] · PDF page 70

115. If Karm's lord is in Yuvati Bhava, the native will be
endowed with happiness through wife, be intelligent,
virtuous, eloquent, truthful, and religious.
~L10I8~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P070_B007_01

- 身份：正文
- PDF 页：70
- 偈颂：116
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 116 [present] · PDF page 70

116. If Karm's lord is in Randhr Bhava, the native will be
devoid of (good) acts, long-lived and intent on blaming
others.
~L10I9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P070_B008_01

- 身份：正文
- PDF 页：70
- 偈颂：117
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 117 [present] · PDF page 70

117. If Karm's lord is in Dharm Bhava, one born of royal
scion will become a king whereas an ordinary native will be
equal to a king. This placement will confer wealth and
progenic happiness, etc..
~L10I10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P070_B009_01

- 身份：正文
- PDF 页：70
- 偈颂：118
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 118 [present] · PDF page 70

118. If Karm's lord is in Karm Bhava, the native will be
skilful in all jobs, be valorous, truthful, and devoted to
elders.
~L10I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P070_B010_01

- 身份：正文
- PDF 页：70
- 偈颂：119
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 119 [present] · PDF page 70

119. If Karm's lord is in Labh Bhava, the native will be
endowed with wealth, happiness, and sons. He will be
virtuous, truthful, and always delighted.
~L10I12~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P071_B001_01

- 身份：正文
- PDF 页：71
- 偈颂：120
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 120 [present] · PDF page 71

120. If Karm's lord is in Vyaya Bhava, the native will
spend through royal abodes (i.e. kings), will have fear
from enemies, and will be worried in spite of being
skilful.
~L11I1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P071_B002_01

- 身份：正文
- PDF 页：71
- 偈颂：121
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 121 [present] · PDF page 71

121. Effects of Labh's Lord in Various Bhavas (up to sloka
132): If Labh's lord is in Tanu Bhava, the native will be
genuine in disposition, be rich, happy, even-sighted, be a
poet, be eloquent in speech, and be always endowed with
gains.
~L11I2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P071_B003_01

- 身份：正文
- PDF 页：71
- 偈颂：122
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 122 [present] · PDF page 71

122. If Labh's lord is in Dhan Bhava, the native will be
endowed with all kinds of wealth and all kinds of
accomplishments, charitable, religious, and always happy.
~L11I3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P071_B004_01

- 身份：正文
- PDF 页：71
- 偈颂：123
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 123 [present] · PDF page 71

123. If Labh's lord is in Sahaj Bhava, the native will be
skilful in all jobs, wealthy, endowed with fraternal bliss,
and may sometimes incur gout pains.
~L11I4~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P071_B005_01

- 身份：正文
- PDF 页：71
- 偈颂：12
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 12 [present] · PDF page 71

12. If Labh's lord is in Bandhu Bhava, the native will gain
from maternal relatives, will undertake visits to shrines
and will possess happiness of house and lands.
~L11I5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P071_B006_01

- 身份：正文
- PDF 页：71
- 偈颂：125
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 125 [present] · PDF page 71

125. If Labh's lord is in Putr Bhava, the native will be
happy, educated and virtuous. He will be religious and
happy.
~L11I6~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P071_B007_01

- 身份：正文
- PDF 页：71
- 偈颂：126
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 126 [present] · PDF page 71

126. If Labh's lord is in Ari Bhava, the native will be
afflicted by diseases, be cruel, living in foreign places
and troubled by enemies.
~L11I7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P071_B008_01

- 身份：正文
- PDF 页：71
- 偈颂：127
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 127 [present] · PDF page 71

127. If Labh's lord is in Yuvati Bhava, the native will
always gain through his wife's relatives, be liberal,
virtuous, sensuous, and will remain at the command of his
spouse.
~L11I8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P071_B009_01

- 身份：正文
- PDF 页：71
- 偈颂：128
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 128 [present] · PDF page 71

128. If Labh's lord is in Randhr Bhava, the native will
incur reversals in his undertakings and will live long
while his wife will predecease him.
~L11I9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P071_B010_01

- 身份：正文
- PDF 页：71
- 偈颂：129
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 129 [present] · PDF page 71

129. If Labh's lord is in Dharm Bhava, the native will be
fortunate, skilful, truthful, honoured by the king, and be
affluent.
~L11I10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P071_B011_01

- 身份：正文
- PDF 页：71
- 偈颂：130
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 130 [present] · PDF page 71

130. If Labh's lord is in Karm Bhava, the native will be
honoured by the king, be virtuous, attached to his
religion, intelligent, truthful, and will subdue his
senses.
~L11I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P072_B001_01

- 身份：正文
- PDF 页：72
- 偈颂：131
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 131 [present] · PDF page 72

131. If Labh's lord is in Labh Bhava, the native will gain
in all his undertakings while his learning and happiness
will be on the increase day by day.
~L11I12~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P072_B002_01

- 身份：正文
- PDF 页：72
- 偈颂：132
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 132 [present] · PDF page 72

132. If Labh's lord is in Vyaya Bhava, the native will
always depend on good deeds, be sensuous, will have many
wives and will befriend barbarians (or foreigners in
general).
~L12I1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P072_B003_01

- 身份：正文
- PDF 页：72
- 偈颂：133
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 133 [present] · PDF page 72

133. Effects of Vyaya's Lord in Various Bhavas (up to sloka
144): If Vyaya's lord is in Tanu Bhava, the native will be
a spend thrift, be weak in constitution, will suffer from
phlegmatic disorders, and be devoid of wealth and
learning.
~L12I2~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P072_B004_01

- 身份：正文
- PDF 页：72
- 偈颂：134
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 134 [present] · PDF page 72

134. If Vyaya's lord is in Dhan Bhava, the native will
always spend on inauspicious deeds, be religious, will
speak sweetly, and will be endowed with virtues and
happiness.
~L12I3~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P072_B005_01

- 身份：正文
- PDF 页：72
- 偈颂：135
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 135 [present] · PDF page 72

135. If Vyaya's lord is in Sahaj Bhava, the native will be
devoid of fraternal bliss, will hate others and will
promote self-nourishment (i.e. be quite selfish).
~L12I4~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P072_B006_01

- 身份：正文
- PDF 页：72
- 偈颂：136
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 136 [present] · PDF page 72

136. If Vyaya's lord is in Bandhu Bhava, the native will be
devoid of maternal happiness and will day by day accrue
losses with respect to lands, conveyances, and houses.
~L12I5~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P072_B007_01

- 身份：正文
- PDF 页：72
- 偈颂：137
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 137 [present] · PDF page 72

137. If Vyaya's lord is in Putr Bhava, the native will be
bereft of sons and learning. He will spend as well as visit
shrines in order to beget a son.
~L12I6~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P072_B008_01

- 身份：正文
- PDF 页：72
- 偈颂：138
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 138 [present] · PDF page 72

138. If Vyaya's lord is in Ari Bhava, the native will incur
enmity with his own men, be given to anger, be sinful,
miserable, and will go to others' wives.
~L12I7~n
If Vyaya's lord is in Yuvati Bhava, the native will incur
expenditure on account of his wife, will not enjoy conjugal
bliss, and will be bereft of learning and strength.
~L12I8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P072_B009_01

- 身份：正文
- PDF 页：72
- 偈颂：140
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 140 [present] · PDF page 72

140. If Vyaya's lord is in Randhr Bhava, the native will
always gain, will speak affably, will enjoy a medium span
of life and be endowed with all good qualities.
~L12I9~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P072_B010_01

- 身份：正文
- PDF 页：72
- 偈颂：141
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 141 [present] · PDF page 72

141. If Vyaya's lord is in Dharm Bhava, the native will
dishonour his elders, be inimical even to his friends and
be always intent on achieving his own ends.
~L12I10~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P073_B001_01

- 身份：正文
- PDF 页：73
- 偈颂：142
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 142 [present] · PDF page 73

142. If Vyaya's lord is in Karm Bhava, the native will
incur expenditure through royal persons and will enjoy only
moderate paternal bliss.
~L12I11~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P073_B002_01

- 身份：正文
- PDF 页：73
- 偈颂：143
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 143 [present] · PDF page 73

143. If Vyaya lord is in Labh Bhava, the native will incur
losses, be brought up by others, and will sometimes gain
through others.
~L12I12~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P073_B003_01

- 身份：正文
- PDF 页：73
- 偈颂：144
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 144 [present] · PDF page 73

144. If Vyaya's lord is in Vyaya Bhava, the native will
only face heavy expenditure, will-not have physical
felicity, be irritable and spiteful.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P073_B004_01

- 身份：正文
- PDF 页：73
- 偈颂：145-148
- 标题路径：CHAPTER 24 Effects of the Bhava Lords
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Bhava Lords · Sloka 145-148 [present] · PDF page 73

145-148. Miscellaneous: O Brahmin, those are the effects of
bhava lords which are to be deduced considering their
strengths and weaknesses. In the case of a grah owning two
bhavas, the results are to be deducted based on its two
lordships (for the same placement). If contrary results are
thus indicated, the results will be nullified, while
results of varied nature will come to pass. The grah will
yield full, half, or a quarter of the effects according to
its strength being full, medium, and negligible
respectively. Thus, I have told you about the effects due
to bhava lords in various bhavas.
