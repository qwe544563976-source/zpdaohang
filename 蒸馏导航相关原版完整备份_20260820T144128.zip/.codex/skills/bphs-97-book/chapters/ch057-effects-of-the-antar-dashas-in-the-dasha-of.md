# 第 57 章：Effects of the Antar Dashas in the Dasha of

- 来源：BPHS 97 章版
- 原始卡片：36 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P247_B002_01

- 身份：正文
- PDF 页：247
- 偈颂：—
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka unknown [unknown] · PDF page 247 · page_block BPHS_PL9_CHAP_97_P247_B002

Shani
@7172@
Effects of the Antar Dasha of Shani in the Dasha of Shani
~7O+7E+7K+7T+7y~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P247_B003_01

- 身份：正文
- PDF 页：247
- 偈颂：1-3
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 1-3 [present] · PDF page 247

1-3. Effects like acquisition of a kingdom (attainment of a
high position in government), happiness from wife and
children, acquisition of conveyances like elephants, gain
of clothes, attainment of the position of a commander of
the army by the beneficence of the king, acquisition of
cattle, villages, and land, etc., will be derived in the
Antar Dasha of Shani in the Dasha of Shani, if Shani is in
his own Rashi, in his Exaltation Rashi, or in deep
exaltation, or if Shani is in a Kendr or in a Trikon (from
Lagn), or if Shani is a Yog Karak.
~7I8+7I12+7Am*7d~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P247_B004_01

- 身份：正文
- PDF 页：247
- 偈颂：4-5 1/2
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 4-5 1/2 [present] · PDF page 247

4-5 1/2. Fear or danger from the king (government), getting
inflicted with injuries with some weapon, bleeding gums,
dysentery, etc., will be the evil effects at the
commencement of the Dasha, if Shani is in Randhr, or in
Vyaya Bhava, or if Shani is associated with malefics in his
Debilitation Rashi.
There will be danger from thieves, etc., going away from
the home land, mental agony, etc., in the middle portion of
the Dasha.
The last  part of the Dasha will yield beneficial results.
~7iL2+7iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P247_B005_01

- 身份：正文
- PDF 页：247
- 偈颂：6-7
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 6-7 [present] · PDF page 247

6-7. There will be danger of premature death, if Shani is
Dhan's lord or Yuvati's lord. Lord Shiva will afford
protection and render relief if Mrityunjaya Japa is
performed in the prescribed manner.
@7142@
Effects of the Antar Dasha of Buddh in the Dasha of Shani
~4K+4T~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P247_B006_01

- 身份：正文
- PDF 页：247
- 偈颂：8-11
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 8-11 [present] · PDF page 247

8-11. Effects like reverence from the people, good
reputation, gain of wealth, comforts of conveyances, etc.,
inclination towards performance of religious sacrifices
(Yagya's), Raj Yog, bodily felicity, enthusiasm, well being
in the family, pilgrimage to holy places, performance of
religious rites, listening to Puranas (Vedic scriptures),
charities, availability of sweetish preparations, etc.,
will be derived in the Antar Dasha of Buddh in the Dasha of
Shani, if Buddh is in a Kendr or in a Trikon.
~4I6+4I8+4I12+(4I6)7+(4I8)7+(4I12)7+4A1*4A3*4A8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P247_B007_01

- 身份：正文
- PDF 页：247
- 偈颂：12-13 1/2
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 12-13 1/2 [present] · PDF page 247

12-13 1/2. Acquisition of a kingdom (attainment of a high
position in Government), gain of wealth, headship of a
village will be the effects at the commencement of the
Dasha, if Buddh is in Ari, in Randhr, or in Vyaya Bhava,
from Lagn or the lord of the Dasha (Shani), or if Buddh is
associated with Surya, Mangal, and Rahu.  Affliction with
diseases, failure in all ventures, anxiety and feeling of
danger, etc., will be experienced in the middle portion and
in the last part of the Dasha.
~4iL2+4iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P248_B001_01

- 身份：正文
- PDF 页：248
- 偈颂：14-15
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 14-15 [present] · PDF page 248

14-15. There will be physical distress if Buddh is Dhan's
lord or Yuvati's lord.
The remedial measures to obtain relief from the above evil
effects and to regain enjoyment in life are recitation of
Vishnu Sahasranam and giving grains in charity.
@7192@
Effects of the Antar Dasha of Ketu in the Dasha of Shani
~9E+9O+9Z+9K+9T+9AB+9DB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P248_B002_01

- 身份：正文
- PDF 页：248
- 偈颂：16-18
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 16-18 [present] · PDF page 248

16-18. Evil effects like loss of position, dangers,
poverty, distress, foreign journeys, etc., will be derived
in the Antar Dasha of Ketu in the Dasha of Shani even if
Ketu is in his Exaltation Rashi, in his own Rashi, in a
benefic Rashi, or in a Kendr, or in a Trikon or if Ketu is
associated with or receives a drishti from benefics.
~9rL1~
If Ketu is related to the Lagn's lord, there will be gain
of wealth and enjoyment and bathing in holy places and
visit to a sacred shrine at the commencement of the Antar
Dasha.
~(9I!K)7+(9I!T)7+(9I3)7+(9I11)7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P248_B003_01

- 身份：正文
- PDF 页：248
- 偈颂：19-19 1/2
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 19-19 1/2 [present] · PDF page 248

19-19 1/2. Gain of physical strength and courage, religious
thoughts, audience with the king (high dignitaries of
government like: president, prime minister, governor,
ministers), and all kinds of enjoyments, will be
experienced if Ketu is in a Kendr, in a Trikon, in the 3rd,
or in the 11th from the lord of the Dasha (Shani).
~9I8+9I2+(9I8)7+(9I2)7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P248_B004_01

- 身份：正文
- PDF 页：248
- 偈颂：20-21 1/2
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 20-21 1/2 [present] · PDF page 248

20-21 1/2. Fear of premature death, coarse food, cold
fever, dysentery, wounds, danger from thieves, separation
from wife and children etc., will be the results if Ketu is
in Randhr or in Vyaya Bhava from Lagn or the lord of the
Dasha (Shani).
~9I2+9I7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P248_B005_01

- 身份：正文
- PDF 页：248
- 偈颂：22-23
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 22-23 [present] · PDF page 248

22-23. There will be physical distress, if Ketu is in Dhan
or in Yuvati Bhava.
Remedial measure to obtain relief from the above evil
effects and to regain enjoyments of life by the beneficence
of Ketu is giving a goat in charity.
@7162@
Effects of the Antar Dasha of Shukr in the Dasha of Shani
~6K+6T+6I11**6AB+6DB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P249_B001_01

- 身份：正文
- PDF 页：249
- 偈颂：24-27 1/2
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 24-27 1/2 [present] · PDF page 249

24-27 1/2. Effects like marriage, birth of a son, gain of
wealth, sound health, well being in the family, acquisition
of a kingdom (attainment of high position in government),
enjoyments by the beneficence of the king (government),
honours, gain of clothes, ornaments, conveyance and other
desired objects, will be derived in the Antar Dasha of
Shukr in the Dasha of Shani, if Shukr is in a Kendr, in a
Trikon, or in Labh Bhava associated with or receiving a
drishti from benefics.
~5QT~
If during the period of Antar Dasha of Shukr, Guru is
favourable in transit, there will be dawn of fortune and
growth of property.
~7QT~
If Shani is favourable in transit, there will be Raj Yog
effects or the accomplishment of Yog rites ('Yog Triya
Siddhi').
~6d+6c+6I6+6I8+6I12~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P249_B002_01

- 身份：正文
- PDF 页：249
- 偈颂：28-29
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 28-29 [present] · PDF page 249

28-29. Distress to wife, loss of position, mental agony,
quarrels with close relations, etc., will be the results,
if Shukr is in his Debilitation Rashi, if Shukr is combust,
or if Shukr is in Ari, Randhr, or Vyaya Bhava.
~(6I9)7+(6I11)7+(6I!K)7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P249_B003_01

- 身份：正文
- PDF 页：249
- 偈颂：30-31 1/2
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 30-31 1/2 [present] · PDF page 249

30-31 1/2. Fulfillment of ambitions by the beneficence of
the king, charities, performance of religious rites,
creation of interest in the study of Shastras, composition
of poems, interest in Vedanta, etc., listening to Puranas,
happiness from wife and children, will be experienced, if
Shukr is in Dharm, Labh or Kendr from the lord of the
Dasha (Shani).
~(6I6)7+(6I8)7+(6I12)7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P249_B004_01

- 身份：正文
- PDF 页：249
- 偈颂：32-34
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 32-34 [present] · PDF page 249

32-34. There will be eye trouble, fevers, loss of good
conduct, dental problems, heart disease, pain in arms,
danger from drowning or falling from a tree, antagonism
towards relations, with the officials of government and
brothers, if Shukr is in the 6th, the 8th, or the 12th from
the lord of the Dasha (Shani).
~6iL2+6iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P249_B005_01

- 身份：正文
- PDF 页：249
- 偈颂：35-36
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 35-36 [present] · PDF page 249

35-36. There will be physical distress if Shukr is Dhan's
lord or Yuvati's lord.
The remedial measures to obtain relief from the above evil
effects and to regain enjoyment and good health by the
beneficence of Goddess Durga and the performance of Durga
Saptashati Path and giving a cow or a female buffalo in
charity.
@7112@
Effects of the Antar Dasha of Surya in the Dasha of Shani
~1E+1O+1AL9+1K*1AB+1K*1DB+1T*1AB+1T*1DB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P250_B001_01

- 身份：正文
- PDF 页：250
- 偈颂：37-38 1/2
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 37-38 1/2 [present] · PDF page 250

37-38 1/2. Effects like good relations with one's employer,
well being in the family, happiness from children, gain of
conveyances and cattle, etc. will be derived in the Antar
Dasha of Surya in the Dasha of Shani, if Surya is in his
Exaltation Rashi, in his own Rashi, or if Surya is
associated with Dharm's lord, or if Surya is in a Kendr or
in a Trikon (from Lagn) associated with or receiving a
drishti from benefics.
~1I8+1I12+(1I8)7+(1I12)7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P250_B002_01

- 身份：正文
- PDF 页：250
- 偈颂：39-41
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 39-41 [present] · PDF page 250

39-41. There will be heart disease, defamation, loss of
position, mental agony, separation from close relatives,
obstacles in industrial ventures, fevers, fears, loss of
kinsmen, loss of articles dear to the person, if Surya is
in Randhr or in Vyaya Bhava, or if Surya is in the 8th or
in the 12th from the lord of the Dasha (Shani).
~1iL2+1iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P250_B003_01

- 身份：正文
- PDF 页：250
- 偈颂：42
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 42 [present] · PDF page 250

42. There will be physical distress if Surya is Dhan's lord
or Yuvati's lord.
The worship of Surya is the remedial measure to obtain
relief from the above evil effects.
@7122@
Effects of the Antar Dasha of Chandr in the Dasha of Shani
~2P+2E+2O+(2I!K)7+(2I!T)7+(2I11)7+2AB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P250_B004_01

- 身份：正文
- PDF 页：250
- 偈颂：43-45
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 43-45 [present] · PDF page 250

43-45. Effects like gains of conveyance, garments,
ornaments, improvement of fortune and enjoyments, taking
care of brothers, happiness in both maternal and paternal
homes increase in cattle wealth, etc., will be derived in
the Antar Dasha of Chandr in the Dasha of Shani, if Chandr
is full, in her Exaltation Rashi, or in her own Rashi, or
in a Kendr, or in a Trikon, or in the 11th from the Dasha
lord or if Chandr receives a drishti from benefics.
~2w+2Am+2Dm+2d+2Nm+2Im~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P250_B005_01

- 身份：正文
- PDF 页：250
- 偈颂：46-48 1/2
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 46-48 1/2 [present] · PDF page 250

46-48 1/2. There will be great distress, wrath, separation
from parents, ill health of children, losses in business,
irregular meals, administration of medicines, if Chandr is
waning, if Chandr is associated with or if Chandr receives a
drishti from malefics, of if Chandr is in his Debilitation
Rashi, or if Chandr is in malefic Navamsh, or if Chandr is
in the Rashi of a malefic grah. There will, however, be
good effects and some gain of wealth at the commencement of
the Antar Dasha.
~(2I!K)7+(2I!T)7+(2I11)7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P250_B006_01

- 身份：正文
- PDF 页：250
- 偈颂：49-50 1/2
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 49-50 1/2 [present] · PDF page 250

49-50 1/2. Enjoyment of conveyances and garments, happiness
from kinsmen, happiness from parents, wife, employer, etc.,
will be the results if Chandr is in a Kendr, in a Trikon,
or in the 11th from the lord of the Dasha (Shani).
~2w*(2I6)7+2w*(2I8)7+2w*(2I12)7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P250_B007_01

- 身份：正文
- PDF 页：250
- 偈颂：51-52
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 51-52 [present] · PDF page 250

51-52. Effects like sleepiness, lethargy, loss of position,
loss of enjoyments, increase in the number of enemies,
antagonism with kinsmen, will be experienced, if Chandr is
weak and is in the 6th, the 8th, or the 12th from the lord
of the Dasha (Shani).
~2iL2+2iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P251_B001_01

- 身份：正文
- PDF 页：251
- 偈颂：53-54
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 53-54 [present] · PDF page 251

53-54. There will be lethargy and physical distress if
Chandr is Dhan's lord or Yuvati's lord.
The remedial measures to obtain relief from the above evil
effects and prolongation of longevity are Havan and giving
jaggery, ghee, rice mixed with curd, a cow, or a female
buffalo in charity.
@7132@
Effects of the Antar Dasha of Mangal in the Dasha of Shani
~3E+3O+3AL1+3A7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P251_B002_01

- 身份：正文
- PDF 页：251
- 偈颂：55-57
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 55-57 [present] · PDF page 251

55-57. Effects like enjoyments, gain of wealth, reverence
from the king (government), gain of conveyances, clothes a
ornaments, attainment of the position of a Commander of the
Army, increase in agricultural and cattle wealth,
construction of a new house, happiness to kinsmen, will be
derived from the very commencement of the Antar Dasha of
Mangal in the Dasha Shani, if Mangal is in his Exaltation
Rashi, in his own Rashi, or if Mangal is associated with
Lagn's lord, or with the Dasha lord (Shani).
~3d+3c+8I8*8Am+8I8*8Dm+8I12*8Am+8I12*8Am~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P251_B003_01

- 身份：正文
- PDF 页：251
- 偈颂：58-60
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 58-60 [present] · PDF page 251

58-60. There will be loss of wealth, danger of wounds,
danger from thieves, snakes, weapons, gout and other
similar diseases, distress to father and brothers, quarrels
with co-partners, loss of kinsmen, coarse food, going away
to foreign lands, unnecessary expenditure, etc., if Mangal
is in his  Debilitation Rashi, or combust, or in Randhr or
Vyaya Bhava and associated with or receiving a drishti from
malefics.
~3I2+3iL7+3iL8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P251_B004_01

- 身份：正文
- PDF 页：251
- 偈颂：61-62
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 61-62 [present] · PDF page 251

61-62. Great distress, dependence on others and fear,
premature death, may be expected if Mangal is in Dhan
Bhava, or if Mangal is Yuvati's lord or Randhr's lord.
The remedial measures to obtain relief from the above evil
effects are performance of Havan and giving a bull in
charity.
@7182@
Effects of the Antar Dasha of Rahu in the Dasha of Shani
~-8E*-8J~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P251_B005_01

- 身份：正文
- PDF 页：251
- 偈颂：63-64
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 63-64 [present] · PDF page 251

63-64. Effects like quarrels, mental agony, physical
distress, agony, antagonism with the sons, danger from
diseases, unnecessary expenditure, discord with close
relations, danger from the government, foreign journeys,
loss of house and agricultural lands, will be derived in
the Antar Dasha of Rahu in the Dasha of Shani, if Rahu not
be in his house of exaltation or any other auspicious
position.
~8AL1+8Ay+8E+8O+8K+8I11+(8I!K)7+(8I11)7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P252_B001_01

- 身份：正文
- PDF 页：252
- 偈颂：65-67
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 65-67 [present] · PDF page 252

65-67. Enjoyment, gains of wealth, increase in agricultural
production, devotion to deities and Brahmins, pilgrimage to
holy places, increase in cattle wealth, well-being in the
family will be the results at the commencement of the Antar
Dasha, if Rahu is be associated with Lagn's lord or a Yog
Karak Grah, or if Rahu is in his Exaltation Rashi, or in
his own Rashi, or if Rahu is in a Kendr or in Labh from
Lagn or from the lord of the Dasha (Shani).
There will be cordiality with the king and happiness from
friends in the middle portion of the Antar Dasha.
~8IR1+8IR6+8IR4+8IR2+8IR12+8IR9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P252_B002_01

- 身份：正文
- PDF 页：252
- 偈颂：68-68 1/2
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 68-68 1/2 [present] · PDF page 252

68-68 1/2. There will be acquisition of elephants,
opulence, and glory, cordial relations with the king
(government), gains of valuable clothes, if Rahu is in
Mesh, Kanya, Kark, Vrishabh, Meen, or Dhanu.
~8AL2+8AL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P252_B003_01

- 身份：正文
- PDF 页：252
- 偈颂：69-70
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 69-70 [present] · PDF page 252

69-70. There will be physical distress, if Rahu is
associated with Dhan's lord or with Yuvati's lord.
The remedial measures to obtain relief from the above evil
effects are Mrityunjaya Japa and giving a goat in charity.
@7152@
Effects of the Antar Dasha of Guru in the Dasha of Saturn
~5K+5T+5AL1+5O+5E~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P252_B004_01

- 身份：正文
- PDF 页：252
- 偈颂：71-73 1/2
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 71-73 1/2 [present] · PDF page 252

71-73 1/2. Effects like success all round, well-being in
the family, gain of conveyances, ornaments, and clothes by
the beneficence of the king (government), reverence,
devotion to deities and the preceptor, association with men
of learning, happiness from wife and children, etc., will
be derived in the Antar Dasha of Guru in the Dasha of
Shani, if Guru is in a Kendr, or in a Trikon, or if Guru is
associated with Lagn's lord, or if Guru is in his own Rashi,
or in his Exaltation Rashi.
~5d+5Am+5I6+5I3+5I12~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P252_B005_01

- 身份：正文
- PDF 页：252
- 偈颂：74-75 1/2
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 74-75 1/2 [present] · PDF page 252

74-75 1/2. Results like death of the near relations, loss
of wealth, antagonism with the government officials,
failure in projects, journeys to foreign lands, affliction
with diseases like leprosy, etc., will be experienced if
Guru is in his Debilitation Rashi, or if Guru is associated
with malefics, or if Guru is in Ari, Sahaj, or Vyaya Bhava.
~(5I5)7+(5I9)7+(5I11)7+(5I2)7+(5I!K)7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P252_B006_01

- 身份：正文
- PDF 页：252
- 偈颂：76-78
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 76-78 [present] · PDF page 252

76-78. There will be opulence and glory, happiness to wife,
gains through the king (government), comforts of good food
and clothes, religious mindedness, name and fame in the
country, interest in Vedas and Vedanta, performance of
religious sacrifices, giving grains, etc. in charity, if
Guru is in the 5th, 9th, 11th, 2nd  or Kendr from the lord
of the Dasha (Shani).
~5w*(5I6)7+5w*(5I8)7+5w*(5I12)7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P252_B007_01

- 身份：正文
- PDF 页：252
- 偈颂：79-80
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 79-80 [present] · PDF page 252

79-80. Antagonism with kinsmen, mental agony, quarrels loss
of position, losses in ventures, loss of wealth as a result
of imposition of fines or penalties by government,
imprisonment distress to wife and son, will be the results
if Guru is weak and is in the 6th, in the 8th, or in the
12th from the lord of the Dasha (Shani).
~5iL2+5iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P253_B001_01

- 身份：正文
- PDF 页：253
- 偈颂：81-82
- 标题路径：CHAPTER 57 Effects of the Antar Dashas in the Dasha of › Shani @7172@ Effects of the Antar Dasha of Shani in the Dasha of Shani ~7O+7E+7K+7T+7y~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 81-82 [present] · PDF page 253

81-82. There will be physical distress, agony, death of the
native or any member of the family, if Guru is Dhan's lord
or Yuvati's lord.
Remedial measures to obtain relief from the above evil
effects are recitation of Shiva Sahasranam and giving gold
in charity.
