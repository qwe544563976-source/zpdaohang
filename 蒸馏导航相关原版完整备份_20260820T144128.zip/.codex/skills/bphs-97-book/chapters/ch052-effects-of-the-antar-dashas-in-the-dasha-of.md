# 第 52 章：Effects of the Antar Dashas in the Dasha of

- 来源：BPHS 97 章版
- 原始卡片：27 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P216_B002_01

- 身份：正文
- PDF 页：216
- 偈颂：—
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka unknown [unknown] · PDF page 216 · page_block BPHS_PL9_CHAP_97_P216_B002

Surya according to the Vimshottari Dasha System.
@1112@
Effects of Antar Dasha of Surya in the Dasha of Surya
~1E+1O+1I11+1K+1T~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P216_B003_01

- 身份：正文
- PDF 页：216
- 偈颂：1-3
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 1-3 [present] · PDF page 216

1-3. Good effects like acquisition of wealth and grains,
etc., are derived in the Antar Dasha of Surya in his own
Dasha, if Surya is exalted, in his own Bhava, in Labh
Bhava, in a Kendr or in a Trikon.
~1d+1a+1s~
Adverse results will be experienced if Surya is debilitated
or in an inauspicious Bhava or Rashi.
~-1E*-1O*-1I11*-1K*-1T*-1d*-1a*-1s~
Medium effects will be realized if Surya is in other
houses.
~1iL2+1iL7~
If Surya is the lord of Dhan or Yuvati Bhava, there will be
danger of premature death or death like sufferings. The
remedial measures to be adopted are Mrityunjaya Japa or the
worship of Surya (by recitation of appropriate mantras,
charity, etc.).
@1122@
Effects of the Antar Dasha of Chandr in the Dasha of Surya
~2K+2T~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P216_B004_01

- 身份：正文
- PDF 页：216
- 偈颂：4-6
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 4-6 [present] · PDF page 216

4-6. Functions like marriage, etc., gain of wealth and
property, acquisition of a house, of land, cattle, and
conveyances, etc., will be the effects of the Antar Dasha
of Chandr in the Dasha of Surya, if Chandr is in a Kendr or
in a Trikon.
~2E+2O~
There will be marriage of the native, birth of children,
beneficence of and favours from kings (the government) and
fulfillment of all ambitions, if Chandr is in his
exaltation Rashi or in his own Rashi.
~2w+2Am~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P216_B005_01

- 身份：正文
- PDF 页：216
- 偈颂：7-10
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 7-10 [present] · PDF page 216

7-10. Distress to wife and children, failures in ventures,
disputes withe others, loss of servants, antagonism withe
the king (government), and destructions of wealth and
grains, will be the effects if Chandr is waning or is
associated with malefics.
~2I6+2I8+2I12~
Effects like danger from water, mental agony, imprisonment,
danger from diseases, loss of position, journeys to
difficult places, disputes withe coparceners, bad food,
trouble from thieves, etc., displeasure of the king
(government), urinary troubles, pains in the body will be
experienced, if Chandr is in Ari, Randhr, or Vyaya Bhava.
~(BI1)1+(BI9)1+(BI!K)1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P216_B006_01

- 身份：正文
- PDF 页：216
- 偈颂：11-12 1/2
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 11-12 1/2 [present] · PDF page 216

11-12 1/2. Luxuries, comforts, pleasures, dawn of fortune
(Bhagyodaya), increase in the enjoyment from wife and
children, acquisition of kingdom, performance of marriage
and religious functions, gain of garments, land, and
conveyance, and birth of children and grand children will
be the auspicious effects if there are benefics in the 1st,
the 9th, or a Kendr from the lord of the Dasha.
~(2I6)1+(2I8)1+(2I12)1+2v~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P217_B001_01

- 身份：正文
- PDF 页：217
- 偈颂：13-14
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 13-14 [present] · PDF page 217

13-14. Unpalatable food or course food, exile to outside
places, etc., will be the effects in the Antar Dasha, if
Chandr is in the 6th, the 8th, or the 12th from the lord of
the Dasha, or if Chandr is weak.
~2iL2+2iL7~
There will be premature death if Chandr is the lord of a
Marak Bhava (Dhan or Yuvati Bhava). To acquire peace and
comfort, the remedial measure is giving in charity of a
white cow and a female buffalo ('Mahishi').
@1132@
Effects of the Antar Dasha of Mangal in the Dasha of Surya
~3E+3O+3K+3T~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P217_B002_01

- 身份：正文
- PDF 页：217
- 偈颂：15-18
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 15-18 [present] · PDF page 217

15-18. Auspicious effects like acquisition of land, gain of
wealth and grains, acquisition of a house, etc., will be
derived in the Antar Dasha of Mangal in the Dasha of Surya
if Mangal is in his exaltation Rashi, in his own Rashi, in
a Kendr, or in a Trikon.
~3YL1~
All round gains, attainment of the position of a commander
of the army, destruction of enemies, peace of mind, family
comforts, and increase in the number of co-borns will be
the effects if Mangal is yuti with the Lagn's lord.
~(3I8)1+(3I12)1+3Am+3u*3x~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P217_B003_01

- 身份：正文
- PDF 页：217
- 偈颂：19-20
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 19-20 [present] · PDF page 217

19-20. Brutality, mental ailment, imprisonment, loss of
kinsmen, disputes with brothers, and failure in ventures
will result if Mangal is in the 8th or in the 12th from the
lord of the Dasha, if Mangal is associated with malefics or
if Mangal is without dignity and strength.
~3d+3v~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P217_B004_01

- 身份：正文
- PDF 页：217
- 偈颂：21-22
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 21-22 [present] · PDF page 217

21-22. Destruction of wealth by the displeasure of the king
(government) will be the effect if Mangal is in his
debilitation Rashi or be weak.
~3iL2+3iL7~
Diseases of the mind and body will result if Mangal is the
lord of Dhan or Yuvati Bhava. Recovery from ill health,
increase in longevity, and success in adventures are
possible if remedial measure like recitation of Vedas,
Japa, and Vrashotsarg are performed in the prescribed
manner.
@1182@
Effects of the Antar Dasha of Rahu in the Dasha of Surya
~8K+8T~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P218_B001_01

- 身份：正文
- PDF 页：218
- 偈颂：23-26 1/2
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 23-26 1/2 [present] · PDF page 218

23-26 1/2. In the Antar Dasha of Rahu in the Dasha of
Surya, if Rahu is in a Kendr or in a Trikon from Lagn,
there will be in the first two months loss of wealth,
danger from thieves, snakes, infliction of wounds, and
distress to wife and children.
~8YB+Nã8iB~
After 2 months inauspicious effects will disappear and
enjoyment and comforts, sound health, satisfaction, favours
from the king and government, etc., will be the favourable
effects, if Rahu is yuti with benefics or if Rahu is in the
Navamsh of a benefic.
~8I3+8I6+8I10+8I11+8Ay+(8J)1~
Recognition from the king (government), good fortune, name
and fame, some distress to wife and children, birth of a
son, happiness in the family, etc., will be derived if Rahu
is in an Upachaya house (Sahaj, Ari, Karm, or Dharm Bhava)
from Lagn, if Rahu is associated with a Yog Karak or is
placed auspiciously from the lord of the Dasha.
~8v+(8I8)1+(8I12)1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P218_B002_01

- 身份：正文
- PDF 页：218
- 偈颂：27-29
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 27-29 [present] · PDF page 218

27-29. Imprisonment, loss of position, danger from thieves
and snakes, inflection of wounds, happiness to wife and
children, destruction of cattle, house, and agricultural
fields, diseases, consumption (Gulma: enlargement of the
skin), dysentery, etc., will be the results, if Rahu is
weak or  is in the 8th or in the 12th from the lord of the
Dasha (Surya).
~8I2+8I7+8AL2+8AL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P218_B003_01

- 身份：正文
- PDF 页：218
- 偈颂：30-31
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 30-31 [present] · PDF page 218

30-31. Adverse effects like premature death, and danger
from snakes, will be derived if Rahu is in Dhan or Yuvati
Bhava or if Rahu is associated with the lords of either of
these Bhavas. Worship of Goddess Durga, Japa, giving in
charity of a black cow or female buffalo are the remedial
measures for alleviation of the above evil effects or total
escape from them.
@1152@
Effects of the Antar Dasha of Guru in the Dasha of Surya
~5K+5T+5E+5O+5VO~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P218_B004_01

- 身份：正文
- PDF 页：218
- 偈颂：32-33 1/2
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 32-33 1/2 [present] · PDF page 218

32-33 1/2. Marriage of the native, favours by the king
(government) gain of wealth and grains, birth of a son,
fulfillment of the ambitions by the beneficence of the
sovereign and gain of clothes, will be the auspicious
effects derived in the Antar Dasha of Guru in the Dasha of
Surya if Guru is in a Kendr or in a Trikon to Lagn, in his
exaltation Rashi, in his own Rashi, or in his own Varg.
~5iL9+5iL10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P218_B005_01

- 身份：正文
- PDF 页：218
- 偈颂：34-36
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 34-36 [present] · PDF page 218

34-36. Acquisition of a kingdom (attainment of a high
position in government), comforts of conveyance like
palanquin (motor car in the present times), gain of
position, etc., will result if Guru is the lord of Dharm or
Karm Bhava
~(5I!K)1+(5I!T)1~
Better fortune, charities, religious inclinations, worship
of deities, devotion to preceptor, fulfillment of ambitions
will be the auspicious effects, if Guru is well placed with
reference to the lord of the Dasha (Surya).
~(5I6)1+(5I8)1+5Am~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P219_B001_01

- 身份：正文
- PDF 页：219
- 偈颂：37-39
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 37-39 [present] · PDF page 219

37-39. Distress to wife and children, pains in the body,
displeasure of the king (government), non-achievement of
desired goals, loss of wealth due to sinful deeds, mental
worries, etc., will result in his Antar Dasha if Guru is in
the 6th or in the 8th from the lord of the Dasha or is
associated with malefics. Giving in charity gold, a tawny
colored cow ('Kapila Gaya') worship of Isht lord
('Isht Dev') are the remedial measures to obtain alleviation
of the evil effects and to achieve good health and
happiness.
@1172@
Effects of the Antar Dasha of Shani in the Dasha of Surya
~7K+7T~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P219_B002_01

- 身份：正文
- PDF 页：219
- 偈颂：40-42
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 40-42 [present] · PDF page 219

40-42. Destruction of foes, full enjoyment, some gain of
grains, auspicious functions like marriage, etc., at home,
will be the good effects derived in the Antar Dasha of
Shani in the Dasha of Surya, if Shani is in a Kendr or in a
Trikon from Lagn.
~7E+7O+7G*7Y6+7G*7Y4~
Well being, acquisition of more property, recognition by
the king (government), achievement of renown in the
country, gain of wealth from many sources, will be the
effects if Shani is in his exaltation Rashi, in his own
Rashi, in a friendly Rashi and if Shani is yuti with a
friendly grah.
~(7I8)1+(7I12)1+7Am~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P219_B003_01

- 身份：正文
- PDF 页：219
- 偈颂：43-44
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 43-44 [present] · PDF page 219

43-44. Rheumatism, pains, fever, dysentery-like disease,
imprison-ment, loss in ventures, loss of wealth, quarrels,
disputes with coparceners, claimants, etc., will be the
effects in the Antar Dasha if Shani is in the 8th or the
12th from the lord of the Dasha or is associated with
malefics.
~7d~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P219_B004_01

- 身份：正文
- PDF 页：219
- 偈颂：45-47
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 45-47 [present] · PDF page 219

45-47. There will be loss of friends at the commencement,
good effects during the middle part and distress at the end
of the Dasha. In addition to other evil effects, there will
be separation from parents and wandering, if Shani be in
his Rashi of debilitation.
~7iL2+7iL7~
If Shani is the lord of Dhan or Yuvati Bhava, there will be
danger of premature death. Giving in charity black cow,
buffalo, goat and Mrityunjaya Japa, are the remedial
measures for obtaining relief from the evil effects of the
Antar Dasha. These measures help to achieve happiness and
gain of wealth and property.
@1142@
Effects of the Antar Dasha of Buddh in the Dasha of Surya
~4K+4T~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P219_B005_01

- 身份：正文
- PDF 页：219
- 偈颂：48-49 1/2
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 48-49 1/2 [present] · PDF page 219

48-49 1/2. Acquisition of a kingdom (attainment of a high
position in government), enthusiasm and vivacity, happiness
from wife and children, acquisition of conveyance through
the beneficence of the Sovereign, gain of clothes,
ornaments, pilgrimage to holy places, acquisition of a cow,
etc., will be the good effects in the Antar Dasha of Buddh
in the Dasha of Surya, if Buddh is in a Kendr or in a
Trikon from Lagn.
~4AL9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P220_B001_01

- 身份：正文
- PDF 页：220
- 偈颂：50-51 1/2
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 50-51 1/2 [present] · PDF page 220

50-51 1/2. Buddh becomes very beneficial if he gets
associated with the lord of Dharm Bhava.
~4I9+4I5+4I10~
Reverence from and popularity amongst people, performance
of pious deeds and religious rites, devotion to the
preceptor and deities, increase in wealth and grains, and
birth of a son, will be the auspicious effects, if Buddh is
in Dharm, Putr, or Karm Bhava.
~(4J)1+(4I9)1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P220_B002_01

- 身份：正文
- PDF 页：220
- 偈颂：52-53 1/2
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 52-53 1/2 [present] · PDF page 220

52-53 1/2. Marriage, offering of oblations, charity,
performance of religious rites, name and fame, becoming
famous by assuming another name, good food, becoming happy
like Indra by acquiring wealth, robes and ornaments, will
be the effects if Buddh is in an auspicious bhava like a
Trikon, etc., from the lord of the Dasha (Surya).
~(4I12)1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P220_B003_01

- 身份：正文
- PDF 页：220
- 偈颂：54-57
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 54-57 [present] · PDF page 220

54-57. Body distress, disturbance of peace of mind,
distress to wife and children, will be the evil effects in
the Antar Dasha of Buddh, if he is in the 6th, the 8th, or
the 12th from the lord of the Dasha (Buddh cannot be in the
6th or the 8th from Surya). There will be evil effects at
the commencement of the Antar Dasha, some good effects in
the middle part of the Antar Dasha and the possibility of
displeasure of the king and exile to a foreign country at
the end of the Dasha.
~4iL2+4iL7~
If Buddh is the lord of Dhan or Yuvati Bhava, there will be
pains in the body and attacks of fever.
For relief from the evil effects and to regain good health
and happiness the remedial measures are the recitation of
Vishnu Sahasranam and giving in charity grains and an idol
made of silver.
@1192@
Effects of the the Antar Dasha of Ketu in the Dasha of
Surya
~9AL1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P220_B004_01

- 身份：正文
- PDF 页：220
- 偈颂：58-59
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 58-59 [present] · PDF page 220

58-59. Body Pains, mental agony, loss of wealth, danger
from the king (government), quarrels with the kinsmen, will
be the effects of the Antar Dasha of Ketu in the Dasha of
Surya. If Ketu is associated with the lord of Lagn, there
will be some happiness at the commencement, distress in the
middle part, and receipt of the news of death at the end of
the Antar Dasha.
~(9I8)1+(9I12)1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P220_B005_01

- 身份：正文
- PDF 页：220
- 偈颂：60-61
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 60-61 [present] · PDF page 220

60-61. Diseases of teethe or cheeks, urinary troubles, loss
of position, loss of friends and wealth, death of father,
foreign journey, and troubles from enemies will be the
results if Ketu is in the 8th or the 12th from the lord of
the Dasha (Surya).
~9I3+9I6+9I10+9I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P221_B001_01

- 身份：正文
- PDF 页：221
- 偈颂：62-64
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 62-64 [present] · PDF page 221

62-64. Beneficial effects like happiness from wife and
children, satisfaction, increase of friends, gain of
clothes, etc., and renown, will be derived if Ketu is in
Sahaj, Ari, Karm, or Labh Bhava.
~9iL2+9I2+9iL2+9I7~
If Ketu is lord of Dhan or Yuvati Bhava (or is in any of
those bhavas), there will be danger of premature death.
The remedial measures for obtaining relief from the evil
effects are recitation of mantras of Goddess Durga (Shat
Chandi Path) and giving a goat in charity.
@1162@
Effects of the Antar Dasha of Shukr in the Dasha of Surya
~6K+6T+6E+6O+6VO+6F~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P221_B002_01

- 身份：正文
- PDF 页：221
- 偈颂：65-68
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 65-68 [present] · PDF page 221

65-68. Marriage and happiness as desired from wife, gain of
property, travels to other places, meeting with Brahmins
and the king (government officials), acquisition of kingdom
(attainment of a high position in government), riches,
magnanimity and majesty, auspicious, functions at the home,
availability of sweet preparations, acquisition of pearls
and other jewels, clothes, cattle, wealth, grains and
conveyances, enthusiasm, good reputation, etc., are the
auspicious effects of the Antar Dasha of Shukr in the Dasha
of Surya, if Shukr is placed in a Kendr or in a Trikon, or
if Shukr is in his exaltation Rashi, in his own Rashi, in
his own Varg, or in a friendly Rashi.
~(6I6)1+(6I8)1+(6I12)1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P221_B003_01

- 身份：正文
- PDF 页：221
- 偈颂：69-73
- 标题路径：CHAPTER 52 Effects of the Antar Dashas in the Dasha of
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 69-73 [present] · PDF page 221

69-73. Displeasure of the king mental agony and distress to
wife and children, will be the effects in the Antar Dasha
of Shukr if he is in the 6th, the 8th or the 12th from the
lord of the Dasha (Surya). The effects of the Antar Dasha
would be moderate at its commencement, good during the
middle portion and evil effects like disrepute, loss of
position, inimical relations with kinsmen and loss of
comforts, will be derived at the end.
~6iL7+6iL2~
If Shukr is the lord of Yuvati (and Dhan Bhava) there will
be pains in the body and the possibility of suffering from
diseases.
~6AL6+6AL8~
There will be premature death if Shukr is associated with
Ari's lord or Randhr's lord. The remedial measures for
obtaining relief from the evil effects are Mrityunjaya
Japa, Rudra Japa, and giving in charity a tawny cow or
female buffalo.
