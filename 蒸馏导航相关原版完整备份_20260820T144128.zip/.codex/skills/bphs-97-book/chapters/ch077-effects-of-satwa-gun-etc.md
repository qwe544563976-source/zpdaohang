# 第 77 章：Effects of Satwa Gun, etc.

- 来源：BPHS 97 章版
- 原始卡片：19 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P325_B002_01

- 身份：正文
- PDF 页：325
- 偈颂：1-4
- 标题路径：CHAPTER 77 Effects of Satwa Gun, etc.
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Satwa Gun, etc. · Sloka 1-4 [present] · PDF page 325

1-4. The Great Sage Parasara said: O Brahmin! When the
satwa-guni  grahas (Surya, Chandr, and Guru) are predominant,
the person born is Satwa-guni and of good character. When
rajo-guna (passion of love and pleasure) is predominant (that
is, when Buddh and Shukr are predominant), the person born is
rajo-guna and intelligent. When the tamo-guna (attribute of
darkness) is predominant (that is, when Mangal and Shani are
predominant) the person born is stupid. When at the time of
birth all the grahas are of equal dominance the person has a
mixture of all the attributes. The persons so born
(creatures) are classified as Uttama (most excellent),
madhyama (of intermediate type), adhama (despisable) and
Udaseena (indifferent or neutral) in that order. Thus, there
are four kinds of animate beings (prani). I will relate their
attributes which have been described by Narada and other
sages.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P325_B003_01

- 身份：正文
- PDF 页：325
- 偈颂：5
- 标题路径：CHAPTER 77 Effects of Satwa Gun, etc.
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Satwa Gun, etc. · Sloka 5 [present] · PDF page 325

5. The natural attributes of persons belonging to Uttam (most
excellent) class are possession of control over organs of
perception and mind, simplicity, truthfulness, patience, and
satisfaction.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P325_B004_01

- 身份：正文
- PDF 页：325
- 偈颂：6
- 标题路径：CHAPTER 77 Effects of Satwa Gun, etc.
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Satwa Gun, etc. · Sloka 6 [present] · PDF page 325

6. Valour, splendour, patience, cleverness, not retreating in
war and protecting the holy men, are the natural attributes
of persons belonging to rajo-guna (intermediate type).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P325_B005_01

- 身份：正文
- PDF 页：325
- 偈颂：7
- 标题路径：CHAPTER 77 Effects of Satwa Gun, etc.
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Satwa Gun, etc. · Sloka 7 [present] · PDF page 325

7. Greed, falsehood, idiocy, laziness, and doing service of
others are the inborn attributes of persons who belong to
adham class (despisable class).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P325_B006_01

- 身份：正文
- PDF 页：325
- 偈颂：8
- 标题路径：CHAPTER 77 Effects of Satwa Gun, etc.
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Satwa Gun, etc. · Sloka 8 [present] · PDF page 325

8. Engagement in agriculture and business, protection of
cattle, and speaking both truth and lies, are inborn
attributes of persons belonging to Udaseena class
(indifferent or neutral type).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P325_B007_01

- 身份：正文
- PDF 页：325
- 偈颂：9
- 标题路径：CHAPTER 77 Effects of Satwa Gun, etc.
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Satwa Gun, etc. · Sloka 9 [present] · PDF page 325

9. O Maitreya! Classify the people as Uttama, Madhyama,
Adhama, and Udaseena after observation of the attributes
described above. A person should be considered appropriate
for a job according to his attributes.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P325_B008_01

- 身份：正文
- PDF 页：325
- 偈颂：10
- 标题路径：CHAPTER 77 Effects of Satwa Gun, etc.
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Satwa Gun, etc. · Sloka 10 [present] · PDF page 325

10. If amongst Satwa, Rajas, and Tamas, any attribute is the
most dominant it is considered the most predominant of all.
Otherwise all have equal effects.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P325_B009_01

- 身份：正文
- PDF 页：325
- 偈颂：11
- 标题路径：CHAPTER 77 Effects of Satwa Gun, etc.
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Satwa Gun, etc. · Sloka 11 [present] · PDF page 325

11. The affectionate relationship between an employer and
employee (master and servant) and man and women (husband and
wife) will be invariable and stable if they possess the same
attributes.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P325_B010_01

- 身份：正文
- PDF 页：325
- 偈颂：12
- 标题路径：CHAPTER 77 Effects of Satwa Gun, etc.
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Satwa Gun, etc. · Sloka 12 [present] · PDF page 325

12. 0 Maitreya! Amongst the above four classes of persons, if
there is any kind of relationship of even Adhama with
udaseena; of Udaseena with Madhyama; and of Madhyama with
Uttama, there will be mutual affection and happiness.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P326_B001_01

- 身份：正文
- PDF 页：326
- 偈颂：13
- 标题路径：CHAPTER 77 Effects of Satwa Gun, etc.
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Satwa Gun, etc. · Sloka 13 [present] · PDF page 326

13. If the bridegroom has better attributes than the bride
and the master has better attributes than the servant, there
will be mutual affection (regard for each other) and
happiness. If the bride or the servant possesses better
attributes, the relationships will be full of bitterness.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P326_B002_01

- 身份：正文
- PDF 页：326
- 偈颂：14
- 标题路径：CHAPTER 77 Effects of Satwa Gun, etc.
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Satwa Gun, etc. · Sloka 14 [present] · PDF page 326

14. The attributes of the native are dependent on his father
and mother, his time of birth, and the persons he gets
associated with. These are the root causes of Uttama, etc.,
qualities possessed by him. The attributes endowed by the
time of the birth and associations are stronger than those
received from the parents.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P326_B003_01

- 身份：正文
- PDF 页：326
- 偈颂：15
- 标题路径：CHAPTER 77 Effects of Satwa Gun, etc.
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Satwa Gun, etc. · Sloka 15 [present] · PDF page 326

15. Consequently the person is embellished with the attribute
satwa, rajas or tamas whichever is predominant at the time of
birth. The predictions should therefore be made after taking
into account the time of birth.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P326_B004_01

- 身份：正文
- PDF 页：326
- 偈颂：16
- 标题路径：CHAPTER 77 Effects of Satwa Gun, etc.
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Satwa Gun, etc. · Sloka 16 [present] · PDF page 326

16. The Supreme lord of the Universe, who is indestructible
and omnicient, is the Kal. He is the Creator, Protector, and
Destroyer of all moveable and immoveable.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P326_B005_01

- 身份：正文
- PDF 页：326
- 偈颂：17
- 标题路径：CHAPTER 77 Effects of Satwa Gun, etc.
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Satwa Gun, etc. · Sloka 17 [present] · PDF page 326

17. These three faculties of lord Kal are called nature.
Divided by these faculties the imperceptible Lord Kal is also
perceptible.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P326_B006_01

- 身份：正文
- PDF 页：326
- 偈颂：18
- 标题路径：CHAPTER 77 Effects of Satwa Gun, etc.
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Satwa Gun, etc. · Sloka 18 [present] · PDF page 326

18. In accordance with the self created qualities by the
Perceptible form of Lord Kal, there are four kinds of limbs
(parts) namely: Uttama, Madhyama, Udaseena, and Adhama.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P326_B007_01

- 身份：正文
- PDF 页：326
- 偈颂：19
- 标题路径：CHAPTER 77 Effects of Satwa Gun, etc.
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Satwa Gun, etc. · Sloka 19 [present] · PDF page 326

19. From the Uttama, Madhyama, Udaseena, and Adhama parts are
created Uttama, Madhyama, Udaseena, and Adhama (in that
order) types of creatures.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P326_B008_01

- 身份：正文
- PDF 页：326
- 偈颂：20
- 标题路径：CHAPTER 77 Effects of Satwa Gun, etc.
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Satwa Gun, etc. · Sloka 20 [present] · PDF page 326

20. The Uttama part of Lord Kal is the head, Madhyama part
both arms and chest, thighs form the Udaseena part, and the
feet fall in the Adhama part.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P326_B009_01

- 身份：正文
- PDF 页：326
- 偈颂：21
- 标题路径：CHAPTER 77 Effects of Satwa Gun, etc.
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Satwa Gun, etc. · Sloka 21 [present] · PDF page 326

21. This is how a differentiation is made between classes of
moveables and immoveables according to attributes and the
parts from which the creations are made.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P326_B010_01

- 身份：正文
- PDF 页：326
- 偈颂：22
- 标题路径：CHAPTER 77 Effects of Satwa Gun, etc.
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Satwa Gun, etc. · Sloka 22 [present] · PDF page 326

22. The Chaturvidha (four sided) Lord Kal has Thus, created
this chaturvidha universe in consonance with his own
attributes.
