# 第 37 章：Chandr's Yogas

- 来源：BPHS 97 章版
- 原始卡片：6 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P133_B002_01

- 身份：正文
- PDF 页：133
- 偈颂：1
- 标题路径：CHAPTER 37 Chandr's Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Chandr's Yogas · Sloka 1 [present] · PDF page 133

1. If Chandr with reference to Surya is in a Kendr, one's
wealth, intelligence and skill will be little.
~(2I!P)1~m
If Chandr with reference to Surya is in a Panaphara, one's
wealth, intelligence and skill will be meddling.
~(2I!A)1~
If Chandr with reference to Surya is in a Apoklima, one's
wealth, intelligence and skill will be excellent.
~@bD*2D5**2NO+N2F~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P133_B003_01

- 身份：正文
- PDF 页：133
- 偈颂：2-4
- 标题路径：CHAPTER 37 Chandr's Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Chandr's Yogas · Sloka 2-4 [present] · PDF page 133

2-4. In the case of a day birth, if Chandr placed in its
own Navamsh, or in a friendly Navamsh, receives a drishti
from Guru, one will be endowed with wealth, and happiness.
~@bN*2D6**2NO+N2F~
One born at night time will enjoy similar effects if Chandr
is in its own Navamsh, or in a friendly Navamsh receiving a
drishti to Shukr.
~@bD*2D6*2NO+@bD*2D6*N2F+@bN*2D6*2NO+@bN*2D6*N2F~n
In a contrary situation, the drishti from Guru, or from
Shukr on Chandr will make one go with little wealth, or
even without that.
~(BI8)2*(BI6)2*(BI7)2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P133_B004_01

- 身份：正文
- PDF 页：133
- 偈颂：5
- 标题路径：CHAPTER 37 Chandr's Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Chandr's Yogas · Sloka 5 [present] · PDF page 133

5. Adhi Yog from Chandr: If benefics occupy the 8th, 6th,
and 7th counted from Chandr, Adhi Yog obtains. According to
the strength of the participating grahas, the native
concerned will be either a king, or a minister, or an army
chief.
~(5I!U)2*(4I!U)2*(6I!U)2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P133_B005_01

- 身份：正文
- PDF 页：133
- 偈颂：6
- 标题路径：CHAPTER 37 Chandr's Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Chandr's Yogas · Sloka 6 [present] · PDF page 133

6. Dhan Yog: Should all the (three) benefics be Upachaya,
i.e. in the 3rd,  the 6th, the 10th, and the 11th counted
from Chandr, one will be very affluent;
~(.|I!U)2~
with two benefics placed in the 3rd, the 6th, the 10th, and
the 11th one will have medium effects in regard to wealth.
~(BI!U)2*-(.|I!U)2~**-(5I!U)2+-(4I!U)2+-(6I!U)2~m
If a single benefic is there, the wealth will be
negligible.
~(.DI2)2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P134_B001_01

- 身份：正文
- PDF 页：134
- 偈颂：7-10
- 标题路径：CHAPTER 37 Chandr's Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Chandr's Yogas · Sloka 7-10 [present] · PDF page 134

7-10. Sunaph, Anaph, and Duradhar: If there is a grah,
other than Surya, in the 2nd from Chandr Sunaph Yog is
formed.
~(.DI12)2~
If there is a grah, other than Surya, in the 12th from
Chandr Anaph Yog is formed.
~(.DI12)2*(.DI2)2~
If there are grahas, other than Surya, in the 2nd from
Chandr and in the 12th from Chandr Duradhar Yog is caused.
~(.DI2)2~
One with Sunaph Yog will be a king or equal to a king
endowed with intelligence, wealth, fame, and self earned
wealth.
~(.DI12)2~
One born in Anaph Yog will be a king, be free from
diseases, virtuous, famous, charming, and happy.
~(.DI2)2*(.DI12)2~
One born in Duradhar Yog will enjoy pleasures; one will be
charitable, and endowed with wealth, conveyances, and
excellent serving force.
~-.DY2*-(.DI2)2*-(.DI12)2*-.DI!K~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P134_B002_01

- 身份：正文
- PDF 页：134
- 偈颂：11-13
- 标题路径：CHAPTER 37 Chandr's Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Chandr's Yogas · Sloka 11-13 [present] · PDF page 134

11-13. Kema Drum Yog: Excluding Surya, should there be no
grah with Chandr, or in the 2nd and/or 12th from Chandr, or
in a Kendr from Lagn, Kema Drum Yog is formed. One born in
Kema Drum Yog will be very much reproached; one will be
bereft of intelligence; learning is reduced to penury and
perils.
