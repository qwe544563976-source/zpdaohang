# 第 59 章：Effects of the Antar Dashas in the Dasha of

- 来源：BPHS 97 章版
- 原始卡片：34 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P260_B002_01

- 身份：正文
- PDF 页：260
- 偈颂：—
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka unknown [unknown] · PDF page 260 · page_block BPHS_PL9_CHAP_97_P260_B002

Ketu
@9192@
Effects of the Antar Dasha of Ketu in the Dasha of Ketu
~9K+9T+9rL9+9rL10+9rL4~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P260_B003_01

- 身份：正文
- PDF 页：260
- 偈颂：1-2 1/2
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 1-2 1/2 [present] · PDF page 260

1-2 1/2. Effects like happiness from wife and children,
recognition from the king (government), but mental agony,
gain of land, village, etc., will be derived in the Antar
Dasha of Ketu in his own Dasha, if Ketu is in a Kendr or in
a Trikon (from Lagn), or if Ketu is related to Dharm's
lord, Karm's lord, or Bandhu's lord.
~9d*9Yb*9I8+9d*9Yb*9I12~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P260_B004_01

- 身份：正文
- PDF 页：260
- 偈颂：3-4
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 3-4 [present] · PDF page 260

3-4. Heart disease, defamation, destruction of wealth and
cattle, distress to wife and children, instability of mind,
etc., will we be the results, if Ketu is in his
Debilitation Rashi, and if Ketu is in Randhr or in Vyaya
Bhava along with a combust grah.
~9rL2+9rL7+9I2+9I7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P260_B005_01

- 身份：正文
- PDF 页：260
- 偈颂：5-6
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 5-6 [present] · PDF page 260

5-6. There will be danger from diseases, great distress and
separation from kinsmen, if Ketu is related to Dhan's lord
or to Yuvati's lord, or if Ketu is in Dhan or in Yuvati
Bhava.
The remedial measures to obtain relief from the above evil
effects are performance of Durga Saptashati Japa and
Mrityunjaya Japa.
@9162@
Effects of the Antar Dasha of Shukr in the Dasha of Ketu
~6E+6O+6K*6AL10+6T*6AL10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P260_B006_01

- 身份：正文
- PDF 页：260
- 偈颂：7-9 1/2
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 7-9 1/2 [present] · PDF page 260

7-9 1/2. Effects like beneficence from the king, good
fortune, gain of clothes etc., recovery of lost kingdom
(reinstatement in a high position in government), comforts
of conveyances, etc., visits to sacred shrines, and gain of
lands and villages by the beneficence of the king
(government), will be derived in the Antar Dasha of Shukr
in the Dasha of Ketu, if Shukr is in his Exaltation Rashi,
in his own Rashi, or if Shukr is associated with Karm's lord
in a Kendr or in a Trikon.
~6K*6AL10*6AL9+6T*6AL10*6AL9~
and there will be dawn of fortune if in such position he is
associated with Dharm's lord also.
~(6I!K)9+(6I!T)9+(6I3)9+(6I11)9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P260_B007_01

- 身份：正文
- PDF 页：260
- 偈颂：10-11
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 10-11 [present] · PDF page 260

10-11. Sound health, well-being in the family, and gains of
good food and conveyances, etc., will be the results if
Shukr is in a Kendr, in a Trikon, or in the 3rd or the 11th
from the lord of the Dasha (Ketu).
~(6I6)9+(6I8)9+(6I12)9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P261_B001_01

- 身份：正文
- PDF 页：261
- 偈颂：12-14
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 12-14 [present] · PDF page 261

12-14. There will be quarrels without any cause, loss of
wealth, distress to cattle if Shukr is in the 6th, in the
8th, or in the 12th from the lord of the Dasha (Ketu).
~6d+6At+6I6+6I8~
If Shukr is in his Debilitation Rashi or if Shukr is
associated with a debilitated grah, or if Shukr is in Ari or
in Randhr Bhava, there will be quarrels with kinsmen,
headaches, eye troubles, heart disease, defamation, loss of
wealth, and distress to cattle and wife.
~6iL2+6iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P261_B002_01

- 身份：正文
- PDF 页：261
- 偈颂：15
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 15 [present] · PDF page 261

15. Physical distress and mental agony will be caused, if
Shukr is Dhan's lord or Yuvati's lord.
The remedial measures to obtain relief from the above evil
effects, are performance of Durga Path and giving a tawny
coloured cow or female buffalo in charity.
@9112@
Effects of the Antar Dasha of Surya in the Dasha of Ketu
~1E+1O+1AB*1K+1AB*1T+1AB*1I11+1DB*1K+1DB*1T+1DB*1I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P261_B003_01

- 身份：正文
- PDF 页：261
- 偈颂：16-17
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 16-17 [present] · PDF page 261

16-17. The effects like gains of wealth, beneficence of the
king, performance of pious deeds, and fulfillment of all
ambitions will be derived in the Antar Dasha of Surya in
the Dasha Ketu if Surya is in his Exaltation Rashi, in his
own Rashi, or if Surya is associated with or receives a
drishti from a benefic in a Kendr, in a Trikon, or in Labh
Bhava.
~1Am*1I8+1Am*1I12~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P261_B004_01

- 身份：正文
- PDF 页：261
- 偈颂：18-19 1/2
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 18-19 1/2 [present] · PDF page 261

18-19 1/2. Danger from the king (government), separation
from parents, journeys to foreign lands, distress from
thieves, snakes, and poison, punishment by government,
antagonism with the friends, sorrows, danger from fever,
etc., will be the results if Surya is associated with a
malefic or malefics in Randhr or in Vyaya Bhava.
~(1I!K)9+(1I!T)9+(1I2)9+(1I11)9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P261_B005_01

- 身份：正文
- PDF 页：261
- 偈颂：20-21
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 20-21 [present] · PDF page 261

20-21. There will be physical fitness, gain of wealth or
the birth of a son, success in performance of pious deeds,
headship of a small village, etc., if Surya is in a Kendr,
in a Trikon, in the 2nd or in the 11th from the lord of the
Dasha (Ketu).
~1Am*(1I8)9+1Am*(1I12)9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P261_B006_01

- 身份：正文
- PDF 页：261
- 偈颂：22-24
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 22-24 [present] · PDF page 261

22-24. Obstacles in availability of food, fears, and loss
of wealth and cattle, will be the results if Surya is
associated with evil grahas in the 8th or in the 12th from
the lord of the Dasha (Ketu). There will be distress at the
commencement of the Antar Dasha with some mitigation at its
end.
~1iL2+1iL7~
There will be fear of premature death if Surya is Dhan's
lord or Yuvati's lord.
The remedial measure to obtain relief from the above evil
effects and to regain comforts by the beneficence of Surya,
is to give a cow and gold in charity.
@9122@
Effects of the Antar Dasha of Chandr in the Dasha of Ketu
~2E+2O+2K+2T+2I11+2I2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P262_B001_01

- 身份：正文
- PDF 页：262
- 偈颂：25-28
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 25-28 [present] · PDF page 262

25-28. Effects like recognition from the king (government),
enthusiasm, well-being, enjoyments, acquisition of a house,
lands, etc., abnormal gains of food, clothes, conveyances,
cattle, etc., success in business, construction of
reservoirs, etc., and happiness to wife and children will
be derived in the Antar Dasha of Chandr in the Dasha of
Ketu, if Chandr is in her Exaltation Rashi, in her own
Rashi, in a Kendr, in a Trikon, in Labh Bhava or in Dhan
Bhava.
~2W~
The beneficial results will be realized fully if Chandr is
waxing.
~2d+2I6+2I8+2I12~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P262_B002_01

- 身份：正文
- PDF 页：262
- 偈颂：29-30
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 29-30 [present] · PDF page 262

29-30. Unhappiness and mental agony, obstacles in ventures,
separation from parents, losses in business, destruction of
cattle, etc., will be caused if Chandr is in her
Debilitation Rashi, or in Ari, in Randhr, or in Vyaya
Bhava.
~(2I!K)9*2X+(2I!T)9*2X+(2I11)9*2X~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P262_B003_01

- 身份：正文
- PDF 页：262
- 偈颂：31-33
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 31-33 [present] · PDF page 262

31-33. There will be the acquisition of a cow or cows,
land, agricultural lands, meeting kinsmen and the
achievement of success through them, increase in cows milk
and curd, if Chandr is in a Kendr, in a Trikon, or in the
11th from the lord of the Dasha (Ketu) and if Chandr is
endowed with strength. There will be auspicious results at
the commencement of the Antar Dasha cordial relations with
the king (government) in the middle portion of the Antar
Dasha, and danger from the king (government) foreign
journey or journeys to distant places at its end.
~(2I6)9+(2I8)9+(2I12)9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P262_B004_01

- 身份：正文
- PDF 页：262
- 偈颂：34-36
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 34-36 [present] · PDF page 262

34-36. Loss of wealth, anxiety, enmity with kinsmen and
distress to brother, will be the results, if Chandr is in
the 6th, in the 8th, or in the 12th from the lord of the
Dasha (Ketu).
~2iL2+2iL7+2iL8~
If Chandr is Dhan's lord, Yuvati's lord, or Randhr's lord,
there will be fear of premature death.
The remedial measures to obtain relief from the above
effects are recitation of mantras of Chandr and giving in
charity things connected with Chandr. (See effects of Antar
Dashas of Chandr in the Dasha of other grahas).
@9132@
Effects of the Antar Dasha of Mangal in the Dasha of Ketu
~3E+3O*3AB+3O*3DB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P262_B005_01

- 身份：正文
- PDF 页：262
- 偈颂：37-39
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 37-39 [present] · PDF page 262

37-39. Effects like acquisition of land, village, etc.,
increase in wealth and cattle, laying out of a new garden,
gain of wealth by the beneficence of the king, will be
derived in the Antar Dasha of Mangal in the Dasha of Ketu,
if Mangal is in his Exaltation Rashi, in his own Rashi, if
Mangal is associated with or if Mangal receives a drishti from
benefics.
~3rL9+3rL10~
If Mangal is related to Dharm's lords or to Karm's lord,
there will definitely be gain of land and enjoyment.
~(3I!K)9+(3I!T)9+(3I3)9+(3I11)9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P263_B001_01

- 身份：正文
- PDF 页：263
- 偈颂：40
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 40 [present] · PDF page 263

40. There will be recognition from the king, great
popularity and reputation and happiness from children and
friends, if Mangal is in a Kendr, in a Trikon, or in the
3rd, or in the 11th from the lord of the Dasha (Ketu).
~(3I8)9+(3I12)9+(3I2)9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P263_B002_01

- 身份：正文
- PDF 页：263
- 偈颂：41-42
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 41-42 [present] · PDF page 263

41-42. There will be fear of death / disaster during a
foreign journey, diabetes, unnecessary troubles, danger
from thieves and the king and quarrels if Mangal is in the
8th, in the 12th, or in the 2nd from the lord of the Dasha
(Ketu). In the above circumstances amidst evil effects
there will be some auspicious effects also.
~3iL2+3iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P263_B003_01

- 身份：正文
- PDF 页：263
- 偈颂：43-44
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 43-44 [present] · PDF page 263

43-44. High fever, danger from poison, distress to wife,
mental agony and fear of premature death, will be the
results if Mangal is Dhan's lord or Yuvati's lord. By the
beneficence of Mangal there will be enjoyment and gain of
property, if as a remedial measure, a bull is given in
charity.
@9182@
Effects of the Antar Dasha of Rahu in the Dasha of Ketu
~8E+8O+8F+8K+8T+8I11+8I3+8I2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P263_B004_01

- 身份：正文
- PDF 页：263
- 偈颂：45-47
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 45-47 [present] · PDF page 263

45-47. Effects like increase of wealth and gain of wealth,
grains, cattle, lands, village from a Yavan king (high
dignitary of a foreign country) will be derived in the
Antar Dasha of Rahu in the Dasha of Ketu, if Rahu is in his
Exaltation Rashi, in his own Rashi, in a friends Rashi or
in a Kendr, or in a Trikon, or in Labh, or in Sahaj, or in
Dhan Bhava. There will be some trouble at the commencement
of the Dasha but all will be well later.
~8Am*8I8+8Am*8I12~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P263_B005_01

- 身份：正文
- PDF 页：263
- 偈颂：48-50
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 48-50 [present] · PDF page 263

48-50. Frequent urination, weakness in the body, cold
fever, danger from thieves, intermittent fever, opprobrium
quarrels, diabetes, pain in stomach, will be the results if
Rahu is associated with a malefic in Randhr or in Vyaya Bhava.
~8I2+8I7~
There will be distress and danger if Rahu is in Dhan or in
Yuvati Bhava.
The remedial measure to obtain relief from the above evil
effects, is Durga Saptashati Path.
@9152@
Effects of the Antar Dasha of Guru in the Dasha of Ketu
~5E+5O+5AL1*5K+5AL1*5T+5AL9*5K+5AL9*5T+5AL10*5K+5AL10*5T~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P263_B006_01

- 身份：正文
- PDF 页：263
- 偈颂：51-54
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 51-54 [present] · PDF page 263

51-54. Effects like increase in wealth and grains,
beneficence of the king, enthusiasm, gain of conveyances,
etc., celebration like birth of a son at home, performance
of pious deeds, Yagyas, conquest of the enemy and
enjoyments, will be derived in the Antar Dasha of Guru in
the Dasha of Ketu, if Guru is in his Exaltation Rashi, in
his own Rashi, or is associated with Lagn's lord, Dharm's
lord or Karm's lord in a Kendr or in a Trikon (from Lagn).
~5d+5I6+5I8+5I12~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P264_B001_01

- 身份：正文
- PDF 页：264
- 偈颂：55-56
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 55-56 [present] · PDF page 264

55-56. Danger from thieves, snakes, and wounds, destruction
of wealth, separation from wife and children, physical
distress, etc., will be the results if Guru is in his
Debilitation Rashi, or in Ari, in Randhr, or in Vyaya
Bhava. Though some good effects may be felt at the
commencement of the Antar Dasha, there will be only adverse
results later.
~5AB*(5I!K)9+5AB*(5I!T)9+5AB*(5I3)9+5AB*(5I11)9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P264_B002_01

- 身份：正文
- PDF 页：264
- 偈颂：57-58 1/2
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 57-58 1/2 [present] · PDF page 264

57-58 1/2. There will be gains of many varieties of
garments, ornaments by the beneficence of the king, foreign
journeys, taking care of kinsmen, availability of decent
food, if Guru is associated with a benefic in a Kendr, in a
Trikon, in the 3rd or in the 11th from the lord of the
Dasha (Ketu).
~5iL2+5iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P264_B003_01

- 身份：正文
- PDF 页：264
- 偈颂：59-60
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 59-60 [present] · PDF page 264

59-60. Fear of premature death will be caused if Guru is
Dhan's lord or Yuvati's lord.
The remedial measures to obtain relief from the above evil
effects are Mrityunjaya Japa. recitation of Shiva
Sahasranama .
@9172@
Effects of the Antar Dasha of Shani in the Dasha of Ketu
~7x*7u~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P264_B004_01

- 身份：正文
- PDF 页：264
- 偈颂：61-62 1/2
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 61-62 1/2 [present] · PDF page 264

61-62 1/2. Effects like distress to oneself and one's
kinsmen, agony, increase in cattle wealth, loss of wealth
as a result of imposition of fines by government,
resignation from the existing post, journeys to foreign
lands, and danger of thieves during travelling will be
derived in the Antar Dasha of Shani in the Dasha of Ketu,
if Shani is deprived of strength and dignity.
~7I8+7I12~
there will be loss of wealth and lethargy, if Shani is in
Randhr or in Vyaya Bhava.
~7T*7IR12+7E+7O+7NJ+7AB*7K+7AB*7T+7AB*7I3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P264_B005_01

- 身份：正文
- PDF 页：264
- 偈颂：63-65
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 63-65 [present] · PDF page 264

63-65. Success in all ventures, happiness from the
employer, comforts during journeys, increase in happiness
and property in ones own village, audience with the king
(visits to high dignitaries), etc., will be the results, if
Shani is  in a Trikon in Meen, in Tula (his Exaltation
Rashi), in his own Rashi or if Shani is in  an auspicious
Navamsh or is associated with a benefic in a Kendr, in a
Trikon or in Sahaj Bhava.
(According to Brihat Jatak Shani in Tula, Meen,
Dhanu, Makar, and Kumbh in Lagn gives Raj Yog).
~7Am*(7I6)9+7Am*(7I8)9+7Am*(7I12)9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P265_B001_01

- 身份：正文
- PDF 页：265
- 偈颂：67-68
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 67-68 [present] · PDF page 265

67-68. There will be physical distress, agony, obstacles in
ventures, lethargy, defamation, death of parents, if Shani
is associated with a malefic, in the 6th, in the 8th, or in
the 12th from the lord of the Dasha (Ketu).
~7iL2+7iL7~
Fear of premature death may be expected if Shani is Dhan's
lord or Yuvati's lord.
The remedial measures to obtain relief from the above evil
effects are performance of Havan with sesame seeds ('Til')
and giving a black cow or female buffalo in charity.
@9142@
Effects of the Antar Dasha of Buddh in the Dasha of Ketu
~4T+4K+4E+4O~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P265_B002_01

- 身份：正文
- PDF 页：265
- 偈颂：69-71
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 69-71 [present] · PDF page 265

69-71. Effects like acquisition of a kingdom (attainment of
a high position in government), enjoyments, charities, gain
of wealth and land, birth of a son, celebration of
religious functions and functions like marriage suddenly,
well-being in the family, gain of clothes, ornaments, etc.,
will be derived in the Antar Dasha of Buddh in the Dasha of
Ketu, if Buddh is in a Kendr or in a Trikon (from Lagn), or
if Budh is in his Exaltation Rashi, or in his own Rashi.
~4AL9+4AL10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P265_B003_01

- 身份：正文
- PDF 页：265
- 偈颂：72
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 72 [present] · PDF page 265

72. There will be association with men of learning, dawn of
fortune, and listening to religious discourses, if Buddh is
associated with Dharm's lord or with Karm's lord.
~4A7+4A3+4A8**4Ia~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P265_B004_01

- 身份：正文
- PDF 页：265
- 偈颂：73-74 1/2
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 73-74 1/2 [present] · PDF page 265

73-74 1/2. Antagonism with government officials, residing
in other people's houses, destruction of wealth, clothes,
conveyances, and cattle, will be the results if Buddh is
associated with Shani, Mangal, or Rahu in Ari, in Randhr,
or in Vyaya Bhava. There will be some beneficial effects at
the commencement of the Dasha, still better results in the
middle but inauspicious at the end.
~(4I!K)9+(4I!T)9+(4I11)9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P265_B005_01

- 身份：正文
- PDF 页：265
- 偈颂：75-76
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 75-76 [present] · PDF page 265

75-76. There will be good health, happiness from one's son,
opulence and glory, availability of good food and clothes,
and abnormal profits in business, if Buddh is in a Kendr,
in a Trikon, or in the 11th from the lord of the Dasha
(Ketu).
~4v*(4I6)9+4v*(4I8)9+4v*(4I12)9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P265_B006_01

- 身份：正文
- PDF 页：265
- 偈颂：77-79
- 标题路径：CHAPTER 59 Effects of the Antar Dashas in the Dasha of › Ketu @9192@ Effects of the Antar Dasha of Ketu in the Dasha of Ketu ~9K+9T+9rL9+9rL10+9rL4~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 77-79 [present] · PDF page 265

77-79. Distress, unhappiness and troubles to wife and
children, and danger from the king (government) may be
expected at the commencement of the Antar Dasha if Buddh is
weak in the 6th, in the 8th, or in the 12th from the lord
of the Dasha (Ketu). There will, however, be visits to
sacred places in the middle of the Dasha.
~4iL2+4iL7~
Fear of premature death will be caused if Buddh is Dhan's
lord or Yuvati's lord.
The remedial measure to obtain relief from the above evil
effects, is recitation of Vishnu Sahasranam.
