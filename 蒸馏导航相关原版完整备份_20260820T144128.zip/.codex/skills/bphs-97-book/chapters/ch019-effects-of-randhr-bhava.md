# 第 19 章：Effects of Randhr Bhava

- 来源：BPHS 97 章版
- 原始卡片：7 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P051_B002_01

- 身份：正文
- PDF 页：51
- 偈颂：1
- 标题路径：CHAPTER 19 Effects of Randhr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Randhr Bhava · Sloka 1 [present] · PDF page 51

1. Long Life: O excellent of the Brahmins, listen to me
speak on the effects of Randhr Bhava. If Randhr's lord is
in an angle, long life is indicated.
~L8Ym*L8I8+L8YL1*L8I8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P051_B003_01

- 身份：正文
- PDF 页：51
- 偈颂：2
- 标题路径：CHAPTER 19 Effects of Randhr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Randhr Bhava · Sloka 2 [present] · PDF page 51

2. Short Life: Should Randhr's lord join Lagn's lord or a
malefic and be in Randhr itself, the native will be short
lived.
~7Ym*7I8+7YL1*7I8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P051_B004_01

- 身份：正文
- PDF 页：51
- 偈颂：3
- 标题路径：CHAPTER 19 Effects of Randhr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Randhr Bhava · Sloka 3 [present] · PDF page 51

3. Shani and Karm's Lord about Longevity : Similarly,
consider Shani and Karm's lord in the matter of longevity.
~L10I8*L10Ym+L10I8*L10YL1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P051_B005_01

- 身份：正文
- PDF 页：51
- 偈颂：3
- 标题路径：CHAPTER 19 Effects of Randhr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Randhr Bhava · Sloka 3 [present] · PDF page 51

3. Karm's lord is in Randhr along with a malefic grah
and/or Lagn's lord.
~L6I12+L6I6*L12I12+L6I1*L12I1+L6I8*L12I8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P051_B006_01

- 身份：正文
- PDF 页：51
- 偈颂：4-7
- 标题路径：CHAPTER 19 Effects of Randhr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Randhr Bhava · Sloka 4-7 [present] · PDF page 51

4-7. Long Life: There will be long life if Ari's lord is in
Vyaya; or if Ari's lord is in Ari as Vyaya's lord is in
Vyaya; or if Ari's lord and Vyaya's lord are in Lagn and
Randhr.
~L5NO*L8NO*L1NO+L5I5*L8I8*L1I1+L5F*L8F*L1F~
If the lords of Putr, Randhr, and Tanu Bhava are in own
Navamshas, own Rashis or in friendly Rashis, the native
will enjoy a long span of life.
~L1·*L8·*L10·*7·~
Should the lords of Lagn, Randhr, and Karm Bhava and Shani
are all disposed severally in an angle, in a trine or in
Labh Bhava, the subject will live long. Like these, there
are many other yogas dealing with the issue of longevity.
The strength and weakness of the grahas concerned be
estimated in deciding longevity.
~L1v*L8K~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P051_B007_01

- 身份：正文
- PDF 页：51
- 偈颂：8-13
- 标题路径：CHAPTER 19 Effects of Randhr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Randhr Bhava · Sloka 8-13 [present] · PDF page 51

8-13. Short Life: One's span of life will be between 20 and
32 years if Lagn's lord is weak while Randhr's lord is an
angle.
~L8d*mI8*!1x~n
The native will only be short-lived if Randhr's lord is in
fall, while Randhr Bhava has a malefic in it and Tanu Bhava
is bereft of strength.
~mI8*L8Ym*mI12~n
Death will be instant at birth if Randhr Bhava, Randhr's
lord, and Vyaya Bhava are all conjunct malefics.
~L8I1**mK*BI6*L8d+mK*BI8*L8d+mT*BI8*L8d+mT*BI6*L8d~n
Malefics in angles and/or trines and benefics in Ari and/or
Randhr Bhava, while Tanu Bhava has in it Randhr's lord in
fall: this yoga will cause immediate end.
~mI5*mI8*L8Ym~n
If Putr and Randhr Bhava and Randhr's lord are all conjunct
malefics, the life span will be very brief.
~L8I8*2Ym*-2DB~n
Within a month of birth, death will befall the child if
Randhr's lord is in Randhr itself while Chandr is with
malefics and be bereft of beneficial drishti.
~L1E*2I11*5I8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P052_B001_01

- 身份：正文
- PDF 页：52
- 偈颂：14-15
- 标题路径：CHAPTER 19 Effects of Randhr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Randhr Bhava · Sloka 14-15 [present] · PDF page 52

14-15. Long Life (again): One will be long-lived if Lagn's
lord is in exaltation, while Chandr and Guru are
respectively in Labh and Randhr Bhava.
~L1X*L1D.BK~
If Lagn's lord is exceedingly strong and receives a drishti
from a benefic which is placed in an angle, the person
concerned will be wealthy, virtuous and long-lived.
