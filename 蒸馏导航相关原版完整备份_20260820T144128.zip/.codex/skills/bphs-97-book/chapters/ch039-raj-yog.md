# 第 39 章：Raj Yog

- 来源：BPHS 97 章版
- 原始卡片：38 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P136_B002_01

- 身份：正文
- PDF 页：136
- 偈颂：1-2
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 1-2 [present] · PDF page 136

1-2. 0 excellent of the Brahmins, I now narrate below the
Raj Yogas making one entitled to royal honour. These were
told to Parvati by Lord Shiva once upon a time, the gist
of which is as follows:

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P136_B003_01

- 身份：正文
- PDF 页：136
- 偈颂：3-5
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 3-5 [present] · PDF page 136

3-5.  Raj Yogas are to be known from the Karakamsh Lagn and
the natal Lagn.  On the one hand the pair of Atma Karak and
Putr Karak should be considered and on the other hand the
natal Lagn's lord and Putr's lord should be taken into
consideration. The effects due to such association will be
full, or a half, or a quarter according to their
strengths.
(Karakamsh Lagn is the Navamsh occupied by the Atma Karak
grah).
~L1lL5+.apI1+.apI5+$OE*.pOE+N$O*N$DB*N.pO*N.pDB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P136_B004_01

- 身份：正文
- PDF 页：136
- 偈颂：6-7
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 6-7 [present] · PDF page 136

6-7. Maha Raj Yog: Should Lagn's Lord and Putr's lord
exchange their rashis or if Atma Karak and Putr Karak
(Char) are in Lagn, or in Putr Bhava, or in the exaltation
rashi, or in own rashi, or in own Navamsh receiving a
drishti from a benefic, Maha Raj Yog is produced. The
native so born will be famous and happy.
~L1YB*$YB+L1DB**L1I1*$I1+$I5*L1I5+L1I7*$I7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P136_B005_01

- 身份：正文
- PDF 页：136
- 偈颂：8
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 8 [present] · PDF page 136

8. If Lagn's lord and Atma Karak are in Tanu, Putr, or
Yuvati Bhava yuti with or receiving a drishti from a benefic,
a Raj Yog is formed.
~(BI2)L1*(BI4)L1*(BI5)L1+(BI2)$*(BI4)$*(BI5)$~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P136_B006_01

- 身份：正文
- PDF 页：136
- 偈颂：9-10
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 9-10 [present] · PDF page 136

9-10. Should there be benefics in the 2nd, the 4th, and the
5th counted either from Lagn's lord or from Atma Karak
rashi, one will become a king.
~(mI3)L1*(mI6)L1+(mI3)$*(mI6)$~
Similarly, malefics in the 3rd and 6th from Lagn's lord or
from Atma Karak rashi will make one a king.
~6D5+6Y5+6D2+6Y2**6IKa+(6I5)Ka+6I1+6ILa~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P136_B007_01

- 身份：正文
- PDF 页：136
- 偈颂：11
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 11 [present] · PDF page 136

11. One will be related to royal circles if Shukr is the
Karakamsh, or in the 5th there from, or in Lagn, or in
Arudh Lagn receiving a drishti from, or yuti with Guru or
Chandr.
~LnD%+LhD%+LgD%~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P136_B008_01

- 身份：正文
- PDF 页：136
- 偈颂：12
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 12 [present] · PDF page 136

12. Even if a single grah gives a drishti to the natal Lagn
or Hora Lagn or Ghatik Lagn, the native will become a
king.
~@s3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P136_B009_01

- 身份：正文
- PDF 页：136
- 偈颂：13-14
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 13-14 [present] · PDF page 136

13-14. If the six divisions (Shad Vargas) of Lagn are
occupied or receive a drishti from one and the same grah, a
Raj Yog is doubtlessly formed. Accordingly, if the drishti
is full, half, or one fourth, results will be in order
full, medium, and negligible.
~ïILn*ïILh*ïILg+EILn*.dEILr*.EILs~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P137_B001_01

- 身份：正文
- PDF 页：137
- 偈颂：15
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 15 [present] · PDF page 137

15. If the 3 Lagnas (i.e. natal Lagn, Hora Lagn, and Ghatik
Lagn) are occupied by grahas in exaltation or in own rashi,
or if the natal Lagn, the Dreshkan Lagn, and the Navamsh
Lagn have exalted grahas, Raj Yog is formed.
~.^ILa*2ILa*BILa*5I2*LaDï*!2Dï~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P137_B002_01

- 身份：正文
- PDF 页：137
- 偈颂：16
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 16 [present] · PDF page 137

16. If Chandr and a benefic are in the Arudh Lang as Guru
is in the 2nd from the natal Lagn and both these places are
receiving drishtis from grahas in exaltation, or grahas in
own rashi, there will be a Raj Yog.
~BI1*BI2*BI4*mI3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P137_B003_01

- 身份：正文
- PDF 页：137
- 偈颂：17
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 17 [present] · PDF page 137

17. If Lagn, Dhan,  and Bandhu Bhava are occupied be
benefics, while a malefic is in Sahaj Bhava, one will
become a king or equal to a king.
~2E*2I2+5E*5I2+6E*6I2+4E*4I2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P137_B004_01

- 身份：正文
- PDF 页：137
- 偈颂：18
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 18 [present] · PDF page 137

18. The native will be wealthy if one among Chandr, Guru,
Shukr, and Buddh is exalted in Dhan Bhava.
~tI6*tI8*tI3*L1E+tI6*tI8*tI3*L1O*!1DL1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P137_B005_01

- 身份：正文
- PDF 页：137
- 偈颂：19
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 19 [present] · PDF page 137

19. If Ari, Randhr, and Sahaj Bhava are occupied by
debilitated grahas as Lagn's lord is exalted, or is in (his
other) own Bhava, and gives a drishti to Lagn, there is a
Raj Yog.
~L6ð*L8ð*L12ð*!1DL1**L1O+L1E~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P137_B006_01

- 身份：正文
- PDF 页：137
- 偈颂：20
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 20 [present] · PDF page 137

20. Again, a Raj Yog is formed if Ari's, Randhr's, and
Vyaya's lords are in fall or in inimical rashis, or in
combustion, as Lagn's lord placed in his (other) own rashi
or in its exaltation rashi gives a drishti to Lagn.
~L10O*!1DL10+L10E*!1DL10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P137_B007_01

- 身份：正文
- PDF 页：137
- 偈颂：21
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 21 [present] · PDF page 137

21. If Karm's lord, placed in his own bhava, or in its
exaltation rashi, gives a drishti to Lagn, a Raj Yog is
formed.
~BK~
Similar is the case if benefics are in Kendras. (a Raj Yog
is formed)
~$IZ+$INZ+(BK)Lk~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P137_B008_01

- 身份：正文
- PDF 页：137
- 偈颂：22
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 22 [present] · PDF page 137

22. If the Atma Karak grah is in a benefic's Rashi/Navamsh,
the native will be wealthy.
~(BK)Lk~
If there are benefics in Kendras from Karakamsh Lagn, he
will become a king.
~(LaK)Ld+(LaI11)Ld+(LaI3)Ld+(LaT)Ld~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P137_B009_01

- 身份：正文
- PDF 页：137
- 偈颂：23
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 23 [present] · PDF page 137

23. If the Arudh Lagn and Dar Pad are in mutual Kendras or
in mutual Sahaj/Labh bhavas, or in mutual Konas, the native
will doubtlessly become a king.
~LbDE*LhDE+LbDE*LgDE+LhDE*LgDE~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P137_B010_01

- 身份：正文
- PDF 页：137
- 偈颂：24
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 24 [present] · PDF page 137

24. If two or all of Bhava Lagn, Hora Lagn, Ghatik Lagn are
receiving a drishti from exalted grahas, a Raj Yog is
formed.
~LbD&*LhD&*LgD&**@s4~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P138_B001_01

- 身份：正文
- PDF 页：138
- 偈颂：25
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 25 [present] · PDF page 138

25. If Bhava Lagn, Hora Lagn, and Ghatik Lagn, their
Dreshkanas and Navamshas, or the said Lagnas and their
Navamshas, or the said Lagnas and their Dreshkanas receive
a drishti from a grah, a Raj Yog is formed.
~-AMLa**EILa+5ILa+6ILa~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P138_B002_01

- 身份：正文
- PDF 页：138
- 偈颂：26-27
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 26-27 [present] · PDF page 138

26-27. If Arudh Pad is occupied by an exalted grah
particularly Chandr in exaltation, or by Guru and/or Shukr
(with or without exaltation), while there is no Argala by a
malefic, the native will become a king. If the Arudh Pad is
a benefic rashi containing Chandr, while Guru is in Dhan
Bhava the same effect will prevail.
~L6d*!1DL6+L8d*!1DL8+L12d*!1DL12~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P138_B003_01

- 身份：正文
- PDF 页：138
- 偈颂：28
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 28 [present] · PDF page 138

28. Even if one among Ari's, Randhr's, and Vyaya's lords
being in debilitation gives a drishti to Lagn, there will
be a Raj Yog.
~(!11D6)La*BILa**!1DL4+!1DL10+!1DL2+!1DL11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P138_B004_01

- 身份：正文
- PDF 页：138
- 偈颂：29-31
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 29-31 [present] · PDF page 138

29-31. The native will become a king if a grah ruling
Bandhu, Karm, Dhan, or Labh gives a drishti to Lagn, while
Shukr gives a drishti to the 11th from Arudh Lagn as Arudh
Lagn is occupied by a benefic.
~3IR4*3I6~
The same effect will be obtained if a debilitated grah gives
a drishti to Lagn and is placed in Ari or Randhr Bhava.
(i.e. The native will become a king)
~7IR1+7I11~
Again, similar result will prevail if a debilitated grah
placed in Sahaj or Labh Bhava gives a drishti to Lagn.
(i.e. The native will become a king)

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P138_B005_01

- 身份：正文
- PDF 页：138
- 偈颂：32
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 32 [present] · PDF page 138

32. I now tell you of the Raj Yogas based on the grahas
with different  dignities and on the drishtis and yutis of
the grahas.

~L5DL9*L9DL5+L5YL9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P138_B006_01

- 身份：正文
- PDF 页：138
- 偈颂：33-34
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 33-34 [present] · PDF page 138

33-34. Dharm's lord is akin to a minister, and more
especially Putr's lord. If these two grahas mutually give a
drishti, the native will obtain a kingdom. Even if these
two are yuti in any bhava, or if they happen to be placed
in mutually 7th places, one born of royal scion will become
a king.

~L4I10*L10I4*L5DL10*L9DL10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P138_B007_01

- 身份：正文
- PDF 页：138
- 偈颂：35
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 35 [present] · PDF page 138

35. The native will attain a kingdom if Bandhu's lord is in
Karm Bhava and Karm's lord is in Bandhu Bhava, and if these
grahas give a drishti to Putr's and Dharm's lords.
~L5YL10*L10YL4*L4YL1*L1I9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P138_B008_01

- 身份：正文
- PDF 页：138
- 偈颂：36
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 36 [present] · PDF page 138

36. If the lords of Putr, Karm, Bandhu, and Lagn are yuti
in Dharm Bhava, one will become a ruler with fame spreading
over the four directions.

~L4YL5+L5YL9+L10YL5+L10YL9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P139_B001_01

- 身份：正文
- PDF 页：139
- 偈颂：37
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 37 [present] · PDF page 139

37. Should the lord of Bandhu Bhava, or of Karm Bhava join
either the Putr's lord or Dharm's lord, the native will
obtain a kingdom.
~-L5I7*L5K*L5YL9+-L5I7*L5K*L5YL1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P139_B002_01

- 身份：正文
- PDF 页：139
- 偈颂：38
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 38 [present] · PDF page 139

38. If Putr's lord is in Lagn, Bandhu, or Karm Bhava yuti
with Dharm's lord or Lagn lord, the native will become a
king.

~5O*5I9*5Y6+5O*5I9*5YL5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P139_B003_01

- 身份：正文
- PDF 页：139
- 偈颂：39
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 39 [present] · PDF page 139

39. Should Guru be in his own rashi identical with Dharm
Bhava and yuti with either Shukr or Putr's lord, the
native will obtain royal status.
~@bM~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P139_B004_01

- 身份：正文
- PDF 页：139
- 偈颂：40
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 40 [present] · PDF page 139

40. Two and a half ghatis (i.e. 60 minutes of time) from
mid-day or from mid-night is auspicious time. A birth
during such an auspicious time will cause one to be a king
or equal to him.
~2I3*6I11+2D6*6D2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P139_B005_01

- 身份：正文
- PDF 页：139
- 偈颂：41
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 41 [present] · PDF page 139

41. Should Chandr and Shukr be mutually in Sahaj and Labh
Bhava and receiving drishtis from each other while they are
placed elsewhere (i.e. not in Sahaj and Labh Bhava), a Raj
Yog is obtained.
~2S*@D4C*N2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P139_B006_01

- 身份：正文
- PDF 页：139
- 偈颂：42
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 42 [present] · PDF page 139

42. Should Chandr, endowed with strength, be Vargottamsh
and receives a drishti from four or more grahas, the native
will become a king.
~LnÃ*@D4l*-2I7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P139_B007_01

- 身份：正文
- PDF 页：139
- 偈颂：43
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 43 [present] · PDF page 139

43. One will become a king if Lagn in Uttamamsh receives a
drishti from four or more grahas out of which Chandr should
not be one.
~&E+@E1+@E2+@E3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P139_B008_01

- 身份：正文
- PDF 页：139
- 偈颂：44
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 44 [present] · PDF page 139

44. If one or two or three grahas are in exaltation, one of
a royal scion will become a king, while another will be
equal to a king or be wealthy.
~@M4+@M5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P139_B009_01

- 身份：正文
- PDF 页：139
- 偈颂：45
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 45 [present] · PDF page 139

45. If four or five grahas occupy their exaltation rashis
or Mooltrikon rashis, even a person of base birth will
become king.
~@E6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P139_B010_01

- 身份：正文
- PDF 页：139
- 偈颂：46
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 46 [present] · PDF page 139

46. If six grahas are exalted, the native will become
emperor and will enjoy various kinds of royal
paraphernalia.
~5E*BK+6E*BK+4E*BK~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P139_B011_01

- 身份：正文
- PDF 页：139
- 偈颂：47
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 47 [present] · PDF page 139

47. Even if one among Guru, Shukr, and Buddh is in
exaltation, while a benefic is in a Kendr the native will
become a king or be equal to him.
~-BI!D*-BI!A*-mI!K*-mI!T*-mI2*-mI8*-mI12~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P139_B012_01

- 身份：正文
- PDF 页：139
- 偈颂：48
- 标题路径：CHAPTER 39 Raj Yog
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Raj Yog · Sloka 48 [present] · PDF page 139

48. If all benefics are relegated to Kendras, while
malefics are in  Sahaj, Ari, and Labh Bhava, the native,
though may be of mean descent will ascend, the throne.
