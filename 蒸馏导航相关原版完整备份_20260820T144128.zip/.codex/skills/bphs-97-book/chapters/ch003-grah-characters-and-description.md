# 第 3 章：Grah Characters and Description

- 来源：BPHS 97 章版
- 原始卡片：62 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P005_B002_01

- 身份：正文
- PDF 页：5
- 偈颂：1
- 标题路径：CHAPTER 3 Grah Characters and Description
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 1 [present] · PDF page 5

1. Maitreya: "O Maharishi, you have affectionately
explained about the incarnations of grahas. Now kindly
detail their characters and dispositions.
{gradef}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P005_B003_01

- 身份：正文
- PDF 页：5
- 偈颂：2-3
- 标题路径：CHAPTER 3 Grah Characters and Description
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 2-3 [present] · PDF page 5

2-3. Parashar: "O Brahmin, listen to the account of
placement of the heavenly bodies. Out of the many luminous
bodies sighted in the skies, some are stars; yet some are
grahas. Those that have no movements are the Nakshatras (or
asterisms).
{NakDef}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P005_B004_01

- 身份：正文
- PDF 页：5
- 偈颂：4-6
- 标题路径：CHAPTER 3 Grah Characters and Description
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 4-6 [present] · PDF page 5

4-6. Those are called 'Grahas' that move through the
Nakshatras (or stellar mansions) in the zodiac. The said
zodiac comprises of 27 Nakshatras commencing from Ashvini.
The same area is divided in 12 parts equal to 12 'Rashis'
commencing from Mesh. The names of the grahas commence from
Surya. The rashi rising is known as 'Lagn'. Based on Lagn
and the grahas joining and departing from each other, the
native's good and bad effects are deducted.
[addition from Santhanam till sloka 7]
The names of the 27 Nakshatras are:

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P005_B005_01

- 身份：正文
- PDF 页：5
- 偈颂：1
- 标题路径：CHAPTER 3 Grah Characters and Description › 1. Ashvini 15. Swati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 1 [present] · PDF page 5

1. Ashvini         15. Swati

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P005_B006_01

- 身份：正文
- PDF 页：5
- 偈颂：2
- 标题路径：CHAPTER 3 Grah Characters and Description › 2. Bharani 16. Vishaka
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 2 [present] · PDF page 5

2. Bharani         16. Vishaka

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P005_B007_01

- 身份：正文
- PDF 页：5
- 偈颂：3
- 标题路径：CHAPTER 3 Grah Characters and Description › 3. Krittika 17. Anuradha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 3 [present] · PDF page 5

3. Krittika        17. Anuradha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P005_B008_01

- 身份：正文
- PDF 页：5
- 偈颂：4
- 标题路径：CHAPTER 3 Grah Characters and Description › 4. Rohini 18. Jyeshtha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 4 [present] · PDF page 5

4. Rohini          18. Jyeshtha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P005_B009_01

- 身份：正文
- PDF 页：5
- 偈颂：5
- 标题路径：CHAPTER 3 Grah Characters and Description › 5. Mrigasira 19. Mula
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 5 [present] · PDF page 5

5. Mrigasira       19. Mula

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P005_B010_01

- 身份：正文
- PDF 页：5
- 偈颂：6
- 标题路径：CHAPTER 3 Grah Characters and Description › 6. Ardra 20. Purvashadh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 6 [present] · PDF page 5

6. Ardra           20. Purvashadh

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P005_B011_01

- 身份：正文
- PDF 页：5
- 偈颂：7
- 标题路径：CHAPTER 3 Grah Characters and Description › 7. Punarvasu 21. Uttarashadh
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 7 [present] · PDF page 5

7. Punarvasu       21. Uttarashadh

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P005_B012_01

- 身份：正文
- PDF 页：5
- 偈颂：8
- 标题路径：CHAPTER 3 Grah Characters and Description › 8. Pushya 22. Shravana
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 8 [present] · PDF page 5

8. Pushya          22. Shravana

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P005_B013_01

- 身份：正文
- PDF 页：5
- 偈颂：9
- 标题路径：CHAPTER 3 Grah Characters and Description › 9. Aslesha 23. Dhanishtha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 9 [present] · PDF page 5

9. Aslesha         23. Dhanishtha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P005_B014_01

- 身份：正文
- PDF 页：5
- 偈颂：10
- 标题路径：CHAPTER 3 Grah Characters and Description › 10. Magha 24. Satabhisha
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 10 [present] · PDF page 5

10. Magha          24. Satabhisha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P005_B015_01

- 身份：正文
- PDF 页：5
- 偈颂：11
- 标题路径：CHAPTER 3 Grah Characters and Description › 11. Purvaphalguni 25. Purvabhadra
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 11 [present] · PDF page 5

11. Purvaphalguni  25. Purvabhadra

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P005_B016_01

- 身份：正文
- PDF 页：5
- 偈颂：12
- 标题路径：CHAPTER 3 Grah Characters and Description › 12. Uttaraphalguni 26. Uttarabhadra
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 12 [present] · PDF page 5

12. Uttaraphalguni 26. Uttarabhadra

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P005_B017_01

- 身份：正文
- PDF 页：5
- 偈颂：13
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 13 [present] · PDF page 5

13. Hasta          27. Revati

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P005_B018_01

- 身份：正文
- PDF 页：5
- 偈颂：14
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 14 [present] · PDF page 5

14. Chitra
The names of the grahas are given in sloka 10 of this chapter.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P006_B001_01

- 身份：正文
- PDF 页：6
- 偈颂：—
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka unknown [unknown] · PDF page 6 · page_block BPHS_PL9_CHAP_97_P006_B001

{deflag}
Lagn is a very important point in the horoscope. It is the
rashi that rises in the east, on the latitude of birth. The
apparent rising of a rashi is due to the rotation of the
earth on its own axis at a rate of motion causing every
degree of the zodiac seemingly ascend on the eastern
horizon.
Approximately, two hours are required for a rashi to pass
via the horizon, thereby every degree taking four minutes
to ascend. This duration, however, is actually dependent on
the concerned latitude.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P006_B002_01

- 身份：正文
- PDF 页：6
- 偈颂：—
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka unknown [unknown] · PDF page 6 · page_block BPHS_PL9_CHAP_97_P006_B002

{gramot}
Actually, Surya has no motion. His motion is an apparent
one as viewed from the rotating earth. Other grahas
including the nodes have varied rates of motion. The
average daily motions of the grahas, which are not, however
standard, are as follows:
Surya  1
Chandr 13-15
Mangal 30-45'
Buddh  65-100'
Shukr  62-82'
Guru   5-15'
Shani  2'
Rahu/Ketu 3'
With such different motions, a grah forms various drishti's
with others. These drishti's through longitudinal distances
have a great deal of utility in Jyotish. This is what
Maharishi Parashar suggests to be considered.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P006_B003_01

- 身份：正文
- PDF 页：6
- 偈颂：7
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 7 [present] · PDF page 6

7. Details (of astronomical nature) of stars have to be
understood by general rules while I narrate to you about
the effects of grahas and rashis.
{gracal}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P006_B004_01

- 身份：正文
- PDF 页：6
- 偈颂：8-9
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 8-9 [present] · PDF page 6

8-9. The positions of the grahas for a given time be taken
as per Drikganit. And with the help of rashi durations
applicable to the respective places, Lagn at birth should
be known. Now, I tell you about the castes, descriptions,
and dispositions of the grahas.
{granam}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P006_B005_01

- 身份：正文
- PDF 页：6
- 偈颂：10
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 10 [present] · PDF page 6

10. Names of grahas: The names of the nine grahas
respectively are: Surya, Chandr, Mangal, Buddh, Guru,
Shukr, Shani, Rahu, and Ketu.
{granat}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P007_B001_01

- 身份：正文
- PDF 页：7
- 偈颂：11
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 11 [present] · PDF page 7

11. Benefics and Malefics: Among these, Surya, Shani,
Mangal, decreasing Chandr, Rahu, and Ketu (the ascending
and the descending nodes of Chandr) are malefics while the
rest are benefics. Buddh, however, is a malefic if he joins
a malefic.
[addition from Santhanam till sloka 12-13]
When Chandr  is ahead of Surya but within 120, she has
medium strength. Between 120 to 240 she is very auspicious,
see ('Atishubhapred'). From 240 to O she is bereft of
strength. This is Yavanas' view, vide P. 70 of my English
Translation of Saravali. This view is, however, related to
Chandr's strength or otherwise, while waning Chandr
(Krishna  Paksh or dark half Chandr) is a malefic and
waxing Chandr  (Shukla Paksh or bright half Chandr) is a
benefic.
Should Chandr  be Yuti with a benefic or receiving a
drishti from a benefic, she turns a benefic, even if in a
waning state.
As regards Buddh, we have clear instructions from Maharishi
Parashar, that he becomes a malefic if he joins a malefic.
If waning Chandr and Buddh are together, both are
benefics.
{grasig}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P007_B002_01

- 身份：正文
- PDF 页：7
- 偈颂：12-13
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 12-13 [present] · PDF page 7

12-13. Grah governances: Surya is the soul of all. Chandr
is the mind. Mangal is one's strength. Buddh is
speech-giver, while Guru confers Knowledge and happiness.
Shukr governs semen (potency), while Shani denotes grief.
{graroy}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P007_B003_01

- 身份：正文
- PDF 页：7
- 偈颂：14-15
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 14-15 [present] · PDF page 7

14-15. Grah cabinet: Of royal status are Surya and Chandr,
while Mangal is the army chief. Prince-apparent is Buddh.
The ministerial grahas are Guru and Shukr. Shani is a
servant. Rahu and Ketu form the grah army.
{gracom}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P007_B004_01

- 身份：正文
- PDF 页：7
- 偈颂：16-17
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 16-17 [present] · PDF page 7

16-17. Complexions of grahas: Surya is blood-red. Chandr is
tawny. Mangal who is not very tall is blood-red, while
Buddh's hue is akin to that of green grass. Tawny,
variegated, and dark are Guru, Shukr, and Shani in their
order.
{gradei}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P007_B005_01

- 身份：正文
- PDF 页：7
- 偈颂：18
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 18 [present] · PDF page 7

18. Deities of grahas: Fire (Agni), Water (Varuna),
Subrahmanya (Lord Shiva's son following Ganesh). Maha
Vishnu, Indra, Shachi Devi (the consort of Lord Indra),
and Brahma are the presiding deities of the 7 grahas in
their order.
{grasex}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P007_B006_01

- 身份：正文
- PDF 页：7
- 偈颂：19
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 19 [present] · PDF page 7

19. Gender of the grahas: Buddh and Shani are neuters.
Chandr and Shukr are females, while Surya, Mangal, and Guru
are males.
{grapri}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P007_B007_01

- 身份：正文
- PDF 页：7
- 偈颂：20
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 20 [present] · PDF page 7

20. Primordial compounds: The Panchabhutas, space, air,
fire, water, and earth, are respectively governed by Guru,
Shani, Mangal, Shukr, and Buddh.
{gracas}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P008_B001_01

- 身份：正文
- PDF 页：8
- 偈颂：21
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 21 [present] · PDF page 8

21. Castes of grahas: Guru and Shukr are Brahmins. Surya is
a royal grah while Chandr and Buddh belong to commercial
community. Shani rules the Sudras (4th caste).
{grasat}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P008_B002_01

- 身份：正文
- PDF 页：8
- 偈颂：22
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 22 [present] · PDF page 8

22. Sattvic grahas are the luminaries and Guru; Shukr and
Buddh are Rajasik; while Mangal and Shani are Tamasic
grahas.
{dessur}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P008_B003_01

- 身份：正文
- PDF 页：8
- 偈颂：23
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 23 [present] · PDF page 8

23. Description of Surya: Surya's eyes are honey coloured.
He has a square body. He is of clean habits, bilious,
intelligent and has limited hair (on his head).
{descha}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P008_B004_01

- 身份：正文
- PDF 页：8
- 偈颂：24
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 24 [present] · PDF page 8

24. Description of Chandr: Chandr  is very windy and
phlegmatic. She is learned and has a round body. She has
auspicious looks and sweet speech, is fickle-minded and
very lustful.
{desman}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P008_B005_01

- 身份：正文
- PDF 页：8
- 偈颂：25
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 25 [present] · PDF page 8

25. Description of Mangal: Mangal has blood-red eyes, is
fickle-minded, liberal, bilious, given to anger and has
thin waist and thin physique.
{desbud}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P008_B006_01

- 身份：正文
- PDF 页：8
- 偈颂：26
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 26 [present] · PDF page 8

26. Description of Buddh: Buddh is endowed with an
attractive physique and the capacity to use words with many
meanings. He is fond of jokes. He has a mix of all the
three humours.
{desgur}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P008_B007_01

- 身份：正文
- PDF 页：8
- 偈颂：27
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 27 [present] · PDF page 8

27. Description of Guru: Guru has a big body, tawny hair
and tawny eyes, is phlegmatic, intelligent and learned in
all Shastras.
{dessuk}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P008_B008_01

- 身份：正文
- PDF 页：8
- 偈颂：28
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 28 [present] · PDF page 8

28. Description of Shukr: Shukr is charming, has a
splendourous physique, is excellent or great in
disposition, has charming eyes, is a poet, is phlegmatic
and windy, and has curly hair.
{dessan}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P008_B009_01

- 身份：正文
- PDF 页：8
- 偈颂：29
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 29 [present] · PDF page 8

29. Description of Shani: Shani has an emaciated and long
physique, has tawny eyes, is windy in temperament has big
teeth, is indolent and lame and has coarse hair.
{desnod}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P008_B010_01

- 身份：正文
- PDF 页：8
- 偈颂：30
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 30 [present] · PDF page 8

30. Description of Rahu and Ketu: Rahu has smoky appearance
with a blue mix physique. He resides in forests and is
horrible. He is windy in temperament and is intelligent.
Ketu is akin to Rahu.
{graing}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P008_B011_01

- 身份：正文
- PDF 页：8
- 偈颂：31
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 31 [present] · PDF page 8

31. Primary ingredients (or Sapth dhatus): Bones, blood,
marrow, skin, fat, semen and muscles are respectively
denoted by the grahas: Surya, Chandr, Mangal, Buddh, Guru,
Shukr, and Shani.
{grapla}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P009_B001_01

- 身份：正文
- PDF 页：9
- 偈颂：32
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 32 [present] · PDF page 9

32. Abodes of the grahas: Temple, watery place, place of
fire, sport-ground, treasure-house, bed-room and filthy
ground: these are respectively the abodes for the seven
grahas from Surya onward.
{gradur}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P009_B002_01

- 身份：正文
- PDF 页：9
- 偈颂：33
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 33 [present] · PDF page 9

33. Grah periods: Ayan, Muhurta, a day (consisting day and
night), Ritu, month, fortnight and year: These are the
periods allotted to the grahas from Surya to Shani.
{gratas}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P009_B003_01

- 身份：正文
- PDF 页：9
- 偈颂：34
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 34 [present] · PDF page 9

34. Tastes of the grahas : Pungent, saline, bitter, mixed,
sweet, acidulous, and astringent are respectively tastes
lorded by Surya, Chandr, Mangal, Buddh, Guru, Shukr, and
Shani.
{grastr}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P009_B004_01

- 身份：正文
- PDF 页：9
- 偈颂：35-38
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 35-38 [present] · PDF page 9

35-38. Strengths of grahas: Strong in the east  are Buddh
and Guru. Surya and Mangal are so in the south, while Shani
is the only grah that derives strength in the west. Chandr
and Shukr are endowed with vigour when in the north. Again,
strong during night are Chandr, Mangal, and Shani while
Buddh is strong during day and night. The rest (i.e. Guru,
Surya, and Shukr) are strong only in daytime. During the
dark half malefics are strong. Benefics acquire strength in
the bright half of the month. Malefics and benefics are
respectively strong in Dakshinayan and Uttarayan. The lords
of the year, month, day, and Hora (hour of grah) are
stronger than the other in ascending order. Again, stronger
than the other in the ascending are: Shani, Mangal, Buddh,
Guru, Shukr, Chandr, and Surya.
{gratre}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P009_B005_01

- 身份：正文
- PDF 页：9
- 偈颂：39-40
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 39-40 [present] · PDF page 9

39-40. Related to trees: Surya rules strong trees (i.e.
trees with stout trunks). Shani useless trees, Chandr milky
trees and rubber yielding plants), Mangal bitter ones (like
lemon plants), Shukr floral plants, Guru fruitful ones and
Buddh fruitless ones.
{graoth}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P009_B006_01

- 身份：正文
- PDF 页：9
- 偈颂：41-44
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 41-44 [present] · PDF page 9

41-44. Other matters: Rahu rules the outcaste while Ketu
governs mixed caste. Shani and the nodes indicate anthills.
Rahu denotes multi-coloured clothes and Ketu rags. Lead and
blue gem belong to Rahu and Ketu. Surya, Chandr, Mangal,
Buddh, Guru, Shukr, and Shani in their order govern red
silken, white silken, red, black silken, saffron, silken,
and multi-coloured robes.
{grasea}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P009_B007_01

- 身份：正文
- PDF 页：9
- 偈颂：45-46
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 45-46 [present] · PDF page 9

45-46. Seasons of grahas: Vasanta, Greeshma, Varsh, Sarad,
Hemanta, and Sisir are the six Ritus (or seasons)
respectively governed by Shukr, Mangal, Chandr, Buddh, Guru
and Shani. Rahu and Ketu denote 8 months and 3 months
respectively.
{gradmj}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P009_B008_01

- 身份：正文
- PDF 页：9
- 偈颂：47
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 47 [present] · PDF page 9

47. Dhatu, Mool, and Jiva Divisions:
Dhatu grahas are Rahu, Mangal, Shani and Chandr, while
Surya and Shukr are Mula grahas. Buddh, Guru, and Ketu rule
Jivas.
{graage}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P010_B001_01

- 身份：正文
- PDF 页：10
- 偈颂：48
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 48 [present] · PDF page 10

48. Age: Out of all the grahas Shani is the eldest (i.e.
with the highest age). He bestows maximum number of years
in Naisargik Dasha.
{graexa}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P010_B002_01

- 身份：正文
- PDF 页：10
- 偈颂：49-50
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 49-50 [present] · PDF page 10

49-50. Exaltation and Debilitation: For the seven grahas
from Surya on, the exaltation rashis are respectively Mesh,
Vrishabh, Makar, Kanya, Kark, Meen, and Tula. The deepest
exaltation degrees are respectively 10, 3, 28, 15, 5, 27,
and 20 in those rashis. And in the seventh rashi from the
said exaltation rashi each grah has its own debilitation.
The same degrees of deep exaltation apply to deep fall.
{gramol}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P010_B003_01

- 身份：正文
- PDF 页：10
- 偈颂：51-54
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 51-54 [present] · PDF page 10

51-54. Additional Dignities: In Simh  the first  20 degrees
are Surya's Mooltrikon while the rest is his own bhava.
After the first 3 degrees of exaltation portion in
Vrishabh, for Chandr,  the rest is her Mooltrikon. Mangal
has the first 12 degrees in Mesh as Mooltrikon with the
rest therein becoming simply his own bhava. For Buddh, in
Kanya the first 15 degrees are exaltation zone, the next 5
degrees Mooltrikon, and the last 10 degrees are own bhava.
The first one third of Dhanu is the Mooltrikon of Guru
while, the remaining part thereof is his own bhava. Shukr
divides Tula into two halves keeping the first as
Mooltrikon and the second as own bhava. Shani's
arrangements are same in Kumbh as Surya has in Simh.
{grarel}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P010_B004_01

- 身份：正文
- PDF 页：10
- 偈颂：55
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 55 [present] · PDF page 10

55. Natural Relationships: Note the rashis which are the
2nd, 4th, 5th, 8th, 9th, and 12th from the Mooltrikon of a
grah. The grahas ruling such rashis are its friends, apart
from the lord of its exaltation rashi. Lords other than
these are its enemies. If a grah becomes its friend as well
as its enemy (on account of the said two computations) then
it is neutral or equal.
{gratem}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P010_B005_01

- 身份：正文
- PDF 页：10
- 偈颂：56
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 56 [present] · PDF page 10

56. Temporary Relationships: The grah posited in the 2nd,
3rd, 4th,10th, 11th, or the 12th from another becomes a
mutual friend. There is enmity otherwise. (This applies to
a given Janm Kundali).
{gracom}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P010_B006_01

- 身份：正文
- PDF 页：10
- 偈颂：57-58
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 57-58 [present] · PDF page 10

57-58. Compound Relationship: Should two grahas  be
naturally and temporarily friendly, they become extremely
friendly. Friendship on one count and neutrality on another
count make them friendly. Enmity on one count combined with
affinity on the other turns into equality. Enmity and
neutralship cause only enmity. Should there be enmity in
both manners, extreme enmity is obtained. The Jyotishi
should consider these and declare horoscopic effects
accordingly.
{graeff}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P011_B001_01

- 身份：正文
- PDF 页：11
- 偈颂：59-60
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 59-60 [present] · PDF page 11

59-60. Ratio of Effects: A grah in exaltation gives fully
good effects while in Mooltrikon it is bereft of its
auspicious effects by one fourth. It is half beneficial in
its own bhava. Its beneficence is one fourth in a friendly
rashi. In an equal's rashi one eighth of auspicious
disposition is useful. The good effects are nil in
debilitation or enemy's camp. Inauspicious effects are
quite reverse with reference to what is stated.
{graupa}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P011_B002_01

- 身份：正文
- PDF 页：11
- 偈颂：61-64
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 61-64 [present] · PDF page 11

61-64. Non-luminous Upagrahas (Sub-grahas):  Add 4 rashis
13 degrees and 20 minutes of arc to Surya's longitude at a
given moment to get the exact position of the all
inauspicious Dhoom. Reduce Dhoom from 12 rashis to arrive
at Vyatipat. Vyatipat is also inauspicious. Add six rashis
to Vyatipat to know the position of Parivesh. He is
extremely inauspicious. Deduct Parivesh from 12 rashis to
arrive at the position of Chap (Indra Dhanus) who is also
inauspicious. Add 16 degrees 40 minutes to Chap which will
give Ketu (Upaketu) who is a malefic. By adding a rashi to
Upaketu, you get the original longitude of Surya. These are
the grahas devoid of splendour which are malefics by nature
and cause affliction.
{upaeff}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P011_B003_01

- 身份：正文
- PDF 页：11
- 偈颂：65
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 65 [present] · PDF page 11

65. Effects of Sub-grahas: If one of these afflicts Surya,
the native's dynasty will decline, while Chandr and Lagn
respectively associated with one of these will destroy the
longevity and wisdom. So declared Lord Brahma, the
lotus-born.
{gulcal}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P011_B004_01

- 身份：正文
- PDF 页：11
- 偈颂：66-69
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 66-69 [present] · PDF page 11

66-69. Calculations of Gulik, etc.: The portions of Surya
etc. up to Shani denote the periods of Gulik and others.
Divide the day duration (of any week day) into eight equal
parts. The eighth portion is lord-less. The seven portions
are distributed to the seven grahas commencing from the
lord of the week day. Whichever portion is ruled by Shani
will be the portion of Gulik. Similarly, make the night
duration into eight equal parts and distribute these
commencing from the lord of the 5th week. Here again, the
eighth portion is lord-less while Shani's portion is Gulik.
Surya's portion is Kaal, Mangal's portion is Mrityu, Guru's
portion is Yamaghantak, and Buddh's portion is Ardhaprahar.
These durations differently apply to different places
(commensurate with variable day and night durations)

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P011_B005_01

- 身份：正文
- PDF 页：11
- 偈颂：70
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 70 [present] · PDF page 11

70. Gulik's Position: The degree ascending at the time of
start of Gulik's portion (as above) will be the longitude
of Gulik at a given place. Based on this longitude only,
Gulik's effects for a particular nativity be estimated.
{pracal}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P012_B001_01

- 身份：正文
- PDF 页：12
- 偈颂：71-74
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 71-74 [present] · PDF page 12

71-74. Calculation of Pranapad: Convert the given time into
vighatis and divide the same by 15. The resultant rashi,
degrees, etc. be added to Surya if he is in a movable rashi
which will yield Pranapad. If Surya is in a fixed rashi,
add 240 degrees additionally and if in a dual rashi add 120
degrees in furtherance to get Pranapad. The birth will be
auspicious if Pranapad falls in the 2nd, 5th, 9th, 4th,
10th, or 11th from the natal Lagn. In other bhavas,
Pranapad indicates an inauspicious birth.
Notes:  Ardhaprahar, Yamaghantak, Mrityu, Kaal, and Gulik
are the 5 Kaal Velas, suggested by Maharishi Parashar. The
day duration according to altitude is divided into eight
equal parts. The eight portion is unlorded. The first
portion is allotted to the weekday lord. Other portions
follow in the order of week-day lords. We consider 5
portions of grahas ignoring that of Chandr and Shukr. The
portions of Surya, Mangal, Buddh, Guru, and Shani are
respectively called  , Mrityu, Ardhaprahar, Yamaghantak,
and Gulik.
In the case of night, the durations or 1/8th parts are
allotted in a different order. The first portion goes to
the grah ruling the 5th weekday lord counted from the day
in question. The others follow in the usual order. Here
again, the 8th part is lord-less. The portions of grahas
from Kaal to Gulik are the same in nomenclature, in the
night also.
Keeranuru Nataraja of Jatakalankaram (Tamil version) gives
rashis of dignities for these Upagrahas and Gulik, etc..:
Upagrah       Exaltation   Debilitation  Swakshetra
& Gulik, etc.                            (own rashi)
Dhoom         Simh         Kumbh         Makar
Vyatipat      Vrischik     Vrishabh      Mithun
Parivesh      Mithun       Dhanu         Dhanu
Indrachap     Dhanu        Mithun        Kark
Upaketu       Kumbh        Simh          Kark
Gulik         -            -             Kumbh
Yamaghantak   -            -             Dhanu
Ardhaprahar   -            -             Mithun
Kaal          -            -             Makar
Mrityu        -            -             Vrischik
From Surya to Shani, no one is exalted in the above
mentioned exaltation rashis, nor debilitated in the above
mentioned debilitation rashis.
Out of the 5 Kaal Velas, viz. Gulik, etc. four except Kaal
(related to Surya) have their own rashi system in the
respective rashis ruled by their fathers. Gulik, son of
Shani, has Kumbh as his own bhava. Guru's son, Yamaghantak,
has it in Dhanu. Ardhaprahar, Buddh's son, is in own rashi
if in Mithun. Mrityu, son of Mangal, has Vrischik as own
bhava. It is not known why Kaal, a son of Surya shifted to
Makar, a rashi of his brother (Shani) leaving his father's
Simh . Obviously, Shani has given his Mooltrikon to his son
Gulik while he gave Makar (a secondary rashi) to his
'brother' Kaal.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P012_B001_02

- 身份：正文
- PDF 页：12
- 偈颂：71-74
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 71-74 [present] · PDF page 12

71-74. Calculation of Pranapad: Convert the given time into
vighatis and divide the same by 15. The resultant rashi,
degrees, etc. be added to Surya if he is in a movable rashi
which will yield Pranapad. If Surya is in a fixed rashi,
add 240 degrees additionally and if in a dual rashi add 120
degrees in furtherance to get Pranapad. The birth will be
auspicious if Pranapad falls in the 2nd, 5th, 9th, 4th,
10th, or 11th from the natal Lagn. In other bhavas,
Pranapad indicates an inauspicious birth.
Notes:  Ardhaprahar, Yamaghantak, Mrityu, Kaal, and Gulik
are the 5 Kaal Velas, suggested by Maharishi Parashar. The
day duration according to altitude is divided into eight
equal parts. The eight portion is unlorded. The first
portion is allotted to the weekday lord. Other portions
follow in the order of week-day lords. We consider 5
portions of grahas ignoring that of Chandr and Shukr. The
portions of Surya, Mangal, Buddh, Guru, and Shani are
respectively called  , Mrityu, Ardhaprahar, Yamaghantak,
and Gulik.
In the case of night, the durations or 1/8th parts are
allotted in a different order. The first portion goes to
the grah ruling the 5th weekday lord counted from the day
in question. The others follow in the usual order. Here
again, the 8th part is lord-less. The portions of grahas
from Kaal to Gulik are the same in nomenclature, in the
night also.
Keeranuru Nataraja of Jatakalankaram (Tamil version) gives
rashis of dignities for these Upagrahas and Gulik, etc..:
Upagrah       Exaltation   Debilitation  Swakshetra
& Gulik, etc.                            (own rashi)
Dhoom         Simh         Kumbh         Makar
Vyatipat      Vrischik     Vrishabh      Mithun
Parivesh      Mithun       Dhanu         Dhanu
Indrachap     Dhanu        Mithun        Kark
Upaketu       Kumbh        Simh          Kark
Gulik         -            -             Kumbh
Yamaghantak   -            -             Dhanu
Ardhaprahar   -            -             Mithun
Kaal          -            -             Makar
Mrityu        -            -             Vrischik
From Surya to Shani, no one is exalted in the above
mentioned exaltation rashis, nor debilitated in the above
mentioned debilitation rashis.
Out of the 5 Kaal Velas, viz. Gulik, etc. four except Kaal
(related to Surya) have their own rashi system in the
respective rashis ruled by their fathers. Gulik, son of
Shani, has Kumbh as his own bhava. Guru's son, Yamaghantak,
has it in Dhanu. Ardhaprahar, Buddh's son, is in own rashi
if in Mithun. Mrityu, son of Mangal, has Vrischik as own
bhava. It is not known why Kaal, a son of Surya shifted to
Makar, a rashi of his brother (Shani) leaving his father's
Simh . Obviously, Shani has given his Mooltrikon to his son
Gulik while he gave Makar (a secondary rashi) to his
'brother' Kaal.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P012_B001_03

- 身份：正文
- PDF 页：12
- 偈颂：71-74
- 标题路径：CHAPTER 3 Grah Characters and Description › 13. Hasta 27. Revati
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Grah Characters and Description · Sloka 71-74 [present] · PDF page 12

71-74. Calculation of Pranapad: Convert the given time into
vighatis and divide the same by 15. The resultant rashi,
degrees, etc. be added to Surya if he is in a movable rashi
which will yield Pranapad. If Surya is in a fixed rashi,
add 240 degrees additionally and if in a dual rashi add 120
degrees in furtherance to get Pranapad. The birth will be
auspicious if Pranapad falls in the 2nd, 5th, 9th, 4th,
10th, or 11th from the natal Lagn. In other bhavas,
Pranapad indicates an inauspicious birth.
Notes:  Ardhaprahar, Yamaghantak, Mrityu, Kaal, and Gulik
are the 5 Kaal Velas, suggested by Maharishi Parashar. The
day duration according to altitude is divided into eight
equal parts. The eight portion is unlorded. The first
portion is allotted to the weekday lord. Other portions
follow in the order of week-day lords. We consider 5
portions of grahas ignoring that of Chandr and Shukr. The
portions of Surya, Mangal, Buddh, Guru, and Shani are
respectively called  , Mrityu, Ardhaprahar, Yamaghantak,
and Gulik.
In the case of night, the durations or 1/8th parts are
allotted in a different order. The first portion goes to
the grah ruling the 5th weekday lord counted from the day
in question. The others follow in the usual order. Here
again, the 8th part is lord-less. The portions of grahas
from Kaal to Gulik are the same in nomenclature, in the
night also.
Keeranuru Nataraja of Jatakalankaram (Tamil version) gives
rashis of dignities for these Upagrahas and Gulik, etc..:
Upagrah       Exaltation   Debilitation  Swakshetra
& Gulik, etc.                            (own rashi)
Dhoom         Simh         Kumbh         Makar
Vyatipat      Vrischik     Vrishabh      Mithun
Parivesh      Mithun       Dhanu         Dhanu
Indrachap     Dhanu        Mithun        Kark
Upaketu       Kumbh        Simh          Kark
Gulik         -            -             Kumbh
Yamaghantak   -            -             Dhanu
Ardhaprahar   -            -             Mithun
Kaal          -            -             Makar
Mrityu        -            -             Vrischik
From Surya to Shani, no one is exalted in the above
mentioned exaltation rashis, nor debilitated in the above
mentioned debilitation rashis.
Out of the 5 Kaal Velas, viz. Gulik, etc. four except Kaal
(related to Surya) have their own rashi system in the
respective rashis ruled by their fathers. Gulik, son of
Shani, has Kumbh as his own bhava. Guru's son, Yamaghantak,
has it in Dhanu. Ardhaprahar, Buddh's son, is in own rashi
if in Mithun. Mrityu, son of Mangal, has Vrischik as own
bhava. It is not known why Kaal, a son of Surya shifted to
Makar, a rashi of his brother (Shani) leaving his father's
Simh . Obviously, Shani has given his Mooltrikon to his son
Gulik while he gave Makar (a secondary rashi) to his
'brother' Kaal.
