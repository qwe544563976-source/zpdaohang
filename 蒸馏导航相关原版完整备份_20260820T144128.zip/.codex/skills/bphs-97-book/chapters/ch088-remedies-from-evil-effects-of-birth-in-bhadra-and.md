# 第 88 章：Remedies from evil effects of birth in Bhadra and

- 来源：BPHS 97 章版
- 原始卡片：3 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P362_B002_01

- 身份：正文
- PDF 页：362
- 偈颂：—
- 标题路径：CHAPTER 88 Remedies from evil effects of birth in Bhadra and › Inauspicious Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from evil effects of birth in Bhadra and · Sloka unknown [unknown] · PDF page 362 · page_block BPHS_PL9_CHAP_97_P362_B002

Inauspicious Yogas

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P362_B003_01

- 身份：正文
- PDF 页：362
- 偈颂：1-2
- 标题路径：CHAPTER 88 Remedies from evil effects of birth in Bhadra and › Inauspicious Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from evil effects of birth in Bhadra and · Sloka 1-2 [present] · PDF page 362

1-2. The Sage said: O Brahmin! Now I am going to describe the
remedial measures for relief from the evil effects of birth
in Bhadra, Tithi Kshaya, Vyatipata, Paridha, Vajra, etc.,
inauspicious Yogas and Yamaghants, etc.. The remedial rites
should be performed on the day when the same inauspicious Yog
operates again.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P362_B004_01

- 身份：正文
- PDF 页：362
- 偈颂：3-5
- 标题路径：CHAPTER 88 Remedies from evil effects of birth in Bhadra and › Inauspicious Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from evil effects of birth in Bhadra and · Sloka 3-5 [present] · PDF page 362

3-5. The remedial rites are to be performed in the following
order by the parents of the child in the above inauspicious
Yogas:
(I) puja of Lord Vishnu and other deities on an auspicious
day and auspicious Lagn on the advice of a proficient
Jyotishi;
(2) burning of deep with ghee in a Shiva temple;
(3) abhisheka of Lord Shiva;
(4) going round a pipal tree 108 times prolongs longevity;
and
(5) perform havan with 108 oblations along with the recital
of 'Vaisneh raratmachityadhi' mantra of Lord Vishnu; and
(6) feeding Brahmins to the best of one's means.
The observance of these remedial measures will give
deliverance to the native from all the evil effects of his
inauspicious birth and he will enjoy happiness.
