# 第 82 章：Effects of Moles, Marks, Signs, etc., for Men

- 来源：BPHS 97 章版
- 原始卡片：11 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P346_B002_01

- 身份：正文
- PDF 页：346
- 偈颂：—
- 标题路径：CHAPTER 82 Effects of Moles, Marks, Signs, etc., for Men › and Women
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Moles, Marks, Signs, etc., for Men · Sloka unknown [unknown] · PDF page 346 · page_block BPHS_PL9_CHAP_97_P346_B002

and Women

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P346_B003_01

- 身份：正文
- PDF 页：346
- 偈颂：1
- 标题路径：CHAPTER 82 Effects of Moles, Marks, Signs, etc., for Men › and Women
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Moles, Marks, Signs, etc., for Men · Sloka 1 [present] · PDF page 346

1. Maharishi Parasara said: O Maitreya! Now I will describe
to you the effects of moles, marks, spots, and signs found on
the body of women and men.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P346_B004_01

- 身份：正文
- PDF 页：346
- 偈颂：2-3
- 标题路径：CHAPTER 82 Effects of Moles, Marks, Signs, etc., for Men › and Women
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Moles, Marks, Signs, etc., for Men · Sloka 2-3 [present] · PDF page 346

2-3. A mole, spot, or figure formed by hair on the left side
of a woman and right side of a man is auspicious. If there is
mole on the chest of a woman, she will be fortunate. A woman
who has a red mark like a mole etc., on her right breast,
begets many children (sons and daughters) and she is blessed
with all kinds of enjoyments and comforts.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P346_B005_01

- 身份：正文
- PDF 页：346
- 偈颂：4
- 标题路径：CHAPTER 82 Effects of Moles, Marks, Signs, etc., for Men › and Women
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Moles, Marks, Signs, etc., for Men · Sloka 4 [present] · PDF page 346

4. The woman who has a red mark (mole) on her left breast
begets only one son.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P346_B006_01

- 身份：正文
- PDF 页：346
- 偈颂：5
- 标题路径：CHAPTER 82 Effects of Moles, Marks, Signs, etc., for Men › and Women
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Moles, Marks, Signs, etc., for Men · Sloka 5 [present] · PDF page 346

5. The woman who has a mole on her right breast begets many
daughters and sons.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P346_B007_01

- 身份：正文
- PDF 页：346
- 偈颂：6
- 标题路径：CHAPTER 82 Effects of Moles, Marks, Signs, etc., for Men › and Women
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Moles, Marks, Signs, etc., for Men · Sloka 6 [present] · PDF page 346

6. There will be gain or acquisition of a kingdom if there as
is a red mole etc., on the forehead or in the middle of
(between) the eye brows. The person will enjoy sweetish
preparations if there is such a mark on the cheeks.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P346_B008_01

- 身份：正文
- PDF 页：346
- 偈颂：7-10
- 标题路径：CHAPTER 82 Effects of Moles, Marks, Signs, etc., for Men › and Women
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Moles, Marks, Signs, etc., for Men · Sloka 7-10 [present] · PDF page 346

7-10. The woman who has a red mark (mole etc.) on her nose
becomes consort of a king (or high dignitary). If the mark be
blackish, the woman concerned becomes an adulteress or widow.
All the marks below the navel are auspicious for both men and
women. If there be moles etc., on the ears, cheeks or neck of
a man, his first issue will be male and he will enjoy good
fortune and happiness. The man who has moles etc., in the
thighs, suffers misery.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P346_B009_01

- 身份：正文
- PDF 页：346
- 偈颂：11
- 标题路径：CHAPTER 82 Effects of Moles, Marks, Signs, etc., for Men › and Women
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Moles, Marks, Signs, etc., for Men · Sloka 11 [present] · PDF page 346

11. The woman who has the sign of trident on her forehead
becomes a queen. Such a mark on the forehead of a man makes
him a king.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P346_B010_01

- 身份：正文
- PDF 页：346
- 偈颂：12
- 标题路径：CHAPTER 82 Effects of Moles, Marks, Signs, etc., for Men › and Women
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Moles, Marks, Signs, etc., for Men · Sloka 12 [present] · PDF page 346

12. A right turned circular hair formation on heart, navel,
hands, right part of the back, and in the portion between sex
organ and navel, is auspicious. Left turned formation is
inauspicious.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P346_B011_01

- 身份：正文
- PDF 页：346
- 偈颂：13-14
- 标题路径：CHAPTER 82 Effects of Moles, Marks, Signs, etc., for Men › and Women
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Moles, Marks, Signs, etc., for Men · Sloka 13-14 [present] · PDF page 346

13-14. Such a hair formation on the waist and private parts
proves inauspicious. If such a formation be on the stomach,
the woman concerned will become a widow. If it be in the
center of the back she will become an adulteress. It will be
inauspicious if it be on the neck, forehead, or center of the
head.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P346_B012_01

- 身份：正文
- PDF 页：346
- 偈颂：15
- 标题路径：CHAPTER 82 Effects of Moles, Marks, Signs, etc., for Men › and Women
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Moles, Marks, Signs, etc., for Men · Sloka 15 [present] · PDF page 346

15. A man with indications of short life, will get his
longevity prolonged by marrying a woman with auspicious or
lucky marks/symbols.
