# 第 53 章：Effects of the Antar Dashas in the Dasha of

- 来源：BPHS 97 章版
- 原始卡片：29 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P222_B002_01

- 身份：正文
- PDF 页：222
- 偈颂：—
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka unknown [unknown] · PDF page 222 · page_block BPHS_PL9_CHAP_97_P222_B002

Chandr
@2122@
Effects of the Antar Dashas of Moon in the Dasha of Chandr
~2E+2O+2K+2T+2AL9+2AL10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P222_B003_01

- 身份：正文
- PDF 页：222
- 偈颂：1-2 1/2
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 1-2 1/2 [present] · PDF page 222

1-2 1/2. Acquisition of horses, elephants, and clothes,
devotion to deities and preceptor, recitation of religious
songs in praise of God, acquisition of a kingdom
(attainment of a high position in government), extreme
happiness and enjoyment and name and fame will be the
beneficial results in the Antar Dasha of Chandr in her own
Dasha, if she is placed in her exaltation Rashi, her own
Rashi, in a Kendr or in a Trikon or is associated with the
lord of Dharm or Karm Bhava.
~2d+2Am+2I6+2I8+2I12~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P222_B004_01

- 身份：正文
- PDF 页：222
- 偈颂：3-6
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 3-6 [present] · PDF page 222

3-6. Loss of wealth, loss of position, lethargy, agony,
antagonism towards the king and ministers, distress to
mother, imprisonment and loss of kinsmen, will be the evil
effects in her Antar Dasha, if Chandr is in her
debilitation Rashi, if Chandr is associated with malefics,
or if Chandr is in Ari, Randhr, or Vyaya Bhava.
~2iL2+2iL7+2AL8+2AL12~
If Chandr is the lord of Dhan or Yuvati Bhava, or is
associated with Randhr's lord or with Vyaya's lord, there
will be pains in the body and danger of premature death.
The remedial measures are giving in charity of a tawny
colored cow or female buffalo.
@2132@
Effects of the Antar Dashas of Mangal in the Dasha of
Chandr
~3K+3T~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P222_B005_01

- 身份：正文
- PDF 页：222
- 偈颂：7-8 1/2
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 7-8 1/2 [present] · PDF page 222

7-8 1/2. Advancement of fortune, recognition by the
government, gain of clothes and ornaments, success in all
efforts, increase in agricultural production and prosperity
at home, and profits in business, will be the favourable
effects of the Antar Dasha of Mangal in the Dasha of
Chandr, if Mangal is in a Kendr or in a Trikon.
~3E+3O~
Great happiness and enjoyment of comforts will be derived
if Mangal is in his exaltation Rashi, or in his own Rashi.
~3I6+3I8+3I12+(3Ia)2*3Am+(3Ia)2*3Dm~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P222_B006_01

- 身份：正文
- PDF 页：222
- 偈颂：9-12
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 9-12 [present] · PDF page 222

9-12. Distress to the body, losses at home and in
agricultural production, losses in business dealings,
antagonism, or adverse relations with servants (employees)
and the king (government), separation from kinsmen and hot
temperament, will be the evil effects in the Antar Dasha of
Mangal, if he is placed in Ari, Randhr, or Vyaya from Lagn,
be associated with or receives a drishti from malefics in
the 6th, the 8th, or the 12th from the Lord of the Dasha
(Chandr).
@2182@
Effects of the Antar Dasha of Rahu in the Dasha of Chandr
~8K+8T~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P223_B001_01

- 身份：正文
- PDF 页：223
- 偈颂：13-14
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 13-14 [present] · PDF page 223

13-14. There will be some auspicious results at the
commencement of the Antar Dasha of Rahu in the Dasha of
Chandr but later there will be danger from the king
(government), thieves, and snakes, distress to cattle, loss
of kinsmen and friends, loss of reputation and mental
agony, if Rahu is placed in a Kendr or in a Trikon.
~8DB+8I3+8I6+8I10+8I11+8Yy~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P223_B002_01

- 身份：正文
- PDF 页：223
- 偈颂：15-16
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 15-16 [present] · PDF page 223

15-16. Success in all ventures, gain of conveyances,
garments, etc., from the king (government), etc., in the
South-West direction, will be derived if Rahu in his Antar
Dasha receives a drishti from benefics, if Rahu is in
Sahaj, Ari, Karm, or Labh Bhava or if Rahu is yuti with a
Yog Karak grah.
~8v*(8I8)2+8v*(8I12)2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P223_B003_01

- 身份：正文
- PDF 页：223
- 偈颂：17-18
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 17-18 [present] · PDF page 223

17-18. Loss of position, mental agony, distress to wife and
children, danger of diseases, danger from the king
(government), scorpions, and snakes, etc., will happen if
Rahu is weak and is placed in the 8th or the 12th from the
lord of the Dasha  (Chandr).
~(8I!K)2+(8I!T)2+(8I3)2+(8I11)2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P223_B004_01

- 身份：正文
- PDF 页：223
- 偈颂：19-21
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 19-21 [present] · PDF page 223

19-21. Pilgrimage to holy places, visits to sacred shrines,
beneficence, inclination towards charitable deeds, etc.,
will be the results, if Rahu is in a Kendr, in a Trikon, or
in the 3rd or the 11th from the lord of the Dasha
(Chandr).
~8I2+8I7~
There will be body troubles (physical afflictions), if Rahu
is in Dhan or in Yuvati Bhava. Rahu Japa and giving a goat
in charity, are the remedial measures, for obtaining relief
from the evil effects in the Antar Dasha of Rahu.
@2152@
Effects of the Antar Dasha of Guru in the Dasha of Chandr
~5K+5T+5E+5O~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P223_B005_01

- 身份：正文
- PDF 页：223
- 偈颂：22-24 1/2
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 22-24 1/2 [present] · PDF page 223

22-24 1/2. Acquisition of a kingdom (attainment of a high
position in government), auspicious celebrations at home,
gains of clothes and ornaments, recognition from the king
(government) beneficence of the Isht lord ('Isht Devata'),
gains of wealth, land, conveyances, success in all ventures
by the  beneficence of the king (government) will be the
beneficial effects in the  Antar Dasha of Guru in the Dasha
of Chandr, if Guru is placed in a Kendr or in a Trikon to
Lagn, or if Guru is in his own Rashi, or in his exaltation
Rashi.
~5I6+5I8+5I12+5c+5Am~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P224_B001_01

- 身份：正文
- PDF 页：224
- 偈颂：25-28 1/2
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 25-28 1/2 [present] · PDF page 224

25-28 1/2. Destruction of preceptor (and father, etc.) and
children, loss of position, mental agony, quarrels,
destruction of a house, conveyances and agricultural land,
will be the evil effects in his Antar Dasha, if Guru is in
Ari, Randhr, or in Vyaya Bhava, if Guru is combust, in his
debilitation Rashi, or be associated with malefics.
~(5I3)2+(5I11)2~
Gains of cattle, grains, clothes and happiness from
brothers, acquisition of property, valour, patience,
oblations, celebrations like marriage, etc., gain of a
kingdom (attainment of a high position in government),
etc., will be the favourable effects, if Guru is in 3rd or
in the 11th from the lord of the Dasha (Chandr).
~5v*(5I6)2+5v*(5I8)2+5v*(5I12)2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P224_B002_01

- 身份：正文
- PDF 页：224
- 偈颂：29-31
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 29-31 [present] · PDF page 224

29-31. Effects like unpalatable food, journeys to places
away from the homeland, will be derived, if Guru is weak
and is placed in the 6th, the 8th or the 12th from Chandr.
There will be good effects at the commencement of the Antar
Dasha and distress at its end.
~5iL2+5iL7~
There will be premature death if Guru is Dhan's Lord or
Yuvati's lord. Remedial measures for obtaining relief from
the above evil effects are recitation of Shiva Sahasranam
Japa and giving gold in charity.
@2172@
Effects of the Antar Dasha of Shani in the Dasha of Chandr
~7K+7T+7O+7NE+7AB+7DB+7I11*7X~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P224_B003_01

- 身份：正文
- PDF 页：224
- 偈颂：32-34
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 32-34 [present] · PDF page 224

32-34. Effects like birth of a son, friendship, gain of
wealth and property, profits in business with the help of
Sudras, increase in agricultural production, gains from
son, riches and glory by the beneficence of the king
(government), will be experienced in the Antar Dasha of
Shani in the Dasha of Chandr, if Shani is in a Kendr or in
a Trikon from Lagn, or if Shani is in his own Rashi, in his
own Navamsh, in his exaltation Rashi, if Shani receives a
drishti from or is associated with benefics, or if Shani is
in Labh Bhava with strength.
~7I6+7I8+7I12+7I2+7d~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P224_B004_01

- 身份：正文
- PDF 页：224
- 偈颂：35-35 1/2
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 35-35 1/2 [present] · PDF page 224

35-35 1/2. Effects like visits to holy places, bathing in
holy rivers, etc., the creation of troubles by many people
and distress from enemies, will be derived in the Antar
Dasha of Shani if Shani is in Ari, in Randhr, in Vyaya or
in Dhan Bhava, or if Shani is in his debilitation Rashi.
~(7I!K)2+(7I!T)2+7X~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P224_B005_01

- 身份：正文
- PDF 页：224
- 偈颂：36-38
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 36-38 [present] · PDF page 224

36-38. Effects like enjoyments, and gains of wealth some
times, while opposition or quarrels with wife and children
at other times, will be realized, if Shani is in a Kendr or
in a Trikon from the lord of that Dasha (Chandr) or is
endowed with strength.
~7I2+7I7+7I8~
If Shani is in Dhan, Yuvati, or Randhr Bhava there will be
physical distress. The remedial measures to be adopted for
obtaining relief from the evil effects, are Mrityunjaya
Japa, giving in charity a black cow or female buffalo.
@2142@
Effects of the Antar Dasha of Buddh in the Dasha of Chandr
~4K+4T+4O+4NO+4E+4X~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P225_B001_01

- 身份：正文
- PDF 页：225
- 偈颂：39-41
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 39-41 [present] · PDF page 225

39-41. Effects like acquisition of wealth, recognition by
the king (government), gain of clothes etc., discussions on
Shastras (Vedic scriptures), gain of knowledge from society
with learned and holy people, enjoyments, birth of
children, satisfaction, profits in business, acquisition of
conveyance and ornaments, etc., will be experienced in the
Antar Dasha of Buddh in the Dasha of Chandr, if Buddh is in
a Kendr or in a Trikon, if Buddh is in his own Rashi, in
his own Navamsh, or in his exaltation Rashi endowed with
strength.
~(4I!K)2+(4I!T)2+(4I11)2+(4I2)2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P225_B002_01

- 身份：正文
- PDF 页：225
- 偈颂：42-43 1/2
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 42-43 1/2 [present] · PDF page 225

42-43 1/2. Effects like marriage, oblations ('Yagya'),
charities, performance of religious rites, close relations
with the king (government), social contacts with men of
learning, acquisition of pearls, corals, Mani (jewels),
conveyances, clothes, ornaments, good health, affections,
enjoyments, drinking of Soma Rasa, and other tasty syrups,
etc., will be derived in the Antar Dasha of Buddh, if he is
in a Kendr or in a Trikon, or in the 11th or in the 2nd
from the lord of the Dasha (Chandr).
~(4I6)2+(4I8)2+(4I12)2+4d~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P225_B003_01

- 身份：正文
- PDF 页：225
- 偈颂：44-46
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 44-46 [present] · PDF page 225

44-46. Pains in the body, loss in agricultural ventures
imprisonment, distress to wife and children, will be the
inauspicious effects, if Buddh be in the 6th, the 8th or
the 12th from the lord of the Dasha (Chandr) or be in his
debilitation Rashi.
~4iL2+4iL7~
If Buddh is the lord of Dhan or Yuvati Bhava, there will be
fear of fever. The remedial measures to be adopted for
obtaining relief from the evil effects, are recitation of
Vishnu Sahasranam and giving a goat in charity.
@2192@
Effects of the Antar Dasha of Ketu in the Dasha of Chandr
~9K*9X+9T*9X+9I3*9X~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P225_B004_01

- 身份：正文
- PDF 页：225
- 偈颂：47-48
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 47-48 [present] · PDF page 225

47-48. Effects like gain of wealth, enjoyment, happiness to
wife and children, religious inclination, etc., will arise
in the Antar Dasha of Ketu in the Dasha of Chandr, if Ketu
is in a Kendr, in a Trikon, or Sahaj Bhava and is endowed
with strength. There will be some loss of wealth at the
commencement of the Antar Dasha. Later all will be well.
~(9I!K)2*9X+(9I9)2*9X+(9I5)2*9X+(9I11)2*9X~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P225_B005_01

- 身份：正文
- PDF 页：225
- 偈颂：49-49 1/2
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 49-49 1/2 [present] · PDF page 225

49-49 1/2. Gain of wealth, cattle, etc., will be the
effects if Ketu is in a Kendr, in the 9th, the 5th, or the
11th from the lord of the Dasha (Chandr) and is equipped
with strength. There will be loss of wealth at the end of
the Antar Dasha.
~(9I8)2+(9I12)2+9Am+9Dm~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P226_B001_01

- 身份：正文
- PDF 页：226
- 偈颂：50-52
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 50-52 [present] · PDF page 226

50-52. There will be obstacles in ventures due to
interference by enemies and quarrels, if Ketu be in the 8th
or the 12th from the lord of the Dasha (Chandr) or receives
a drishti from or is associated with malefics.
~9I2+9I7~
If Ketu is in Dhan or in Yuvati Bhava there will be danger
of affliction of the body with diseases. Mrityunjaya Japa
will give relief in all the evil effects and will ensure
gain of wealth and property with the beneficence of lord
Shiva.
@2162@
Effects of the Antar Dasha of Shukr in the Dasha of Chandr
~6K+6T+6I11+6I4+6I9+9E+9O~
Effects like acquisition of a kingdom (attainment of a high
position in government), gaining of clothes, ornaments,
cattle, conveyances, etc., happiness to wife and children,
construction of a new house, availability of sweet
preparations every day, use of perfumes, affairs with
beautiful women, sound health, etc., will be experienced in
the Antar Dasha of Shukr in the Dasha of Chandr, if Shukr
is in a Kendr, in a Trikon, in Labh, Bandhu, or Dharm Bhava
4th, or in his exaltation Rashi, or in his own Rashi.
~6Y2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P226_B002_01

- 身份：正文
- PDF 页：226
- 偈颂：56
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 56 [present] · PDF page 226

56. Physical soundness, good reputation, acquisition of
more land and houses, will result, if Shukr is yuti with
the lord of the Dasha (Chandr).
~6d+6c+6Am+6Dm~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P226_B003_01

- 身份：正文
- PDF 页：226
- 偈颂：57-57 1/2
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 57-57 1/2 [present] · PDF page 226

57-57 1/2. There will be loss of landed property, children,
wife and cattle, and opposition from government, if Shukr
is in his debilitation Rashi, combust, or receives a
drishti from or is associated with malefics.
~6I2*6E+6I2*6O+6AL11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P226_B004_01

- 身份：正文
- PDF 页：226
- 偈颂：58-60
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 58-60 [present] · PDF page 226

58-60. If Shukr is in Dhan Bhava in his exaltation Rashi
or in his own Rashi, or is there associated with the lord
of Labh Bhava, there will be acquisition of an underground
hidden treasure, gain of land, enjoyment, birth of a son,
etc..
~6YL9+6YL11~
Advancement of good fortune, fulfillment of ambitions with
the beneficence of the king (government), devotion to
deities and Brahmins, gain of jewels like pearls, etc.,
will result if Shukr is yuti with Dharm's lord, or with
Labh's lord.
~(6I!K)2+(6I!T)2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P226_B005_01

- 身份：正文
- PDF 页：226
- 偈颂：61
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 61 [present] · PDF page 226

61. Acquisition of more house property and agricultural
land, and gain of wealth and enjoyment will be the good
effects if Shukr is in a Kendr or in a Trikon from the lord
of the Dasha (Chandr).
~(6I6)2+(6I8)2+(6I12)2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P226_B006_01

- 身份：正文
- PDF 页：226
- 偈颂：62
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 62 [present] · PDF page 226

62. Deportation to foreign lands, sorrows, death and danger
from thieves and snakes will be the results, if Shukr is in
the 6th, the 8th, or the 12th from the lord of the Dasha
(Chandr).
~6iL2+6iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P227_B001_01

- 身份：正文
- PDF 页：227
- 偈颂：63-64
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 63-64 [present] · PDF page 227

63-64. There will be danger of premature death, if Shukr be
the lord of the 2nd or 7th. The remedial measures to be
adopted for obtaining relief from the evil effects, are
Rudra Japa and giving in charity a white cow and silver.
@2112@
Effects of the Antar Dasha of Surya in the Dasha of Chandr
~1E+1O+1K+1I5+1I9+1I11+1I2+1I3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P227_B002_01

- 身份：正文
- PDF 页：227
- 偈颂：65-67
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 65-67 [present] · PDF page 227

65-67. Recovery of a lost kingdom (high position in
government) and wealth, happiness in the family,
acquisition of villages and land with then kind assistance
of one's friends and the king (government), birth of a son,
beneficence of Goddess Lakshmi, will be the beneficial
results in the Antar Dasha of Surya in the Dasha of Chandr,
if Surya is in his exaltation Rashi, in his own Rashi, in a
Kendr, or in Putr, or in Dharm, or in Labh, or in Dhan, or
in Sahaj Bhava. At the end of the Antar Dasha, there is the
likelihood of attacks of fever and lethargy.
~(1I8)2+(1I12)2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P227_B003_01

- 身份：正文
- PDF 页：227
- 偈颂：68-70
- 标题路径：CHAPTER 53 Effects of the Antar Dashas in the Dasha of › Chandr @2122@ Effects of the Antar Dashas of Moon in the Dasha of Chandr ~2E+2O+2K+2T+2AL9+2AL10~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 68-70 [present] · PDF page 227

68-70. Danger from the government, thieves, and snakes,
affliction with fever and troubles in foreign journey are
the likely results if Surya is in the 8th or in the 12th
from the lord of the Dasha (Chandr).
~1iL2+1iL7~
If Surya is the lord of Dhan or Yuvati Bhava, there will be
sufferings from fever in his Antar Dasha. Worship of Lord
Shiva is the remedial measure to obtain relief from the
above evil effects.
