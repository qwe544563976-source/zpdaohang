# 第 5 章：Special Lagnas

- 来源：BPHS 97 章版
- 原始卡片：9 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P016_B002_01

- 身份：正文
- PDF 页：16
- 偈颂：1
- 标题路径：CHAPTER 5 Special Lagnas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Special Lagnas · Sloka 1 [present] · PDF page 16

1. Oh excellent of the Brahmins, I explain below again some
special Lagnas, viz. Bhava Lagn, Hora Lagn, and Ghati
Lagn.
{lagbha}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P016_B003_01

- 身份：正文
- PDF 页：16
- 偈颂：2-3
- 标题路径：CHAPTER 5 Special Lagnas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Special Lagnas · Sloka 2-3 [present] · PDF page 16

2-3. Bhava Lagn: From sunrise to the time of birth every 5
ghatis (or 120 minutes) constitute one Bhava Lagn. Divide
the time of birth (in ghatis, vighatis, etc.) from sunrise
by 5 and add the quotient etc. to Surya's longitude as at
sunrise. This is called Bhava Lagn.
{laghor}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P016_B004_01

- 身份：正文
- PDF 页：16
- 偈颂：4-5
- 标题路径：CHAPTER 5 Special Lagnas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Special Lagnas · Sloka 4-5 [present] · PDF page 16

4-5. Hora Lagn: Again from sunrise till the time of birth,
Hora Lagn repeats itself every 21/2 ghatis (i. e. 60
minutes). Divide the time past up to birth from sunrise by
2 1/2 and add the quotient etc. in rashis, degrees, and so
on to the longitude of Surya as at the sunrise. This will
yield Hora Lagn in rashi, degrees, etc..
{laggha}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P016_B005_01

- 身份：正文
- PDF 页：16
- 偈颂：6-8
- 标题路径：CHAPTER 5 Special Lagnas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Special Lagnas · Sloka 6-8 [present] · PDF page 16

6-8. Ghati Lagn (Ghatik Lagn): Now listen to the method of
working out Ghati Lagn. This Lagn changes along with every
Ghati (24 minutes) from the sunrise. Note birth time in
ghatis and vighatis. Consider the number of ghatis past as
number of rashis or Ghati Lagnas. The vighatis be divided
by 2 to arrive at degrees and minutes of arc past in the
said Ghati Lagn. The product so arrived in rashis, degrees,
and minutes be added to Surya's longitude as at sunrise to
get the exact location of Ghati Lagn. So, say Maharishis
like Narada.
{speuse}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P016_B006_01

- 身份：正文
- PDF 页：16
- 偈颂：9
- 标题路径：CHAPTER 5 Special Lagnas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Special Lagnas · Sloka 9 [present] · PDF page 16

9. Use of Special Lagnas: Keeping the grahas at birth as it
is, prepare various bhava kundalis with respect to each
special Lagn and analyze as done for the natal Lagn.
{dasvar}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P016_B007_01

- 身份：正文
- PDF 页：16
- 偈颂：10-13 1/2
- 标题路径：CHAPTER 5 Special Lagnas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Special Lagnas · Sloka 10-13 1/2 [present] · PDF page 16

10-13 1/2. Varnad Dasha: I now detail Varnad Dasha just by
knowing which, one can deal with the longevity of a native.
If the natal Lagn  is an odd rashi count directly from to
natal Lagn. If the natal Lagn is an even rashi, count from
Meen to the natal Lagn, in the reverse order. Similarly, if
the Hora Lagn is an odd one, count from Mesh to Hora Lagn
in direct order. If the Hora Lagn is an even one, count
from Meen to Hora Lagn in the reverse order. If both the
products are odd rashis or even rashis, then add both the
figures. If one is odd and the other is even, then know the
difference between the two products. If the latest product,
in  this process, is an odd one, count so many rashis from
Mesh in a direct manner, if an even one, count so many
rashis from Meen in reverse order. The rashi so known will
be the Varnad for Lagn.
{vareff}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P017_B001_01

- 身份：正文
- PDF 页：17
- 偈颂：14-15
- 标题路径：CHAPTER 5 Special Lagnas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Special Lagnas · Sloka 14-15 [present] · PDF page 17

14-15. Effects of Varnad: Now, listen to the use of the
above. Out of the two, viz. natal Lagn and Hora Lagn,
whichever is stronger, from there Varnad starts. If the
natal Lagn is an old rashi, the counting of dashas is
clockwise, otherwise anticlockwise. Lagn dasha years will
equal the number of rashis intervening between the natal
Lagn and Varnad. Similarly, for other bhavas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P017_B002_01

- 身份：正文
- PDF 页：17
- 偈颂：16-20
- 标题路径：CHAPTER 5 Special Lagnas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Special Lagnas · Sloka 16-20 [present] · PDF page 17

16-20. Effects of Varnad (cont.): Should a Kon from Lagn 's
Varnad be occupied or drishtied by a malefic, the native
will live only up to the dasha of the said rashi. Just as
the Rudra grah in Sool Dasha is capable of causing evils,
the above mentioned grahas related to Varnad's Kon be
treated. The Varnad Lagn be considered as natal Lagn while
the 7th from Varnad will denote the longevity of the
spouse, the 11th longevity of elder brothers and sisters,
the 3rd longevity of younger brothers and sisters, the 5th
the longevity of sons, the 4th longevity of mother and the
9th longevity of father. The Dasha of the Sool rashi will
inflict greater evils.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P017_B003_01

- 身份：正文
- PDF 页：17
- 偈颂：21-24
- 标题路径：CHAPTER 5 Special Lagnas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Special Lagnas · Sloka 21-24 [present] · PDF page 17

21-24. Effects of Varnad (cont.): Similar assessments be
made with reference to the Varnad of each bhava commencing
the first and the evils and goods due to a nativity be
known. These Varnad Dashas are  only for bhavas (rashis)
and not their occupants. The sub period  of each Dasha will
be one twelfth of the Dasha and the order will also be
clockwise or anti-clockwise as explained  earlier. The
natal Lagn  is to be calculated according to birth place
while Bhava Lagn, Hora Lagn, etc., are common to all
places.
