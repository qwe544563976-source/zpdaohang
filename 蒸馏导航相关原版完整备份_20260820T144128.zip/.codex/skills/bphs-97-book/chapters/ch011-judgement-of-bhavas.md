# 第 11 章：Judgement of Bhavas

- 来源：BPHS 97 章版
- 原始卡片：14 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P031_B002_01

- 身份：正文
- PDF 页：31
- 偈颂：1
- 标题路径：CHAPTER 11 Judgement of Bhavas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Judgement of Bhavas · Sloka 1 [present] · PDF page 31

1. O Maharishi Parashar, I have come to know of the evils
and antidotes thereof as well from you. Please tell me,
what is to be deduced from each bhava.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P031_B003_01

- 身份：正文
- PDF 页：31
- 偈颂：2
- 标题路径：CHAPTER 11 Judgement of Bhavas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Judgement of Bhavas · Sloka 2 [present] · PDF page 31

2. Indications of Tanu Bhava: Maharishi Parashar replies:
physique, appearance, intellect (or the organ of
intelligence, i.e. brain), complexion of the body, vigour,
weakness, happiness, grief, and innate nature are all to be
guessed through the ascending rashi.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P031_B004_01

- 身份：正文
- PDF 页：31
- 偈颂：3
- 标题路径：CHAPTER 11 Judgement of Bhavas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Judgement of Bhavas · Sloka 3 [present] · PDF page 31

3. Indications of Dhan Bhava: Wealth, grains (food etc.),
family, death, enemies, metals, precious stones etc. are to
be understood through Dhan Bhava.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P031_B005_01

- 身份：正文
- PDF 页：31
- 偈颂：4
- 标题路径：CHAPTER 11 Judgement of Bhavas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Judgement of Bhavas · Sloka 4 [present] · PDF page 31

4. Indications of Sahaj Bhava: From Sahaj Bhava, know of
the following: valour, servants (attending, etc.),
brothers, sisters, etc. initiatory instructions (Upadesh),
journey, and parent's death.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P031_B006_01

- 身份：正文
- PDF 页：31
- 偈颂：5
- 标题路径：CHAPTER 11 Judgement of Bhavas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Judgement of Bhavas · Sloka 5 [present] · PDF page 31

5. Indications of Bandhu Bhava: Conveyances, relatives,
mother, happiness, treasure, lands and buildings are to be
consulted through Bandhu Bhava.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P031_B007_01

- 身份：正文
- PDF 页：31
- 偈颂：6
- 标题路径：CHAPTER 11 Judgement of Bhavas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Judgement of Bhavas · Sloka 6 [present] · PDF page 31

6. Indications of Putr Bhava: The learned should deduce
from Putr Bhava: amulets, sacred spells, learning,
knowledge, sons, royalty (or authority), fall of position,
etc..

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P031_B008_01

- 身份：正文
- PDF 页：31
- 偈颂：7
- 标题路径：CHAPTER 11 Judgement of Bhavas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Judgement of Bhavas · Sloka 7 [present] · PDF page 31

7. Indications of Ari Bhava: Maternal uncle, doubts about
death, enemies, ulcers, step-mother, etc., are to be
estimated from Ari Bhava.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P031_B009_01

- 身份：正文
- PDF 页：31
- 偈颂：8
- 标题路径：CHAPTER 11 Judgement of Bhavas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Judgement of Bhavas · Sloka 8 [present] · PDF page 31

8. Indications of Yuvati Bhava: Wife, travel, trade, loss
of sight, death, etc., be known from Yuvati Bhava.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P031_B010_01

- 身份：正文
- PDF 页：31
- 偈颂：9
- 标题路径：CHAPTER 11 Judgement of Bhavas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Judgement of Bhavas · Sloka 9 [present] · PDF page 31

9. Indications of Randhr Bhava: Randhr Bhava indicates
longevity, battle, enemies, forts, wealth of the dead, and
things that have happened and are to happen (in the past
and future births).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P031_B011_01

- 身份：正文
- PDF 页：31
- 偈颂：10
- 标题路径：CHAPTER 11 Judgement of Bhavas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Judgement of Bhavas · Sloka 10 [present] · PDF page 31

10. Indications of Dharm Bhava: Fortunes, wife's brother,
religion, brother's wife, visits to shrines, etc., be known
from Dharm Bhava.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P031_B012_01

- 身份：正文
- PDF 页：31
- 偈颂：11
- 标题路径：CHAPTER 11 Judgement of Bhavas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Judgement of Bhavas · Sloka 11 [present] · PDF page 31

11. Indications of Karm Bhava: Royalty (authority), place,
profession (livelihood), honour, father, living in foreign
lands and debts are to be understood from Karm Bhava.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P031_B013_01

- 身份：正文
- PDF 页：31
- 偈颂：12
- 标题路径：CHAPTER 11 Judgement of Bhavas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Judgement of Bhavas · Sloka 12 [present] · PDF page 31

12. Indications of Labh Bhava: All articles, son's wife,
income, prosperity, quadrupeds, etc., are to be understood
from Labh Bhava.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P031_B014_01

- 身份：正文
- PDF 页：31
- 偈颂：13
- 标题路径：CHAPTER 11 Judgement of Bhavas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Judgement of Bhavas · Sloka 13 [present] · PDF page 31

13. Indications of Vyaya Bhava: From Vyaya Bhava, one can
know about expenses, history of enemies, one's own death,
etc..

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P032_B001_01

- 身份：正文
- PDF 页：32
- 偈颂：14-16
- 标题路径：CHAPTER 11 Judgement of Bhavas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Judgement of Bhavas · Sloka 14-16 [present] · PDF page 32

14-16. Prosperity or Annihilation of a Bhava: Predict
prosperity of the bhava which is yuti with or drishtied by
a benefic. Also, when its lord is in Yuvavastha or
Prabuddhavastha or in Kismaravastha or in Karm Bhava, the
bhavas well-being is indicated. The bhava which is not
drishtied by its lord or whose lord is with a malefic grah
or with one of the lords of evil and such other bhavas
(i.e. 3rd, 6th, 8th, 11th, and 12th) or is defeated in a
war between grahas or is in one of the three Avasthas, viz,
Vriddhavastha, Mritavastht, and Suptavastha.
