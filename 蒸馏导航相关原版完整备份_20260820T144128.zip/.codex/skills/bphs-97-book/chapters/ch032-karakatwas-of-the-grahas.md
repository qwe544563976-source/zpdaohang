# 第 32 章：Karakatwas of the Grahas

- 来源：BPHS 97 章版
- 原始卡片：17 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P105_B002_01

- 身份：正文
- PDF 页：105
- 偈颂：1-2
- 标题路径：CHAPTER 32 Karakatwas of the Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Karakatwas of the Grahas · Sloka 1-2 [present] · PDF page 105

1-2. I now detail below Atma Karak, etc., obtainable from
among the 7 grahas, viz. Surya to Shani. Some say that Rahu
will become a Karak when there is a state of similarity in
terms of longitude between (two) grahas. Yet, some say that
the 8 grahas including Rahu will have to be considered
irrespective of such a state.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P105_B003_01

- 身份：正文
- PDF 页：105
- 偈颂：3-8
- 标题路径：CHAPTER 32 Karakatwas of the Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Karakatwas of the Grahas · Sloka 3-8 [present] · PDF page 105

3-8. Atma Karak Defined: Among the grahas from Surya, etc.,
whichever has traversed maximum number of degrees in a
particular rashi is called Atma Karak. If the degrees are
identical, then the one with more minutes of arc, and if
the minutes are also identical then the one with higher
seconds of arc, have to be considered. In that case, these
three are called Anthya Karak, Madhya Karak, and Upakheta.
In the case of Rahu, deduct his longitude in that
particular rashi from 30. The karakas will have to be
decided as above and as per further rules given below. Out
of these Karakas, Atma Karak is the most important and has
a prime say on the native just as the king is the most
famous among the men of his country and is the head of all
affairs and is entitled to arrest and release men.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P105_B004_01

- 身份：正文
- PDF 页：105
- 偈颂：9-12
- 标题路径：CHAPTER 32 Karakatwas of the Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Karakatwas of the Grahas · Sloka 9-12 [present] · PDF page 105

9-12. Importance of Atma Karak: O Brahmin, as the minister
cannot go against the king, the other karakas, viz, Putr
Karak, Amatya Karak, etc., cannot predominate over Atma
Karak in the affairs of the native. If the Atma Karak is
adverse, other karakas cannot give their benefic effects
(fully). Similarly, if Atma Karak is favourable, other
karakas cannot predominate with their malefic influences.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P105_B005_01

- 身份：正文
- PDF 页：105
- 偈颂：13-17
- 标题路径：CHAPTER 32 Karakatwas of the Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Karakatwas of the Grahas · Sloka 13-17 [present] · PDF page 105

13-17. Other Karakas: The grah next to Atma Karak in terms
of longitude is called Amatya Karak. Similarly, following
one another in terms of longitude are Bhratru Karak, Matru
Karak, Pitru Karak, Putr Karak, Gnati Karak, and Stri
Karak. These are Char karakas or inconstant significators.
Some consider Matru Karak and Putr Karak as identical. If
two grahas have the same longitude, both become the same
Karak in which case there will be a deficit of one Karak.
In that circumstance, consider constant significator in the
context of benefic/malefic influence for the concerned
relative.
Notes: A total of eight Char Karakas (inconstant, or
variable significators) are suggested as under:

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P105_B006_01

- 身份：正文
- PDF 页：105
- 偈颂：1
- 标题路径：CHAPTER 32 Karakatwas of the Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Karakatwas of the Grahas · Sloka 1 [present] · PDF page 105

1. Atma Karak (highest in longitude devoid of rashis)

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P105_B007_01

- 身份：正文
- PDF 页：105
- 偈颂：2
- 标题路径：CHAPTER 32 Karakatwas of the Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Karakatwas of the Grahas · Sloka 2 [present] · PDF page 105

2. Amatya Karak (next to Atma Karak in longitude)

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P105_B008_01

- 身份：正文
- PDF 页：105
- 偈颂：3
- 标题路径：CHAPTER 32 Karakatwas of the Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Karakatwas of the Grahas · Sloka 3 [present] · PDF page 105

3. Bhratru Karak (next to Amatya Karak in longitude)

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P105_B009_01

- 身份：正文
- PDF 页：105
- 偈颂：4
- 标题路径：CHAPTER 32 Karakatwas of the Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Karakatwas of the Grahas · Sloka 4 [present] · PDF page 105

4. Matru Karak (next to Bhratru Karak in longitude)

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P105_B010_01

- 身份：正文
- PDF 页：105
- 偈颂：5
- 标题路径：CHAPTER 32 Karakatwas of the Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Karakatwas of the Grahas · Sloka 5 [present] · PDF page 105

5. Pitru Karak (next to Matru Karak in longitude)

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P105_B011_01

- 身份：正文
- PDF 页：105
- 偈颂：6
- 标题路径：CHAPTER 32 Karakatwas of the Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Karakatwas of the Grahas · Sloka 6 [present] · PDF page 105

6. Putr Karak (next to Pitru Karak in longitude)

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P105_B012_01

- 身份：正文
- PDF 页：105
- 偈颂：7
- 标题路径：CHAPTER 32 Karakatwas of the Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Karakatwas of the Grahas · Sloka 7 [present] · PDF page 105

7. Gnati Karak (next to Putr Karak in longitude)

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P105_B013_01

- 身份：正文
- PDF 页：105
- 偈颂：8
- 标题路径：CHAPTER 32 Karakatwas of the Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Karakatwas of the Grahas · Sloka 8 [present] · PDF page 105

8. Stri Karak (next to Gnati Karak in longitude)

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P106_B001_01

- 身份：正文
- PDF 页：106
- 偈颂：18-21
- 标题路径：CHAPTER 32 Karakatwas of the Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Karakatwas of the Grahas · Sloka 18-21 [present] · PDF page 106

18-21. Constant Karakatwas: I narrate below the constant
Karakatwas as related to the grahas. The stronger among
Surya and Shukr indicates the father, while the stronger
among Chandr and Mangal indicates the mother. Mangal
denotes sister, brother-in-law, younger brother, and
mother. Buddh rules maternal relative, while Guru indicates
paternal grand father. Husband and sons are respectively
denoted by Shukr and Shani. From Ketu note wife, father,
mother, parents-in law and maternal grand father. These are
constant Karakatwas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P106_B002_01

- 身份：正文
- PDF 页：106
- 偈颂：22-24
- 标题路径：CHAPTER 32 Karakatwas of the Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Karakatwas of the Grahas · Sloka 22-24 [present] · PDF page 106

22-24. Bhavas Related: These constant significances are
derivable from the bhavas counted from the said constant
Karakatwas. The 9th from Surya denotes father, the 4th from
Chandr mother, the 3rd from Mangal brothers, the 6th from
Buddh maternal uncle, the 5th from Guru sons, the 7th from
Shukr wife, and the 8th from Shani death. The learned
should consider all these and declare related effects
accordingly.
Notes: From these three verses, the constant Karakas emerge
as under as normally discussed in standard literature on
Jyotish:
Surya : father
Chandr : mother
Mangal : brothers (and sisters)
Buddh : maternal relatives
Guru : Sons (and daughters)
Shukr : wife (or husband)
Shani : death (or longevity)

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P106_B003_01

- 身份：正文
- PDF 页：106
- 偈颂：25-30
- 标题路径：CHAPTER 32 Karakatwas of the Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Karakatwas of the Grahas · Sloka 25-30 [present] · PDF page 106

25-30. Yog Karakas: O Brahmin, I make below a passing
reference to Yog Karakas (or mutual co-workers). Grahas
become Yog Karakas if they are in mutual angles identical
with own rashis, exaltation rashis, or friendly rashis. In
Karm Bhava, a grah will be significantly so. Grahas simply
(i. e. not being in friendly, own, or exaltation rashis) in
Lagn, Bandhu and Yuvati Bhava, do not become such Yog
Karakas. Even if they be placed in other bhavas, but with
such dignities as mentioned shall become Yog Karakas. With
such grahas, even a person of mean birth will become a king
and be affluent. One born of royal scion then, will surely
become a king. Thus, the effects be declared considering
the number of such grahas and the order the native belongs
to.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P106_B004_01

- 身份：正文
- PDF 页：106
- 偈颂：31-34
- 标题路径：CHAPTER 32 Karakatwas of the Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Karakatwas of the Grahas · Sloka 31-34 [present] · PDF page 106

31-34. Bhava Significance: I now narrate the significance
of the bhavas. Tanu Bhava denotes the soul (self), Dhan
Bhava family, finance, wife, etc., Sahaj Bhava younger
brothers/sisters, Putr Bhava progeny, and Yuvati Bhava
wife. It is also said that a grah in Putr Bhava becomes a
Karak for wife. The Karakatwas of the bhava in order are:
Surya, Guru, Mangal, Chandr, Guru, Mangal, Shukr, Shani,
Guru, Buddh, Guru, and Shani.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P107_B001_01

- 身份：正文
- PDF 页：107
- 偈颂：35-37
- 标题路径：CHAPTER 32 Karakatwas of the Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Karakatwas of the Grahas · Sloka 35-37 [present] · PDF page 107

35-37. O excellent of the Brahmins, after knowing the
merits of Tanu Bhava, etc., the good and bad effects can be
declared. Ari, Randhr, and Vyaya Bhava are Trikas, Dusthan,
or malefic bhavas. Sahaj, Ari, Karm, and Labh Bhava are
Upachayas (growing bhavas); Dhan, Putr, Randhr, and  Labh
Bhava are Panapharas (succedents); and Sahaj, Ari, Dharm,
and Vyaya Bhava are Apoklimas (cadents). Association with
Trikas will inflict evils. Kendras (i.e. Tanu, Bandhu,
Yuvati, and Karm Bhava) and Konas (i.e. Putr and Dharm
Bhava) are auspicious bhavas, the association with which
turns even evil into auspiciousness.
(Also see ch. 34 for more information).
