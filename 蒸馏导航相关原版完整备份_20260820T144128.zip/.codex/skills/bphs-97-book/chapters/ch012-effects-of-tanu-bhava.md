# 第 12 章：Effects of Tanu Bhava

- 来源：BPHS 97 章版
- 原始卡片：10 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P033_B002_01

- 身份：正文
- PDF 页：33
- 偈颂：1-2
- 标题路径：CHAPTER 12 Effects of Tanu Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Tanu Bhava · Sloka 1-2 [present] · PDF page 33

1-2. Physical comforts: Should Lagn lord be yuti with a
malefic or be in Randhr, 6th, or 12th, physical felicity
will diminish.
~L1K+L1T~909~
If he is in an angle or trine there will be at all times
comforts of the body.
~L1d+L1c+L1e~n
If Lagn lord is in debilitation, combustion, or enemy's
rashi, there will be diseases.
~BK+BT~
With a benefic in an angle or trine, all diseases will
disappear.
~BK+BT~
Lagn's angles (i.e. Bandhu, Yuvati, or the lOth) or its
trine (Putr, Dharm) containing a benefic is a powerful
remedy for all related to health.
~!1Dm*-!1DB+mI1*-!1DB+2Dm*-!1DB+2Ym*-!1DB~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P033_B003_01

- 身份：正文
- PDF 页：33
- 偈颂：3
- 标题路径：CHAPTER 12 Effects of Tanu Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Tanu Bhava · Sloka 3 [present] · PDF page 33

3. There will not be bodily health if Lagn or Chandr be
drishtied by or yuti with a malefic, being devoid of a
benefics drishti.
~BI1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P033_B004_01

- 身份：正文
- PDF 页：33
- 偈颂：4
- 标题路径：CHAPTER 12 Effects of Tanu Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Tanu Bhava · Sloka 4 [present] · PDF page 33

4. Bodily Beauty: A benefic in Lagn will give a pleasing
appearance,
~mI1~n
while a malefic will make one bereft of good appearance.
~!1DB+BI1~
Felicity of the body will be enjoyed if Lagn is drishtied
by or yuti with a benefic.
~L1i4*4K+L1i4*4T+L1i5*5K+L1i5*5T+L1i6*6K+L1i6*6T~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P033_B005_01

- 身份：正文
- PDF 页：33
- 偈颂：5-7
- 标题路径：CHAPTER 12 Effects of Tanu Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Tanu Bhava · Sloka 5-7 [present] · PDF page 33

5-7. Other Benefits: If Lagn lord, Buddh, Guru, or Shukr be
in an angle or in a trine, the native will be long lived,
wealthy, intelligent, and liked by the king.
~L1IRm*L1DB~
Fame, wealth, abundant pleasures, and comforts of the body
will be acquired if Lagn lord is in a movable rashi and be
drishtied by a benefic grah.
~4I1*2I1+5I1*2I1+6I1*2I1+4K*4Y2+5K*5Y2+6K*6Y2~
One will be endowed with royal marks (of fortune) if Buddh,
Guru, or Shukr be in Lagn along with the Chandr, or be in
angle from Lagn.
~4I4+4I7+4I10+5I4+5I7+5I10+6I4+6I7+6I10+4I1*4Y2+5I1*5Y2+6I1*6Y2~
If Buddh, Guru, or Shukr be in 4th, 7th, or 10th from Lagn,
or be in the company of Chandr in Lagn, the native will
enjoy royal fortunes.
~R1I1+R2I1+R5I1**7I1+3I1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P033_B006_01

- 身份：正文
- PDF 页：33
- 偈颂：8
- 标题路径：CHAPTER 12 Effects of Tanu Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Tanu Bhava · Sloka 8 [present] · PDF page 33

8. Coiled Birth: If there be a birth in one of Mesh,
Vrishabh, and Simh Lagnas containing either Shani or
Mangal, the birth of the child is with a coil around a
limb. The corresponding limb will be in accordance with the
Rashi or Navamsh rising.
(The limbs indicated by the Rashis are shown in sloka
4-4 1/2 of ch. 4 )
~@1q*2IRd*3IRd*4IRd*5IRd*6IRd*7IRd*8IRd~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P034_B001_01

- 身份：正文
- PDF 页：34
- 偈颂：9
- 标题路径：CHAPTER 12 Effects of Tanu Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Tanu Bhava · Sloka 9 [present] · PDF page 34

9. Birth of Twins: The native, who has Surya in a quadruped
rashi while others are in dual rashis with strength, is
born as one of the twins (Quadruped rashis are: Mesh,
Vrishabh, Simh, first half of Makar, and second part of
Dhanu).
~1Y2*1YN2~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P034_B002_01

- 身份：正文
- PDF 页：34
- 偈颂：10
- 标题路径：CHAPTER 12 Effects of Tanu Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Tanu Bhava · Sloka 10 [present] · PDF page 34

10. To Be Nurtured by Three Mothers: If Surya and Chandr
join in one and the same bhava and fall in one Navamsh, the
native will be nurtured by three different mothers for the
first three months from its birth and will later on be
brought up by its father and brother.
('Bhratri' apart from meaning a brother calls for
interpretation as a near relative in general).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P034_B003_01

- 身份：正文
- PDF 页：34
- 偈颂：11
- 标题路径：CHAPTER 12 Effects of Tanu Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Tanu Bhava · Sloka 11 [present] · PDF page 34

11. Important: The learned in Jyotish should base the
effects on Chandr also as are applicable to Lagn. Now
explained are clues to know of ulcers, identity marks,
etc., on one's person.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P034_B004_01

- 身份：正文
- PDF 页：34
- 偈颂：12-14
- 标题路径：CHAPTER 12 Effects of Tanu Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Tanu Bhava · Sloka 12-14 [present] · PDF page 34

12-14. Decanates and Bodily Limbs: Head, eyes, ears, nose,
temple, chin, and face is the order of limbs denoted (by
the various bhavas) when the first decanate of a rashi
ascends. In the case of the second decanate ascending, the
order is: neck, shoulder, arm, side, heart, stomach, and
navel. The order for the third decanate ascending is:
pelvis, anus/penis, testicles, thigh, knee, calf, and foot.
The portion already risen indicates left side of the body
(while the one yet to rise, i.e. the invisible half,
denotes the right side of the body).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P034_B005_01

- 身份：正文
- PDF 页：34
- 偈颂：15
- 标题路径：CHAPTER 12 Effects of Tanu Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Tanu Bhava · Sloka 15 [present] · PDF page 34

15. Limbs Affected: The limb related to a malefic by
occupation will have ulcers or scars while the one related
to a benefic will have a mark (like moles etc). So say the
Jyotishis.
(Also see sloka 6, ch. 4 of Saravali, which states
that a malefic or a benefic if be in own Rashi or Navamsh,
the effects will be right from birth. In other cases, it
will be in the course of one's life that these effects will
come to pass.)
