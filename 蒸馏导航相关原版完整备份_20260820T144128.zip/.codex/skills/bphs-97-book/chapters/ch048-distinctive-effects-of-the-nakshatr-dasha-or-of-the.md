# 第 48 章：Distinctive Effects of the Nakshatr Dasha or of the

- 来源：BPHS 97 章版
- 原始卡片：6 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P202_B002_01

- 身份：正文
- PDF 页：202
- 偈颂：—
- 标题路径：CHAPTER 48 Distinctive Effects of the Nakshatr Dasha or of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Distinctive Effects of the Nakshatr Dasha or of the · Sloka unknown [unknown] · PDF page 202 · page_block BPHS_PL9_CHAP_97_P202_B002

Dashas of the lords (Vimshottari Dasha) of various Bhavas

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P202_B003_01

- 身份：正文
- PDF 页：202
- 偈颂：1
- 标题路径：CHAPTER 48 Distinctive Effects of the Nakshatr Dasha or of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Distinctive Effects of the Nakshatr Dasha or of the · Sloka 1 [present] · PDF page 202

1. If the lord of Karm Bhava is placed in an auspicious
bhava in his exaltation rashi, etc., his Dasha effects will
be favourable. The effects will be adverse if the lord of
Karm Bhava is in his debilitation rashi and occupies an
inauspicious bhava. This proves that an inauspicious grah
in his exaltation rashi, etc., will not produce
unfavourable results if placed in an auspicious bhava and a
benefic being in his debilitation rashi and being placed in
an inauspicious bhava will produce adverse effects.
Now, I will describe the effects of the Dasha of the lords
of various bhavas who are related to each other.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P202_B004_01

- 身份：正文
- PDF 页：202
- 偈颂：2-4
- 标题路径：CHAPTER 48 Distinctive Effects of the Nakshatr Dasha or of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Distinctive Effects of the Nakshatr Dasha or of the · Sloka 2-4 [present] · PDF page 202

2-4. There will be physical well being in the Dasha of the
lord of Lagn, distress and possibility of death in the
Dasha of the lord of Dhan Bhava, unfavourable effects in
the Dasha of the lord of Sahaj Bhava, acquisition of house
and land in the Dasha of the lord of Bandhu Bhava, progress
in educational sphere and happiness from the children in
the Dasha of the lord of Putr Bhava and danger from enemies
and ill health in the Dasha of the lord of Ari Bhava.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P202_B005_01

- 身份：正文
- PDF 页：202
- 偈颂：5-8
- 标题路径：CHAPTER 48 Distinctive Effects of the Nakshatr Dasha or of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Distinctive Effects of the Nakshatr Dasha or of the · Sloka 5-8 [present] · PDF page 202

5-8. There will be distress to wife and the possibility of
the death of the native in the Dasha of the lord of Yuvati
Bhava, the possibility of death and financial losses in the
Dasha of the lord of Randhr Bhava, improvement in the
educational sphere, religious mindedness and unexpected
gains of wealth in the Dasha of the lord of Dharm Bhava,
recognition from and awards by the Government in the Dasha
of the lord of Karm Bhava, obstacles in gains of wealth and
the possibility of diseases in the Dasha of the lord of
Labh Bhava, and distress and danger from diseases in the
Dasha of the lord of Vyaya Bhava.
A grah placed in an auspicious bhava like Trikon, etc., at
the commencement of the Dasha, produces favourable results
in his Dasha. The grah placed in Ari, Randhr, or Vyaya
Bhava at that time, yields only adverse results during his
Dasha. It is therefore, essential that the placement of a
grah at the time of birth and at the commencement of the
Dasha, should both be taken into account for the assessment
of the Dasha effects.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P202_B006_01

- 身份：正文
- PDF 页：202
- 偈颂：14-17 1/2
- 标题路径：CHAPTER 48 Distinctive Effects of the Nakshatr Dasha or of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Distinctive Effects of the Nakshatr Dasha or of the · Sloka 14-17 1/2 [present] · PDF page 202

14-17 1/2. The Dasha of Ari's lord, Randhr's lord, or
Vyaya's lord also becomes favourable if they get associated
with the lord of a Trikon. If the lord of a Kendr is in a
Trikon or the lord of a Trikon is in a Kendr, the Dasha of
the grah yuti with either or them, becomes favourable. The
Dasha of a grah receiving a drishti from the lord of a
Kendr or Trikon is also favourable. If Dharm's lord is in
Lagn and Lagn's lord is in Dharm Bhava, the Dashas of both
of them will produce extremely beneficial results. There
will be acquisition of a kingdom (attainment of a high
position in Government) in the Dashas of Lagn's lord and
Karm's lord, if Karm's lord is in Lagn and Lagn's lord is
in Karm Bhava.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P203_B001_01

- 身份：正文
- PDF 页：203
- 偈颂：18-20
- 标题路径：CHAPTER 48 Distinctive Effects of the Nakshatr Dasha or of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Distinctive Effects of the Nakshatr Dasha or of the · Sloka 18-20 [present] · PDF page 203

18-20. The Dasha of Sahaj's lord, Ari's lord, and Labh's
lord, of the grahas placed in Sahaj, Ari, and Labh Bhava,
and of the grahas yuti with the above, will prove
unfavourable. The Dasha of the grahas associated with the
lords of Marak Bhavas, namely, Dhan and Yuvati Bhava in
Dhan or Yuvati Bhava, and the Dashas of the grahas placed
in Randhr Bhava, will produce unfavourable effects.
Thus, the Dashas should be considered favourable after
taking into account the placement of a grah and his
relationship of one grah with the other.
(Rahu and Ketu give favourable results in Sahaj, Ari, and
Labh Bhava (the three Upachaya Bhavas)).
