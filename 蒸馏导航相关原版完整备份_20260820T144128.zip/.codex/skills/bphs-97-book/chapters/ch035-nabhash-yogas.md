# 第 35 章：Nabhash Yogas

- 来源：BPHS 97 章版
- 原始卡片：43 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P123_B002_01

- 身份：正文
- PDF 页：123
- 偈颂：1-2
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 1-2 [present] · PDF page 123

1-2. 0 excellent of the Brahmins, explained below are 32
Nabhash Yogas which have a total of 1800 different
varieties. These consist of 3 Asraya Yogas, 2 Dala Yogas,
20 Akriti Yogas, and 7 Sankhya Yogas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P123_B003_01

- 身份：正文
- PDF 页：123
- 偈颂：3-6
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 3-6 [present] · PDF page 123

3-6. Names of Nabhash Yogas:

The 3 Asraya Yogas are:  Rajju, Musala, and Nala Yogas;
The 2 Dala Yogas are:  Maal and Sarpa;
The 20 Akriti Yogas are: Gada, Sakat, Shringatak, Vihag,
Hal, Vajr, Kamal, Vapi, Yup, Shar, Shakti, Danda, Nisk,
Koot, Chatr, Dhanushi, (or Chap), Ardh, Chandr, Chakr,
and Samudr Yogas;
The 7 Sankhya Yogas are:  Vallaki, Daam, Paash, Kedara,
Sool, Yuga,  and Gola Yogas. Thus, these are 32 in total.
~-&IRf*-&IRd~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P123_B004_01

- 身份：正文
- PDF 页：123
- 偈颂：7
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 7 [present] · PDF page 123

7. Rajju, Musala, and Nala Yogas: All the grahas in movable
rashis cause Rajju Yog.
~-&IRm*-&IRd~
All the grahas in fixed rashis cause Musala Yog.
~-&IRm*-&IRf~
All the grahas in dual rashis cause Nala Yog.
~BI1*BI4*BI7+BI1*BI4*BI10+BI4*BI7*BI10+BI1*BI7*BI10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P123_B005_01

- 身份：正文
- PDF 页：123
- 偈颂：8
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 8 [present] · PDF page 123

8. Maal and Sarpa Yogas: If 3 Kendras are occupied by
benefics Maal Yog is produced, (benefic results)
~mI1*mI4*mI7+mI1*mI4*mI10+mI4*mI7*mI10+mI1*mI7*mI10~m
while malefics so placed will cause Bhujang or Sarpa Yog.
These Yogas respectively produce benefic and malefic
results.
~-&I!P*-&I!A**-&I1*-&I4+-&I4*-&I7+-&I7*-&I10+-&I10*-&I1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P123_B006_01

- 身份：正文
- PDF 页：123
- 偈颂：9-11
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 9-11 [present] · PDF page 123

9-11. Gada, Sakat, Vihag, Shringatak, Hal, Vajr, and Yav Yogas:
If all the grahas occupy two successive Kendras, Gada Yog
is formed.
~-&I!P*-&I!A*-&I4*-&I10~
Sakat Yog occurs when all the grahas are disposed in Lagn
and Yuvati Bhava.
~-&I!P*-&I!A*-&I1*-&I7~
If all confine to Bandhu and Karm Bhava, then Vihag Yog
occurs.
~@t1~
All grahas in Lagn, Putr and Dharm Bhava cause Shringatak
Yog,
~@t2+@t3+@t4~
while all grahas are in Dhan, Ari, and Karm Bhava, or in
Sahaj, Yuvati, and Labh Bhava, or in Bandhu, Randhr, and
Vyaya Bhava cause Hal Yog.
~-BI!P*-BI!A*-BI4*-BI10+-mI!P*-mI!A*-mI1*-mI7~
Vajr Yog is caused by all benefics in Lagn and Yuvati
Bhava, or all malefics in Bandhu and Karm Bhava.
~-mI!P*-mI!A*-mI4*-mI10+-BI!P*-BI!A*-BI1*-BI7~
In a contrary situation, i.e. all benefics in Bandhu and
Karm Bhava or all malefics in Lagn and Yuvati Bhava, Yav
Yog is generated.
~1K*2K*3K*4K*5K*6K*7K~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P124_B001_01

- 身份：正文
- PDF 页：124
- 偈颂：12
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 12 [present] · PDF page 124

12. Kamal and Vapi Yogas: If all the grahas are in the 4
Kendras, Kamal Yog is produced.
~-&K*-&I!P+-&K*-&I!A~
If all of them happen to be in all the Apoklimas (cadent
bhavas), or in all the Panapharas (succedent bhavas), Vapi
Yog occurs.
~-&I5*-&I6*-&I7*-&I8*-&I9*-&I10*-&I11*-&I12~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P124_B002_01

- 身份：正文
- PDF 页：124
- 偈颂：13
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 13 [present] · PDF page 124

13. Yup, Shar, Shakti, and Danda Yogas: If  all the 7
grahas are in the 4 bhavas commencing from Lagn, they cause
Yup Yog;
~-&I8*-&I9*-&I10*-&I11*-&I12*-&I1*-&I2*-&I3~
if all the 7 grahas are in the 4 bhavas commencing from
Bandhu Bhava Shar Yog occurs;
~-&I11*-&I12*-&I1*-&I2*-&I3*-&I4*-&I5*-&I6~
if all the 7 grahas are in the 4 bhavas commencing from
Yuvati Bhava Shakti Yog occurs;
~-&I2*-&I3*-&I4*-&I5*-&I6*-&I7*-&I8*-&I9~
and if all the 7 grahas are in the 4 bhavas commencing from
Karm Bhava Danda Yog is formed.
~-&I8*-&I9*-&I10*-&I11*-&I12~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P124_B003_01

- 身份：正文
- PDF 页：124
- 偈颂：14
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 14 [present] · PDF page 124

14. Nauka, Koot, Chatr, and Chap Yogas: If all the grahas
occupy the seven bhavas from Lagn Nauka Yog occurs;
~-&I11*-&I12*-&I1*-&I2*-&I3~
if all the grahas occupy the seven bhavas from Bandhu Bhava
Koot Yog is formed;
~-&I2*-&I3*-&I4*-&I5*-&I6~
if all the grahas occupy the seven bhavas from Yuvati Bhava
Chatr Yog occurs;
~&I1*&I2*&I3*&I4*&I10*&I11*&I12*-&I5*-&I6*-&I7*-&I8*-&I9~
and if all the seven grahas occupy the seven bhavas from
Karm Bhava, Chap Yog occurs. Here again, the grahas should
occupy seven continuous bhavas.
~@s5~
Quoted from saravali:
If the seven grahas occupy continuously seven bhavas
commencing from a bhava which is not angular to the lagna,
the yoga produced is known as Ardh Chandra yoga.
~&I1*-&I2*&I3*-&I4*&I5*-&I6*&I7*-&I8*&I9*-&I10*&I11*-&I12~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P124_B004_01

- 身份：正文
- PDF 页：124
- 偈颂：15
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 15 [present] · PDF page 124

15. Chakr and Samudr Yogas: If all the grahas occupy six
alternative rashis commencing from Lagn, Chakr Yog is
formed.
~&I2*-&I3*&I4*-&I5*&I6*-&I7*&I8*-&I9*&I10*-&I11*&I12*-&I1~
Samudr Yog is produced if all grahas occupy six alternative
rashis commencing from Dhan Bhava.
~1Y2*2Y3*3Y4*4Y5*5Y6*6Y7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P125_B001_01

- 身份：正文
- PDF 页：125
- 偈颂：16-17
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 16-17 [present] · PDF page 125

16-17. Sankhya Yogas: If all grahas are in one Rashi Gola
Yog is formed;
~Re10~
if all grahas are in 2 rashis, Yuga Yog is formed;
~Re9~
if all grahas are in 3 rashis Sool Yog occurs;
~Re8~
if all grahas are in 4 rashis Kedara Yog occurs;
~Re7~
if all grahas are in 5 rashis Paash Yogis formed,
~Re6~
if all grahas are in 6 rashis Daam Yog occurs;
~Re5~
and if all grahas are in 7 rashis Veena Yog is produced.
None of these seven Yogas will be operable, if another
Nabhash Yog (explained earlier) is derivable.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P125_B002_01

- 身份：正文
- PDF 页：125
- 偈颂：18
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 18 [present] · PDF page 125

18. Effects of Nabhash Yogas (up to sloka 50):
~-&IRf*-&IRd~n
Rajju Yog: One born in Rajju Yog will be fond of
wandering, be charming, will earn in foreign countries. He
will be cruel and mischievous.
~-&IRm*-&IRd~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P125_B003_01

- 身份：正文
- PDF 页：125
- 偈颂：19
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 19 [present] · PDF page 125

19. Musala Yog: One born in Musala Yog will be endowed with
honour, wisdom, wealth, etc., be dear to king, famous, will
have many sons and be firm in disposition.
~-&IRm*-&IRf~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P125_B004_01

- 身份：正文
- PDF 页：125
- 偈颂：20
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 20 [present] · PDF page 125

20. Nala Yog: One born in Nala Yog will have uneven
physique, be interested in accumulating money, very
skillful, helpful to relatives, and charming.
~BI1*BI4*BI7+BI1*BI4*BI10+BI4*BI7*BI10+BI1*BI7*BI10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P125_B005_01

- 身份：正文
- PDF 页：125
- 偈颂：21
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 21 [present] · PDF page 125

21. Maal Yog: One born in Maal Yog will be ever happy,
endowed with conveyances robes, food, and pleasures, be
splendorous and endowed with many females.
~mI1*mI4*mI7+mI1*mI4*mI10+mI4*mI7*mI10+mI1*mI7*mI10~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P125_B006_01

- 身份：正文
- PDF 页：125
- 偈颂：22
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 22 [present] · PDF page 125

22. Sarpa Yog: One born in Sarpa (Bhujang) Yog will be
crooked, cruel, poor, miserable, and will depend on others
for food and drinks.
~-&I!P*-&I!A**-&I1*-&I4+-&I4*-&I7+-&I7*-&I10+-&I10*-&I1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P125_B007_01

- 身份：正文
- PDF 页：125
- 偈颂：23
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 23 [present] · PDF page 125

23. Gada Yog: One born in Gada Yog will always make efforts
to earn wealth, will perform sacrificial rites, be skilful
in Shastras and songs, and endowed with wealth, gold, and
precious stones.
~-&I!P*-&I!A*-&I4*-&I10~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P125_B008_01

- 身份：正文
- PDF 页：125
- 偈颂：24
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 24 [present] · PDF page 125

24. Sakat Yog: One born in Sakat Yog will be afflicted by
diseases, will have diseased or ugly nails, be foolish,
will live by pulling carts, be poor, and devoid of friends
and relatives.
~-&I!P*-&I!A*-&I1*-&I7~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P125_B009_01

- 身份：正文
- PDF 页：125
- 偈颂：25
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 25 [present] · PDF page 125

25. Vihag Yog: One born in Vihag Yog will be fond of
roaming, be a messenger, will live by sexual dealings, be
shameless, and interested in quarrels.
~@t1~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P126_B001_01

- 身份：正文
- PDF 页：126
- 偈颂：26
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 26 [present] · PDF page 126

26. Shringatak Yog: One born in Shringatak Yog will be fond
of quarrels, and battles, be happy, dear to king, endowed
with an auspicious wife, be rich, and will hate women.
~@t2+@t3+@t4~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P126_B002_01

- 身份：正文
- PDF 页：126
- 偈颂：27
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 27 [present] · PDF page 126

27. Hal Yog: One born in Hal Yog will eat a lot, will be
very poor, will be miserable, agitated, given up by friends and
relatives; he will be a servant.
~-BI!P*-BI!A*-BI4*-BI10+-mI!P*-mI!A*-mI1*-mI7~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P126_B003_01

- 身份：正文
- PDF 页：126
- 偈颂：28
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 28 [present] · PDF page 126

28. Vajr Yog: One born in Vajr Yog will be happy in the
beginning and at the end of life, be valorous, charming,
devoid of desires, and fortunes and be inimical.
~-mI!P*-mI!A*-mI4*-mI10+-BI!P*-BI!A*-BI1*-BI7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P126_B004_01

- 身份：正文
- PDF 页：126
- 偈颂：29
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 29 [present] · PDF page 126

29. Yav Yog: One born in Yav Yog will observe fasts and
other religious rules, will do auspicious acts, will obtain
happiness, wealth and sons in his mid-life; he will be
charitable and firm.
~1K*2K*3K*4K*5K*6K*7K~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P126_B005_01

- 身份：正文
- PDF 页：126
- 偈颂：30
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 30 [present] · PDF page 126

30. Kamal Yog: One born in Kamal Yog will be rich and
virtuous, be long lived, very famous, and pure; he will
perform hundreds of auspicious acts and he will be a king.
~-&K*-&I!P+-&K*-&I!A~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P126_B006_01

- 身份：正文
- PDF 页：126
- 偈颂：31
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 31 [present] · PDF page 126

31. Vapi Yog: One born in Vapi Yog will be capable of
accumulating wealth, be endowed with lasting wealth, and
happiness and sons, be free from eye afflictions and will
be a king.
~-&I5*-&I6*-&I7*-&I8*-&I9*-&I10*-&I11*-&I12~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P126_B007_01

- 身份：正文
- PDF 页：126
- 偈颂：32
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 32 [present] · PDF page 126

32. Yup Yog: One born in Yup Yog will have spiritual
knowledge and will be interested in sacrificial rites. He
will be endowed with a wife, be strong, interested in fasts
and other religious observations and be distinguished.
~-&I8*-&I9*-&I10*-&I11*-&I12*-&I1*-&I2*-&I3~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P126_B008_01

- 身份：正文
- PDF 页：126
- 偈颂：33
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 33 [present] · PDF page 126

33. Shar Yog: One born in Shar Yog will make arrows, be
head of a prison, will earn through animals, will eat meat,
will indulge in torture and mean handiworks.
~-&I11*-&I12*-&I1*-&I2*-&I3*-&I4*-&I5*-&I6~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P126_B009_01

- 身份：正文
- PDF 页：126
- 偈颂：34
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 34 [present] · PDF page 126

34. Shakti Yog: One born in Shakti Yog will be bereft of
wealth, be unsuccessful, miserable, mean, lazy, long lived,
interested and skilful in war, firm and auspicious.
~-&I2*-&I3*-&I4*-&I5*-&I6*-&I7*-&I8*-&I9~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P126_B010_01

- 身份：正文
- PDF 页：126
- 偈颂：35
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 35 [present] · PDF page 126

35. Danda Yog: One born in Danda Yog will lose sons and
wife, will be indigent, unkind, away from his men, and will
serve mean people.
~-&I8*-&I9*-&I10*-&I11*-&I12~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P126_B011_01

- 身份：正文
- PDF 页：126
- 偈颂：36
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 36 [present] · PDF page 126

36. Nauka Yog: One born in Nauka Yog will derive his
livelihood through water, be wealthy, famous wicked,
wretched, dirty and miserly.
~-&I11*-&I12*-&I1*-&I2*-&I3~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P127_B001_01

- 身份：正文
- PDF 页：127
- 偈颂：37
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 37 [present] · PDF page 127

37. Koot Yog: One born in Koot Yog will be a liar, will
head a jail, be poor, crafty, cruel, and will live in hills
and fortresses.
~-&I2*-&I3*-&I4*-&I5*-&I6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P127_B002_01

- 身份：正文
- PDF 页：127
- 偈颂：38
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 38 [present] · PDF page 127

38. Chatr Yog: One born in Chatr Yog will help his own men,
be kind, dear to many kings, very intelligent, happy at the
beginning and end of his life and be long-lived.
~&I1*&I2*&I3*&I4*&I10*&I11*&I12*-&I5*-&I6*-&I7*-&I8*-&I9~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P127_B003_01

- 身份：正文
- PDF 页：127
- 偈颂：39
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 39 [present] · PDF page 127

39. Chap Yog: One born in Chap Yog will be liar, will
protect secrets, be a thief, be fond of wandering forests,
be devoid of luck, and be happy in the middle of the life.
~@ya~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P127_B004_01

- 身份：正文
- PDF 页：127
- 偈颂：40
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 40 [present] · PDF page 127

40. Ardh Chandr Yog: One born in Ardh Chandr Yog will lead
an army, will possess a splendorous body, be dear to king,
be strong and endowed with gems, gold, and ornaments.
~&I1*-&I2*&I3*-&I4*&I5*-&I6*&I7*-&I8*&I9*-&I10*&I11*-&I12~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P127_B005_01

- 身份：正文
- PDF 页：127
- 偈颂：41
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 41 [present] · PDF page 127

41. Chakr Yog: One born in Chakr Yog will be an emperor at
whose feet will be the prostrating kings heads adoring gem
studded diadems.
~&I2*-&I3*&I4*-&I5*&I6*-&I7*&I8*-&I9*&I10*-&I11*&I12*-&I1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P127_B006_01

- 身份：正文
- PDF 页：127
- 偈颂：42
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 42 [present] · PDF page 127

42. Samudr Yog: One born in Samudr Yog will have many
precious stones and abundant wealth, be endowed with
pleasures, dear to people, will have firm wealth and be,
well-disposed.
~Re5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P127_B007_01

- 身份：正文
- PDF 页：127
- 偈颂：43
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 43 [present] · PDF page 127

43. Veena Yog: One born in Veena Yog will be fond of songs,
dance and musical instruments, be skilful, happy, wealthy,
and be a leader of men.
~Re6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P127_B008_01

- 身份：正文
- PDF 页：127
- 偈颂：44
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 44 [present] · PDF page 127

44. Daamini Yog: One born in Daamini Yog will be helpful to
others, will have righteously earned wealth, be very
affluent, famous, will have many sons, and gems, be
courageous, and red-lettered.
~Re7~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P127_B009_01

- 身份：正文
- PDF 页：127
- 偈颂：45
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 45 [present] · PDF page 127

45. Paash Yog: One born in Paash Yog will be liable to be
imprisoned, be skilful in work, be deceiving in
disposition, will talk much, be bereft of good qualities
and will have many servants.
~Re8~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P127_B010_01

- 身份：正文
- PDF 页：127
- 偈颂：46
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 46 [present] · PDF page 127

46. Kedara Yog: One born in Kedara Yog will be useful to
many, be an agriculturist, be truthful, happy, fickle
minded, and wealthy.
~Re9~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P127_B011_01

- 身份：正文
- PDF 页：127
- 偈颂：47
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 47 [present] · PDF page 127

47. Sool Yog: One born in Sool Yog will sharp, indolent,
bereft of wealth, be tortuous, prohibited, valiant, and
famous through war.
~Re10~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P128_B001_01

- 身份：正文
- PDF 页：128
- 偈颂：48
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 48 [present] · PDF page 128

48. Yuga Yog: One born in Yuga Yog will heretic, be devoid
of wealth, be discarded by others, and be devoid of sons,
mother and virtues.
~1Y2*2Y3*3Y4*4Y5*5Y6*6Y7~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P128_B002_01

- 身份：正文
- PDF 页：128
- 偈颂：49
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 49 [present] · PDF page 128

49. Gola Yog: One born in Gola Yog will be strong, be
devoid of wealth, learning and intelligence, be dirty,
sorrowful, and miserable.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P128_B003_01

- 身份：正文
- PDF 页：128
- 偈颂：50
- 标题路径：CHAPTER 35 Nabhash Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Nabhash Yogas · Sloka 50 [present] · PDF page 128

50. Ancestors say that the results due to said (Nabhash)
Yogas will be felt throughout, in all the Dasha periods.
