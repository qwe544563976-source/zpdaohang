# 第 16 章：Effects of Putr Bhava

- 来源：BPHS 97 章版
- 原始卡片：22 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P041_B002_01

- 身份：正文
- PDF 页：41
- 偈颂：1-3
- 标题路径：CHAPTER 16 Effects of Putr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Putr Bhava · Sloka 1-3 [present] · PDF page 41

1-3. 0 Brahmin, now I tell you the effects related to Putr
Bhava. If the lords of Lagn and Putr are in their own
rashis or in an angle, or in a trine, one will enjoy
thorough happiness through his children.
~L5I6+L5I8+L5I12~n
Should Putr's lord be in Ari, Randhr, or Vyaya Bhava, there
will be no offspring.
~L5c+L5Ym*L5v~n
Should the lord of Putr be combust or be with malefics and
be weak, there will be no children; even if per chance
issues are obtained, they will only quit the world soon.
~L5YL1**L1I5+L1I4+L1I9+L1I10+L1I7~
The yuti of Putr's lord with Lagn's lord in a good bhava
will ensure early obtainment of children apart from
happiness through them.
~L5YL1*L1Ia~n
If they join in an evil bhava, they will prove a defect in
this respect.
~L5I6*3YL1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P041_B003_01

- 身份：正文
- PDF 页：41
- 偈颂：4
- 标题路径：CHAPTER 16 Effects of Putr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Putr Bhava · Sloka 4 [present] · PDF page 41

4. If Putr's lord is in Ari Bhava as Lagn's lord is yuti
with Mangal, the native will lose his very first child
where after his female will not be fertile to yield an
offspring.
~L5d*L5I6*4I5*9I5+L5d*L5I8*4I5*9I5+L5d*L5I12*4I5*9I5~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P041_B004_01

- 身份：正文
- PDF 页：41
- 偈颂：5
- 标题路径：CHAPTER 16 Effects of Putr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Putr Bhava · Sloka 5 [present] · PDF page 41

5. Should Putr's lord be in fall in Ari, Randhr,  or Vyaya
Bhava, while Buddh and Ketu are in Putr Bhava, the native's
wife will give birth to one child only.
~L5d*4I5*7I5~
~L5d*-L5r!5*7I5*4I5~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P041_B005_01

- 身份：正文
- PDF 页：41
- 偈颂：6
- 标题路径：CHAPTER 16 Effects of Putr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Putr Bhava · Sloka 6 [present] · PDF page 41

6. If Putr's lord is in fall and be not in drishti to Putr,
while Shani and Buddh are in Putr, the native's wife wil
give birth to one child only.
~L9I1*L5d*9I5*4I5~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P041_B006_01

- 身份：正文
- PDF 页：41
- 偈颂：7
- 标题路径：CHAPTER 16 Effects of Putr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Putr Bhava · Sloka 7 [present] · PDF page 41

7. Should Dharm's lord be in Lagn, while Putr's lord is in
fall and Ketu is in Putr along with Buddh, obtainment of
progeny will be after a great deal of ordeal.
~L5I6+L5I8+L5I12+L5Ia+L5d+L5I5~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P041_B007_01

- 身份：正文
- PDF 页：41
- 偈颂：8
- 标题路径：CHAPTER 16 Effects of Putr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Putr Bhava · Sloka 8 [present] · PDF page 41

8. If Putr's lord is in Ari, Randhr, or Vyaya Bhava, or be
in an inimical rashi, or be in fall, or in Putr itself, the
native will beget issues with difficulty.
~L5i7+L5i4**7I5*.mI5+!5D.m*!5D7+!5D7*.mI5+7I5*!5D.m~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P041_B008_01

- 身份：正文
- PDF 页：41
- 偈颂：9
- 标题路径：CHAPTER 16 Effects of Putr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Putr Bhava · Sloka 9 [present] · PDF page 41

9. Should Putr Bhava be owned by Shani or Buddh and be
occupied or drishtied by Shani and Mandi, one will have
adopted issues.
~1Y2*N1Y2~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P041_B009_01

- 身份：正文
- PDF 页：41
- 偈颂：10
- 标题路径：CHAPTER 16 Effects of Putr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Putr Bhava · Sloka 10 [present] · PDF page 41

10. Should Surya and Chandr be together in a rashi and in
the same Navamsh, the native will be brought up by three
mothers or two fathers.
~@p65*L5I12*2X*LnX~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P042_B001_01

- 身份：正文
- PDF 页：42
- 偈颂：11
- 标题路径：CHAPTER 16 Effects of Putr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Putr Bhava · Sloka 11 [present] · PDF page 42

11. Adopted issue is indicated if Putr is tenanted by six
grahas, while its lord is in Vyaya Bhava, and Chandr and
Lagn are endowed with strength.
~L5X*!5D4*4X*!5D5*!5D6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P042_B002_01

- 身份：正文
- PDF 页：42
- 偈颂：12
- 标题路径：CHAPTER 16 Effects of Putr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Putr Bhava · Sloka 12 [present] · PDF page 42

12. There will be many children if Putr's lord is strong
while Putr is drishtied by strong Buddh, Guru, and Shukr.
~L5Y2+@L5d2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P042_B003_01

- 身份：正文
- PDF 页：42
- 偈颂：13
- 标题路径：CHAPTER 16 Effects of Putr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Putr Bhava · Sloka 13 [present] · PDF page 42

13. If Putr's lord is with Chandr or is in her Decanate the
native will beget daughters, so say Jyotishis.
~L5IRm*7I5*8Y2~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P042_B004_01

- 身份：正文
- PDF 页：42
- 偈颂：14
- 标题路径：CHAPTER 16 Effects of Putr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Putr Bhava · Sloka 14 [present] · PDF page 42

14. If Putr's lord is in a movable rashi, while Shani is in
Putr, as Rahu is with Chandr the child (so born) is of
questionable birth.
~2I8*5I3**2Dm+5Dm+2Ym+5Ym~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P042_B005_01

- 身份：正文
- PDF 页：42
- 偈颂：15
- 标题路径：CHAPTER 16 Effects of Putr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Putr Bhava · Sloka 15 [present] · PDF page 42

15. Undoubtedly, the native is born of other's loins if
Chandr is in the 8th from Lagn, while Guru is in the 8th
from Chandr. Malefic's drishti or yuti is essential in this
Yog.
~L5E+L5I2+L5I5+L5I9+L5Y5+L5D5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P042_B006_01

- 身份：正文
- PDF 页：42
- 偈颂：16
- 标题路径：CHAPTER 16 Effects of Putr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Putr Bhava · Sloka 16 [present] · PDF page 42

16. If Putr's lord is exalted or be in Dhan, Putr, or Dharm
Bhava, or be yuti with or drishtied by Guru, obtainment of
children will be there.
~mI5*L5d*-BI5~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P042_B007_01

- 身份：正文
- PDF 页：42
- 偈颂：17
- 标题路径：CHAPTER 16 Effects of Putr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Putr Bhava · Sloka 17 [present] · PDF page 42

17. One will obtain children that will indulge in mean
deeds if Putr is occupied by three or four malefics, while
Putr's lord is in fall. A benefic (including Buddh) in Putr
is excluded in the said combination.
~5I5*L5Y6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P042_B008_01

- 身份：正文
- PDF 页：42
- 偈颂：18
- 标题路径：CHAPTER 16 Effects of Putr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Putr Bhava · Sloka 18 [present] · PDF page 42

18. If Putr is occupied by Guru, while its lord is with
Shukr, one will obtain an offspring in his 32nd or 33rd
year.
~L5K*L5Y5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P042_B009_01

- 身份：正文
- PDF 页：42
- 偈颂：19
- 标题路径：CHAPTER 16 Effects of Putr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Putr Bhava · Sloka 19 [present] · PDF page 42

19. Should Putr's lord be in an angle along with Guru, the
Karak, one will beget a child at the age of 30 or 36.
~5I9*6I5*6YL1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P042_B010_01

- 身份：正文
- PDF 页：42
- 偈颂：20
- 标题路径：CHAPTER 16 Effects of Putr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Putr Bhava · Sloka 20 [present] · PDF page 42

20. If Guru is in Dharm Bhava, while Shukr is in the 9th
from Guru along with Lagn's lord, one will beget a child at
the age of 40.
~8I5*L5Ym*5d~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P042_B011_01

- 身份：正文
- PDF 页：42
- 偈颂：21
- 标题路径：CHAPTER 16 Effects of Putr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Putr Bhava · Sloka 21 [present] · PDF page 42

21. The native will at the age of 32 lose his child if Rahu
is in Putr, Putr's lord is in yuti with a malefic, and Guru
is in debilitation.
~(mI5)5*mI5~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P042_B012_01

- 身份：正文
- PDF 页：42
- 偈颂：22
- 标题路径：CHAPTER 16 Effects of Putr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Putr Bhava · Sloka 22 [present] · PDF page 42

22. There will be loss of children at 33 and 36 if a
malefic is in the 5th from Guru, while another is in the
5th from Lagn.
~.mI1*L1d~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P043_B001_01

- 身份：正文
- PDF 页：43
- 偈颂：23
- 标题路径：CHAPTER 16 Effects of Putr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Putr Bhava · Sloka 23 [present] · PDF page 43

23. Should Mandi be in Lagn, while Lagn's lord is in fall,
grief on account of loss of child at the age of 56 will
come to pass.
~mI4*mI6*L5E*L5YL1*5YB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P043_B002_01

- 身份：正文
- PDF 页：43
- 偈颂：24-32
- 标题路径：CHAPTER 16 Effects of Putr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Putr Bhava · Sloka 24-32 [present] · PDF page 43

24-32. Number of Children: There will be 10 sons if Bandhu
Bhava and Ari Bhava are occupied by malefics while Putr's
lord is in deep exaltation joining Lagn's lord as Guru is
with another benefic.
~5E*8YL2*L9O~
Nine will be the number of sons that one will beget if Guru
is in deep exaltation as Rahu is with Dhan's lord, and
Dharm is occupied by its own lord.
~5I5*L5X*L2I10+5I9*L5X*L2I10~
There will be eight sons if Guru is in Putr, or Dharm
Bhava, while Putr's lord is endowed with strength and
Dhan's lord is in Karm Bhava.
~7I9*L5I5~
Shani in Dharm Bhava, while Putr's lord is in Putr itself,
gives 7 sons out of which twins will be born twice.
~L5I5*L5YL2~n
If Putr's lord is in Putr in yuti with Dhan's lord, there
will be birth of 7 sons out of which 3 will pass away.
~mI5*(5I5)7+(7I5)5~n
Only one son is denoted if there be a malefic in Putr
Bhava, while Guru is in the 5th from Shani or vice versa.
~mI5+(7I5)5~n
If Putr Bhava has a malefic in it or if Shani is in the 5th
from Guru the native will beget offspring only through his
second or third wife.
~mI5*(7I5)5*L1I2*L5Y3~n
Should Putr be occupied by a malefic, while Guru is yuti
with Shani in Putr Bhava, as Lagn's lord is in Dhan Bhava,
and Putr's lord is yuti with Mangal, one will live long but
lose his children one after the other as they are born.
