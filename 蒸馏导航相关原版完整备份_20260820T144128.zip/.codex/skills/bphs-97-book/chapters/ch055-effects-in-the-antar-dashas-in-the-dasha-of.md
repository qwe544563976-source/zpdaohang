# 第 55 章：Effects in the Antar Dashas in the Dasha of

- 来源：BPHS 97 章版
- 原始卡片：34 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P234_B002_01

- 身份：正文
- PDF 页：234
- 偈颂：—
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka unknown [unknown] · PDF page 234 · page_block BPHS_PL9_CHAP_97_P234_B002

Rahu
@8182@
Effects of the Antar Dashas of Rahu in the Dasha of Rahu
~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P234_B003_01

- 身份：正文
- PDF 页：234
- 偈颂：1-4
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 1-4 [present] · PDF page 234

1-4. Effects like acquisition of a kingdom (attainment of a
high position in government), enthusiasm, cordial relations
with the king (government), happiness from wife and
children, and increase in property, will be derived in the
Antar Dasha of Rahu in the Dasha of Rahu, if Rahu is in
Kark, Vrischik, Kanya, or Dhanu and is in Sahaj, Ari, Karm,
or Labh Bhava, or is yuti with a Yog Karak grah in his
exaltation Rashi.
~8I8+8I12+8Am~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P234_B004_01

- 身份：正文
- PDF 页：234
- 偈颂：5-6
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 5-6 [present] · PDF page 234

5-6. There will be danger from thieves, distress from
wounds, antagonism with government officials, destruction
of kinsmen, distress to wife and children, if Rahu is in
Randhr or Vyaya Bhava or be associated with malefics.
~8iL2+8iL7+8I2+8I7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P234_B005_01

- 身份：正文
- PDF 页：234
- 偈颂：7
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 7 [present] · PDF page 234

7. If Rahu is Dhan's lord or Yuvati's lord, or is in Dhan
or Yuvati Bhava, there will be distress and diseases. To
obtain relief from the above evil effects Rahu should be
worshipped (by recitation of his mantras) and by giving in
charity things connected with or ruled by Rahu.
@8152@
Effects of the Antar Dasha of Guru in the Dasha of Rahu
~5E+5O+5NO+5NE+5K+5T~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P234_B006_01

- 身份：正文
- PDF 页：234
- 偈颂：8-12 1/2
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 8-12 1/2 [present] · PDF page 234

8-12 1/2. Effects like gain of position, patience,
destruction or foes, enjoyment, cordial relations with the
king (government), regular increase in wealth and property
like the growth of Chandr of the bright half of the month
(Shukla Paksh), gain of conveyance and cows, audience with
the king (high government officials) by performing journey
to the West or South East, success in the desired ventures,
return to one's homeland, doing good for Brahmins, visit to
holy places. gain of a village, devotion to deities and
Brahmins, happiness from wife, children, and grand
children, availability of sweetish preparations daily, etc,
will be derived, in the Antar Dasha of Guru in the Dasha of
Rahu, if Guru is in his Exaltation Rashi, in his own Rashi,
in his own Navamsh, or in his exalted Navamsh, or if Guru
is in a Kendr or in a Trikon with reference to Lagn.
~5d+5c+5I6+5I8+5I12+5e+5Am~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P234_B007_01

- 身份：正文
- PDF 页：234
- 偈颂：13-14 1/2
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 13-14 1/2 [present] · PDF page 234

13-14 1/2. Loss of wealth, obstacles in work, defamation,
distress to wife and children, heart disease, entrustment
of governmental authority, etc., will result if Guru is in
his Debilitation Rashi, if Guru is combust, if Guru is in
Ari, Randhr, or Vyaya Bhava, if Guru is in an enemy Rashi,
or if Guru is associated with malefics.
~(5I!K)8*5X+(5I!T)8*5X+(5I11)8*5X+(5I2)8*5X+(5I3)8*5X~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P235_B001_01

- 身份：正文
- PDF 页：235
- 偈颂：15-17
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 15-17 [present] · PDF page 235

15-17. There will be gains of land, good food, gains of
cattle, etc., inclinations towards charitable and religious
work, etc., if Guru is in a Kendr, in a Trikon, the 11th,
the 2nd, or the 3rd from the lord of the Dasha (Rahu) and
is endowed with strength.
~(5I6)8+(5I8)8+(5I12)8+5Am~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P235_B002_01

- 身份：正文
- PDF 页：235
- 偈颂：18-20
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 18-20 [present] · PDF page 235

18-20. Loss of wealth, and distress to body will result if
Guru is in the 6th, the 8th or the 12th from the lord of
the Dasha (Rahu) or if Guru is associated with malefics.
~5iL2+5iL7~
There will be danger of premature death if Guru is Dhan's
lord or Yuvati's lord. The person will get relief from the
above evil effects and enjoy good health by the beneficence
of the lord Shiva if he worships His idol made of gold.
@8172@
Effects of the Antar Dasha of Shani in the Dasha of Rahu
7K+7T+7E+7O+7M+7I3+7I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P235_B003_01

- 身份：正文
- PDF 页：235
- 偈颂：21-24
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 21-24 [present] · PDF page 235

21-24. Effects like pleasure of the king for devotion in
his service, auspicious functions like celebration of
marriage, etc., at home, construction of a garden,
reservoir, etc., gain of wealth and cattle from well to do
persons belonging to the Sudra class, loss of wealth caused
by the king (government officials) during journey to the
West, reduction in income due to lethargy, return to
homeland, will be derived in the Antar Dasha of Shani in
the Dasha of Rahu, if Shani is in a Kendr, in a Trikon, in
his Exaltation Rashi, in his own Rashi, in his Multrikon,
in Sahaj, or in Labh Bhava.
~7d+7e+7I8+7I12~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P235_B004_01

- 身份：正文
- PDF 页：235
- 偈颂：25-26
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 25-26 [present] · PDF page 235

25-26. Danger from menials, the king, and enemies, distress
to wife and children, distress to kinsmen, disputes with
the coparceners, disputes in dealings with others, but
sudden gain of ornaments, will result if Shani is in his
Debilitation Rashi, in his enemy's Rashi, or in Randhr or
Vyaya Bhava.
~(7I6)8+(7I8)8+(7I12)8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P235_B005_01

- 身份：正文
- PDF 页：235
- 偈颂：27-29
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 27-29 [present] · PDF page 235

27-29. There will be heart disease, defamation, quarrels.
danger from enemies, foreign journeys, affliction with
Gulma (enlargement of the skin), unpalatable food, and
sorrows, etc., if Shani is in the 6th, the 8th, or the 12th
from the lord of the Dasha (Rahu).
~7iL2+7iL7~
Premature death is likely if Shani is Dhan's lord or
Yuvati's lord.
Remedial measure to obtain relief from the above evil
effects and to regain good health, is giving a black cow or
a she buffalo in charity.
@8142@
Effects of the Antar Dasha of Buddh in the Dasha of Rahu
~4E*4X+4K*4X+4I5*4X~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P236_B001_01

- 身份：正文
- PDF 页：236
- 偈颂：30-33
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 30-33 [present] · PDF page 236

30-33. Auspicious effects like Raj Yog, well being in the
family, profits and gain of wealth in business, comforts of
conveyances, marriage and other auspicious functions,
increase in the number of cattle, gain of perfumes,
comforts of bed, women, etc, will be derived in the Antar
Dasha of Buddh in the Dasha of Rahu, if Buddh is in his
Exaltation Rashi, in a Kendr, or in Putr Bhava and if Buddh
is endowed with strength. Good results like Raj Yog,
beneficence of the king, and gain of wealth and reputation,
will be realized particularly on Wednesday in the month of
Buddh.
~(4I!K)8+(4I11)8+(4I3)8+(4I9)8+(4I10)8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P236_B002_01

- 身份：正文
- PDF 页：236
- 偈颂：34-35
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 34-35 [present] · PDF page 236

34-35. Sound health, Isht Siddhi, attending discourse on
Puranas and ancient history, marriage, offering of
oblations, charities, religious inclination, and
sympathetic attitude toward's others, will result if Buddh
is in a Kendr, in the 11th, in the 3rd, in the 9th, or in
the 10th from the lord of the Dasha (Rahu).
~4I6+4I8+4I12+4D7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P236_B003_01

- 身份：正文
- PDF 页：236
- 偈颂：36-38
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 36-38 [present] · PDF page 236

36-38. There will be opprobrium (Ninda') of deities and
Brahmins by the native, loss of fortune, speaking lies,
unwise actions, fear from snakes, thieves, and the
government, quarrels, distress to wife and children, etc.,
if Buddh is in Ari, Randhr, or Vyaya Bhava, or if Buddh
receives a drishti from Shani.
~4iL2+4iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P236_B004_01

- 身份：正文
- PDF 页：236
- 偈颂：39
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 39 [present] · PDF page 236

39. If Buddh is Dhan's lord or Yuvati's lord, there will be
fear of premature death. Remedial measure to obtain relief
from the above evil effects is recitation of Vishnu
Sahasranam.
@8192@
Effects of the Antar Dasha of Ketu in the Dasha of Rahu

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P236_B005_01

- 身份：正文
- PDF 页：236
- 偈颂：40-41
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 40-41 [present] · PDF page 236

40-41. During the Antar Dasha of Ketu in the Dasha of Rahu,
there will be journeys to foreign countries, danger from
the king (government), rheumatic fever, etc., and loss of
cattle.
~9YL8~
If Ketu is yuti with Randhr's lord there will be distress
to the body and mental tension.
~9AB+9DB~
Enjoyment, gain wealth, recognition by the king
(government), acquisition gold etc., will be the results if
Ketu is associated with or receives a drishti from benefics.
~9rL1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P236_B006_01

- 身份：正文
- PDF 页：236
- 偈颂：42-42 1/2
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 42-42 1/2 [present] · PDF page 236

42-42 1/2. There will be Isht Siddhi if Ketu is related to
the lord of Lagn.
~9AL1~
If he is associated with the lord of Lagn there will
definitely be gain of wealth.
~9K+9T~
There will also definitely be increase in the number of
cattle if Ketu is in a Kendr or in a Trikon (from Lagn).
~9x*9I8+9x*9I12~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P237_B001_01

- 身份：正文
- PDF 页：237
- 偈颂：43-45
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 43-45 [present] · PDF page 237

43-45. Effects like danger from thieves and snakes,
distress from wounds, separation from parents, antagonistic
relations with kinsmen, mental agony, etc., will be derived
if Ketu is without strength in Randhr or Vyaya Bhava.
~9iL2+9iL7~
If Ketu is Dhan's lord or Yuvati's lord, there will be
distress to the body. The remedial measure to obtain relief
from the above evil effects is giving a goat in charity.
@8162@
Effects of the Antar Dasha of Shukr in the Dasha of Rahu
~6X*6K+6X*6T+6I11*6X~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P237_B002_01

- 身份：正文
- PDF 页：237
- 偈颂：46-47 1/2
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 46-47 1/2 [present] · PDF page 237

46-47 1/2. Effects like gains of wealth through Brahmins,
increase in the number of cattle, celebrations for the
birth of a son, well being, recognition from government,
acquisition of a kingdom, attainment of a high position in
government, great enjoyment and comforts, etc., will be
experienced in the Antar Dasha of Shukr in the Dasha of
Rahu if Shukr is with strength in a Kendr, in a Trikon, or
in Labh Bhava.
~6E+6O+6NE+6NO~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P237_B003_01

- 身份：正文
- PDF 页：237
- 偈颂：48-50 1/2
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 48-50 1/2 [present] · PDF page 237

48-50 1/2. Construction of a new house, availability of
sweet preparations, happiness from wife and children,
association with friends, giving of grains, etc., in
charity, beneficence of the king (government), gain of
conveyances and clothes extraordinary profits in business,
celebration of Upasayan ceremony of wearing the sacred
thread ('Janou'), etc., will be the auspicious. Results, if
Shukr be in his Exaltation Rashi, in his own Rashi, in is
exalted Navamsh, or in his own Navamsh.
~6I6+6I8+6I12+6d+6e+6A7+6A3+6A8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P237_B004_01

- 身份：正文
- PDF 页：237
- 偈颂：51-53 1/2
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 51-53 1/2 [present] · PDF page 237

51-53 1/2. There will be diseases, quarrels, separation
from one's son or father, distress to kinsmen, disputes
with coparceners, danger of death to oneself or to one's
employer, unhappiness to wife and children, pain in the
stomach, etc., if Shukr is in Ari, Randhr, or Vyaya Bhava,
if Shukr is in his Debilitation Rashi, or in an enemy's
Rashi, or if Shukr is associated with Shani, Mangal, or
Rahu.
~(6I!K)8+(6I!T)8+(6I11)8+(6I10)8~
54-55 1/2, Enjoyments from perfumes, bed, music, etc., gain
of a desired object, fulfillment of desires, will be the
results, if Shukr is in a Kendr, in a Trikon, in the 11th,
or in the 10th from the lord of the Dasha (Rahu).
~(6I6)8*6Am+(6I8)8*6Am+(6I12)8*6Am~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P238_B001_01

- 身份：正文
- PDF 页：238
- 偈颂：56-59
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 56-59 [present] · PDF page 238

56-59. Effects like danger from the wrath of Brahmins,
snakes, and the king (government), possibility of
affliction with diseases like stoppage of urine, diabetes,
pollution of blood, anaemia, availability of only coarse
food, nervous disorder, imprisonment, loss of wealth as a
result of penalties or fines imposed by government, will be
derived if Shukr is associated with malefics in the 6th, the
8th, or the 12th from the lord of the Dasha (Rahu).
~6iL2+6iL7~
There will be distress to wife and children, danger of
premature death to oneself if Shukr is Dhan's lord or
Yuvati's.
Remedial measures to obtain relief from the above evil
effects are worship of Goddess Durga and Goddess Lakshmi.
@8112@
Effects of the Antar Dasha of Surya in the Antar Dasha of
Rahu
~1E+1O+1I11+1K+1T+1NE+1NO~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P238_B002_01

- 身份：正文
- PDF 页：238
- 偈颂：60-61 1/2
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 60-61 1/2 [present] · PDF page 238

60-61 1/2. Effects like cordial relations with the king
(government), increase in wealth and grains, some
popularity/ respect, some possibility of becoming head of a
village, etc., will be experienced in the Antar Dasha of
Surya in the Dasha of Rahu, if Surya is in his Exaltation
Rashi, in his own Rashi, in Labh Bhava, in a Kendr, or in a
Trikon (from Lagn), or if Surya is in his exalted or own
Navamsh.
~1AL1+1DL1+1AL9+1DL9+1AL10+1DL10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P238_B003_01

- 身份：正文
- PDF 页：238
- 偈颂：62-63 1/2
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 62-63 1/2 [present] · PDF page 238

62-63 1/2. There will be good reputation and encouragement
and assistance by government, journeys to foreign
countries, acquisition of the sovereignty of the country,
gains of elephants, horses, clothes, ornaments, fulfillment
of ambitions, happiness to children, etc., if Surya is
associated with or receives a drishti from Lagn's lord, Dharm's
lord, or Karm's lord.
~1d+(1I6)8+(1I8)8+(1I12)8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P238_B004_01

- 身份：正文
- PDF 页：238
- 偈颂：64-65
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 64-65 [present] · PDF page 238

64-65. Fevers, dysentery, other diseases, quarrels,
antagonism with the king (government), travels, danger from
foes, thieves, fire, etc., will be the results if Surya is
in his Debilitation Rashi or if Surya is in the 6th, the
8th, or the 12th from the lord of the Dasha (Rahu).
~(1I!K)8+(1I!T)8+(1I3)8+(1I11)8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P238_B005_01

- 身份：正文
- PDF 页：238
- 偈颂：66
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 66 [present] · PDF page 238

66. Well-being in every way and recognition from kings
(high dignitaries) in foreign countries, will be the
results if Surya is in a Kendr, in a Trikon, in the 3rd, or
in the 11th from the lord of the Dasha (Rahu).
~1iL2+1iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P238_B006_01

- 身份：正文
- PDF 页：238
- 偈颂：67
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 67 [present] · PDF page 238

67. There will be danger of critical illness if Surya is
Dhan's lord or Yuvati's lord. Worship of Surya is the
remedial measure recommend to obtain relief from the above
evil effects.
@8122@
Effects of the Antar Dasha of Chandr in the Dasha of Rahu
~2E+2O+2K+2T+2I11+2F*2DB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P239_B001_01

- 身份：正文
- PDF 页：239
- 偈颂：68-70
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 68-70 [present] · PDF page 239

68-70. Effects like acquisition of a kingdom (attainment of
high position in government), respect from the king (high
officials of government), gains of wealth, sound health,
gains of garments and ornaments, happiness from children,
comforts of conveyances, increase in house and landed
property, etc., will be derived, in the Antar Dasha of
Chandr in the Dasha of Rahu if Chandr is in his Exaltation
Rashi, in his own Rashi, in a Kendr, in a Trikon, or in
Labh Bhava, or if Chandr is in a friendly Rashi receiving a
drishti from benefics.
~(2I5)8+(2I9)8+(2I11)8+(2I!K)8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P239_B002_01

- 身份：正文
- PDF 页：239
- 偈颂：71-72
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 71-72 [present] · PDF page 239

71-72. Beneficence of the Goddess Lakshmi, all round
success, increase in wealth and grains, good reputation,
and worship of deities, will be the results, if Chandr is
in the 5th, in the 9th, in a Kendr, or in the 11th from the
lord of the Dasha (Rahu).
~2x*(2I6)8+2x*(2I12)8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P239_B003_01

- 身份：正文
- PDF 页：239
- 偈颂：73-75
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 73-75 [present] · PDF page 239

73-75. There will be the creation of disturbances at home
and in the agricultural activities by evil spirits,
leopards, and other wild animals, danger from thieves
during journeys, and stomach disorders, if Chandr is bereft
of strength in the 6th, in the 8th, or the 12th from the
lord of the Dasha (Rahu).
~2iL2+2iL12~
There will the possibility of premature death if Chandr is
Dhan's lord or Vyaya's lord. The remedial measure to obtain
relief from the above evil effects is to give in charity a
white cow or a female buffalo
@8132@
Effects of the Antar Dasha of Mangal in the Dasha of Rahu
~3I11+3I5+3I9+3K+3DB+3E+3O~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P239_B004_01

- 身份：正文
- PDF 页：239
- 偈颂：76-77 1/2
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 76-77 1/2 [present] · PDF page 239

76-77 1/2. Effects like the recovery of a lost kingdom
(reinstatement in a high position in government) and
recovery of lost wealth, property at home, and increase in
agricultural production, gain of wealth, blessings by the
household deity  (Isht Dev), happiness from children,
enjoyment of good food, etc., will be derived in the Antar
Dasha of Mangal in the Dasha of Rahu if Mangal is in Labh,
in Putr, or in Dharm Bhava, or if Mangal is in a Kendr
(from Lagn), if Mangal receives a drishti from benefics, or
if Mangal is in his exaltation Rashi, or in his own Rashi.
~(3I!K)8+(3I5)8+(3I9)8+(3I3)8+(3I11)8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P239_B005_01

- 身份：正文
- PDF 页：239
- 偈颂：78-79 1/2
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 78-79 1/2 [present] · PDF page 239

78-79 1/2. There will be acquisition of red coloured
garments, journeys, audience with the king (meetings with
high governmental officials), well being of children and
employer, attainment of the position of a commander of the
army, enthusiasm, and gain of wealth through kinsmen, if
Mangal is in a Kendr, in the 5th, in the 9th, in the 3rd,
or in the 11th from the lord of the Dasha (Rahu).
~8Dm*(8I6)8+8Dm*(8I8)8+8Dm*(8I12)8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P240_B001_01

- 身份：正文
- PDF 页：240
- 偈颂：80-82
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 80-82 [present] · PDF page 240

80-82. Distress to wife, children, and co-borns, loss of
position, antagonistic relations with children, wife, and
other close relations, danger from thieves, wounds and pain
in the body, etc., will result if Mangal is in the 6th, the
8th, or the 12th from the lord of the Dasha (Rahu)
receiving a drishti from malefics.
~8iL2+8iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P240_B002_01

- 身份：正文
- PDF 页：240
- 偈颂：83
- 标题路径：CHAPTER 55 Effects in the Antar Dashas in the Dasha of › Rahu @8182@ Effects of the Antar Dashas of Rahu in the Dasha of Rahu ~8I3+8I6+8I10+8I11+8Yy*8E**8Yy*8E+8IR4+8IR8+8IR6+8IR9~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects in the Antar Dashas in the Dasha of · Sloka 83 [present] · PDF page 240

83. There will be lethargy and danger of death, if Mangal
is Dhan's lord or Yuvati's lord.
The remedial measure to obtain relief from the above evil
effects is giving a cow or a bull in charity.
