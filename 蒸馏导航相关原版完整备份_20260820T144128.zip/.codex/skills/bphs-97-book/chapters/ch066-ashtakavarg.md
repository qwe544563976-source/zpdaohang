# 第 66 章：Ashtakavarg

- 来源：BPHS 97 章版
- 原始卡片：24 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P299_B002_01

- 身份：正文
- PDF 页：299
- 偈颂：1-4
- 标题路径：CHAPTER 66 Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ashtakavarg · Sloka 1-4 [present] · PDF page 299

1-4. Maitreya said: "O Venerable Sage! You have described
many kinds of effects relating to the grahas and bhavas after
incorporating the views of many sages and acharyas, but it is
not possible to say with certainty if a particular effect is
quite correct after considering the contradictions in the
effects by the movements of the various grahas. As because of
sinful deeds committed by people in Kaliyuga , their minds
have become blunt, be kind enough to describe a method which
would enable even the shallow minded persons to ascertain
their happiness and sorrows and determine their longevity on
the basis of the positions of the grahas in transit."

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P299_B003_01

- 身份：正文
- PDF 页：299
- 偈颂：5-6
- 标题路径：CHAPTER 66 Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ashtakavarg · Sloka 5-6 [present] · PDF page 299

5-6. The sage replied: "O Brahmin! You have put a very
intelligent  question. I will now describe the Shastra for
the benefit of all-the Shastra in which there will be no
contradictions in judging the effects of happiness and
sorrows and for determination of the longevity. You now
listen to me carefully.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P299_B004_01

- 身份：正文
- PDF 页：299
- 偈颂：7-11
- 标题路径：CHAPTER 66 Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ashtakavarg · Sloka 7-11 [present] · PDF page 299

7-11. If the 12 bhavas, including Lagn are occupied by or
aspected by benefic grahas, they yield auspicious results
according to their characteristics but this happens where the
grahas concerned are in their exaltation rashi, own rashi, or
posited in a benefic bhava. There will be no good effects if
such grahas are in depression or posited in an inauspicious
bhava. Similarly, the bhavas associated with or aspected by
malefics in depression or posited in malefic bhavas, yield
adverse results according to their characteristics. If such
grahas be in their exaltation rashi, the effects will not be
adverse. This is how the general effects have been described
by the Daivajnas. I have only repeated those effects. The
main purposes of this Jyotish Shastra are to determine the
longevity and joys and sorrows of the people, but because the
movements of the grahas are so subtle, even sages like
Vashista and Brihaspati have not been able to be quite
definite in this respect. Then, how can a common man,
particularly in Kaliyuga do so.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P299_B005_01

- 身份：正文
- PDF 页：299
- 偈颂：12
- 标题路径：CHAPTER 66 Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ashtakavarg · Sloka 12 [present] · PDF page 299

12. There are two divisions or parts of the Jyotish Shastra,
namely general and particular. I have already dealt with the
general part. I now come to the other part which deals with
this subject in particular.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P300_B001_01

- 身份：正文
- PDF 页：300
- 偈颂：13-15
- 标题路径：CHAPTER 66 Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ashtakavarg · Sloka 13-15 [present] · PDF page 300

13-15. As the effects of the twelve bhavas are judged from
Lagn and Chandr, effects of the twelve bhavas and the various
grahas are judged in the same manner. Therefore, the
inauspicious places from the seven grahas, named as Karan,
beginning from Surya and Lagn (total 8) should be marked by
dots (bindus) and auspicious places named as Sthan by small
vertical lines (rekhas) and on the basis of their assessment
should the judgment of the horoscope and predictions be
made."
Notes: The above arrangement is known as Ashtakavarg. The
meaning of Ashtakavarg is literally the group of eight
things. In other words, it is the combination of the good and
bad positions of a grah with reference to the seven grahas
and Lagn. So, it is the combination of the benefic and
malefic marks (the rekhas and the bindus) in a planet's chart
with reference to the position of the eight grahas (here,
Lagn is to be treated as a grah).

Karanprad bhavas in the Ashtakavarg of Surya

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P300_B002_01

- 身份：正文
- PDF 页：300
- 偈颂：16
- 标题路径：CHAPTER 66 Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ashtakavarg · Sloka 16 [present] · PDF page 300

16. Five grahas in 1st, 2nd, 8th, 3rd and the 12th bhavas
from Surya are Karanprad (dot significators). Similarly, five
grahas in the 7th and 4th; three grahas in the 6th and 9th;
six grahas in the 5th; 2 grahas in the 10th and one grah in
the 11th are dot significators.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P300_B003_01

- 身份：正文
- PDF 页：300
- 偈颂：17-19
- 标题路径：CHAPTER 66 Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ashtakavarg · Sloka 17-19 [present] · PDF page 300

17-19. Thus, Lagn, Chandr, Guru, Shukr, and Buddh (5 grahas)
in the 1st, 2nd and 8th from Surya; Surya, Mangal, Shani,
Chandr, and Guru (5 grahas) in the 12th; Buddh, Chandr,
Shukr, Guru (4 grahas) in the 4th; Lagn, Chandr, Shukr (3
grahas) in the 9th; Surya, Shani an Mangal (3 grahas) in the
6th; Lagn, Buddh, Guru, and Chandr (4 grahas) in the 7th;
Shukr (1 grah) in the 11th; Surya, Shani, Shukr, Guru, and
Mangal (5 grahas) in the 3rd; Guru and Shukr (2 grahas) in
the 10th; Surya, Shani, Chandr, Lagn Mangal, and Shukr (6
grahas) in the 5th are Karanprad or dot indicators.
Karanprad bhavas in the Ashtakavarg of Chandr

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P300_B004_01

- 身份：正文
- PDF 页：300
- 偈颂：20-22
- 标题路径：CHAPTER 66 Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ashtakavarg · Sloka 20-22 [present] · PDF page 300

20-22. In Chandr's Ashtakavarg, 6 grahas in the 9th and the
2nd; 5 grahas in the 4th, 8th, and the 1st; one grah in the
10th and the 3rd; 4 grahas in the 5th; 3 grahas in the 6th
and the 7th and 1 st; eight (7 grahas and Lagn) in the 12th
are Karanprad (dot significators). Thus, Lagn, Surya, Mangal,
Shani and Shukr, these five in the 1st; Lagn, Buddh, Surya,
Chandr, Shani, and Shukr, these 6 in the 2nd; Guru in the
3rd; Surya, Shani, Chandr, Lagn, and Mangal, these 5 in the
4th; Shukr, Buddh, Guru, these 3 in the 6th; Mangal, Lagn,
and Shani, these 3 in the 7th; Mangal, Lagn, Shani. Shukr,
and Chandr, these five in the 8th; Lagn, Surya, Mangal,
Shani, Buddh, and Guru, these 6 in the 9th; Shani only in the
10th; none in the 11th; all the eight in the 12th from their
own places are Karanprad (dot significators). These grahas in
the other bhavas are Rekhaprad (line significators).
Karanprad bhavas in the Ashtakavarg of Mangal

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P301_B001_01

- 身份：正文
- PDF 页：301
- 偈颂：23-27
- 标题路径：CHAPTER 66 Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ashtakavarg · Sloka 23-27 [present] · PDF page 301

23-27. In the Ashtakavarg of Mangal 6 grahas in the 12th, the
4th, the 5th, and the 7th; 7 grahas in the 2nd and the 9th; a
grah in the 1st and the 8th; 4 grahas in the 3rd; 3 grahas in
the 10th, and 2 grahas in the 6th are Karanprad (dot
significators). In the 11th no grah is Karanprad. In other
words all the grahas in the 11th from their own places are
rekhaprad (line significators). Thus, Surya, Chandr, Buddh,
Guru, and Shukr, these five in the 1st; Lagn, Surya, Chandr,
Buddh, Guru, and Shani, these 7 in the 2nd; Shukr, Mangal,
Guru, and Shani, these 4 in the 3rd; Surya, Chandr, Buddh,
Guru, Shukr, and Lagn, these 6 in the 4th; Chandr, Mangal,
Guru, Shukr, and Lagn, these 5 in the 5th; Mangal and Shani,
these 2 in the 6th; Buddh, Chandr, Surya, Shukr, Guru, and
Lagn, these 6 in the 7th; Buddh Chandr, Surya, Lagn, and
Guru, these five in the 8th; Surya, Chandr, Mangal, Buddh,
Guru, Shukr and Lagn, these 7 in the 9th; Shukr, Chandr, and
Buddh, these 3 in the 10th; none in the 11th; Surya, Shani,
Buddh, Chandr, Lagn, and Mangal, these 6 in the 12th, from
their own places are Karanprad (dot significators).
Karanprad bhavas in the Ashtakavarg of Buddh

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P301_B002_01

- 身份：正文
- PDF 页：301
- 偈颂：28-30
- 标题路径：CHAPTER 66 Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ashtakavarg · Sloka 28-30 [present] · PDF page 301

28-30. In the Ashtakavarg of Buddh 3 grahas in the 1st, the
2nd, the 4th, the 10th, the 6th, and the 9th; 2 grahas in the
8th; 6 grahas in the 3rd and the 7th; none in the 11th; 5
grahas in the 5th and the 12th are Karanprad (dot
significators). Thus, Surya, Chandr, and Guru, these 3 in the
1st; Guru, Surya, and Buddh, these 3 in the 2nd; Lagn, Surya,
Mangal, Shani, Chandr, and Guru, these 6 in the 3rd; Buddh,
Surya, and Guru, these 3 in the 4th; Guru, Mangal, Chandr,
Shani, and Lagn, these 5 in the 5th; Shukr, Shani, and
Mangal, these 3 in the 6th; Buddh, Chandr, Lagn, Surya,
Shukr, and Guru, these 6 in the 7th; Buddh and Surya, these 2
in the 8th; Guru, Chandr, and Lagn, these 3 in the 9th;
Surya, Guru, and Shukr, these 3 in the 10th; none in the
11th; Lagn, Chandr, Mangal, Shani, and Shukr these 5 in the
12th from their own places are Karanprad (dot significators).
Karanprad bhavas in the Ashtakavarg of Guru

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P301_B003_01

- 身份：正文
- PDF 页：301
- 偈颂：31-34
- 标题路径：CHAPTER 66 Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ashtakavarg · Sloka 31-34 [present] · PDF page 301

31-34. In the Ashtakavarg of Guru one grah in the 2nd and the
11th, 2 grahas in the 10th, 7 grahas in the 12th; 4 grahas in
the 6th; 5 grahas in the 8th and the 3rd, 3 grahas in the
remaining bhavas (1st, 4th, 5th, 7th, 9th) are Karanprad (dot
significators). Thus, Shukr, Chandr, and Shani, these 3 in
the 1st; Shani in the 2nd and 11th; Lagn, Mangal, Chandr,
Buddh and Shukr, these 5 in the 3rd; Surya, Guru, and Mangal,
these 3 in the 5th; Shukr, Shani, and Chandr, these 3 in the
4th; Buddh, Shukr, and Shani, these 3 in the 7th; Guru,
Mangal, Surya, and Chandr, these 4 in the 6th; all except
Shani, these 7 in the 12th; Chandr and Shani, these 2 in the
10th; Shani, Mangal, and Guru, these 3 in the 9th; Lagn,
Shani, Shukr, Chandr, and Buddh, these 5 in the 8th, from
their own places are Karanprad (dot significators).
Karanprad bhavas in the Ashtakavarg of Shukr

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P302_B001_01

- 身份：正文
- PDF 页：302
- 偈颂：35-38
- 标题路径：CHAPTER 66 Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ashtakavarg · Sloka 35-38 [present] · PDF page 302

35-38. In the Ashtakavarg of Shukr, 2 grahas in the 5th, the
8th, and the 3rd, 5 grahas in the 1st, the 2nd, the 12th, the
10th, 8 grahas in the 7th, 6 grahas in the 6th, one in the
9th, 3 in the 4th, none in the 11th, are Karanpradas. Thus,
Surya, Mangal, Buddh, Guru, and Shani, these 5 in the 1st and
the 2nd; all the 8 grahas (including Lagn) in the 7th; .Guru
and Surya, these 2 in the 3rd; Surya and Mangal, these 2 in
the 5th; Surya in 2nd; Surya, Buddh, and Guru, these 3 in the
4th; Mangal and Buddh, these 2 in the 8th; Shukr, Surya,
Chandr, Shani, Lagn, and Guru, these 6 in the 6th; none in
the 11th; Lagn, Shani, Buddh, Shukr, and Guru, these 5 in the
12th; Lagn, Mangal, Buddh, Chandr, Surya, these 5 in the
10th, from their own places are Karanpradas (dot
significators).
Karanprad bhavas in the Ashtakavarg of Shani

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P302_B002_01

- 身份：正文
- PDF 页：302
- 偈颂：39-42
- 标题路径：CHAPTER 66 Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ashtakavarg · Sloka 39-42 [present] · PDF page 302

39-42. In the Ashtakavarg of Shani, 7 grahas in the 2nd, the
7th, the 9th, 6 grahas in the 8th, Lagn, and the 4th, 4
grahas in the 10th, the 3rd, and the 12th, one grah in the
6th, 5 grahas in the 5th, none in the 11th, are Karanpradas
(Bindu significators). Thus, Chandr, Mangal, Buddh, Guru,
Shukr, and Shani, these 6 in the 4th and the 1st; Chandr,
Mangal, Buddh, Guru, Shukr, Shani, and Lagn, these 7 in the
2nd and the 7th; Surya, Chandr, Mangal, Guru, Shukr, Shani,
and Lagn, these 7 in the 9th; Chandr, Guru, Shukr, and Shani,
these 4 in the 10th; Guru, Surya, Buddh, and Shukr, these 4
in the 3rd; Surya in the 6th; Lagn, Chandr, Shani, Surya,
these 4 in the 12th; Shukr, Surya, Chandr, Buddh, and Lagn,
these 5 in the 5th; Chandr, Mangal, Guru, Shukr, Shani, and
Lagn, these 6 in the 8th; none in the 11th, from their own
places are Karanpradas (dot significators). The remaining
places are Rekhapradas (line significators) and are
auspicious.
Rekhapradas bhavas in the Ashtakavarg of Surya

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P302_B003_01

- 身份：正文
- PDF 页：302
- 偈颂：43-45
- 标题路径：CHAPTER 66 Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ashtakavarg · Sloka 43-45 [present] · PDF page 302

43-45. The sage said: "Now I will describe the auspicious
(Rekhaprad) bhavas for the benefit of the acharyas. In the
Ashtakapradas of Surya, Shani, Mangal, and Surya in the 2nd,
the 8th and the 1st; Guru and Buddh in the 5th; Buddh,
Chandr, and Lagn in the 3rd;  Lagn, Surya, Shani, and Mangal
in the 4th; Lagn, Surya, Shani, Mangal, Buddh, and Chandr in
the 10th; Surya, Chandr, Mangal, Buddh, Guru, Shani, and Lagn
in the 11th; Lagn, Shukr, and Buddh in the 12th; Lagn, Shukr,
Buddh, Guru, and Chandr in the 6th; Surya, Mangal, Shani, and
Shukr in the 7th; Surya, Mangal, Shani, Buddh, and Guru in
the 9th from their own places are Rekhapradas (auspicious).
Rekhaprad bhavas in the Ashtakavarg of Chandr

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P302_B004_01

- 身份：正文
- PDF 页：302
- 偈颂：46-48
- 标题路径：CHAPTER 66 Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ashtakavarg · Sloka 46-48 [present] · PDF page 302

46-48. In the Ashtakavarg of Chandr: Buddh, Chandr and Guru
in the 1st; Guru and Mangal in the 2nd; Buddh, Surya, Chandr,
Mangal, Shani, Shukr, and Lagn in the 3rd; Guru, Shukr, and
Buddh in the 4th; Mangal, Buddh, Shukr, and Shani in the 5th;
Surya, Chandr, Mangal, Shani, and Lagn in the 6th; Surya,
Chandr, Guru, Buddh, and Shukr in the 7th; Surya, Buddh, and
Guru in the 8th; Shukr and Chandr in the 9th; Surya, Buddh,
Guru, Shukr, Chandr, Lagn, and Mangal in the 10th; and all
the 8 grahas in the 11th from their own places are
Rekhapradas. No grah is Rekhaprad in the 12th.

Rekhaprad bhavas in the Ashtakavarg of Mangal

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P303_B001_01

- 身份：正文
- PDF 页：303
- 偈颂：49-50
- 标题路径：CHAPTER 66 Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ashtakavarg · Sloka 49-50 [present] · PDF page 303

49-50. In the Ashtakavarg of Mangal: Lagn, Shani, and Mangal
in the 1st; Mangal in the 2nd; Lagn, Buddh, Chandr, and Surya
in the 3rd; Shani, and Mangal in the 4th; Buddh and Surya in
the 5th; Buddh, Chandr, Guru, Surya, Lagn, and Shukr in the
6th; Shani and Mangal in the 7th; Shani, Mangal, and Shukr in
the 8th; Shani in the 9th; Mangal, Surya, Guru, Shani, and
Lagn in 10th; all in the 11th and Guru and Shukr in the 12th
from their own places are rekhapradas.
Rekhaprad bhavas in the Ashtakavarg of Buddh

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P303_B002_01

- 身份：正文
- PDF 页：303
- 偈颂：51-52
- 标题路径：CHAPTER 66 Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ashtakavarg · Sloka 51-52 [present] · PDF page 303

51-52. In the Ashtakavarg of Buddh: Lagn, Shani, Mangal,
Shukr, and Buddh in the 1st; Lagn, Mangal, Chandr, Shukr, and
Shani in the 2nd; Shukr and Buddh in the 3rd; Lagn, Chandr,
Shani, Shukr, and Mangal in the 4th; Buddh, Shani, and Shukr
in the 5th; Guru, Buddh, Surya, Chandr, and Lagn in the 6th;
Mangal and Shani in the 7th; Mangal, Shani, Lagn, Chandr,
Shukr, and Guru in the 8th; Shani, Mangal, Surya, Buddh, and
Shukr in the 9th; Lagn, Shani, Mangal, Buddh, and Chandr in
the 10th ; all in the 11th and Guru, Buddh, and Surya in the
12th, from their own places, are rekhapradas.

Rekhaprad bhavas in the Ashtakavarg of Guru

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P303_B003_01

- 身份：正文
- PDF 页：303
- 偈颂：53-55
- 标题路径：CHAPTER 66 Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ashtakavarg · Sloka 53-55 [present] · PDF page 303

53-55. In the Ashtakavarg of Guru: Lagn, Mangal, Surya and
Buddh in the 1st and the 4th; Guru, Lagn, Mangal, Surya,
Buddh, Chandr, and Shukr in the 2nd; Shani, Guru, and Surya
in the 3rd; Shukr, Chandr, Lagn, Buddh and Shani in the 5th;
Shukr, Lagn, Buddh, and Shani in the 6th; Lagn, Mangal, Guru,
Surya, and Chandr in the 7th; Guru, Surya, and Mangal in the
8th; Shukr, Surya, Lagn, Chandr, and Buddh in the 9th; Guru,
Buddh, Mangal, Surya, Shukr, and Lagn in the 10th; all except
Shani in the 11th and Shani in the 12th, from their own
places are rekhapradas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P303_B004_01

- 身份：正文
- PDF 页：303
- 偈颂：56-58
- 标题路径：CHAPTER 66 Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ashtakavarg · Sloka 56-58 [present] · PDF page 303

56-58. In the Ashtakavarg of Shukr, Lagn, Shukr, and Chandr
in the 1st; Lagn, Shukr and Chandr in the 2nd; Lagn, Shukr,
Chandr, Buddh, Shani, and Mangal in the 3rd; Lagn, Shukr,
Chandr, Shani, and Mangal in the 4th; Lagn, Buddh, Chandr,
Guru, Shani, and Shukr in the 5th; Buddh and Mangal in the
6th; none in the 7th; Shukr, Surya, Chandr, Guru, Lagn and
Shani in the 8th; all except Surya in the 9th; Shukr, Guru,
and Shani in the 10th; all in the 11th; Mangal, Chandr, and
Surya in the 12th; from their own places, are rekhapradas.
Rekhaprad bhavas in the Ashtakavarg of Shani

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P303_B005_01

- 身份：正文
- PDF 页：303
- 偈颂：59-60
- 标题路径：CHAPTER 66 Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ashtakavarg · Sloka 59-60 [present] · PDF page 303

59-60. In the Ashtakavarg of Shani, Surya and Lagn in the
1st; Surya in the 2nd; Lagn, Chandr, Mangal, and Shani in the
3rd; Lagn and Surya in the 4th; Guru, Shani, and Mangal in
the 5th; all except Surya in the 6th; Surya in the 7th; Surya
and Buddh in the 8th; Buddh in the 9th; Surya, Mangal, Lagn,
and Buddh in the 10th; all in the 11th; Mangal, Buddh, Guru,
and Shukr in the 12th from their own places, are rekhapradas.
Karanprad bhavas in the Ashtakavarg of Lagn

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P304_B001_01

- 身份：正文
- PDF 页：304
- 偈颂：61-64
- 标题路径：CHAPTER 66 Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ashtakavarg · Sloka 61-64 [present] · PDF page 304

61-64. In the Ashtakavarg of Lagn 3 grahas in the 1st and the
4th; 2 grahas in the 3rd; 5 grahas in the 2nd; 6 grahas in
the 5th, the 8th, the 9th and the 12th; one grah in the 10th,
the 11th, and the 6th; and all except Guru in the 7th are
Karanpradas (dot significators). Thus, Lagn, Surya, and
Chandr in the 1st; Lagn, Mangal, Chandr,  Surya, and Shani in
the 2nd; Guru and Buddh in the 3rd; Lagn, Chandr, Mangal,
Buddh, Shani, and Surya in the 5th; Lagn, Chandr, and Mangal
in the 4th;  Shukr in the 6th; all except Guru in the 7th
;Lagn, Surya, Chandr, Mangal, Guru, and Shani in the 8th;
Lagn, Surya, Chandr, Mangal, Buddh and Shani in the 9th;
Shukr in the 10th; Shukr in the 11th; Lagn, Mangal, Buddh,
Guru, Shukr, and Shani in the 12th from their own places are
Karanpradas (dot significators).

Rekhapradas in the Ashtakavarg of Lagn

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P304_B002_01

- 身份：正文
- PDF 页：304
- 偈颂：65-68
- 标题路径：CHAPTER 66 Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ashtakavarg · Sloka 65-68 [present] · PDF page 304

65-68. In the Ashtakavarg of Lagn: Shani, Buddh, Shukr, Guru,
and Mangal in the 1st; Buddh, Guru, and Shukr in the 2nd;
Lagn, Surya, Chandr, Mangal, Shukr, and Shani in 3rd; Surya,
Buddh, Guru, Shukr, and Shani in the 4th; Guru and Shukr in
the 5th, all except Shukr in the 6th; Guru in the 7th; Buddh
and Shukr in the 8th; Guru and Shukr in the 9th; all except
Shukr in the 10th; all except Shukr in the 11th; and Surya
and Chandr in the 12th from their own places are rekhapradas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P304_B003_01

- 身份：正文
- PDF 页：304
- 偈颂：69
- 标题路径：CHAPTER 66 Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ashtakavarg · Sloka 69 [present] · PDF page 304

69. In the charts of Ashtakavarg, Karan is signified by a
bindu or dot (O) and Sthan by a Rekhapradas or line (1).
Karan is inauspicious while Sthan is auspicious.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P304_B004_01

- 身份：正文
- PDF 页：304
- 偈颂：70-72
- 标题路径：CHAPTER 66 Ashtakavarg
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ashtakavarg · Sloka 70-72 [present] · PDF page 304

70-72. To identify the auspicious and in auspicious bhavas
in the Ashtakavarg, a chart should be prepared with 14
horizontal lines and ten vertical lines. The form of the
chart so prepared will consist of 117 apartments. In this
chart in the first line (horizontally) incorporate the names
of the seven grahas and Lagn. In the first column
(vertically) write the numbers of all the 12 bhavas. After
this, mark dots under the grah and against the Karanprad
bhavas. By doing so the Karanprad bhavas of all the 8 grahas
including Lagn will become known clearly and whenever the
Ashtakavarg grah will pass in transit the dot marked bhavas,
he will yield unfavourable results. In his transit to other
bhavas he would give favourable effects.The following table
shows the dots in the Ashtakavarg of Surya.
