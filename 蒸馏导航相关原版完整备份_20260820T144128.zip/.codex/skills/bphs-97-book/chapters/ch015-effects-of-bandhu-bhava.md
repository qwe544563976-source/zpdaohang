# 第 15 章：Effects of Bandhu Bhava

- 来源：BPHS 97 章版
- 原始卡片：10 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P039_B002_01

- 身份：正文
- PDF 页：39
- 偈颂：1
- 标题路径：CHAPTER 15 Effects of Bandhu Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Bandhu Bhava · Sloka 1 [present] · PDF page 39

1. O excellent of the Brahmins: Thus, have been briefly
told about the effects of Sahaj Bhava. Now listen to the
results related to Bandhu Bhava.
~L4I4*L4DB+L1I4*L1DB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P039_B003_01

- 身份：正文
- PDF 页：39
- 偈颂：2
- 标题路径：CHAPTER 15 Effects of Bandhu Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Bandhu Bhava · Sloka 2 [present] · PDF page 39

2. Housing Comforts: One will have residential comforts in
full degree if Bandhu is occupied by its lord or by Lagn's
lord and be drishtied by a benefic.
~L5I5+L5O+L5NO+L5E+L5NE~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P039_B004_01

- 身份：正文
- PDF 页：39
- 偈颂：3
- 标题路径：CHAPTER 15 Effects of Bandhu Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Bandhu Bhava · Sloka 3 [present] · PDF page 39

3. Miscellaneous: Should Putr's lord be in his own bhava,
or in own Navamsh or in exaltation, the native will be
endowed with comforts related to lands, conveyances,
houses, etc., and musical instruments.
~L10YL4*L4K+L10YL4*L4T~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P039_B005_01

- 身份：正文
- PDF 页：39
- 偈颂：4
- 标题路径：CHAPTER 15 Effects of Bandhu Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Bandhu Bhava · Sloka 4 [present] · PDF page 39

4. Housing Comforts: If Karm's lord joins Bandhu's lord in
an angle or in a trine, the native will acquire beautiful
mansions.
~4I1*L4iB*L4DB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P039_B006_01

- 身份：正文
- PDF 页：39
- 偈颂：5
- 标题路径：CHAPTER 15 Effects of Bandhu Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Bandhu Bhava · Sloka 5 [present] · PDF page 39

5. Relatives: Should Buddh be in Lagn, while Bandhu's lord
being a benefic is drishtied by another benefic, the native
will be honoured by his relatives.
~BI4*L4E*2X+BI4*L4E*3X~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P039_B007_01

- 身份：正文
- PDF 页：39
- 偈颂：6
- 标题路径：CHAPTER 15 Effects of Bandhu Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Bandhu Bhava · Sloka 6 [present] · PDF page 39

6. Long-living Mother: If Bandhu Bhava is occupied by a
benefic, while its lord is in his exaltation rashi, as the
indicator of mother is endowed with strength, the native
with have a long-living mother.
~L4K*6K*4E~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P039_B008_01

- 身份：正文
- PDF 页：39
- 偈颂：7
- 标题路径：CHAPTER 15 Effects of Bandhu Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Bandhu Bhava · Sloka 7 [present] · PDF page 39

7. Happiness of Mother: The native's mother will be happy
if Bandhu's lord is in an angle while Shukr is also in an
angle as Buddh is exalted.
~1I4*2I9*7I9*3I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P039_B009_01

- 身份：正文
- PDF 页：39
- 偈颂：8
- 标题路径：CHAPTER 15 Effects of Bandhu Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Bandhu Bhava · Sloka 8 [present] · PDF page 39

8. Quadrupeds: Surya in Bandhu, Chandr and Shani in Dharm,
and Mangal in Labh Bhava, this yoga will confer cows and
buffaloes on the native.
~RmI!4**L4Y3*3I6+L4Y3*3I8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P039_B010_01

- 身份：正文
- PDF 页：39
- 偈颂：9
- 标题路径：CHAPTER 15 Effects of Bandhu Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Bandhu Bhava · Sloka 9 [present] · PDF page 39

9. Dumbness: Should Bandhu Bhava be a movable one, while
its lord and Mangal are together in Ari or Randhr Bhava,
the native will be dumb.
~L1iB*L4d*6I12+L1iB*L4I11*6I12~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P040_B001_01

- 身份：正文
- PDF 页：40
- 偈颂：10-14
- 标题路径：CHAPTER 15 Effects of Bandhu Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Bandhu Bhava · Sloka 10-14 [present] · PDF page 40

10-14. Conveyances: If Lagn's lord is a benefic while
Bandhu's lord is in fall or in Labh Bhava and the
significator (Shukr) is in Vyaya Bhava, the native will
obtain conveyances in his 12th year.
~1I4*L4E*L4Y6~
Should Surya be in Bandhu Bhava, as Bandhu's lord is
exalted and be with Shukr, one will acquire conveyanees in
his 32nd year.
~L4NE*L4YNL10~
It will be in the 42nd year that one will be endowed with
conveyances if Bandhu's lord joins Karm's lord in his (4th
lord's) exaltation Navamsh.
~L4lL11~
An exchange between Labh's and Bandhu's lords will confer
conveyances in the 12th year.
~BI4+!4DB**L4YB+L4DB~
A benefic related to Bandhu Bhava (and to its lord) will
bring with him auspicious effects (regarding conveyances)
~mI4+!4Dm**L4Ym+L4Dm~n
while a malefic will produce only malefic effects (in
respect of conveyances).
~BI4+!4DB+L4YB+L4DB~
Should a benefic be in Bandhu, drishti Bandhu, or in yuti
with the lord of Bandhu, or a drishti on the lord of Bandhu
Bhava, then the native will be happy with conveyances and
be free from accidents and dangers.
~mI4+!4Dm+mYL4+L4Dm~n
A malefic replacing the said benefic will cause losses
concerning vehicles and reduce one to severe accidents.
