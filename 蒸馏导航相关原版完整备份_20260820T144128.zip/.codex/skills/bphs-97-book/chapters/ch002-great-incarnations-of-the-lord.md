# 第 2 章：Great Incarnations (Of The Lord)

- 来源：BPHS 97 章版
- 原始卡片：5 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P004_B002_01

- 身份：正文
- PDF 页：4
- 偈颂：1
- 标题路径：CHAPTER 2 Great Incarnations (Of The Lord)
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Great Incarnations (Of The Lord) · Sloka 1 [present] · PDF page 4

1.  Maitreya: "O Maharishi Parashar, are the incarnations
of Vishnu, viz. Shri Ram, Shri Krishn, etc., endowed with
Jivamsh?

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P004_B003_01

- 身份：正文
- PDF 页：4
- 偈颂：2
- 标题路径：CHAPTER 2 Great Incarnations (Of The Lord)
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Great Incarnations (Of The Lord) · Sloka 2 [present] · PDF page 4

2. Maharishi Parashar: "O Brahmin, the four incarnations,
viz. Ram, Krishn, Narasimh, and Varah are wholly with
Paramatmamsh. The other incarnations (than these, out of
the ten) have in them Jivamsh too.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P004_B004_01

- 身份：正文
- PDF 页：4
- 偈颂：3-4
- 标题路径：CHAPTER 2 Great Incarnations (Of The Lord)
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Great Incarnations (Of The Lord) · Sloka 3-4 [present] · PDF page 4

3-4. The Unborn lord has many incarnations. He has
incarnated as the 9 grahas (Nava Grahas) to bestow on the
living beings the results due to their Karmas. He is
Janardan. He assumed the auspicious form of grahas to
destroy the demons (evil forces) and sustain the divine
beings.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P004_B005_01

- 身份：正文
- PDF 页：4
- 偈颂：5-7
- 标题路径：CHAPTER 2 Great Incarnations (Of The Lord)
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Great Incarnations (Of The Lord) · Sloka 5-7 [present] · PDF page 4

5-7. From Surya the incarnation of Ram, from Chandr that of
Krishn, from Mangal that of Narasimh, from Buddh that of
Buddha, from Guru that of Vaman, from Shukr that of
Parashuram, from Shani that of Kurma (Tortoise), from Rahu
that of Varah (pig), and from Ketu that of Meen (Fish)
occurred. All other incarnations than these also are
through the grahas. The beings with more Paramatmamsh are
called divine beings.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P004_B006_01

- 身份：正文
- PDF 页：4
- 偈颂：8-13
- 标题路径：CHAPTER 2 Great Incarnations (Of The Lord)
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Great Incarnations (Of The Lord) · Sloka 8-13 [present] · PDF page 4

8-13. The beings with more Jivatmamsh are (mortal) beings.
The high degree of Paramatmamsh from the grahas, viz.
Surya, etc., did incarnate as Ram, Krishn, etc.. After
completing the mission, the Paramatmamshas (of the
respective) grahas again merge (in the  respective) grahas.
The Jivatma portions from the grahas take births as human
beings and live their lives  according to their Karmas and
again merge in the grahas. And at the time of Great
Destruction, the grahas as well merge in Lord Vishnu. One
who knows of all these, will become versed in the knowledge
of the past, present, and future. Without a knowledge of
Jyotish these cannot be known. Hence, everyone should have
a knowledge of Jyotish particularly the Brahmin. One who,
devoid of knowledge of Jyotish, blames this Vedic Science
will go to the hell called 'Raurava', and will be reborn
blind.
