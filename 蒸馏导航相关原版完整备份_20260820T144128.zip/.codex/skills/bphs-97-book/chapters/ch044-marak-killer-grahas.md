# 第 44 章：Marak (Killer) Grahas

- 来源：BPHS 97 章版
- 原始卡片：19 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P155_B002_01

- 身份：正文
- PDF 页：155
- 偈颂：1
- 标题路径：CHAPTER 44 Marak (Killer) Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Marak (Killer) Grahas · Sloka 1 [present] · PDF page 155

1. O Maharishi Parashar, you have mentioned a lot about
longevity. Be kind enough to throw light on Marakas or
killers.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P155_B003_01

- 身份：正文
- PDF 页：155
- 偈颂：2-5
- 标题路径：CHAPTER 44 Marak (Killer) Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Marak (Killer) Grahas · Sloka 2-5 [present] · PDF page 155

2-5. 0 Brahmin, Sahaj and Randhr Bhava are the two bhavas
of longevity. The bhavas related to death are the 12th from
each of these, i.e. Dhan and Yuvati Bhava are Marak
Bhavas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P155_B004_01

- 身份：正文
- PDF 页：155
- 偈颂：3
- 标题路径：CHAPTER 44 Marak (Killer) Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Marak (Killer) Grahas · Sloka 3 [present] · PDF page 155

3. Out of the two (i.e. Dhan and Yuvati Bhava), Dhan Bhava
is a powerful Marak Bhava (as against Yuvati Bhava). The
lords of Dhan and Yuvati Bhava, malefics in Dhan and Yuvati
Bhava, and malefics yuti with Dhan's lord and yuti with
Yuvati's lord, are all known as Marakas. The major and sub
periods of these grahas will bring death on the native
depending on whether he has a long life, medium life, or
short life person.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P155_B005_01

- 身份：正文
- PDF 页：155
- 偈颂：6-7
- 标题路径：CHAPTER 44 Marak (Killer) Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Marak (Killer) Grahas · Sloka 6-7 [present] · PDF page 155

6-7. The Dasha of a benefic grah related to Vyaya's lord
may also inflict death. End may descend on the native in
Randhr's lord's Dasha. The Dasha of a grah which is an
exclusive malefic (i.e. first-rate malefic) may also cause
death.
~7x*7rk~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P155_B006_01

- 身份：正文
- PDF 页：155
- 偈颂：9
- 标题路径：CHAPTER 44 Marak (Killer) Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Marak (Killer) Grahas · Sloka 9 [present] · PDF page 155

9. Should Shani be ill-disposed and be related to a Marak
grah, he will be the first to kill in preference to other
grahas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P155_B007_01

- 身份：正文
- PDF 页：155
- 偈颂：10-14
- 标题路径：CHAPTER 44 Marak (Killer) Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Marak (Killer) Grahas · Sloka 10-14 [present] · PDF page 155

10-14. 0 Brahmin, I tell you further about Marakas.
Narrated earlier are three kinds of life spans, viz. short,
medium, and long. Short life is before 32 years, later on
up to 64 it is medium life, and from 64 to 100 it is long
life. Beyond 100 the longevity is called supreme. O
excellent of the Brahmins, it is impossible to decide upon
longevity till the native is 20 years old. Till such year
the child should be protected by sacred recitations,
religious offerings (of ghee, etc., to consecrated fire as
prescribed in the Vedas, etc., and through medical
treatments, for premature death may descend on the child
due to sins of father and mother or of its own (in the
previous birth).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P156_B001_01

- 身份：正文
- PDF 页：156
- 偈颂：15-21
- 标题路径：CHAPTER 44 Marak (Killer) Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Marak (Killer) Grahas · Sloka 15-21 [present] · PDF page 156

15-21. I further mention about the Marak grahas. One born
with short life combinations may face death in the Dasha
denoted by Vipat star (the 3rd from the birth star); one of
medium life may die in the Dasha denoted by Pratyak star
(the 5th from the birth star). In the Dasha denoted by Vadh
star (the 7th from the birth star), one with long life may
obtain his end. The Dasha of the lord of the 22nd Dreshkan,
or the Dasha of the lord of the 23rd, or the Dasha of the
lord of the 3rd, or the Dasha of the lord of the 5th, or
the Dasha of the lord of the 7th asterisms may also cause
death. The lords of the 2nd and the 12th counted from Kark
may bring death, this is true when Chandr is a malefic;  if
he happens to be a benefic there will be (only) diseases
(but not death). Death may come to pass in the Dasha of
Ari's lord and in the sub periods of Ari's, Randhr's,
and/or Vyaya's lords. Should there be many Marakas (endowed
with the power of killing),and if these Marakas are strong,
there will be diseases, miseries, etc., in major and sub
periods. Thus, these are Marakas (as is mentioned above)
and are primarily related to bring death upon the native.
According to their dispositions there may be death or
difficulties.
~8I1+8I7+8I8+8I2+8I12+8I6+(8I7)k+(9I7)k~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P156_B001_02

- 身份：正文
- PDF 页：156
- 偈颂：15-21
- 标题路径：CHAPTER 44 Marak (Killer) Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Marak (Killer) Grahas · Sloka 15-21 [present] · PDF page 156

15-21. I further mention about the Marak grahas. One born
with short life combinations may face death in the Dasha
denoted by Vipat star (the 3rd from the birth star); one of
medium life may die in the Dasha denoted by Pratyak star
(the 5th from the birth star). In the Dasha denoted by Vadh
star (the 7th from the birth star), one with long life may
obtain his end. The Dasha of the lord of the 22nd Dreshkan,
or the Dasha of the lord of the 23rd, or the Dasha of the
lord of the 3rd, or the Dasha of the lord of the 5th, or
the Dasha of the lord of the 7th asterisms may also cause
death. The lords of the 2nd and the 12th counted from Kark
may bring death, this is true when Chandr is a malefic;  if
he happens to be a benefic there will be (only) diseases
(but not death). Death may come to pass in the Dasha of
Ari's lord and in the sub periods of Ari's, Randhr's,
and/or Vyaya's lords. Should there be many Marakas (endowed
with the power of killing),and if these Marakas are strong,
there will be diseases, miseries, etc., in major and sub
periods. Thus, these are Marakas (as is mentioned above)
and are primarily related to bring death upon the native.
According to their dispositions there may be death or
difficulties.
~8I1+8I7+8I8+8I2+8I12+8I6+(8I7)k+(9I7)k~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P156_B002_01

- 身份：正文
- PDF 页：156
- 偈颂：22-24
- 标题路径：CHAPTER 44 Marak (Killer) Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Marak (Killer) Grahas · Sloka 22-24 [present] · PDF page 156

22-24. Rahu and Ketu as Marakas: If Rahu or Ketu are placed
in Tanu, Yuvati, Randhr, or Vyaya Bhava, or happen to be in
the 7th from a Marak lord, or are placed with such a grah,
they acquire powers of killing in their major or sub
periods.
~Lni10+Lni8~n
For one born in Makar, or in Vrischik, Rahu will be a
Marak.
~-8RB**8I6+8I12+8I8~m
Should Rahu be in Ari, Randhr, or Vyaya Bhava, he will give
difficulties in his Dasha periods. He will not, however, do
so if Rahu receives a drishti from, or is yuti with a
benefic.
~1X*1I3~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P157_B001_01

- 身份：正文
- PDF 页：157
- 偈颂：25-31
- 标题路径：CHAPTER 44 Marak (Killer) Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Marak (Killer) Grahas · Sloka 25-31 [present] · PDF page 157

25-31. Sahaj Bhava and Death: O excellent of Brahmins, if
Surya, being with strength, is in Sahaj Bhava, one will
obtain his death due to a king (or legal punishments);
~2I3~n
Chandr in Sahaj Bhava will cause death due to
tuberculosis,
~3I3~n
while wounds, weapons, fire, and thirst will cause death
through Mangal in Sahaj Bhava.
~!3R8+!3R7~n
If Sahaj Bhava receives a drishti from, or is occupied by
Shani and Rahu, death will be through poison, water, or
fire, or fall from heights, or confinement.
~!3R.G*!3R2~n
Death will surely come to descend through insects or
leprosy if Chandr and Gulik occupy or give a drishti to
Sahaj Bhava.
~!3R4~n
Buddh giving a drishti to or occupying Sahaj Bhava will
bring death followed by fever.
~5I3+!3D5~n
Guru in Sahaj Bhava or giving a drishti to Sahaj Bhava will
cause death by swelling or tumours.
~6I3+!3D6~n
Urinary diseases will cause death if Shukr is in, or gives
a drishti to Sahaj Bhava.
~.^I3~n
Many grahas giving a drishti to
or occupying   Sahaj Bhava will bring death through many
diseases.
~BI3~n
32, If Sahaj Bhava is occupied by a benefic, death will be
in an auspicious place (like a shrine);
~mI3~n
and if Sahaj Bhava is occupied by a malefic death will be
in sinful places.
~BI3*mI3~m
Mixed occupation of Sahaj Bhava will yield mixed results
with regard to the place of death.
~5I3+6I3~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P157_B001_02

- 身份：正文
- PDF 页：157
- 偈颂：25-31
- 标题路径：CHAPTER 44 Marak (Killer) Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Marak (Killer) Grahas · Sloka 25-31 [present] · PDF page 157

25-31. Sahaj Bhava and Death: O excellent of Brahmins, if
Surya, being with strength, is in Sahaj Bhava, one will
obtain his death due to a king (or legal punishments);
~2I3~n
Chandr in Sahaj Bhava will cause death due to
tuberculosis,
~3I3~n
while wounds, weapons, fire, and thirst will cause death
through Mangal in Sahaj Bhava.
~!3R8+!3R7~n
If Sahaj Bhava receives a drishti from, or is occupied by
Shani and Rahu, death will be through poison, water, or
fire, or fall from heights, or confinement.
~!3R.G*!3R2~n
Death will surely come to descend through insects or
leprosy if Chandr and Gulik occupy or give a drishti to
Sahaj Bhava.
~!3R4~n
Buddh giving a drishti to or occupying Sahaj Bhava will
bring death followed by fever.
~5I3+!3D5~n
Guru in Sahaj Bhava or giving a drishti to Sahaj Bhava will
cause death by swelling or tumours.
~6I3+!3D6~n
Urinary diseases will cause death if Shukr is in, or gives
a drishti to Sahaj Bhava.
~.^I3~n
Many grahas giving a drishti to
or occupying   Sahaj Bhava will bring death through many
diseases.
~BI3~n
32, If Sahaj Bhava is occupied by a benefic, death will be
in an auspicious place (like a shrine);
~mI3~n
and if Sahaj Bhava is occupied by a malefic death will be
in sinful places.
~BI3*mI3~m
Mixed occupation of Sahaj Bhava will yield mixed results
with regard to the place of death.
~5I3+6I3~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P157_B002_01

- 身份：正文
- PDF 页：157
- 偈颂：33
- 标题路径：CHAPTER 44 Marak (Killer) Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Marak (Killer) Grahas · Sloka 33 [present] · PDF page 157

33. Consciousness will prevail at the time of death if Guru
or Shukr are placed in Sahaj Bhava.
~-5I3*-6I3*&I3~n
With other grahas in Sahaj Bhava, there will be
unconsciousness before death.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P158_B001_01

- 身份：正文
- PDF 页：158
- 偈颂：34
- 标题路径：CHAPTER 44 Marak (Killer) Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Marak (Killer) Grahas · Sloka 34 [present] · PDF page 158

34. According to Sahaj Bhava being a movable, a fixed, or a
dual rashi, death will be respectively in a foreign place
(other than native birth place), in one's own house, or on
the way.
~1I8~n
35-36: Occupants of Randhr Bhava: Note the occupant of
Randhr Bhava: If it is Surya, death will be through fire;
~2I8~n
if Chandr is in Randhr Bhava, death will be through water;
~3I8~n
if Mangal is in Randhr Bhava, death will be through
weapons;
~4I8~n
if Buddh is in Randhr Bhava, death will be through fever;
~5I8~n
if Guru is in Randhr Bhava, death will be through
diseases;
~6I8~n
if Shukr is in Randhr Bhava, death will be through hunger;
~7I8~n
and if Shani is in Randhr Bhava, death will be through
thirst.
~BI8*L9YB+!8DB*L9YB~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P158_B002_01

- 身份：正文
- PDF 页：158
- 偈颂：37
- 标题路径：CHAPTER 44 Marak (Killer) Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Marak (Killer) Grahas · Sloka 37 [present] · PDF page 158

37. If Randhr Bhava is occupied by or receives a drishti
from a benefic, while Dharm's lord is yuti with a benefic
the native will die in a shrine.
~mI8*L9Ym+!8Dm*L9Ym~n
If Randhr Bhava is occupied by or receives a drishti from a
malefic, while Dharm's lord is yuti with a malefic, death
will be in a place other than a shrine.
~? ~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P158_B003_01

- 身份：正文
- PDF 页：158
- 偈颂：38-39
- 标题路径：CHAPTER 44 Marak (Killer) Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Marak (Killer) Grahas · Sloka 38-39 [present] · PDF page 158

38-39. Fate of the Human Physical System: Should there be a
benefic's Dreshkan in Randhr Bhava (i.e. the 22nd
Dreshkan), the body will be burnt in fire (as prescribed in
Shastras);
if a malefic's Dreshkan happens to be in Randhr Bhava, the
body will be thrown away in water;
if the Dreshkan in Randhr Bhava is owned by a mixed grah
the dead body will only dry up;
if the Dreshkan in Randhr Bhava is a serpent Dreshkan, the
body will be eaten away by animals, crows, etc.;

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P158_B004_01

- 身份：正文
- PDF 页：158
- 偈颂：40
- 标题路径：CHAPTER 44 Marak (Killer) Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Marak (Killer) Grahas · Sloka 40 [present] · PDF page 158

40. Serpent Dreshkanas: The 2nd and 3rd Dreshkan in Kark,
the initial one in Vrischik, and the last one in Meen are
designated as serpent Dreshkanas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P158_B005_01

- 身份：正文
- PDF 页：158
- 偈颂：41-42
- 标题路径：CHAPTER 44 Marak (Killer) Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Marak (Killer) Grahas · Sloka 41-42 [present] · PDF page 158

41-42. Pre-natal Abode: O excellent of Brahmins, the
stronger of the two luminaries, Surya and Chandr, occupying
a Dreshkan of Guru denotes the descent from the world of
gods.
If the stronger of the luminaries, Surya and Chandr,
occupies the  Dreshkan of Shukr or Chandr, the descent is
from the world of the Manes;
if the stronger of the two luminaries, Surya and Chandr, is
in the Dreshkan of Surya or Mangal, the descent is from the
world of Yama (the world of the death);
and if the stronger of the two luminaries, Surya and
Chandr, is in Dreshkan of Buddh or Shani, the descent is
from the hell.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P159_B001_01

- 身份：正文
- PDF 页：159
- 偈颂：43-45
- 标题路径：CHAPTER 44 Marak (Killer) Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Marak (Killer) Grahas · Sloka 43-45 [present] · PDF page 159

43-45. Ascent after Death: According to the following
grahas in Vyaya, Yuvati, Ari, or Randhr Bhava, the native
will attain one of the different worlds after death:

Guru: heaven;
Chandr or Shukr: the world of Manes;
Mangal and/or Surya: earth (i.e. rebirth);
Buddh and/or Shani: hell.
In case the said bhavas are not occupied, the native will
go to the world indicated by the stronger of the Dreshkan
lords related to Ari and Randhr Bhava. The relative grah's
exaltation, etc., will denote the high, medium, and low
status the native will obtain in the said world.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P159_B002_01

- 身份：正文
- PDF 页：159
- 偈颂：46
- 标题路径：CHAPTER 44 Marak (Killer) Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Marak (Killer) Grahas · Sloka 46 [present] · PDF page 159

46. Other grahas and rashis becoming Marakas are being
discussed in the chapter related to Dashas.
