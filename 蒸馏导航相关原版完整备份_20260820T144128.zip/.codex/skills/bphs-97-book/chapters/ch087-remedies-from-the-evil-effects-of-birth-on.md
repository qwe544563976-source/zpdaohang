# 第 87 章：Remedies from the evil effects of birth on

- 来源：BPHS 97 章版
- 原始卡片：4 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P361_B002_01

- 身份：正文
- PDF 页：361
- 偈颂：—
- 标题路径：CHAPTER 87 Remedies from the evil effects of birth on › Krishna Chaturdashi
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from the evil effects of birth on · Sloka unknown [unknown] · PDF page 361 · page_block BPHS_PL9_CHAP_97_P361_B002

Krishna Chaturdashi

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P361_B003_01

- 身份：正文
- PDF 页：361
- 偈颂：1-3
- 标题路径：CHAPTER 87 Remedies from the evil effects of birth on › Krishna Chaturdashi
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from the evil effects of birth on · Sloka 1-3 [present] · PDF page 361

1-3. The Sage said: Divide the span of Chaturdashi in 6
parts. The birth in the first part is auspicious. The birth
in the second part causes destruction or death of father. The
birth in the third part causes death of the mother. The birth
in the fourth part takes away the maternal uncle. The birth
in the fifth part destroys the entire family
(Khula-generation). The birth in the sixth part causes loss
of wealth or destruction (death) of the native.
Therefore, it is essential to take immediate remedial
measures to escape these evil effects.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P361_B004_01

- 身份：正文
- PDF 页：361
- 偈颂：4-5
- 标题路径：CHAPTER 87 Remedies from the evil effects of birth on › Krishna Chaturdashi
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from the evil effects of birth on · Sloka 4-5 [present] · PDF page 361

4-5. Have an idol of Lord Shiva made of one karsha (equal in
weight to the former silver rupee) of gold or of weight one
can afford. The idol should:
(I) have a New Moon on the forehead;
(2) have a white garland round the neck;
(3) have three eyes (one being on the forehead);
(4) be dressed in white robes;
(5) be seated on a bull;
(6) be two armed, and
(7) carry Vara and Abhaya.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P361_B005_01

- 身份：正文
- PDF 页：361
- 偈颂：6-13
- 标题路径：CHAPTER 87 Remedies from the evil effects of birth on › Krishna Chaturdashi
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from the evil effects of birth on · Sloka 6-13 [present] · PDF page 361

6-13. Then after invocation with Varun mantra, worship should
be performed by chanting (.....) etc., mantras. Thereafter, a
kalash should be placed in the North East direction with
chanting of ('Imah mai Varun', 'Tan tva Yami', Tvan nai
Agni') mantras followed by Japa of (.....) etc., and 'Bhadra
Agni ....' suktas and the chanting of (......) mantra. Then,
after sprinkling water over the idol of Lord Shiva
(Abhisheka), the nine grahas should be worshipped. This
should be followed by havan by using ghee, powder of sesame
seeds, urda, sarson, and wood pieces of Pipal, Pakar, Palas
and Khadir trees. 108 or 28 oblations should be made
separately for the nine grahas. Thereafter, along with
chanting of (.....) etc. mantras, havan should be performed
with sesame seeds for the nine grahas. Lastly, the water of
the Kalash should be sprinkled on the native and his parents,
and the Brahmins should be fed according to means.
