# 第 20 章：Effects Of Dharm Bhava

- 来源：BPHS 97 章版
- 原始卡片：18 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P053_B002_01

- 身份：正文
- PDF 页：53
- 偈颂：—
- 标题路径：CHAPTER 20 Effects Of Dharm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Dharm Bhava · Sloka unknown [unknown] · PDF page 53 · page_block BPHS_PL9_CHAP_97_P053_B002

~L9I9*L9X~
Combinations for Fortunes: O Brahmin, now listen to the
effects of Dharm Bhava. One will be fortunate (or affluent)
if Dharm's lord is in Dharm Bhava with strength.
~5I9*L9K*L1X~
Should Guru be in Dharm Bhava while Dharm's lord is in an
angle and Lagn's lord is endowed with strength, one will be
extremely fortunate.
~L9X*6I9*5K~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P053_B003_01

- 身份：正文
- PDF 页：53
- 偈颂：3
- 标题路径：CHAPTER 20 Effects Of Dharm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Dharm Bhava · Sloka 3 [present] · PDF page 53

3. Fortunate (Affluent) Father: If Dharm's lord is with
strength as Shukr is in Dharm, while Guru is in an angle
from Tanu Bhava, the native's father is fortunate.
~L9d*3I10+L9d*3I12~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P053_B004_01

- 身份：正文
- PDF 页：53
- 偈颂：4
- 标题路径：CHAPTER 20 Effects Of Dharm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Dharm Bhava · Sloka 4 [present] · PDF page 53

4. Indigent Father: If Dharm's lord is debilitated while
the 2nd and/or the 4th from Dharm Bhava is occupied by
Mangal, the native's father is poor.
~L9E*6K*N5I9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P053_B005_01

- 身份：正文
- PDF 页：53
- 偈颂：5
- 标题路径：CHAPTER 20 Effects Of Dharm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Dharm Bhava · Sloka 5 [present] · PDF page 53

5. Long-living Father: Should Dharm's lord be in deep
exaltation while Shukr is in an angle from Tanu Bhava and
Guru is in the 9th from Navamsh Lagn, the father of the
native will enjoy a long span of life.
~L9K*L9D5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P053_B006_01

- 身份：正文
- PDF 页：53
- 偈颂：6
- 标题路径：CHAPTER 20 Effects Of Dharm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Dharm Bhava · Sloka 6 [present] · PDF page 53

6. Royal Status for Father: If Dharm's lord is an angle and
receives a drishti from Guru, the native's father will be a
king endowed with conveyances or be equal to a king.
~L9I10*L10DB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P053_B007_01

- 身份：正文
- PDF 页：53
- 偈颂：7
- 标题路径：CHAPTER 20 Effects Of Dharm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Dharm Bhava · Sloka 7 [present] · PDF page 53

7. Wealthy and Famous Father: Should Dharm's lord be in
Karm Bhava, while Karm's lord receives a drishti from a
benefic the native's father will be very rich and famous.
~1E*L9I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P053_B008_01

- 身份：正文
- PDF 页：53
- 偈颂：8-9
- 标题路径：CHAPTER 20 Effects Of Dharm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Dharm Bhava · Sloka 8-9 [present] · PDF page 53

8-9. Virtuous and Devoted to Father: Should Surya be in
deep exaltation as Dharm's lord is in Labh Bhava, the
native will be virtuous, dear to the king, and devoted to
father.
~1T*L9I7*L9Y5+1T*L9I7*L9D5~
If Surya is in a trine from Lagna, while Dharm's lord is in
Yuvati in yuti with or receiving a drishti from Guru, the
native will be devoted to his father.
~L9I2*L2I9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P053_B009_01

- 身份：正文
- PDF 页：53
- 偈颂：10
- 标题路径：CHAPTER 20 Effects Of Dharm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Dharm Bhava · Sloka 10 [present] · PDF page 53

10. Fortunes, etc.: Acquisition of fortunes, conveyances,
and fame will follow the 32nd year of age if Dharm's lord
is in Dhan, while Dhan's lord is in Dharm.
~L1I9*L6I9~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P053_B010_01

- 身份：正文
- PDF 页：53
- 偈颂：11
- 标题路径：CHAPTER 20 Effects Of Dharm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Dharm Bhava · Sloka 11 [present] · PDF page 53

11. Inimical to Father: There will be mutual enmity between
the father and the native if Lagn's lord is in Dharm Bhava,
but with the lord of Ari. Further, the native's father will
be of contemptible disposition.
~L10x*L3x*L9d+L10x*L3x*L9c~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P054_B001_01

- 身份：正文
- PDF 页：54
- 偈颂：12
- 标题路径：CHAPTER 20 Effects Of Dharm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Dharm Bhava · Sloka 12 [present] · PDF page 54

12. Begged Food: If Karm's lord and Sahaj's lord are bereft
of strength, while Dharm's lord is in fall or combust the
native will go begging for his food.
~1Ia*L8I9*L12I1*L6I5~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P054_B002_01

- 身份：正文
- PDF 页：54
- 偈颂：13-25
- 标题路径：CHAPTER 20 Effects Of Dharm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Dharm Bhava · Sloka 13-25 [present] · PDF page 54

13-25. Combinations for Father's Death: The father of the
native would have passed away prior to the native's birth
if Surya is in Ari, Randhr, or Vyaya Bhava as Randhr's lord
is in Dharm Bhava, Vyaya's lord is in Tanu Bhava, and Ari's
lord is in Putr Bhava.
~1I8*L8I9~n
Should Surya be in Randhr Bhava, while Randhr's lord is in
Dharm, the native's father will pass away within a year of
his birth.
~L12I9*NL9d~n
If the lord of Vyaya Bhava is in Dharm Bhava, while Dharm's
lord is in its debilitation Navamsh, the native's father
will face his end during the 3rd or the 16th year of the
native.
~L1I8*L8Y1~n
Death of father will occur in the 2nd or the 12th year, if
Lagn's lord is in Randhr Bhava, as Randhr's lord is with
Surya.
~8I4*1I5~n
Should Rahu be in the 8th from Dharm (i.e. Bandhu Bhava),
as Surya is in the 9th from Dharm (i.e. Putr Bhava), death
of father will take place in the 16th or the 18th year of
the native.
~(7I9)2*1Y8~n
If Shani is in the 9th from Chandr, as Surya is with Rahu,
the native's father will die in the 7th or the 19th year of
the native.
~L9I12*L12I9~n
The native in his 44th year will lose his father if Dharm's
lord is in Vyaya, as Vyaya's lord is in Dharm.
~L1I8*N2IR5~n
If Lagn's lord is in Randhr Bhava as Chandr is in Surya's
Navamsh, the native in his 35th or 41st year will lose his
father.
~R5I9*1Y3*1Y7~n
One will lose his father in the 50th year if Surya, being
the lord of Dharm, is conjunct Mangal and Shani.
~1I3*8I9~n
If Surya is in the 7th from Dharm Bhava (i.e. Sahaj Bhava),
as Rahu is in the 7th from Sahaj Bhava (i.e. Dharm Bhava),
the 6th or 25th year of the native will be fatal for
father.
~7I2*1I8~n
If Shani is in the 7th from Randhr Bhava (i.e. Dhan Bhava),
as Surya is in the 7th from Shani (i.e. Randhr Bhava), the
ages of 21, 26, or 30 will be fatal for the father.
~L9d*ãL9I9~n
If Dharm's lord is in its debilitation rashi, while his
dispositor is in Dharm Bhava, the native will lose his
father at the age of 26 or 30. Thus, the Jyotishis may know
the effects (of Dharm Bhava).
~6E*6YL9*7I3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P054_B002_02

- 身份：正文
- PDF 页：54
- 偈颂：13-25
- 标题路径：CHAPTER 20 Effects Of Dharm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Dharm Bhava · Sloka 13-25 [present] · PDF page 54

13-25. Combinations for Father's Death: The father of the
native would have passed away prior to the native's birth
if Surya is in Ari, Randhr, or Vyaya Bhava as Randhr's lord
is in Dharm Bhava, Vyaya's lord is in Tanu Bhava, and Ari's
lord is in Putr Bhava.
~1I8*L8I9~n
Should Surya be in Randhr Bhava, while Randhr's lord is in
Dharm, the native's father will pass away within a year of
his birth.
~L12I9*NL9d~n
If the lord of Vyaya Bhava is in Dharm Bhava, while Dharm's
lord is in its debilitation Navamsh, the native's father
will face his end during the 3rd or the 16th year of the
native.
~L1I8*L8Y1~n
Death of father will occur in the 2nd or the 12th year, if
Lagn's lord is in Randhr Bhava, as Randhr's lord is with
Surya.
~8I4*1I5~n
Should Rahu be in the 8th from Dharm (i.e. Bandhu Bhava),
as Surya is in the 9th from Dharm (i.e. Putr Bhava), death
of father will take place in the 16th or the 18th year of
the native.
~(7I9)2*1Y8~n
If Shani is in the 9th from Chandr, as Surya is with Rahu,
the native's father will die in the 7th or the 19th year of
the native.
~L9I12*L12I9~n
The native in his 44th year will lose his father if Dharm's
lord is in Vyaya, as Vyaya's lord is in Dharm.
~L1I8*N2IR5~n
If Lagn's lord is in Randhr Bhava as Chandr is in Surya's
Navamsh, the native in his 35th or 41st year will lose his
father.
~R5I9*1Y3*1Y7~n
One will lose his father in the 50th year if Surya, being
the lord of Dharm, is conjunct Mangal and Shani.
~1I3*8I9~n
If Surya is in the 7th from Dharm Bhava (i.e. Sahaj Bhava),
as Rahu is in the 7th from Sahaj Bhava (i.e. Dharm Bhava),
the 6th or 25th year of the native will be fatal for
father.
~7I2*1I8~n
If Shani is in the 7th from Randhr Bhava (i.e. Dhan Bhava),
as Surya is in the 7th from Shani (i.e. Randhr Bhava), the
ages of 21, 26, or 30 will be fatal for the father.
~L9d*ãL9I9~n
If Dharm's lord is in its debilitation rashi, while his
dispositor is in Dharm Bhava, the native will lose his
father at the age of 26 or 30. Thus, the Jyotishis may know
the effects (of Dharm Bhava).
~6E*6YL9*7I3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P055_B001_01

- 身份：正文
- PDF 页：55
- 偈颂：26
- 标题路径：CHAPTER 20 Effects Of Dharm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Dharm Bhava · Sloka 26 [present] · PDF page 55

26. Fortunes: One will enjoy abundant fortunes if Shukr is
in deep exaltation and be in the company of Dharm's lord,
as Shani is in Sahaj.
~5I9*L9K~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P055_B002_01

- 身份：正文
- PDF 页：55
- 偈颂：27-28
- 标题路径：CHAPTER 20 Effects Of Dharm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Dharm Bhava · Sloka 27-28 [present] · PDF page 55

27-28. Fortunate Periods: Abundant fortunes be acquired
after the 20th year if Dharm has Guru in it, as its lord is
in an angle from Lagn.
~4E*L9I9~
Should Buddh be in his deep exaltation as Dharm's lord is
in Dharm itself, abundant fortunes will be earned after the
36th year.
~L1I9*L9I1*5I7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P055_B003_01

- 身份：正文
- PDF 页：55
- 偈颂：29
- 标题路径：CHAPTER 20 Effects Of Dharm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Dharm Bhava · Sloka 29 [present] · PDF page 55

29. Should Lagn's lord be in Dharm as Dharm's lord is in
Lagn, and Guru is in Yuvati, there will be gains of wealth
and conveyances.
~8I5*ã8I8*L9d~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P055_B004_01

- 身份：正文
- PDF 页：55
- 偈颂：30
- 标题路径：CHAPTER 20 Effects Of Dharm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Dharm Bhava · Sloka 30 [present] · PDF page 55

30. Lack of Fortunes: If Rahu is in the 9th from Dharm
Bhava (i.e. Putr Bhava), as his dispositor is in Randhr
Bhava, and Dharm's lord is in fall, the native be devoid of
fortunes.
~7I9*7Y2*L1d~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P055_B005_01

- 身份：正文
- PDF 页：55
- 偈颂：31
- 标题路径：CHAPTER 20 Effects Of Dharm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Dharm Bhava · Sloka 31 [present] · PDF page 55

31. Food by Begging: Should Shani be in Dharm Bhava along
with Chandr, as Lagn's lord is in fall, the native will
acquire food by begging.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P055_B006_01

- 身份：正文
- PDF 页：55
- 偈颂：32
- 标题路径：CHAPTER 20 Effects Of Dharm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Dharm Bhava · Sloka 32 [present] · PDF page 55

32. 0 Brahmin, these are the effects related to Dharm
Bhava. I have explained (these) briefly. These may be
(further, estimated with the help of the state of the lords
of Lagn and Dharm Bhava and in other manners as well.
