# 第 41 章：Combinations For Wealth

- 来源：BPHS 97 章版
- 原始卡片：23 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P142_B002_01

- 身份：正文
- PDF 页：142
- 偈颂：1
- 标题路径：CHAPTER 41 Combinations For Wealth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations For Wealth · Sloka 1 [present] · PDF page 142

1. I now tell you of special combinations giving wealth.
One born to these Yogas will surely become wealthy.
~6O*6I5*3I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P142_B003_01

- 身份：正文
- PDF 页：142
- 偈颂：2
- 标题路径：CHAPTER 41 Combinations For Wealth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations For Wealth · Sloka 2 [present] · PDF page 142

2. Yogas for Great Affluence (up to sloka 8): Should a
rashi of Shukr be Putr Bhava and be occupied by Shukr
himself, while Mangal is in Labh Bhava, the native will
obtain great riches.
~4O+4E**4I5*2I11*2Y3*2Y5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P142_B004_01

- 身份：正文
- PDF 页：142
- 偈颂：3
- 标题路径：CHAPTER 41 Combinations For Wealth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations For Wealth · Sloka 3 [present] · PDF page 142

3. Should a rashi of Buddh be Putr Bhava and be occupied by
Buddh himself as Labh Bhava is occupied by Chandr, Mangal,
and Guru, the native will be very affluent.
~R5I5*1I5*7I11*7Y2*7Y5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P142_B005_01

- 身份：正文
- PDF 页：142
- 偈颂：4
- 标题路径：CHAPTER 41 Combinations For Wealth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations For Wealth · Sloka 4 [present] · PDF page 142

4. Should Simh be Putr Bhava and be occupied by Surya
himself as Shani, Chandr, and Guru are in Labh Bhava, the
native will be very affluent.
~1I11*1Y2*7I5*7O~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P142_B006_01

- 身份：正文
- PDF 页：142
- 偈颂：5
- 标题路径：CHAPTER 41 Combinations For Wealth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations For Wealth · Sloka 5 [present] · PDF page 142

5. Should Surya and Chandr be in Labh Bhava as Shani is in
Putr Bhava identical with his own bhava, the native will be
very affluent.
~5I5*5O*4I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P142_B007_01

- 身份：正文
- PDF 页：142
- 偈颂：6
- 标题路径：CHAPTER 41 Combinations For Wealth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations For Wealth · Sloka 6 [present] · PDF page 142

6. Should Guru be in Putr Bhava identical with his own
rashi as Buddh is in Labh Bhava, the native will be very
affluent.
~3O*3I5*6I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P142_B008_01

- 身份：正文
- PDF 页：142
- 偈颂：7
- 标题路径：CHAPTER 41 Combinations For Wealth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations For Wealth · Sloka 7 [present] · PDF page 142

7. If a rashi of Mangal happens to be Putr Bhava with
Mangal there in while Shukr is in Labh Bhava, the native
will become very affluent.
~2I5*2O*7I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P142_B009_01

- 身份：正文
- PDF 页：142
- 偈颂：8
- 标题路径：CHAPTER 41 Combinations For Wealth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations For Wealth · Sloka 8 [present] · PDF page 142

8. If Kark happens to be Putr Bhava containing Chandr there
in, while  Shani is in Labh Bhava, the native will become
very affluent.
~1O*1I1**1Y3*1Y5+1Y3*1D5+1Y5*1D3+1D3*1D5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P142_B010_01

- 身份：正文
- PDF 页：142
- 偈颂：9
- 标题路径：CHAPTER 41 Combinations For Wealth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations For Wealth · Sloka 9 [present] · PDF page 142

9. Yogas for Wealth (up to sloka 15): Should Surya be in
Simh identical with Lagn, and be yuti with or receiving a
drishti from Mangal and Guru, one will be wealthy.
~2O*2I1**2Y4*2Y5+2Y4*2D5+2D4*2Y5+2D4*2D5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P142_B011_01

- 身份：正文
- PDF 页：142
- 偈颂：10
- 标题路径：CHAPTER 41 Combinations For Wealth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations For Wealth · Sloka 10 [present] · PDF page 142

10. Should Chandr be in Kark identical with Lagn, and be
yuti with or receiving a drishti from Buddh and Guru one
will be wealthy.
~3I1*3O*3D7+3I1*3O*3I1**4K*6K*-4I4*-4I10*-6I4*-6I10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P142_B012_01

- 身份：正文
- PDF 页：142
- 偈颂：11
- 标题路径：CHAPTER 41 Combinations For Wealth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations For Wealth · Sloka 11 [present] · PDF page 142

11. Should Mangal be in Lagn identical with his own rashi
and be yuti with or receiving a drishti from Buddh, Shukr,
and Shani, the native will be rich.
~4I1*L1i4**4D7*4D5+4Y7*4D5+4D7*4Y5+4Y7*4Y5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P142_B013_01

- 身份：正文
- PDF 页：142
- 偈颂：12
- 标题路径：CHAPTER 41 Combinations For Wealth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations For Wealth · Sloka 12 [present] · PDF page 142

12. Should Buddh's rashi be Lagn with Buddh there in and
should Buddh be yuti with or receiving a drishti from Shani
and Guru the native will be rich.
~5I1*L1i5**5D4*5D3+5Y4*5D3+5D4*5Y3+5Y4*5Y3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P143_B001_01

- 身份：正文
- PDF 页：143
- 偈颂：13
- 标题路径：CHAPTER 41 Combinations For Wealth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations For Wealth · Sloka 13 [present] · PDF page 143

13. Should Guru be in Lagn identical with as own rashi and
be yuti with or receiving a drishti from Buddh and Mangal,
the native will be rich.
~6I1*L1i6**6D4*6D7+6Y4*6D7+6D4*6Y7+6Y4*6Y7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P143_B002_01

- 身份：正文
- PDF 页：143
- 偈颂：14
- 标题路径：CHAPTER 41 Combinations For Wealth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations For Wealth · Sloka 14 [present] · PDF page 143

14. If Shukr happens to be in Lagn identical with his own
rashi and be yuti with or receiving a drishti from Shani
and Buddh, one will be wealthy.
~7I1*L1i7**7D3*7D5+7Y3*7D5+7D3*7Y5+7Y3*7Y5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P143_B003_01

- 身份：正文
- PDF 页：143
- 偈颂：15
- 标题路径：CHAPTER 41 Combinations For Wealth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations For Wealth · Sloka 15 [present] · PDF page 143

15. If Shani is in his own rashi identical with Lagn and
receiving a drishti from or being yuti with Mangal and
Guru, the native will be wealthy.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P143_B004_01

- 身份：正文
- PDF 页：143
- 偈颂：16
- 标题路径：CHAPTER 41 Combinations For Wealth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations For Wealth · Sloka 16 [present] · PDF page 143

16. Other Qualified Grahas: Dharm's lord and Putr's lord
are capable of bestowing wealth. Similarly, grahas yuti
with Dharm's lord and/or Putr's lord are capable of
bestowing wealth. There is no doubt that these grahas will
give wealth during their Dasha periods.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P143_B005_01

- 身份：正文
- PDF 页：143
- 偈颂：17
- 标题路径：CHAPTER 41 Combinations For Wealth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations For Wealth · Sloka 17 [present] · PDF page 143

17. The Yogas mentioned above (up to sloka 16) should be
delineated after knowing favourable or unfavourable
dispositions of the participant grahas and their strength
and weakness.
~LKIç~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P143_B006_01

- 身份：正文
- PDF 页：143
- 偈颂：18-19
- 标题路径：CHAPTER 41 Combinations For Wealth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations For Wealth · Sloka 18-19 [present] · PDF page 143

18-19. Effects of the  Divisional Dignities of the Lords of
Kendras: If the lord of a Kendr is in Parijatamsh, the
native will be liberal,
~LKIÄ~
if the lord of a Kendr is in Uttamamsh the native will be
highly liberal,
~LKIé~
if the lord of a Kendr is in Gopuramsh the native will be
endowed with prowess,
~LKIê~
if the lord of a Kendr is in Simhasanamsh the native will
be  honourable, (prominent, etc.),
~LKIë~
if the lord of a Kendr is in Paravatamsh the native will be
valorous,
~LKIì~
if the lord of a Kendr is in Devalokamsh the native will be
head of an assembly,
~LKIÄ~
if the lord of a Kendr is in Brahmalokamsh the native will
be a sage,
~LKIí~
and if the lord of Kendr is in Iravatamsh the native will
be delighted and be celebrated in all quarters.
~L5Iç~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P144_B001_01

- 身份：正文
- PDF 页：144
- 偈颂：20-22
- 标题路径：CHAPTER 41 Combinations For Wealth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations For Wealth · Sloka 20-22 [present] · PDF page 144

20-22. Effects of the Divisional Dignities of Putr's Lord:
If Putr's lord is in Parijatamsh, the native will take to
the branch of learning befitting his race;
~L5IÅ~
if Putr's lord is in Uttamamsh the native will have
excellent learning;
~L5Ié~
if Putr's lord is in Gopuramsh the native will receive
world-wide honours;
~L5Iê~
if Putr's lord is in Simhasanamsh the native will become a
minister;
~L5Ië~
if Putr's lord is in also Paravatamsh the native will be
endowed with Vedic Knowledge;
~L5Iì~
if Putr's lord is in Devalokamsh the native will be a Karm
Yogi (i.e. a performer of actions, worldly and religious
rites);
~L5IÄ~
if Putr's lord is in Brahmalokamsh the native will be
devoted to the Lord;
~L5Ií~
and if Putr's lord is in Iravatamsh the native will be
pious.
Notes: While the lords of the four Kendras are treated in
one and the same breath, Maharishi Parashar gives special
importance to Putr's and Dharm's lords individually. The
effects may suitably be understood based on the
explanations given above for the lords of Kendras.
~L9Iç~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P145_B001_01

- 身份：正文
- PDF 页：145
- 偈颂：23-27
- 标题路径：CHAPTER 41 Combinations For Wealth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations For Wealth · Sloka 23-27 [present] · PDF page 145

23-27. Effects of the Divisional Dignities of Dharm's Lord:
If Dharm's lord is in Parijatamsh, the native will visit
holy places;
~L9IÄ~
if Dharm's lord is in Uttamamsh, the native has been
visiting holy places in the past births and he will do the
same within this life-time;
~L9Ié~
if Dharm's lord is in Gopuramsh the native will perform
sacrificial rites;
~L9Iê~
if Dharm's lord is in Simhasanamsh the native will be
mighty and truthful; he will be a conquerer of his senses
and will concentrate only on the Brahman, giving up all
religions;
~L9Ië~
if Dharm's lord is in Paravatamsh the native will be the
greatest of ascetics;
~L9Iì~
if Dharm's lord is in Devalokamsh the native will be an
ascetic holding a cudgel ('lagudi'), or he will be a
religious mendicant that has renounced all mundane
attachments and carrying three long staves tied together in
his right hand ('Tridandin');
~L9I¿~
and if Dharm's lord is in Brahmalokamsh the native will
perform Aswamedh Yagya (Horse Sacrifice) and will attain
the state of Lord Indra.
~L9Ií~
If Dharm's lord is in Iravatamsh the native will be a
synonym of Dharma or virtues just as Lord Ram and
Yudhishtira (the eldest of Pandavas).
~LKlLT+(LKI7)LT+LKYLT~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P146_B001_01

- 身份：正文
- PDF 页：146
- 偈颂：28
- 标题路径：CHAPTER 41 Combinations For Wealth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations For Wealth · Sloka 28 [present] · PDF page 146

28. Lords of Kendras and Konas Related: The Kendras are
known as Vishnu Sthanas (i.e. Bhavas of Lord Vishnu), while
the Konas are called Lakshmi Sthanas (i.e. Bhavas of
Lakshmi). If the lord of a Kendr establishes a relationship
with the lord of a Kon, a Raj Yog is obtained.
(A sixth kind of relationship can also be extended in this
context to Navamsh positions though there is no specific
classic sanction for this. For example in the case of a
Makar native, Mangal in the Navamsh of Shukr, and Shukr in
the Navamsh of Mangal will confer a superior Raj Yog. This
form of relationship will be equally superior like the
first 3 relationships mentioned  in the earlier paragraph).
~?~
29-34 Effects of the Divisional Dignities of Related Lords
of Kendras and Lords of Konas (as indicated in sloka 28):
If the lord of a Kendr and the lord of a Kon, having a
relationship as indicated in sloka 28, happen to be in
Parijatamsh, the native will be king and will protect men;

~?~
if the lord of a Kendr and the lord of a Kon, having a
relationship as indicated in sloka 28, happen to be in
Uttamamsh, the native will be an excellent king endowed
with elephants, horses, chariots, etc.;

~?~
if the lord of a Kendr and the lord of a Kon, having a
relationship as indicated in sloka 28, happen to be in
Gopuramsh, the native will be a tiger of kings honoured by
other kings;
~?~
and if the lord of a Kendr and the lord of a Kon, having a
relationship as indicated in slokas 28, happen to be in
Simhasanamsh the native will be an emperor ruling over the
entire earth; with the said Raj Yog relationship of the
said grahas in Simhasanamsh were born Harish Chandr, Manu,
Bali, the Fire god (Agni Deva) and many  emperors.
In the present Yuga so born is Yudhishtira (or Dharm Raj of
Mahabharat). Salivahana's birth and that of others will
also come with this Yog.
With the lord of a Kendr and the lord of a Kon, having a
relationship as indicated in sloka 28, placed in
Paravatamsh, Manu, etc., were born.
The Incarnations of Lord Vishnu took place when the lord of
a Kendr and the lord of a Kon, having a relationship as
indicated in sloka 28, were placed in Devalokamsh;
with the lord of a Kendr and the lord of a Kon, having a
relationship as indicated in sloka 28, placed in
Brahmalokamsh Lord Brahma was born;
and with the lord of a Kendr and the lord of a Kon, having
a relationship as indicated in sloka 28, placed in
Iravatamsh the Swayambhu Manu was born. (Manu is the first
of the 14 Manus, identified as the second creator who
produced the Prajapatis. To Manu, the code of laws, viz.
Manu Smriti is ascribed) .

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P146_B001_02

- 身份：正文
- PDF 页：146
- 偈颂：28
- 标题路径：CHAPTER 41 Combinations For Wealth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations For Wealth · Sloka 28 [present] · PDF page 146

28. Lords of Kendras and Konas Related: The Kendras are
known as Vishnu Sthanas (i.e. Bhavas of Lord Vishnu), while
the Konas are called Lakshmi Sthanas (i.e. Bhavas of
Lakshmi). If the lord of a Kendr establishes a relationship
with the lord of a Kon, a Raj Yog is obtained.
(A sixth kind of relationship can also be extended in this
context to Navamsh positions though there is no specific
classic sanction for this. For example in the case of a
Makar native, Mangal in the Navamsh of Shukr, and Shukr in
the Navamsh of Mangal will confer a superior Raj Yog. This
form of relationship will be equally superior like the
first 3 relationships mentioned  in the earlier paragraph).
~?~
29-34 Effects of the Divisional Dignities of Related Lords
of Kendras and Lords of Konas (as indicated in sloka 28):
If the lord of a Kendr and the lord of a Kon, having a
relationship as indicated in sloka 28, happen to be in
Parijatamsh, the native will be king and will protect men;

~?~
if the lord of a Kendr and the lord of a Kon, having a
relationship as indicated in sloka 28, happen to be in
Uttamamsh, the native will be an excellent king endowed
with elephants, horses, chariots, etc.;

~?~
if the lord of a Kendr and the lord of a Kon, having a
relationship as indicated in sloka 28, happen to be in
Gopuramsh, the native will be a tiger of kings honoured by
other kings;
~?~
and if the lord of a Kendr and the lord of a Kon, having a
relationship as indicated in slokas 28, happen to be in
Simhasanamsh the native will be an emperor ruling over the
entire earth; with the said Raj Yog relationship of the
said grahas in Simhasanamsh were born Harish Chandr, Manu,
Bali, the Fire god (Agni Deva) and many  emperors.
In the present Yuga so born is Yudhishtira (or Dharm Raj of
Mahabharat). Salivahana's birth and that of others will
also come with this Yog.
With the lord of a Kendr and the lord of a Kon, having a
relationship as indicated in sloka 28, placed in
Paravatamsh, Manu, etc., were born.
The Incarnations of Lord Vishnu took place when the lord of
a Kendr and the lord of a Kon, having a relationship as
indicated in sloka 28, were placed in Devalokamsh;
with the lord of a Kendr and the lord of a Kon, having a
relationship as indicated in sloka 28, placed in
Brahmalokamsh Lord Brahma was born;
and with the lord of a Kendr and the lord of a Kon, having
a relationship as indicated in sloka 28, placed in
Iravatamsh the Swayambhu Manu was born. (Manu is the first
of the 14 Manus, identified as the second creator who
produced the Prajapatis. To Manu, the code of laws, viz.
Manu Smriti is ascribed) .

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P146_B001_03

- 身份：正文
- PDF 页：146
- 偈颂：28
- 标题路径：CHAPTER 41 Combinations For Wealth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Combinations For Wealth · Sloka 28 [present] · PDF page 146

28. Lords of Kendras and Konas Related: The Kendras are
known as Vishnu Sthanas (i.e. Bhavas of Lord Vishnu), while
the Konas are called Lakshmi Sthanas (i.e. Bhavas of
Lakshmi). If the lord of a Kendr establishes a relationship
with the lord of a Kon, a Raj Yog is obtained.
(A sixth kind of relationship can also be extended in this
context to Navamsh positions though there is no specific
classic sanction for this. For example in the case of a
Makar native, Mangal in the Navamsh of Shukr, and Shukr in
the Navamsh of Mangal will confer a superior Raj Yog. This
form of relationship will be equally superior like the
first 3 relationships mentioned  in the earlier paragraph).
~?~
29-34 Effects of the Divisional Dignities of Related Lords
of Kendras and Lords of Konas (as indicated in sloka 28):
If the lord of a Kendr and the lord of a Kon, having a
relationship as indicated in sloka 28, happen to be in
Parijatamsh, the native will be king and will protect men;

~?~
if the lord of a Kendr and the lord of a Kon, having a
relationship as indicated in sloka 28, happen to be in
Uttamamsh, the native will be an excellent king endowed
with elephants, horses, chariots, etc.;

~?~
if the lord of a Kendr and the lord of a Kon, having a
relationship as indicated in sloka 28, happen to be in
Gopuramsh, the native will be a tiger of kings honoured by
other kings;
~?~
and if the lord of a Kendr and the lord of a Kon, having a
relationship as indicated in slokas 28, happen to be in
Simhasanamsh the native will be an emperor ruling over the
entire earth; with the said Raj Yog relationship of the
said grahas in Simhasanamsh were born Harish Chandr, Manu,
Bali, the Fire god (Agni Deva) and many  emperors.
In the present Yuga so born is Yudhishtira (or Dharm Raj of
Mahabharat). Salivahana's birth and that of others will
also come with this Yog.
With the lord of a Kendr and the lord of a Kon, having a
relationship as indicated in sloka 28, placed in
Paravatamsh, Manu, etc., were born.
The Incarnations of Lord Vishnu took place when the lord of
a Kendr and the lord of a Kon, having a relationship as
indicated in sloka 28, were placed in Devalokamsh;
with the lord of a Kendr and the lord of a Kon, having a
relationship as indicated in sloka 28, placed in
Brahmalokamsh Lord Brahma was born;
and with the lord of a Kendr and the lord of a Kon, having
a relationship as indicated in sloka 28, placed in
Iravatamsh the Swayambhu Manu was born. (Manu is the first
of the 14 Manus, identified as the second creator who
produced the Prajapatis. To Manu, the code of laws, viz.
Manu Smriti is ascribed) .
