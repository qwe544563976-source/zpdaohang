# 第 36 章：Many Other Yogas

- 来源：BPHS 97 章版
- 原始卡片：21 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P129_B002_01

- 身份：正文
- PDF 页：129
- 偈颂：1-2
- 标题路径：CHAPTER 36 Many Other Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Many Other Yogas · Sloka 1-2 [present] · PDF page 129

1-2. Benefic and Malefic Yogas: If there be a benefic in
Lagn, Subh Yog is produced,
~mI1~n
while a malefic in Lagn causes Asubh Yog.
~BI12*BI2~
Benefics in both Vyaya and Dhan Bhava cause Subh Yog.
~mI12*mI2~n
Malefics in both Vyaya and Dhan Bhava cause Asubh Yog.
~BI12*BI2~
One born in Subh Yog will be eloquent, charming, and
virtuous,
~mI12*mI2~n
while his counterpart will be sensuous, will do sinful
acts, and will enjoy (or swallow) others' wealth.
~-5c*-5d*-5Iz**5K*5YB+(5K)2*5YB+5K*5DB+(5K)2*5DB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P129_B003_01

- 身份：正文
- PDF 页：129
- 偈颂：3-4
- 标题路径：CHAPTER 36 Many Other Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Many Other Yogas · Sloka 3-4 [present] · PDF page 129

3-4. Gaj Kesari Yog: Should Guru be in a Kendr from Lagn or
from Chandr, and be yuti with or receiving a drishti from
(another) benefic, avoiding at the same time debilitation,
combustion, and inimical rashi, Gaj Kesari Yog is caused.
One born in Gaj Kesari Yog will be splendorous, wealthy
intelligent endowed with many laudable virtues and will
please the king.
~BI10*-mI10+(BI10)2*-(mI1O)2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P129_B004_01

- 身份：正文
- PDF 页：129
- 偈颂：5-6
- 标题路径：CHAPTER 36 Many Other Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Many Other Yogas · Sloka 5-6 [present] · PDF page 129

5-6. Amal Yog: If there be exclusively a benefic in the
10th from Lagn or Chandr, Amal Yog exists. Amal Yog will
confer fame lasting till Chandr and stars exist and will
make the native honoured by the king, enjoy abundant
pleasures, charitable, fond of relatives, helpful to
others, pious, and virtuous.
~BK*-&I7*-&I8+BK*-mI7*-mI8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P129_B005_01

- 身份：正文
- PDF 页：129
- 偈颂：7-8
- 标题路径：CHAPTER 36 Many Other Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Many Other Yogas · Sloka 7-8 [present] · PDF page 129

7-8. Parvat Yog: Benefics in Kendras will produce Parvat
Yog, as Yuvati and Randhr Bhava are vacant or are occupied
by only benefics. One born in Parvat Yog will be wealthy,
eloquent, charitable, learned in Shastras, fond of mirth,
famous, splendorous, and be the leader of a city.
~(L4I4)5*L1S+(L4I10)5*L1S+L4O*L4YL10+L4E*L4YL10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P129_B006_01

- 身份：正文
- PDF 页：129
- 偈颂：9-10
- 标题路径：CHAPTER 36 Many Other Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Many Other Yogas · Sloka 9-10 [present] · PDF page 129

9-10. Kahal Yog: Should Bandhu's lord and Guru be in mutual
Kendras, while Lagn's lord is strong, Kahal Yog occurs.
Alternatively, Bandhu's lord being in his own or exaltation
rashi should be yuti with Karm's lord. In effect, the
native will be energetic, adventurous, charming, endowed
with a complete army consisting of chariots elephants
horses and infantry, and he will lord over a few villages.
~L1E*L1K*L1D5+.^I1*-mI1+.^I9*-mI9+.^I10*-mI10+.^7*-mI7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P129_B007_01

- 身份：正文
- PDF 页：129
- 偈颂：11-12
- 标题路径：CHAPTER 36 Many Other Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Many Other Yogas · Sloka 11-12 [present] · PDF page 129

11-12. Chamar Yog: If Lagn's lord is exalted in a Kendr and
receives a drishti from Guru, Chamar Yog is formed. This
Yog also occurs if two benefics are in Lagn, or Dharm, or
Karm, or Yuvati Bhava. The effects of Chamar Yog are: the
native will be a king or honoured by the king, long lived,
scholarly, eloquent, and versed in all arts.
~L1S*(.L5I!K)L6+L1YL10*L1IRm*L9S~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P130_B001_01

- 身份：正文
- PDF 页：130
- 偈颂：13-14
- 标题路径：CHAPTER 36 Many Other Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Many Other Yogas · Sloka 13-14 [present] · PDF page 130

13-14. Shankh Yog: If Lagn's lord is strong, while the
lords of Putr and Ari Bhava are in mutual Kendras, then,
what is known as Shankh Yog is produced. Alternatively, if
Lagn's lord along with Karm's lord is in a movable rashi,
while Dharm's lord is strong, Shankh Yog is obtained. One
born with Shankh Yog will be endowed with wealth, spouse
and sons; he will be kindly disposed, propitious,
intelligent, meritorious, and long lived.
~&I12*&I1*&I2*&I7*L9S+6Y5*5YL1*L1K*L9S~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P130_B002_01

- 身份：正文
- PDF 页：130
- 偈颂：15-16
- 标题路径：CHAPTER 36 Many Other Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Many Other Yogas · Sloka 15-16 [present] · PDF page 130

15-16. Bhairi Yog: If Vyaya, Tanu, Dhan, and Yuvati Bhava
are occupied as Dharm's lord is strong, the native obtains
Bhairi Yog. Again, another kind of Bhairi Yog is formed if
Shukr, Guru, and Lagn's lord are in a Kendr, while Dharm's
lord is strong. The results of Bhairi Yog are: the native
will be endowed with wealth, wife and sons; he will be a
king, be famous, virtuous, and endowed with good behaviour,
happiness, and pleasures.
~@s1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P130_B003_01

- 身份：正文
- PDF 页：130
- 偈颂：17
- 标题路径：CHAPTER 36 Many Other Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Many Other Yogas · Sloka 17 [present] · PDF page 130

17. Mridang Yog: If Lagn's lord is strong and others occupy
Kendras, Konas, own bhavas or exaltation rashis, Mridang
Yog is formed. The native concerned will be a king or equal
to a king and be happy.
~L7I10*L10E*L10YL9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P130_B004_01

- 身份：正文
- PDF 页：130
- 偈颂：18
- 标题路径：CHAPTER 36 Many Other Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Many Other Yogas · Sloka 18 [present] · PDF page 130

18. Shrinath Yog: If Yuvati's lord is in Karm Bhava, while
Karm's lord is exalted and yuti with Dharm's lord, Shrinath
Yog takes place. The native with Shrinath Yog will be equal
to lord Devendra (the god of gods).
~L10I5*4K*1S*1IR5+(5T)2*3I11+(4T)2*3I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P130_B005_01

- 身份：正文
- PDF 页：130
- 偈颂：19-20
- 标题路径：CHAPTER 36 Many Other Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Many Other Yogas · Sloka 19-20 [present] · PDF page 130

19-20. Sharad Yog: Should Karm's lord be in Putr Bhava,
while Buddh is in a Kendr, as Surya with strength is in
Simh, Sharad Yog is formed. This will again be obtained if
Guru or Buddh is in a Kon to Chandr, while Mangal is in
Labh Bhava. One born in either kind of Yog will obtain
wealth, spouse and sons, be happy, scholarly, dear to the
king, pious, and virtuous.
~BI9*BI1*BI5*mI5*mI4*mI8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P130_B006_01

- 身份：正文
- PDF 页：130
- 偈颂：21-22
- 标题路径：CHAPTER 36 Many Other Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Many Other Yogas · Sloka 21-22 [present] · PDF page 130

21-22. Matsya Yog: Benefics in Dharm and Tanu Bhava, mixed
grahas in Putr Bhava and malefics in Bandhu and Randhr
Bhava: this array of grahas at birth will produce Matsya
Yog. In effect, the native will be a Jyotishi, be a synonym
of kindness, be virtuous, strong, beautiful, famous,
learned, and pious.
~BUI5*BUI6*BUI7*mUI3*mUI11*mUI1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P130_B007_01

- 身份：正文
- PDF 页：130
- 偈颂：23-24
- 标题路径：CHAPTER 36 Many Other Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Many Other Yogas · Sloka 23-24 [present] · PDF page 130

23-24. Kurm Yog: If Putr, Ari and Yuvati Bhava occupied by
benefic grahas identical with own bhava, or exaltation, or
friendly rashi, while malefics are in Sahaj, Labh, and Tanu
Bhava, in own bhava or in exaltation, Kurm Yog is formed.
The results of Kurm Yog are: the native will be a king. be
courageous, virtuous, famous, helpful, happy; he will be a
leader of men.
~L2I9*L9I2*L1K+L2I9*L9I2*L1T~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P131_B001_01

- 身份：正文
- PDF 页：131
- 偈颂：25-26
- 标题路径：CHAPTER 36 Many Other Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Many Other Yogas · Sloka 25-26 [present] · PDF page 131

25-26. Khadg Yog: Should there be an exchange of rashis
between the lords of Dhan and Dharm Bhava, as Lagn's lord
is in a Kendr or in a Kon Khadg Yog is obtained. One with
Khadg Yog will be endowed with wealth, fortunes and
happiness, be learned in Shastras, be intelligent, mighty,
grateful, and skilful.
~L9K*L9O*L1S+L9K*L9M*L1S+L9K*L9E*L1S~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P131_B002_01

- 身份：正文
- PDF 页：131
- 偈颂：27-28
- 标题路径：CHAPTER 36 Many Other Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Many Other Yogas · Sloka 27-28 [present] · PDF page 131

27-28. Lakshmi Yog: If Dharm's lord is in a Kendr identical
with his Mooltrikon rashi, or own rashi, or in exaltation,
while Lagn's lord is endowed with strength, Lakshmi Yog
occurs. The native with Lakshmi Yog will be charming,
virtuous, kingly in status, endowed with many sons and
abundant wealth; he will be famous and of high moral
merits.
~6K*2T*2YB*7I10*RfI1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P131_B003_01

- 身份：正文
- PDF 页：131
- 偈颂：29-30
- 标题路径：CHAPTER 36 Many Other Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Many Other Yogas · Sloka 29-30 [present] · PDF page 131

29-30. Kusum Yog: Shukr in a Kendr, Chandr in a Kon along
with a benefic and Shani in Karm Bhava: these grahas thus
cause Kusum Yog for one born in a fixed rashi ascending.
Such a native will be a king or equal to him, be
charitable, will enjoy pleasures, be happy, prime among his
race men, virtuous and red-lettered.
~5I2*5D4*5D6+5I5*5D4*5D6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P131_B004_01

- 身份：正文
- PDF 页：131
- 偈颂：31-32
- 标题路径：CHAPTER 36 Many Other Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Many Other Yogas · Sloka 31-32 [present] · PDF page 131

31-32. Kalanidhi Yog: If Guru is placed in Dhan, or Putr
Bhava, and receives a drishti from Buddh and Shukr,
Kalanidhi Yog is caused. In effect, the native will be
virtuous, honoured by the kings, bereft of diseases, be
happy, wealthy, and learned.
~@s2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P131_B005_01

- 身份：正文
- PDF 页：131
- 偈颂：33-34
- 标题路径：CHAPTER 36 Many Other Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Many Other Yogas · Sloka 33-34 [present] · PDF page 131

33-34. Kalpa Drum Yog:
Note the following four grahas:
(a) Lagn's lord,
(b) the dispositor of Lagn's lord,
(c) the dispositor of the grah at "b",
(d) the Navamsh dispositor of the grah at "c".
If all these are disposed in Kendras and in Konas from
Lagn, or are exalted, Kalpa Drum Yog exists. One with Kalpa
Drum Yog will be endowed with all kinds of wealth, be a
king, pious, strong, fond of war, and merciful.
~(BI2)L2*(BI12)L2*(BI8)L2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P131_B006_01

- 身份：正文
- PDF 页：131
- 偈颂：35-36
- 标题路径：CHAPTER 36 Many Other Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Many Other Yogas · Sloka 35-36 [present] · PDF page 131

35-36. Trimurthi Yogas: Counted from Dhan's lord, if
benefics occupy the 2nd, 12th, and 8th, Hari Yog is formed.
(The native will be happy, learned, and endowed with wealth
and sons).
~(BI4)L7*(BI9)L7*(BI8)L7~
If the 4th, 9th, and 8th with reference to the rashi
occupied by Yuvati's lord are occupied by benefics, Hara Yog
is obtainable. (The native will be happy, learned, and
endowed with wealth and sons).
~(BI4)L1*(BI10)L1*(BI11)L1~
Brahma Yog is generated if, counted from Lagn's lord,
benefics are in the 4th, 10th, and 11th rashis.
One born in anyone of the said three Yogas will be happy,
learned, and endowed with wealth and sons.
~BI7*BI8*-mI7*-mI8*-!7Dm*-!8Dm~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P132_B001_01

- 身份：正文
- PDF 页：132
- 偈颂：37
- 标题路径：CHAPTER 36 Many Other Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Many Other Yogas · Sloka 37 [present] · PDF page 132

37. Lagn Adhi Yog: Should benefics be in Yuvati and Randhr
Bhava counted from Lagn, and be devoid of yuti with, and/or
drishti from malefics, Lagn Adhi Yog is produced making one
a great person, learned in Shastras and happy.
~L1ç~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P132_B002_01

- 身份：正文
- PDF 页：132
- 偈颂：38-39
- 标题路径：CHAPTER 36 Many Other Yogas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Many Other Yogas · Sloka 38-39 [present] · PDF page 132

38-39. Effects of Lagn's Lord's Division Dignities: Lagn's
lord in Parijatamsh will make one happy;
~L1è~
Lagn's lord in Vargottama will give immunity to diseases;
~L1é~
Lagn's lord in Gopuramsh will make one rich with wealth and
grains;
~L1ê~
Lagn's lord in Simhasanamsh will make one a king;
~L1ë~
Lagn's lord in Paravatamsh will make one a scholar;
~L1ì~
Lagn's lord in Devalokamsh will make one opulent and
endowed with conveyances;
~L1í~
and Lagn's lord in Iravatamsh will make one famous and
honoured by kings.
(Vargottama indicates a grah occupying the same Rashi
and the same Navamsh).
