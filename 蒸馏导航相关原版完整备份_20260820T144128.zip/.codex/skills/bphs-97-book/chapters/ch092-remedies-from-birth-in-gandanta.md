# 第 92 章：Remedies from Birth in Gandanta

- 来源：BPHS 97 章版
- 原始卡片：7 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P366_B002_01

- 身份：正文
- PDF 页：366
- 偈颂：1
- 标题路径：CHAPTER 92 Remedies from Birth in Gandanta
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from Birth in Gandanta · Sloka 1 [present] · PDF page 366

1. The Sage said: O Brahmin! Gandanta is of three kinds,
namely of Tithi, Nakshatr, and Lagn. Birth, travelling, and
performance of auspicious functions like marriage, etc.,
during Gandanta are likely to cause death of the person
concerned.

Tithi Gandanta

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P366_B003_01

- 身份：正文
- PDF 页：366
- 偈颂：2
- 标题路径：CHAPTER 92 Remedies from Birth in Gandanta
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from Birth in Gandanta · Sloka 2 [present] · PDF page 366

2. 0 Maitreya! The last 2 ghatikas of Purna tithi (5th, 10th,
15th), and the first 2 ghatikas of Nanda tithi (1st, 6th,
11th) (total 4 ghatikas) are known as Tithi Gandanta.
Nakshatr Gandanta

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P366_B004_01

- 身份：正文
- PDF 页：366
- 偈颂：3
- 标题路径：CHAPTER 92 Remedies from Birth in Gandanta
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from Birth in Gandanta · Sloka 3 [present] · PDF page 366

3. Similarly, the last two ghatikas of Revati and first two
ghatikas of Ashvini, the last two ghatikas of Aslesha and
first two ghatikas of Magha, and the last two ghatikas of
Jyeshtha and first two ghatikas of Mula (total 4 ghatikas)
are known as Nakshatr Gandanta.
Lagn Gandanta

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P366_B005_01

- 身份：正文
- PDF 页：366
- 偈颂：4
- 标题路径：CHAPTER 92 Remedies from Birth in Gandanta
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from Birth in Gandanta · Sloka 4 [present] · PDF page 366

4. The last half ghatika of Meen and first half ghatika of
Mesh, the last half ghatika of Kark and first half ghatika of
Simh, the last half ghatika of Vrischik and first half
ghatika of Dhanu, are known as Lagn Gandanta.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P366_B006_01

- 身份：正文
- PDF 页：366
- 偈颂：5
- 标题路径：CHAPTER 92 Remedies from Birth in Gandanta
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from Birth in Gandanta · Sloka 5 [present] · PDF page 366

5. Amongst these Gandantas the last 6 ghatikas of Jyeshtha
and first 8 ghatikas of Mula are known as Abhukta Mula.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P366_B007_01

- 身份：正文
- PDF 页：366
- 偈颂：6-8
- 标题路径：CHAPTER 92 Remedies from Birth in Gandanta
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from Birth in Gandanta · Sloka 6-8 [present] · PDF page 366

6-8. Now, I will tell you the remedial measures to be adopted
to release the child born during gandanta from its evil
effects. The father should see the child born only on the
morning next to the end of the days of Sutaka or on any
auspicious day after the performance of the remedial
measures. The remedial measures are:
(I) Giving a bullock in charity, in the case of Tithi
Gandanta;
(2) Giving a cow with calf in charity in the case of Nakshatr
Gandanta;
(3) Giving gold in charity in the case of Lagn Gandanta;
(4) Performing Abhisheka of the child along with father if
the birth is in the first part of gandanta and along with
mother if the birth is in the second part of gandanta.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P366_B008_01

- 身份：正文
- PDF 页：366
- 偈颂：9-11
- 标题路径：CHAPTER 92 Remedies from Birth in Gandanta
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from Birth in Gandanta · Sloka 9-11 [present] · PDF page 366

9-11. Performance of Puja on the holy Kalash of the idol of
the deities of tithi (in case of tithi gandanta), Nakshatr
(in case of Nakshatr Gandanta), and Lagn (in case of Lagn
Gandanta) made of 16 masas, 8 masas or 4 masas of gold as may
be possible followed by havan and abhisheka according to
procedure already described earlier. At the end as many
Brahmins as may be possible within one's means should be fed.
These remedial measures will ensure long life, good health
and prosperity for the child.
Notes: Unless one is himself fully conversant with the
performance of religious rites, the remedies recommended in
this chapter, earlier and later chapters should be got
performed by and under the directions of a learned priest,
because the full effects will be derived if the rites are
performed correctly and according to the procedure prescribed
in the religious scriptures on this subject.
