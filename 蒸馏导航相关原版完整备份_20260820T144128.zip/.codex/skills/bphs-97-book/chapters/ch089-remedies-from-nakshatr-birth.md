# 第 89 章：Remedies from Nakshatr Birth

- 来源：BPHS 97 章版
- 原始卡片：2 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P363_B002_01

- 身份：正文
- PDF 页：363
- 偈颂：1-7
- 标题路径：CHAPTER 89 Remedies from Nakshatr Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from Nakshatr Birth · Sloka 1-7 [present] · PDF page 363

1-7. The Sage Parasara said: O Maitreya! If the birth takes
place in the nakshatras of the brother and the parents, death
takes place, without doubt, of the brother and the father or
mother or they have to undergo death like suffering.
Therefore, I am going to describe the remedial measures to be
adopted to escape from these evil effects. The remedial rites
should be performed in a muhurta when Chandr and stars are
favourable on a day on which there is no Rikta-Bhadra dosha.
The remedial rites should be performed in the following
order:
(I) Instal an idol of the Janm Nakshatr on a Kalash in the
north east direction from the fire. Cover it with a red piece
of cloth and then warp two pieces of cloth round it;
(2) Worship the idol by chanting the mantras of the Janm
Nakshatr;
(3) According to one's gotra, perform havan 108 times with
the recitation of the same mantra, facing the fire, with ghee
and other havan material (described in earlier chapters);
(4) Then the priest performing the puja should sprinkle water
on the parents and brother (whoever is concerned);
(5) Give presents in cash (dakshena) to the priest and his
colleagues associated with the ceremony, to the best of one's
means; and
(6) Then, feed the Brahmins to the best of one's means.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P363_B002_02

- 身份：正文
- PDF 页：363
- 偈颂：1-7
- 标题路径：CHAPTER 89 Remedies from Nakshatr Birth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from Nakshatr Birth · Sloka 1-7 [present] · PDF page 363

1-7. The Sage Parasara said: O Maitreya! If the birth takes
place in the nakshatras of the brother and the parents, death
takes place, without doubt, of the brother and the father or
mother or they have to undergo death like suffering.
Therefore, I am going to describe the remedial measures to be
adopted to escape from these evil effects. The remedial rites
should be performed in a muhurta when Chandr and stars are
favourable on a day on which there is no Rikta-Bhadra dosha.
The remedial rites should be performed in the following
order:
(I) Instal an idol of the Janm Nakshatr on a Kalash in the
north east direction from the fire. Cover it with a red piece
of cloth and then warp two pieces of cloth round it;
(2) Worship the idol by chanting the mantras of the Janm
Nakshatr;
(3) According to one's gotra, perform havan 108 times with
the recitation of the same mantra, facing the fire, with ghee
and other havan material (described in earlier chapters);
(4) Then the priest performing the puja should sprinkle water
on the parents and brother (whoever is concerned);
(5) Give presents in cash (dakshena) to the priest and his
colleagues associated with the ceremony, to the best of one's
means; and
(6) Then, feed the Brahmins to the best of one's means.
