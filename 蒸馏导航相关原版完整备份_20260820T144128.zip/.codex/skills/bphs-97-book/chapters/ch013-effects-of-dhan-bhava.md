# 第 13 章：Effects of Dhan Bhava

- 来源：BPHS 97 章版
- 原始卡片：11 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P035_B002_01

- 身份：正文
- PDF 页：35
- 偈颂：1-2
- 标题路径：CHAPTER 13 Effects of Dhan Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dhan Bhava · Sloka 1-2 [present] · PDF page 35

1-2. Combinations for Wealth: O excellent of the Brahmins,
listen to me speaking on the effects of Dhan Bhava.
~L2I2+L2K+L2T~
If the lord of Dhan is in Dhan or is in an angle or in
trine he will promote one's wealth (or monetary state).
~L2I6+L2I8+L2I12~n
Should he be in Ari/8th/12th, financial conditions will
decline.
~BI2~
A benefic in Dhan will give wealth
~mI2~n
while a malefic instead will destroy wealth.
~5I2*5O+5Y3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P035_B003_01

- 身份：正文
- PDF 页：35
- 偈颂：3
- 标题路径：CHAPTER 13 Effects of Dhan Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dhan Bhava · Sloka 3 [present] · PDF page 35

3. One will be wealthy if Guru is in Dhan as the lord of
Dhan or is with Mangal.
~L2I11*L11I2+L2YL11*L2K+L2YL11*L2T~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P035_B004_01

- 身份：正文
- PDF 页：35
- 偈颂：4
- 标题路径：CHAPTER 13 Effects of Dhan Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dhan Bhava · Sloka 4 [present] · PDF page 35

4. If Dhan lord is in Labh, while the lord of Labh in Dhan,
wealth will be acquired by the native. Alternately, these
two lords may join in an angle or in a trine.
~L2K*(L11T)L2+L2K*L11A5+L2K*L11Y5+L2K*L11A6+L2K*L11Y6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P035_B005_01

- 身份：正文
- PDF 页：35
- 偈颂：5
- 标题路径：CHAPTER 13 Effects of Dhan Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dhan Bhava · Sloka 5 [present] · PDF page 35

5. If the lord of Dhan is in an angle while Labh lord is in
a trine thereof or is drishtied by or yuti with by Guru and
Shukr, the subject will be wealthy.
~L2Ia*L11Ia*mI2~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P035_B006_01

- 身份：正文
- PDF 页：35
- 偈颂：6-7
- 标题路径：CHAPTER 13 Effects of Dhan Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dhan Bhava · Sloka 6-7 [present] · PDF page 35

6-7. Yogas for Poverty: One will be penniless if the lord
of Dhan Bhava is in an evil bhava while the lord of Labh
Bhava is also so placed, and Dhan Bhava is occupied by a
malefic.
~L2c*L11c+L2Ym*L11Ym~n
There will be penury right from birth and the native will
have to beg even for his food if the lords of Dhan and Labh
Bhava are both combust or with malefics.
~L2Ia*L11Ia*3I11*8I2~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P035_B007_01

- 身份：正文
- PDF 页：35
- 偈颂：8
- 标题路径：CHAPTER 13 Effects of Dhan Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dhan Bhava · Sloka 8 [present] · PDF page 35

8. Loss of Wealth through the King: Should the lords of
Dhan and Labh Bhava be relegated to Ari, Randhr, or Vyaya
Bhava (jointly or separately),while Mangal is in Labh Bhava
and Rahu is in Dhan Bhava, the native will lose his wealth
on account of royal punishments.
~5I11*6I2*BI12*L2YB~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P035_B008_01

- 身份：正文
- PDF 页：35
- 偈颂：9
- 标题路径：CHAPTER 13 Effects of Dhan Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dhan Bhava · Sloka 9 [present] · PDF page 35

9. Expenses on Good Accounts: When Guru is in Labh, Shukr
is in Dhan, and a benefic is placed in Vyaya Bhava, while
Dhan's lord is yuti with a benefic, there will be expenses
on religious or charitable grounds.
~L2O+L2E~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P035_B009_01

- 身份：正文
- PDF 页：35
- 偈颂：10
- 标题路径：CHAPTER 13 Effects of Dhan Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dhan Bhava · Sloka 10 [present] · PDF page 35

10. Fame, etc.: If Dhan's lord is in own rashi or is
exalted the native will look after his people, will help
others, and all will become famous.
~L2YB*@hL2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P036_B001_01

- 身份：正文
- PDF 页：36
- 偈颂：11
- 标题路径：CHAPTER 13 Effects of Dhan Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dhan Bhava · Sloka 11 [present] · PDF page 36

11. Effortless Aquisition: If Dhan's lord is yuti with a
benefic and is in a good division like Paravatamsh, there
will be effortlessly all kinds of wealth in the native's
family.
("Paravatamshdau" of the text denotes Paravat or such
other higher vargas: Dhan's lord should be in Paravatamsh
or in Devalokamsh, Brahmalokamsh, Sakravahanamsh, or
Sridhamamsh in the Dash Varg scheme.)
~L2X~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P036_B002_01

- 身份：正文
- PDF 页：36
- 偈颂：12
- 标题路径：CHAPTER 13 Effects of Dhan Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dhan Bhava · Sloka 12 [present] · PDF page 36

12. Eyes: If Dhan lord is endowed with strength, the native
will possess beautiful eyes.
~L2I6+L2I8+L2I12~n
Should the said grah be in Ari,  Randhr, or Vyaya Bhava,
there will be disease or deformity of eyes.
~L2Ym*mI2~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P036_B003_01

- 身份：正文
- PDF 页：36
- 偈颂：13
- 标题路径：CHAPTER 13 Effects of Dhan Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Dhan Bhava · Sloka 13 [present] · PDF page 36

13. Untruthful Person: If Dhan Bhava and its lord are yuti
with malefics, the native will be a tale-bearer, will speak
untruth and will be afflicted by windy diseases.
