# 第 31 章：Argala or Intervention from Grahas

- 来源：BPHS 97 章版
- 原始卡片：11 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P101_B002_01

- 身份：正文
- PDF 页：101
- 偈颂：1
- 标题路径：CHAPTER 31 Argala or Intervention from Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Argala or Intervention from Grahas · Sloka 1 [present] · PDF page 101

1. O Maharishi Parashar, you have told of (some) auspicious
effects related to Argala. Kindly narrate its conditions
and effects.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P101_B003_01

- 身份：正文
- PDF 页：101
- 偈颂：2-9
- 标题路径：CHAPTER 31 Argala or Intervention from Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Argala or Intervention from Grahas · Sloka 2-9 [present] · PDF page 101

2-9. Formation of Argala: Maitreya, I explain below Argala
to know the definite effects of bhavas and grahas. Grahas
in the 4th, 2nd, and the 11th (from a bhava or a grah)
cause Argalas, while obstructors of the Argala will be
those in the 10th, 12th, and 3rd from a bhava or a grah.
If the Argala causing grah is stronger than the obstructing
one, the former will prevail. Or if the number of Argalas
are more than the obstructing grahas, then also the Argala
will prevail. If there are 3 or more malefics in the 3rd
they will cause Vipreet Argala (more effective
intervention) which will also be harmless and be very
favourable. The 5th is also an Argala place, while the grah
in the 9th will counteract such Argala. As Rahu and Ketu
have retrograde motions, the Argalas and obstructions be
also counted accordingly in a reverse manner. Maharishis
say that the Argala caused by one grah will yield limited
effect, by two medium and by more than two excellent
effects. Argalas should be counted from a rashi or a grah
as the case may be. The Argala which is unobstructed will
be fruitful, while the one duly obstructed will go astray.
The Argala effects will be derived in the Dasha periods of
the rashi or grah concerned.
Notes: 'Argala' in Sanskrit is figuratively used to denote
an impediment or obstruction. Argala is calculated from a
bhava or from a grah. The 4th, 2nd, and 11th bhava
occupants cause Argala for a bhava or a grah. A grah in the
10th (from where the Argala is calculated) will obstruct
the Argala coming from the 4th. Similarly, a grah in 12th
will counteract Argala emanating from the 2nd, while the
one in 11th will impede the Argala from the 3rd. Some
suggest that the Argala obstruction places are countable
from the Argala place instead of from the original place or
grah. This is not logical and a glance into Gochar Vedha
(or obstructions during transits) will confirm our
findings.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P101_B003_02

- 身份：正文
- PDF 页：101
- 偈颂：2-9
- 标题路径：CHAPTER 31 Argala or Intervention from Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Argala or Intervention from Grahas · Sloka 2-9 [present] · PDF page 101

2-9. Formation of Argala: Maitreya, I explain below Argala
to know the definite effects of bhavas and grahas. Grahas
in the 4th, 2nd, and the 11th (from a bhava or a grah)
cause Argalas, while obstructors of the Argala will be
those in the 10th, 12th, and 3rd from a bhava or a grah.
If the Argala causing grah is stronger than the obstructing
one, the former will prevail. Or if the number of Argalas
are more than the obstructing grahas, then also the Argala
will prevail. If there are 3 or more malefics in the 3rd
they will cause Vipreet Argala (more effective
intervention) which will also be harmless and be very
favourable. The 5th is also an Argala place, while the grah
in the 9th will counteract such Argala. As Rahu and Ketu
have retrograde motions, the Argalas and obstructions be
also counted accordingly in a reverse manner. Maharishis
say that the Argala caused by one grah will yield limited
effect, by two medium and by more than two excellent
effects. Argalas should be counted from a rashi or a grah
as the case may be. The Argala which is unobstructed will
be fruitful, while the one duly obstructed will go astray.
The Argala effects will be derived in the Dasha periods of
the rashi or grah concerned.
Notes: 'Argala' in Sanskrit is figuratively used to denote
an impediment or obstruction. Argala is calculated from a
bhava or from a grah. The 4th, 2nd, and 11th bhava
occupants cause Argala for a bhava or a grah. A grah in the
10th (from where the Argala is calculated) will obstruct
the Argala coming from the 4th. Similarly, a grah in 12th
will counteract Argala emanating from the 2nd, while the
one in 11th will impede the Argala from the 3rd. Some
suggest that the Argala obstruction places are countable
from the Argala place instead of from the original place or
grah. This is not logical and a glance into Gochar Vedha
(or obstructions during transits) will confirm our
findings.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P102_B001_01

- 身份：正文
- PDF 页：102
- 偈颂：10
- 标题路径：CHAPTER 31 Argala or Intervention from Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Argala or Intervention from Grahas · Sloka 10 [present] · PDF page 102

10. Special: The Argala caused by placement of a grah in
the first one fourth part of the rashi is countered by
another placed in the 4th quarter of the respective
obstructive rashi. Similarly, 2nd quarter's Argala is
eliminated by the 3rd quarter placement of another grah.
Notes: We have learnt that an Argala, for example in the
4th from a bhava or a grah is eliminated by another placed
in the 10th bhava from the original grah or bhava. Here,
the rules for obstruction of Argala are still narrowed
down. Accordingly, there are only two circumstances of
Argala getting nullified. Make the rashi in which the
Argala occurs into four quarters (of 7 degrees 30 min.
each). Similarly, the rashi where obstruction occurs is
also made in four quarters. If the Argala causing grah is
in the first  quarter (or first 7 degrees 30' of the
rashi), while the obstructing grah is in the 4th quarter
(i.e. 22 degrees 30' - 30 degrees), the obstruction indeed
will come to pass. Otherwise, not. So to say, Argala will
operate and the obstruction will fail. Likewise, while the
Argala grah is in the 2nd quarter of the rashi (i.e. 7
degrees 30 min - 1 5 degrees), the obstruction (grah in 15
degrees - 22 degrees 30 min: i.e. in the 3rd quarter) will
combat the Argala.
~ArLa*Ar!1*(Ar!7)La*Ar!7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P102_B001_02

- 身份：正文
- PDF 页：102
- 偈颂：10
- 标题路径：CHAPTER 31 Argala or Intervention from Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Argala or Intervention from Grahas · Sloka 10 [present] · PDF page 102

10. Special: The Argala caused by placement of a grah in
the first one fourth part of the rashi is countered by
another placed in the 4th quarter of the respective
obstructive rashi. Similarly, 2nd quarter's Argala is
eliminated by the 3rd quarter placement of another grah.
Notes: We have learnt that an Argala, for example in the
4th from a bhava or a grah is eliminated by another placed
in the 10th bhava from the original grah or bhava. Here,
the rules for obstruction of Argala are still narrowed
down. Accordingly, there are only two circumstances of
Argala getting nullified. Make the rashi in which the
Argala occurs into four quarters (of 7 degrees 30 min.
each). Similarly, the rashi where obstruction occurs is
also made in four quarters. If the Argala causing grah is
in the first  quarter (or first 7 degrees 30' of the
rashi), while the obstructing grah is in the 4th quarter
(i.e. 22 degrees 30' - 30 degrees), the obstruction indeed
will come to pass. Otherwise, not. So to say, Argala will
operate and the obstruction will fail. Likewise, while the
Argala grah is in the 2nd quarter of the rashi (i.e. 7
degrees 30 min - 1 5 degrees), the obstruction (grah in 15
degrees - 22 degrees 30 min: i.e. in the 3rd quarter) will
combat the Argala.
~ArLa*Ar!1*(Ar!7)La*Ar!7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P103_B001_01

- 身份：正文
- PDF 页：103
- 偈颂：11-17
- 标题路径：CHAPTER 31 Argala or Intervention from Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Argala or Intervention from Grahas · Sloka 11-17 [present] · PDF page 103

11-17. Argala Effects: Should there be Argala for the Arudh
Pad, for the natal Lagn, and for the 7th from both, the
native will be famous and fortunate.
~mAu*!1Dm+BAu*!1DB~
A malefic or a benefic causing unobstructed Argala giving a
drishti to Lagn, will make one famous.
~mAu*!2Dm+BAu*!2DB~
Similarly, a malefic or a benefic causing unobstructed
Argala giving a drishti to Dhan Bhava denotes acquisition
of wealth and grains;
~mAu*!3Dm+BAu*!3DB~n
a malefic or a benefic causing unobstructed Argala giving a
drishti to Sahaj Bhava denotes happiness from co-born;
~mAu*!4Dm+BAu*!4DB~
a malefic or a benefic causing unobstructed Argala giving a
drishti to Bandhu Bhava denotes residences, quadrupeds, and
relatives;
~mAu*!5Dm+BAu*!5DB~
a malefic or a benefic causing unobstructed Argala giving a
drishti to Putr Bhava denotes sons, grandsons, and
intelligence;
~mAu*!6Dm+BAu*!6DB~n
a malefic or a benefic causing unobstructed Argala giving a
drishti to Ari Bhava denotes fear from enemies;
~mAu*!7Dm+BAu*!7DB~
a malefic or a benefic causing unobstructed Argala giving a
drishti to Yuvati Bhava denotes abundant wealth and marital
happiness;
~mAu*!8Dm+BAu*!8DB~n
a malefic or a benefic causing unobstructed Argala giving a
drishti to Randhr Bhava denotes difficulties;
~mAu*!9Dm+BAu*!9DB~
a malefic or a benefic causing unobstructed Argala giving a
drishti to Dharm Bhava denotes fortunes;
~mAu*!10Dm+BAu*!10DB~
a malefic or a benefic causing unobstructed Argala giving a
drishti to Karm Bhava denotes royal honour;
~mAu*!11Dm+BAu*!11DB~
a malefic or a benefic causing unobstructed Argala giving a
drishti to Labh Bhava denotes gains;
~mAu*!12Dm+BAu*!12DB~n
and a malefic or a benefic causing unobstructed Argala
giving a drishti to Vyaya Bhava denotes expenses.
~BAr~
The Argala by benefics will give various kinds of
happiness,
~mAr~m
while benefic effects will be meddling with malefic
Argalas.
~mAr*BAr~
Argala by both benefics and malefics will yield results.
Notes: For our own benefit we should understand the word
'Argala' in a suitable manner apart from the manner the
Argala functions vis-a-vis Argala elimination.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P103_B001_02

- 身份：正文
- PDF 页：103
- 偈颂：11-17
- 标题路径：CHAPTER 31 Argala or Intervention from Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Argala or Intervention from Grahas · Sloka 11-17 [present] · PDF page 103

11-17. Argala Effects: Should there be Argala for the Arudh
Pad, for the natal Lagn, and for the 7th from both, the
native will be famous and fortunate.
~mAu*!1Dm+BAu*!1DB~
A malefic or a benefic causing unobstructed Argala giving a
drishti to Lagn, will make one famous.
~mAu*!2Dm+BAu*!2DB~
Similarly, a malefic or a benefic causing unobstructed
Argala giving a drishti to Dhan Bhava denotes acquisition
of wealth and grains;
~mAu*!3Dm+BAu*!3DB~n
a malefic or a benefic causing unobstructed Argala giving a
drishti to Sahaj Bhava denotes happiness from co-born;
~mAu*!4Dm+BAu*!4DB~
a malefic or a benefic causing unobstructed Argala giving a
drishti to Bandhu Bhava denotes residences, quadrupeds, and
relatives;
~mAu*!5Dm+BAu*!5DB~
a malefic or a benefic causing unobstructed Argala giving a
drishti to Putr Bhava denotes sons, grandsons, and
intelligence;
~mAu*!6Dm+BAu*!6DB~n
a malefic or a benefic causing unobstructed Argala giving a
drishti to Ari Bhava denotes fear from enemies;
~mAu*!7Dm+BAu*!7DB~
a malefic or a benefic causing unobstructed Argala giving a
drishti to Yuvati Bhava denotes abundant wealth and marital
happiness;
~mAu*!8Dm+BAu*!8DB~n
a malefic or a benefic causing unobstructed Argala giving a
drishti to Randhr Bhava denotes difficulties;
~mAu*!9Dm+BAu*!9DB~
a malefic or a benefic causing unobstructed Argala giving a
drishti to Dharm Bhava denotes fortunes;
~mAu*!10Dm+BAu*!10DB~
a malefic or a benefic causing unobstructed Argala giving a
drishti to Karm Bhava denotes royal honour;
~mAu*!11Dm+BAu*!11DB~
a malefic or a benefic causing unobstructed Argala giving a
drishti to Labh Bhava denotes gains;
~mAu*!12Dm+BAu*!12DB~n
and a malefic or a benefic causing unobstructed Argala
giving a drishti to Vyaya Bhava denotes expenses.
~BAr~
The Argala by benefics will give various kinds of
happiness,
~mAr~m
while benefic effects will be meddling with malefic
Argalas.
~mAr*BAr~
Argala by both benefics and malefics will yield results.
Notes: For our own benefit we should understand the word
'Argala' in a suitable manner apart from the manner the
Argala functions vis-a-vis Argala elimination.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P104_B001_01

- 身份：正文
- PDF 页：104
- 偈颂：1
- 标题路径：CHAPTER 31 Argala or Intervention from Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Argala or Intervention from Grahas · Sloka 1 [present] · PDF page 104

1. Argala can be caused by a benefic which is known as Subh
Argala. This Argala can be from a malefic also, so that the
benefic causing Argala stalls the malefic role going
against the native. If the benefic's Argala is obstructed
by another, then the benefic will become ineffective in
Argala and the first-mentioned malefic will operate
freely.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P104_B002_01

- 身份：正文
- PDF 页：104
- 偈颂：2
- 标题路径：CHAPTER 31 Argala or Intervention from Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Argala or Intervention from Grahas · Sloka 2 [present] · PDF page 104

2. Argala can be by a malefic with reference to a benefic,
so that the native does not enjoy good effects due to the
benefic. This is Pap Argala (or malefic Argala). If the
Argala is eliminated by a benefic or a malefic, then again
the first mentioned benefic will be at liberty to act
according to his own disposition.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P104_B003_01

- 身份：正文
- PDF 页：104
- 偈颂：3
- 标题路径：CHAPTER 31 Argala or Intervention from Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Argala or Intervention from Grahas · Sloka 3 [present] · PDF page 104

3. Argala is operable with reference to bhavas as well.
Other relative rules need to be well understood before
application of the Argala.
~L1Au*!5Au*!9Au~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P104_B004_01

- 身份：正文
- PDF 页：104
- 偈颂：18
- 标题路径：CHAPTER 31 Argala or Intervention from Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Argala or Intervention from Grahas · Sloka 18 [present] · PDF page 104

18. Should there be (unobstructed) Argala for Lagn, Putr,
and Dharm Bhava the native will doubtlessly become a king
and fortunate.
