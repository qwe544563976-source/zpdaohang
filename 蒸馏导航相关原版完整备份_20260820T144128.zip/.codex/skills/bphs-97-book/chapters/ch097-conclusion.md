# 第 97 章：Conclusion

- 来源：BPHS 97 章版
- 原始卡片：5 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P372_B002_01

- 身份：正文
- PDF 页：372
- 偈颂：1-4
- 标题路径：CHAPTER 97 Conclusion
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Conclusion · Sloka 1-4 [present] · PDF page 372

1-4. Maharishi Parasara said: O Brahmin! I have described to
you the Jyotish Shastra as narrated by Lord Brahma to the
Sage Narada and by Narada to Shaunaka and other Sages from
whom I received the knowledge of this Shastra. I have
narrated the same Jyotish Shastra which I learnt from them.
Do not impart the knowledge of this Shastra to one who is
insignificative, slanders, or calumniates others, not to one
who is not intelligent, is wicked, and unknown to you. Teach
this supreme Vedanga Jyotish Shastra only to one who is
gentle and amiable, devoted, truthful, brilliant, and well
known to you.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P372_B003_01

- 身份：正文
- PDF 页：372
- 偈颂：5-6
- 标题路径：CHAPTER 97 Conclusion
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Conclusion · Sloka 5-6 [present] · PDF page 372

5-6. Only that person who possesses adequate knowledge of
time and the positions of grahas and constellations
(nakshatras) can understand this Hora Shatra. Only that
person who has complete knowledge of the Hora Sastra and who
is truthful, can make correct favourable or unfavourable
predictions.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P372_B004_01

- 身份：正文
- PDF 页：372
- 偈颂：7
- 标题路径：CHAPTER 97 Conclusion
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Conclusion · Sloka 7 [present] · PDF page 372

7. One who reads or listens with attention and devotion to
this most excellent Hora Shastra, becomes long lived and is
blessed with increase in his strength, wealth, and good
reputation.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P372_B005_01

- 身份：正文
- PDF 页：372
- 偈颂：8-9
- 标题路径：CHAPTER 97 Conclusion
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Conclusion · Sloka 8-9 [present] · PDF page 372

8-9. Thus, was narrated by Maharishi Parasara to Maitreya,
this novel Hora Shastra containing invaluable and uncommon
material from (many) ancient scriptures on Jyotish, for the
benefit of the world at large. Afterwards it came into usage
on the earth and received reverence from all.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P372_B006_01

- 身份：正文
- PDF 页：372
- 偈颂：10-25
- 标题路径：CHAPTER 97 Conclusion
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Conclusion · Sloka 10-25 [present] · PDF page 372

10-25. In these verses have been described the subject
matters of all the chapters contained in this book and their
importance. This information has been given in detail in the
Table of contents in Volumes I and II of this book.
