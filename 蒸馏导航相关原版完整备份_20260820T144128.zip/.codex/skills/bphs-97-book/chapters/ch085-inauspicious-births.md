# 第 85 章：Inauspicious Births

- 来源：BPHS 97 章版
- 原始卡片：1 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P359_B002_01

- 身份：正文
- PDF 页：359
- 偈颂：1-4
- 标题路径：CHAPTER 85 Inauspicious Births
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Inauspicious Births · Sloka 1-4 [present] · PDF page 359

1-4. The venerable Sage said: O Maitreya! Now I will describe
to you the circumstances in which the births are inauspicious
in spite of Lagn and the grahas being well disposed. Although
Lagn may be well disposed births will be inauspicious if they
take place on Amavasya (the last day of the dark half of the
month), on Chaturdasi (14th tithi), in Krishna Paksha (dark
half of the month, in Bhadra Karan, in the nakshatr of the
brother, in the nakshatras of father and mother, at the time
of entry of Surya in a rashi, the time of Pata, at the time
of solar and lunar eclipses, at the time of Vyati pata, in
gandantas of all the three kinds, in yamaghant, Tithikshaya,
in Dagdha Yog, etc.. The birth of a son after three daughters
and birth of a daughter after three sons and the birth of a
freak are inauspicious. But there are remedial measures for
obtaining relief from the evil effects of such births which
are being described in the foregoing chapters.
