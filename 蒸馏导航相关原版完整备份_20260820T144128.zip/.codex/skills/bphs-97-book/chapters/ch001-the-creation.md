# 第 1 章：The Creation

- 来源：BPHS 97 章版
- 原始卡片：9 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P002_B002_01

- 身份：正文
- PDF 页：2
- 偈颂：—
- 标题路径：CHAPTER 1 The Creation
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Creation · Sloka unknown [unknown] · PDF page 2 · page_block BPHS_PL9_CHAP_97_P002_B002

{Intro}
I prostrate before the lotus-feet of Lord Vighneswara,
offspring of Uma, the cause of destruction of sorrow, who
served by Mahabhutas (the five great elements of the
universe) etc; who has the face of a tusker and who
consumes the essence of Kapittha and Jambu fruits.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P002_B003_01

- 身份：正文
- PDF 页：2
- 偈颂：1-4
- 标题路径：CHAPTER 1 The Creation
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Creation · Sloka 1-4 [present] · PDF page 2

1-4. Offering his obeisance to all-knowing Maharishi
Parashar and with folded hands, Maitreya said:
"O Venerable Maharishi, Jyotish, the supreme limb of the
Vedas, has three divisions, viz. Hora, Ganita, and Samhita.
Among the said three divisions, Hora or the general part of
Jyotish is still more excellent. I desire to know of its
glorious aspects from you. Be pleased to tell me, how this
Universe is created? How does it end? What is the
relationship of the animals born on this earth with the
heavenly bodies? Please speak elaborately".

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P002_B004_01

- 身份：正文
- PDF 页：2
- 偈颂：5-8
- 标题路径：CHAPTER 1 The Creation
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Creation · Sloka 5-8 [present] · PDF page 2

5-8. Maharishi Parashar answered, 'O Brahmin, your query
(so to say the desire to know of the intricacies of
Jyotish) has an auspicious purpose in it for the welfare of
the Universe. Praying Lord Brahma and Shri Saraswati, His
power (and consort), and Surya the leader of the grahas,
and the cause of Creation, I shall proceed to narrate to
you the science of Jyotish as heard through Lord Brahma.
Only good will follow the teaching of this Vedic Science to
the students who are peacefully disposed, who honour the
preceptors (and elders) who speak only truth and are God
fearing. Woeful forever, doubtlessly, will it be to impart
knowledge of this science to an unwilling student, to a
heterodox, and to a crafty person.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P002_B005_01

- 身份：正文
- PDF 页：2
- 偈颂：9-12
- 标题路径：CHAPTER 1 The Creation
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Creation · Sloka 9-12 [present] · PDF page 2

9-12. Shri Vishnu who is the lord (of all matters), who has
undefiled spirit, who is endowed with the three gunas,
although he transcends the grip of gunas (i.e. Gunatita),
who is the Author of this Universe, who is glorious, who is
the Cause and who is endowed with valour has no beginning.
He authored the Universe and administers it with a quarter
of his power. The other three quarters of Him, filled with
nectar, are knowable only to the philosophers (of
maturity). The Principal Evolver who is both perceptible
and imperceptible in Vasudeva. The Imperceptible part of
the Lord is endowed with dual powers, while the Perceptible
with triple powers.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P002_B006_01

- 身份：正文
- PDF 页：2
- 偈颂：13-15
- 标题路径：CHAPTER 1 The Creation
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Creation · Sloka 13-15 [present] · PDF page 2

13-15. The three powers are: Shri Shakti (Mother Lakshmi)
with Sattva-gun, Bhoo Shakti (Mother-Earth) with Rajo-gun,
and Neel Shakti with Tamo-gun. Apart from the three, the
fourth kind of Vishnu, influenced by Shri Shakti and Bhoo
Shakti, assumes the form of Shankarshan with Tamo-gun, of
Pradyumna with Rajo-gun, and of Anirudh with Sattva-gun.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P002_B007_01

- 身份：正文
- PDF 页：2
- 偈颂：16-17
- 标题路径：CHAPTER 1 The Creation
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Creation · Sloka 16-17 [present] · PDF page 2

16-17. Mahattatwa, Ahamkar, and Ahamkar Murti, and Brahma,
are born from Shankarshan, Pradyumna, and Anirudh
respectively. All these three forms are endowed with all
the three gunas, with predominance of the Gun due to their
origin.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P003_B001_01

- 身份：正文
- PDF 页：3
- 偈颂：18-19
- 标题路径：CHAPTER 1 The Creation
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Creation · Sloka 18-19 [present] · PDF page 3

18-19. Ahamkar is of three classes, i.e. with Sattvic,
Rajasic, and Tamasic dispositions. Divine class, sensory
organs and the five primordial compounds (space, air, fire,
water, and earth) are respectively from the said three
Ahamkaras.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P003_B002_01

- 身份：正文
- PDF 页：3
- 偈颂：20
- 标题路径：CHAPTER 1 The Creation
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Creation · Sloka 20 [present] · PDF page 3

20. Lord Vishnu,coupled with Shri Shakti rules over the
three worlds. Coupled with Bhoo Shakti, He is Brahma
causing the Universe. Coupled with Neel Shakti, He is
Shiva, destroying the Universe.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P003_B003_01

- 身份：正文
- PDF 页：3
- 偈颂：21-24
- 标题路径：CHAPTER 1 The Creation
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Creation · Sloka 21-24 [present] · PDF page 3

21-24. The Lord is in all beings and the entire Universe is
in Him. All beings contain both Jivatma and Paramatmamshas.
Some have predominance of the former, while yet some have
the latter in predominance. Paramatmamsh is predominant in
the grahas, viz. Surya, etc., and Brahma, Shiva and others.
Their powers or consorts too have predominance of
Paramatmamsh. Others have more of Jivatmamsh.
