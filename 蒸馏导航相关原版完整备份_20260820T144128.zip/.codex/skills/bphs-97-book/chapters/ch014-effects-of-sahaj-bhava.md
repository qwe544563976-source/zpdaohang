# 第 14 章：Effects of Sahaj Bhava

- 来源：BPHS 97 章版
- 原始卡片：9 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P037_B002_01

- 身份：正文
- PDF 页：37
- 偈颂：1
- 标题路径：CHAPTER 14 Effects of Sahaj Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Sahaj Bhava · Sloka 1 [present] · PDF page 37

1. O Brahmin, I now tell you about Sahaj Bhava. Should
Sahaj Bhava be yuti with or drishtied by a benefic, the
native will be endowed with co-born and be courageous.
~!3DL3*!3D3+L3I3*3I3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P037_B003_01

- 身份：正文
- PDF 页：37
- 偈颂：2
- 标题路径：CHAPTER 14 Effects of Sahaj Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Sahaj Bhava · Sloka 2 [present] · PDF page 37

2. If Sahaj's lord along with Mangal drishtis Sahaj Bhava
the native will enjoy good results due to Sahaj Bhava.
Alternatively, these two grahas may be in Sahaj itself.
~L3Ym*3YL3+L3Iz*3YL3~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P037_B004_01

- 身份：正文
- PDF 页：37
- 偈颂：3
- 标题路径：CHAPTER 14 Effects of Sahaj Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Sahaj Bhava · Sloka 3 [present] · PDF page 37

3. Destruction at once of co-born will come to pass if the
said 2 grahas are together with a malefic or in a rashi
owned by a malefic.
~L3i.F+.FI3**-L3i.M*-.MI3*-L3IRM~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P037_B005_01

- 身份：正文
- PDF 页：37
- 偈颂：4-4 1/2
- 标题路径：CHAPTER 14 Effects of Sahaj Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Sahaj Bhava · Sloka 4-4 1/2 [present] · PDF page 37

4-4 1/2. Female and Male Co-born: If Sahaj's lord is a
female grah or if Sahaj Bhava be occupied by female grahas,
one will have sisters born after him.
~L3i.M+.MI3**-L3i.F*-.FI3*-L3IRF~
Similarly, male grahas and male rashis denote younger
brothers.
~L3i.M+.MI3+L3IRM**L3i.F+.FI3*L3IRF~
Should it be of mixed nature, co-born of both sexes will be
obtained. These effects be declared after assessing the
strength and weakness of the concerned.
~L3I8*3I8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P037_B006_01

- 身份：正文
- PDF 页：37
- 偈颂：5-6
- 标题路径：CHAPTER 14 Effects of Sahaj Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Sahaj Bhava · Sloka 5-6 [present] · PDF page 37

5-6. Should Sahaj's lord and Mangal be together in Randhr
Bhava, destruction of co-born will result.
~L3K+3K+L3T+3T+L3K+L3E+3E+@f3+@fL3~
Happiness in this respect will come to pass if Mangal or
Sahaj's lord is in an angle or in a trine or in exaltation,
or friendly divisions.
~4I3*L3Y2*3Y7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P037_B007_01

- 身份：正文
- PDF 页：37
- 偈颂：7-11
- 标题路径：CHAPTER 14 Effects of Sahaj Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Sahaj Bhava · Sloka 7-11 [present] · PDF page 37

7-11. Number of Brothers and Sisters: If Buddh is in Sahaj
Bhava while Sahaj's lord and Chandr are together as the
indicator (Mangal) joins Shani, the effects are: there
occurred the birth of an elder sister and there will be
younger brothers. Furthermore, the third brother will die.
~3Y8*L3d~n
Should Mangal be yuti with Rahu, while Sahaj's lord is in
his debilitation rashi, there will be loss of younger
brothers, and/or sisters, while three elder brothers and/or
sisters were attained by the native.
~L3K*3E*3Y5*3T~n
If Sahaj's lord is in an angle while the significator
(Mangal) is exalted in a trine and be yuti with Guru, 12
will be the number of total co-born. Out of these two
elders and the 3rd,  the 7th, the 9th, and the 12th of the
younger co-born will be shortlived, while six of the said
twelve will be longlived.
~L12Y3*3Y5*2I3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P038_B001_01

- 身份：正文
- PDF 页：38
- 偈颂：12-13
- 标题路径：CHAPTER 14 Effects of Sahaj Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Sahaj Bhava · Sloka 12-13 [present] · PDF page 38

12-13. There will be 1 co-born if Vyaya's lord (some texts
read as Labh's lord) joins Mangal and Guru, while Sahaj
Bhava is occupied by Chandr. If Chandr is lonely placed in
Sahaj Bhava with drishti on male grahas, there will be
younger brothers, while the drishti of Shukr denotes
younger sisters.
~1I3~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P038_B002_01

- 身份：正文
- PDF 页：38
- 偈颂：14
- 标题路径：CHAPTER 14 Effects of Sahaj Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Sahaj Bhava · Sloka 14 [present] · PDF page 38

14. Adverse Grahas: Surya in Sahaj Bhava will destroy the
preborn.
~7I3~n
The afterborn will be destroyed if Shani is found in Sahaj
Bhava.
~3I3~n
In the same situation, Mangal will destroy both the preborn
and later born.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P038_B003_01

- 身份：正文
- PDF 页：38
- 偈颂：15
- 标题路径：CHAPTER 14 Effects of Sahaj Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Sahaj Bhava · Sloka 15 [present] · PDF page 38

15. After estimating the strength and weakness of such
yogas, the effects related to brothers and sisters be
announced.
