# 第 17 章：Effects of Ari Bhava

- 来源：BPHS 97 章版
- 原始卡片：12 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P044_B002_01

- 身份：正文
- PDF 页：44
- 偈颂：1
- 标题路径：CHAPTER 17 Effects of Ari Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Ari Bhava · Sloka 1 [present] · PDF page 44

1. O Brahmin, following are the effects produced by Ari
Bhava, relating to diseases, ulcers, etc.. Listen to this
attentively.
~L6I6+L6I1+L6I8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P044_B003_01

- 身份：正文
- PDF 页：44
- 偈颂：2
- 标题路径：CHAPTER 17 Effects of Ari Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Ari Bhava · Sloka 2 [present] · PDF page 44

2. Ulcers / Bruises: Should Ari's lord be in Ari itself, or
in Lagn, or Randhr, there will be ulcers or bruises on the
body. The rashi becoming Ari Bhava will lead to the
knowledge of the concerned limb.
~L4I6+L4YL6+L4I8+L5I6+L5YL6+L5I8+L9I6+L9YL6+L9I8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P044_B004_01

- 身份：正文
- PDF 页：44
- 偈颂：3-5
- 标题路径：CHAPTER 17 Effects of Ari Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Ari Bhava · Sloka 3-5 [present] · PDF page 44

3-5. Relatives Affected: The Karak of a relative or the
lord of such a bhava joining Ari's lord, or being in Ari,
or Randhr Bhava, indicates ulcers/bruises to such a
relative like father. Surya with such lordship and in such
a bhava denotes such affectation of head, Chandr denotes
such affection of the face, Mangal denotes such affection
of the neck, Buddh denotes such affection of the navel,
Guru denotes such affection of the nose, Shukr denotes such
affection of the eyes, Shani denotes such affection of the
feet,  and the Rahu and Ketu denote such affection of the
abdomen.
~L6i1+1YL6+1I6+1I8~
The relatives signified by grahas and bhavas are denoted in
ch. 32, infra. The second clue is to know the possible
affliction, to the native, of a particular area in the
body. If Surya is the lord of Ari Bhava, or is with Ari's
lord, or is in Ari, or Randhr Bhava, the native will be apt
to incur affliction of head, and so on and so forth.
~8I6+8I8+9I6+9I8~
As regards, Rahu and Ketu, they do not own any bhava in the
normal context. Hence, their position in Ari or Randhr
Bhava, or the situation that they are joining Ari's lord
need only be considered. Rahu or Ketu in the Ari or Randhr
Bhava will cause stomachial disorders.
~L1IR1*4DL1+L1IR8*4DL1+L1IR3*4DL1+L1IR6*4DL1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P044_B005_01

- 身份：正文
- PDF 页：44
- 偈颂：6
- 标题路径：CHAPTER 17 Effects of Ari Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Ari Bhava · Sloka 6 [present] · PDF page 44

6. Facial Diseases: Should Lagn's lord be in a rashi of
Mangal or of Buddh, and has a drishti on Buddh, there will
be diseases of the face.
~L1i3*3Y2*3Y8*3Y7+L1i4*4Y2*4Y8*4Y7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P044_B006_01

- 身份：正文
- PDF 页：44
- 偈颂：7-8 1/2
- 标题路径：CHAPTER 17 Effects of Ari Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Ari Bhava · Sloka 7-8 1/2 [present] · PDF page 44

7-8 1/2. Leprosy: Mangal or Buddh having ownership of the
ascending rashi and joining Chandr, Rahu, and Shani, will
cause leprosy.
~2I1*2Y8*-2IR4~
If Chandr is in Lagn, which is not however Cancer, and be
with Rahu, there will occur white leprosy.
~2I1*2Y7*-2IR4~
Shani in place of Rahu will cause black leprosy,
~2I1*2Y3*-2IR4~
while Mangal similarly will afflict one with
blood-leprosy.
~L6I1*L8I1*1I1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P045_B001_01

- 身份：正文
- PDF 页：45
- 偈颂：9-12 1/2
- 标题路径：CHAPTER 17 Effects of Ari Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Ari Bhava · Sloka 9-12 1/2 [present] · PDF page 45

9-12 1/2. Diseases in General: When Lagn is occupied by the
lords of Ari and Randhr Bhava along with Surya, the native
will be afflicted by fever and tumours.
~L6I1*L8I1*3I1~
Mangal replacing Surya will cause swelling and hardening of
the blood vessels and wounds and hits by weapons.
~L6I1*L8I1*4I1~
Buddh so featuring will bring in billious diseases,
~L6I1*L8I1*5I1~
while Guru in similar case will destroy any disease.
~L6I1*L8I1*6I1~
Similarly, Shukr will cause diseases through females;
~L6I1*L8I1*7I1~
Shani windy diseases;
~L6I1*L8I1*8I1~
Rahu danger through low caste-men; and
~L6I1*L8I1*9I1~
Ketu navel diseases.
~L6I1*L8I1*2I1~
Chandr in yuti with the lords or Ari and Randhr Bhava will
inflict dangers through water and phlegmatic disorders.
Similar estimates be made from the respective significators
and bhavas for relatives like father.
(Replacing Lagn with a certain bhava, these afflictions to
the concerned relatives be predicted).
~L6I3*L8I3*2I3~
For example, if Ari's and Randhr's lords join Chandr in
Sahaj Bhava, danger to co-born by drowning, lung disorders
etc. be known.
~L6I11*L8I11*6I11~
Should Shukr join Ari's and Randhr's lords in Labh Bhava,
an elder brother of the native will incur venereal
diseases.
~7Y8*L6Ym*mI6~
13-19 1/2 TIMING OF ILLNESS: The native will be afflicted
by illness throughout life if Shani is with Rahu while Ari
lord and 6th Bhava are yuti with malefics.
~3I6*L6I8~
One will suffer from (severe) fever at the age of 6 and at
the age of 12 if Mangal is in Ari while Ari lord is in
Randhr.
~2IR9*5I6+2IR12*5I6~n
If the Chandr is in Dhanu/Meen while Guru is in Ari from
Lagn, one will suffer from leprosy at the age of 19 and 22.
~8I6*L1I8*3K~n
If Rahu is in Ari, Lagna lord is in Randhr and Mandi is in
an angle, consumption will trouble the native at the age
of 26.
~L6lL12~n
Spleenary disorders will be experienced
at the age of 29 and 30 if the lords of 6th and 12th are in
exchange of their Rashis.
~7I6*7Y2~n
Shani and Chandr together in Ari will infflct blood-leprosy
at the age of 45.
~7Y1+7Y2+7Y3**L1I1~n
If Shani is with an inimical planet while Lagn lord is in
Lagn itself windy disorders (like rheumatism) will trouble
the native at the age of 59.
~2YL6*L8I6*L12I1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P045_B001_02

- 身份：正文
- PDF 页：45
- 偈颂：9-12 1/2
- 标题路径：CHAPTER 17 Effects of Ari Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Ari Bhava · Sloka 9-12 1/2 [present] · PDF page 45

9-12 1/2. Diseases in General: When Lagn is occupied by the
lords of Ari and Randhr Bhava along with Surya, the native
will be afflicted by fever and tumours.
~L6I1*L8I1*3I1~
Mangal replacing Surya will cause swelling and hardening of
the blood vessels and wounds and hits by weapons.
~L6I1*L8I1*4I1~
Buddh so featuring will bring in billious diseases,
~L6I1*L8I1*5I1~
while Guru in similar case will destroy any disease.
~L6I1*L8I1*6I1~
Similarly, Shukr will cause diseases through females;
~L6I1*L8I1*7I1~
Shani windy diseases;
~L6I1*L8I1*8I1~
Rahu danger through low caste-men; and
~L6I1*L8I1*9I1~
Ketu navel diseases.
~L6I1*L8I1*2I1~
Chandr in yuti with the lords or Ari and Randhr Bhava will
inflict dangers through water and phlegmatic disorders.
Similar estimates be made from the respective significators
and bhavas for relatives like father.
(Replacing Lagn with a certain bhava, these afflictions to
the concerned relatives be predicted).
~L6I3*L8I3*2I3~
For example, if Ari's and Randhr's lords join Chandr in
Sahaj Bhava, danger to co-born by drowning, lung disorders
etc. be known.
~L6I11*L8I11*6I11~
Should Shukr join Ari's and Randhr's lords in Labh Bhava,
an elder brother of the native will incur venereal
diseases.
~7Y8*L6Ym*mI6~
13-19 1/2 TIMING OF ILLNESS: The native will be afflicted
by illness throughout life if Shani is with Rahu while Ari
lord and 6th Bhava are yuti with malefics.
~3I6*L6I8~
One will suffer from (severe) fever at the age of 6 and at
the age of 12 if Mangal is in Ari while Ari lord is in
Randhr.
~2IR9*5I6+2IR12*5I6~n
If the Chandr is in Dhanu/Meen while Guru is in Ari from
Lagn, one will suffer from leprosy at the age of 19 and 22.
~8I6*L1I8*3K~n
If Rahu is in Ari, Lagna lord is in Randhr and Mandi is in
an angle, consumption will trouble the native at the age
of 26.
~L6lL12~n
Spleenary disorders will be experienced
at the age of 29 and 30 if the lords of 6th and 12th are in
exchange of their Rashis.
~7I6*7Y2~n
Shani and Chandr together in Ari will infflct blood-leprosy
at the age of 45.
~7Y1+7Y2+7Y3**L1I1~n
If Shani is with an inimical planet while Lagn lord is in
Lagn itself windy disorders (like rheumatism) will trouble
the native at the age of 59.
~2YL6*L8I6*L12I1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P046_B001_01

- 身份：正文
- PDF 页：46
- 偈颂：20-22
- 标题路径：CHAPTER 17 Effects of Ari Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Ari Bhava · Sloka 20-22 [present] · PDF page 46

20-22. UNFORTUNATE YEARS: Should Chandr be yuti with Ari
lord while the 8th lord is in Ari and the l2th lord is in
Lagn, the native will be troubled by animals at the age of
eight.
~8I6*7I1~n
O Brahmin, if Rahu is in Ari while Shani is in Randhr from
the said Rahu, the child will have danger through fire at
the age 1 and 2 while in Sahaj year birds will bring some
evils.
~1I6*2I5+1I8*2I7~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P046_B002_01

- 身份：正文
- PDF 页：46
- 偈颂：23-25
- 标题路径：CHAPTER 17 Effects of Ari Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Ari Bhava · Sloka 23-25 [present] · PDF page 46

23-25. UNFORTUNATE YEARS (continued): Danger through water
will have to be feared during Putr and Dharm years if Surya
is in Ari or Randhr while Chandr is in Vyaya from the said
Surya.
~7I8*3I7~n
Shani in Randhr as Mangal is in Yuvati all cause small-pox,
in Karm year and 30th year of age.
~L8Y8*L8I2+L8Y8*L8IN8*L8I5+L8Y8*L8IN8*L8I12+L8Y8*L8IN8*L8I4~n
If 8th lord joins Rahu in an angle/trine from Randhr Bhava
and be in Randhr in Navamsa, the subject will be troubled
by swelling of blood vessels, urinary disorders etc. during
the 18th year and the 22nd year.
~L11lL6~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P046_B003_01

- 身份：正文
- PDF 页：46
- 偈颂：26
- 标题路径：CHAPTER 17 Effects of Ari Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Ari Bhava · Sloka 26 [present] · PDF page 46

26. LOSS THROUGH ENEMIES: Loss of wealth will come to pass
during the 31st year if Labh and 6th lords exchange their
Rasis.
~L5I6*L6Y5*L12Y1~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P046_B004_01

- 身份：正文
- PDF 页：46
- 偈颂：27
- 标题路径：CHAPTER 17 Effects of Ari Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Ari Bhava · Sloka 27 [present] · PDF page 46

27. INIMICAL SONS: One's own sons will be his enemies if
Putr lord is in Ari while Ari Lord is with Guru.
Simultaneously Vyaya lord should be in Lagn..
~L1lL6~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P046_B005_01

- 身份：正文
- PDF 页：46
- 偈颂：28
- 标题路径：CHAPTER 17 Effects of Ari Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Ari Bhava · Sloka 28 [present] · PDF page 46

28. FEAR FROM DOGS: There will be fear from dogs during the
10th and 19th year if the Lagna lord and the 6th lord are
in exchange.
