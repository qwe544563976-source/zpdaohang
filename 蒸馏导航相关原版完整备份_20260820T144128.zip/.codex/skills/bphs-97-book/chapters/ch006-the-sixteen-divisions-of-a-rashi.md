# 第 6 章：The Sixteen Divisions of a Rashi

- 来源：BPHS 97 章版
- 原始卡片：20 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P018_B002_01

- 身份：正文
- PDF 页：18
- 偈颂：1
- 标题路径：CHAPTER 6 The Sixteen Divisions of a Rashi
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Sixteen Divisions of a Rashi · Sloka 1 [present] · PDF page 18

1. O Maharishi Parashar, I have known from you about the
grahas, rashis, and their descriptions. I desire to know
the details of various divisions of a rashi, will you
please narrate.
{varnam}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P018_B003_01

- 身份：正文
- PDF 页：18
- 偈颂：2-4
- 标题路径：CHAPTER 6 The Sixteen Divisions of a Rashi
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Sixteen Divisions of a Rashi · Sloka 2-4 [present] · PDF page 18

2-4. Names of the 16 Vargas: Lord Brahma has described 16
kinds of Vargas (Divisions) for each rashi. Listen to
those. The names are: Rashi, Hora, Dreshkan, Chaturthamsh,
Saptamsh, Navamsh, Dashamsh, Dvadashamsh, Shodashamsh,
Vimshamsh, Chaturvimshamsh, Saptavimshamsh, Trimshamsh,
Khavedamsh, Akshavedamsh, and Shashtiamsh.
{amshhor}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P018_B004_01

- 身份：正文
- PDF 页：18
- 偈颂：5-6
- 标题路径：CHAPTER 6 The Sixteen Divisions of a Rashi
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Sixteen Divisions of a Rashi · Sloka 5-6 [present] · PDF page 18

5-6. Rashi and Hora: The rashi owned by a grah is called
its Kshetra. The first half of an odd rashi is the Hora
ruled by Surya. While the second half is the Hora of
Chandr. The reverse is true in the case of an even rashi.
Half of a rashi is called Hora. These are totally 24
counted from Mesh and repeated twice (at the rate of 12) in
the whole of the zodiac.
{amshdec}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P018_B005_01

- 身份：正文
- PDF 页：18
- 偈颂：7-8
- 标题路径：CHAPTER 6 The Sixteen Divisions of a Rashi
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Sixteen Divisions of a Rashi · Sloka 7-8 [present] · PDF page 18

7-8. Dreshkan: One third of a rashi is  called Dreshkan
(Dreshkan). These are totally 36, counted from Mesh (to
Meen), repeating thrice at the rate of 12 per round. The
1st,  5th, and the 9th rashis from a rashi are its three
Dreshkanas, and  are respectively lorded by Narada,
Agasthya and Durvash.
{amshcha}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P018_B006_01

- 身份：正文
- PDF 页：18
- 偈颂：9
- 标题路径：CHAPTER 6 The Sixteen Divisions of a Rashi
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Sixteen Divisions of a Rashi · Sloka 9 [present] · PDF page 18

9. Chaturthamsh: The lords of the 4 Kendras from a rashi
are the rulers of respective Chaturthamsh of a rashi
commencing from Mesh. Each Chaturthamsh is one fourth of a
rashi. The deities respectively are Sanak, Sanand, Kumar,
and Sanatan.
{amshsap}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P018_B007_01

- 身份：正文
- PDF 页：18
- 偈颂：10-11
- 标题路径：CHAPTER 6 The Sixteen Divisions of a Rashi
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Sixteen Divisions of a Rashi · Sloka 10-11 [present] · PDF page 18

10-11. Saptamsh: The Saptamsh (one seventh of a rashi)
counting commences from the same rashi in the case of an
odd rashi. It is from the seventh rashi there of while an
even rashi is considered. The names of the seven divisions
in odd rashis are : Kshaar, Ksheer, Dadhi, Ghrith, Ikshu,
Ras, Madhya, and Suddh Jal. These designations are reversed
for an even rashi.
{amshnav}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P018_B008_01

- 身份：正文
- PDF 页：18
- 偈颂：12
- 标题路径：CHAPTER 6 The Sixteen Divisions of a Rashi
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Sixteen Divisions of a Rashi · Sloka 12 [present] · PDF page 18

12. Navamsh: The Navamsh calculation are for a movable
rashi from there itself, for a fixed rashi from the 9th
thereof and for a dual rashi from the 5th thereof. They go
by designations Deva (divine), Manushya (human), and
Rakshasa (devilish) in a successive and repetitive order
for a movable rashi. (Manushya, Rakshasa and Deva are the
order for a fixed rashi while Rakshasa, Manushya, and Deva
are a dual rashi's order.)
{amshdas}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P019_B001_01

- 身份：正文
- PDF 页：19
- 偈颂：13-14
- 标题路径：CHAPTER 6 The Sixteen Divisions of a Rashi
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Sixteen Divisions of a Rashi · Sloka 13-14 [present] · PDF page 19

13-14. Dashamsh: Starting from the same rashi for an odd
rashi and from the 9th with reference to an even rashi, the
10 Dashamshas each of 3 degrees are reckoned. These are
presided over by  the ten rulers of the cardinal
directions, viz. Indra, Agni, Yama,  Rakshasa, Varuna,
Vayu, Kuber, Isan, Brahma, and Ananth in case of an odd
rashi. It is in the reverse order that these presiding
deities are reckoned when an even rashi is given.
{amshdva}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P019_B002_01

- 身份：正文
- PDF 页：19
- 偈颂：15
- 标题路径：CHAPTER 6 The Sixteen Divisions of a Rashi
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Sixteen Divisions of a Rashi · Sloka 15 [present] · PDF page 19

15. Dvadashamsh: The reckoning of the Dvadashamsh  (one
twelfth of a rashi or 2 1/2 degrees each) commences from
the same rashi. In each rashi the presidentship repeats
thrice in the order of Ganesh, Ashvini, Kumar, Yama, and
Sarpa for the 12 Dvadashamshas.
{amshsho}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P019_B003_01

- 身份：正文
- PDF 页：19
- 偈颂：16
- 标题路径：CHAPTER 6 The Sixteen Divisions of a Rashi
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Sixteen Divisions of a Rashi · Sloka 16 [present] · PDF page 19

16. Shodashamsh (or Kalamsh): Starting from Mesh for a
movable rashi, from Simh  for a fixed rashi and from Dhanu
for a dual rashi, the 16 Shodashamshas (16th part of a
rashi i.e. of 152' 30") are regularly distributed. The
presiding deities of these repeat in the order Brahma,
Vishnu, Shiva, and Surya four times in the case of an odd
rashi. It is reverse in the case of an even rashi that
these ruling deities are understood.
{amshvim}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P019_B004_01

- 身份：正文
- PDF 页：19
- 偈颂：17-21
- 标题路径：CHAPTER 6 The Sixteen Divisions of a Rashi
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Sixteen Divisions of a Rashi · Sloka 17-21 [present] · PDF page 19

17-21. Vimshamsh:  From Mesh for a movable rashi, from
Dhanu from a fixed rashi and from Simh for a common rashi:
this is how the calculations of Vimshamshas ( 1/20th of a
rashi or 1 degree 30' each) are to commerce. The presiding
deities of the 20 Vimshamshas are in an odd rashi are
respectively: Kali, Gauri, Jaya, Lakshmi, Vijaya, Vimal,
Sati, Tara, Jvalamukhi, Sveta, Lalita, Bagalamukhi,
Pratyangir, Shachi, Raudri, Bhavani, Varad, Jaya, Tripura,
and Sumukhi. In an even rashi these 20 deities respectively
are: Daya, Megha, Chinnasi, Pisachini, Dhumavathi; Matangi,
Bal, Bhadr, Arun, Anal, Pingal, Chuchchuk, Ghora, Vaarahi,
Vaishnavi, Sita, Bhuvanesvari, Bhairavi, Mangal, and
Aparajit.
{amshsid}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P019_B005_01

- 身份：正文
- PDF 页：19
- 偈颂：22-23
- 标题路径：CHAPTER 6 The Sixteen Divisions of a Rashi
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Sixteen Divisions of a Rashi · Sloka 22-23 [present] · PDF page 19

22-23. Chaturvimshamsh: The Chaturvimshamsh (1/24th part of
a rashi or 115 each) distribution commences from Simh and
Kark respectively for an odd and an even rashi. In the case
of an odd rashi the ruling deities repeat twice in the
order of Skand, Parusdhar, Anal, Vishwakarma, Bhag, Mitr,
Maya, Antaka, Vrisha-dwaja, Govinda Madan, and Bhima.
Reverse these from Bhima (to Skand) twice to know the
deities for the Chaturvimshamsh in an even rashi.
{amshbha}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P020_B001_01

- 身份：正文
- PDF 页：20
- 偈颂：24-26
- 标题路径：CHAPTER 6 The Sixteen Divisions of a Rashi
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Sixteen Divisions of a Rashi · Sloka 24-26 [present] · PDF page 20

24-26. Saptavimshamsh (Nakshatramsh or Bhamsh): The
Saptavimshamsh lords are respectively the presiding deities
of the 27 Nakshatras as under: Dastra (Ashvini Kumar),
Yama, Agni, Brahma, Chandr, Isa, Adhiti, Jiva, Ahi, Pitar,
Bhag, Aryama, Surya, Tvasht, Marut, Chakragni, Mitr,
Vasava, Rakshasa, Varuna, Vishwadeva, Govinda, Vasu,
Varuna, Ajap, Ahirbuddhnya, and Pushya. These are for an
odd rashis. Count these deities in a reverse order for an
even rashi. The Saptavimshamsh distribution commences from
Mesh and other movable rashis for all the 12 rashis.
{amshtri}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P020_B002_01

- 身份：正文
- PDF 页：20
- 偈颂：27-28
- 标题路径：CHAPTER 6 The Sixteen Divisions of a Rashi
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Sixteen Divisions of a Rashi · Sloka 27-28 [present] · PDF page 20

27-28. Trimshamsh: The Trimshamsh lords for an odd rashi
are: Mangal, Shani, Guru, Buddh, and Shukr. Each of them in
order rules 5, 5, 8, 7, and 5 degrees, The deities ruling
over the Trimshamshas are respectively, Agni, Vayu, Indra,
Kuber, and Varuna. Tn the case of an even rashi, the
quantum of Trimshamsh, grah lordship and deities get
reversed.
{amshvar}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P020_B003_01

- 身份：正文
- PDF 页：20
- 偈颂：29-30
- 标题路径：CHAPTER 6 The Sixteen Divisions of a Rashi
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Sixteen Divisions of a Rashi · Sloka 29-30 [present] · PDF page 20

29-30. Khavedamsh (or Chatvarimshamsh): (1/40th part of a
rashi): For odd rashis count from Mesh and for an even
rashi from Tula in respect of Khavedamshas (each of 45' of
arc). Vishnu, Chandr, Marichi, Tvasht, Dhata, Shiva, Ravi,
Yama, Yaksh, Gandharv, Kaal, and Varuna repeat successively
as presiding deities in the same order for all rashis.
{amshaks}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P020_B004_01

- 身份：正文
- PDF 页：20
- 偈颂：31-32
- 标题路径：CHAPTER 6 The Sixteen Divisions of a Rashi
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Sixteen Divisions of a Rashi · Sloka 31-32 [present] · PDF page 20

31-32. Akshavedamsh: (1/45th part of a rashi): Mesh, Simh,
and Dhanu are the rashis from which the distributions
respectively commence for movable, immovable, and common
rashis. In movable rashis, Brahma, Shiva, and Vishnu; in
immovable rashis Shiva, Vishnu, and Brahma and in common
rashis Vishnu, Brahma, and Shiva repeat 15 times the
presidentship over these Akshavedamshas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P021_B001_01

- 身份：正文
- PDF 页：21
- 偈颂：33-41
- 标题路径：CHAPTER 6 The Sixteen Divisions of a Rashi
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Sixteen Divisions of a Rashi · Sloka 33-41 [present] · PDF page 21

33-41. Shashtiamsh: (1/60th part of a rashi or half a
degree each): To calculate the Shashtiamsh lord, ignore the
rashi position of a grah and take the degrees, etc., it
traversed in that rashi. Multiply that figure by 2 and
divide the degrees by 12. Add 1 to the remainder which will
indicate the rashi in which the Shashtiamsh falls. The lord
of that rashi is the grah ruling the said Shashtiamsh. In
odd rashis, the names of Shashtiamshas are:1.Ghora,
2.Rakshasa, 3.Deva, 4.Kuber, 5.Yaksh, 6.Kindar, 7.Bhrasht,
8.Kulaghna, 9.Garal, 10.Vahni, 11.Maya, 12.Purishak,
13.Apampathi, 14.Marutwan, 15.Kaal, 16.Sarpa, 17.Amrit.
18.Indu, 19.Mridu, 20. Komal, 21.Heramba, 22.Brahma,
23.Vishnu, 24.Maheshwara, 25.Deva, 26.Ardr, 27.Kalinas,
28.Kshitees, 29.Kamalakar, 30.Gulik, 31.Mrityu, 32.Kaal,
33.Davagni, 34.Ghora,      35.Yama, 36 Kantak, 37.Suddh,
38.Amrit, 39.Purnachandr, 40.Vishadagdha, 41.Kulanas,
42.Vamshakshaya, 43.Utpat, 44.Kaal, 45.Saumya, 46.Komal,
47.Sheetal, 48.Karaladamshtr, 49.Chandramukhi, 50.Praveen,
51.Kaalpavak, 52 Dhannayudh, 53.Nirmal, 54.Saumya, 55.Krur,
56.Atisheetal, 57.Amrit, 58.Payodhi, 59.Brahman,
60.Chandrarekha (Indurekha).
The reverse is the order for even rashis in so much as
these names are cased. Grahas in benefic Shashtiamshas
produce auspicious, while the opposite is true in case of
grahas in malefic Shashtiamshas.
{varclas}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P021_B001_02

- 身份：正文
- PDF 页：21
- 偈颂：33-41
- 标题路径：CHAPTER 6 The Sixteen Divisions of a Rashi
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Sixteen Divisions of a Rashi · Sloka 33-41 [present] · PDF page 21

33-41. Shashtiamsh: (1/60th part of a rashi or half a
degree each): To calculate the Shashtiamsh lord, ignore the
rashi position of a grah and take the degrees, etc., it
traversed in that rashi. Multiply that figure by 2 and
divide the degrees by 12. Add 1 to the remainder which will
indicate the rashi in which the Shashtiamsh falls. The lord
of that rashi is the grah ruling the said Shashtiamsh. In
odd rashis, the names of Shashtiamshas are:1.Ghora,
2.Rakshasa, 3.Deva, 4.Kuber, 5.Yaksh, 6.Kindar, 7.Bhrasht,
8.Kulaghna, 9.Garal, 10.Vahni, 11.Maya, 12.Purishak,
13.Apampathi, 14.Marutwan, 15.Kaal, 16.Sarpa, 17.Amrit.
18.Indu, 19.Mridu, 20. Komal, 21.Heramba, 22.Brahma,
23.Vishnu, 24.Maheshwara, 25.Deva, 26.Ardr, 27.Kalinas,
28.Kshitees, 29.Kamalakar, 30.Gulik, 31.Mrityu, 32.Kaal,
33.Davagni, 34.Ghora,      35.Yama, 36 Kantak, 37.Suddh,
38.Amrit, 39.Purnachandr, 40.Vishadagdha, 41.Kulanas,
42.Vamshakshaya, 43.Utpat, 44.Kaal, 45.Saumya, 46.Komal,
47.Sheetal, 48.Karaladamshtr, 49.Chandramukhi, 50.Praveen,
51.Kaalpavak, 52 Dhannayudh, 53.Nirmal, 54.Saumya, 55.Krur,
56.Atisheetal, 57.Amrit, 58.Payodhi, 59.Brahman,
60.Chandrarekha (Indurekha).
The reverse is the order for even rashis in so much as
these names are cased. Grahas in benefic Shashtiamshas
produce auspicious, while the opposite is true in case of
grahas in malefic Shashtiamshas.
{varclas}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P021_B002_01

- 身份：正文
- PDF 页：21
- 偈颂：42-53
- 标题路径：CHAPTER 6 The Sixteen Divisions of a Rashi
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Sixteen Divisions of a Rashi · Sloka 42-53 [present] · PDF page 21

42-53. Varg Classification: Maitreya, explained now are the
sum effects of classifications of different divisions (or
vargas so far narrated). These are four kinds, viz. Shad
Varg (6 divisions considered), Sapth Varg (7 divisions
considered), Dasha Varg (10 divisions considered) and
Shodasha Varg (all the 16 divisions considered). In the
Shadvarg classification, the varg designations are Kimshuk,
Vyanjan, Chamar, Chatr, and Kundal according to a grah
being in 2 to 6 combinations of good vargas. Next is the
Sapth varg in which these classifications continue in the
same manner up to six combinations of good vargas, the 7th
additional varg getting classified as Mukut. In the Dasha
Varg scheme, the designations commence from Parijata etc.
such as 2 good Vargas-Parijatha, 3. Uttama, 4. Gopur,  5.
Simhsan, 6. Paravata, 7. Devaloka, 8. Brahmaloka, 9.
Sakravahana, and 10. Vargas-Shridham. In the Shodasha Varg
scheme the combinations of vargas go with designations
thus: two good Vargas-Bhedak, 3. Kusum, 4. Nagapushpa, 5.
Kanduk, 6. Kerala, 7. Kalpa Vriksha,  8. Chandan Vana, 9.
Purnachandr, 10. Uchchaisrava, 11. Dhanvantari,
12.Suryakant,   13. Vidrum,  14. Chakra-simhasan, 15.
Golok,  and 16. Vargas-Shri Vallabh. In these divisions,
the divisions falling in the grah's exaltation rashi,
Mooltrikon rashi, own rashi, and the rashis owned by the
lord of a Kendra from the Arudha Lagn are all to be
considered (as good vargas). The divisions of a combust
grah, defeated grah, weak grah and a grah in bad Avasthas
like Sayan be all ignored to be auspicious, for these
destroy the good Yogas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P021_B002_02

- 身份：正文
- PDF 页：21
- 偈颂：42-53
- 标题路径：CHAPTER 6 The Sixteen Divisions of a Rashi
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: The Sixteen Divisions of a Rashi · Sloka 42-53 [present] · PDF page 21

42-53. Varg Classification: Maitreya, explained now are the
sum effects of classifications of different divisions (or
vargas so far narrated). These are four kinds, viz. Shad
Varg (6 divisions considered), Sapth Varg (7 divisions
considered), Dasha Varg (10 divisions considered) and
Shodasha Varg (all the 16 divisions considered). In the
Shadvarg classification, the varg designations are Kimshuk,
Vyanjan, Chamar, Chatr, and Kundal according to a grah
being in 2 to 6 combinations of good vargas. Next is the
Sapth varg in which these classifications continue in the
same manner up to six combinations of good vargas, the 7th
additional varg getting classified as Mukut. In the Dasha
Varg scheme, the designations commence from Parijata etc.
such as 2 good Vargas-Parijatha, 3. Uttama, 4. Gopur,  5.
Simhsan, 6. Paravata, 7. Devaloka, 8. Brahmaloka, 9.
Sakravahana, and 10. Vargas-Shridham. In the Shodasha Varg
scheme the combinations of vargas go with designations
thus: two good Vargas-Bhedak, 3. Kusum, 4. Nagapushpa, 5.
Kanduk, 6. Kerala, 7. Kalpa Vriksha,  8. Chandan Vana, 9.
Purnachandr, 10. Uchchaisrava, 11. Dhanvantari,
12.Suryakant,   13. Vidrum,  14. Chakra-simhasan, 15.
Golok,  and 16. Vargas-Shri Vallabh. In these divisions,
the divisions falling in the grah's exaltation rashi,
Mooltrikon rashi, own rashi, and the rashis owned by the
lord of a Kendra from the Arudha Lagn are all to be
considered (as good vargas). The divisions of a combust
grah, defeated grah, weak grah and a grah in bad Avasthas
like Sayan be all ignored to be auspicious, for these
destroy the good Yogas.
