# 第 74 章：Effects of the Sudarshana Chakr

- 来源：BPHS 97 章版
- 原始卡片：14 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P318_B002_01

- 身份：正文
- PDF 页：318
- 偈颂：1-3
- 标题路径：CHAPTER 74 Effects of the Sudarshana Chakr
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sudarshana Chakr · Sloka 1-3 [present] · PDF page 318

1-3. Maharishi Parasara said to Maitreya: O Brahmin! now I
will impart to you the knowledge of a great secrecy and
superior importance which was communicated to me by Lord
Brahma himself for the benefit of the world. This is a chakr
by the name of Sudarshana through which Devajnas will be able
to predict the favourable and unfavourable results for every
year, every month, and every day from the time of birth to
the time of death of a person. Listen to this very intently.
Form of Sudarshana Chakr

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P318_B003_01

- 身份：正文
- PDF 页：318
- 偈颂：4
- 标题路径：CHAPTER 74 Effects of the Sudarshana Chakr
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sudarshana Chakr · Sloka 4 [present] · PDF page 318

4. 0 Brahmin! Take a point and from it draw three circles.
Within the circles draw 12 lines so as to provide 12 bhavas
within each circle. This is how Sudarshana Chakr is drawn.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P318_B004_01

- 身份：正文
- PDF 页：318
- 偈颂：5-6
- 标题路径：CHAPTER 74 Effects of the Sudarshana Chakr
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sudarshana Chakr · Sloka 5-6 [present] · PDF page 318

5-6. In the first circle (inner most) place the 12 bhavas
from Lagn with grahas posited there. In the circle next to
the inner most circle place the 12 bhavas from the rashi of
Chandr with the grahas in them. In the third circle place the
12 bhavas from the rashi of Surya with grahas in them. Thus,
there will be 3 rashis in each bhava of the Chakr.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P318_B005_01

- 身份：正文
- PDF 页：318
- 偈颂：7-9
- 标题路径：CHAPTER 74 Effects of the Sudarshana Chakr
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sudarshana Chakr · Sloka 7-9 [present] · PDF page 318

7-9. The significant aspect of this Chakr is that Lagn,
Chandr, and Surya represent the first bhava. The 2nd, 3rd,
etc. up to 12th from Chandr and Surya will deal with the same
subject as they do when reckoned from Lagn. Then, the results
should be assessed according to the grahas in each bhava. In
this form of rashi kundali Surya is considered auspicious in
the first bhava and inauspicious or malefic in other bhavas.
The malefics do not produce evil effects if they are in their
exaltation rashi. In this manner predictions should be made
after considering the benefic and malefic natures of the
grahas, their disposition and aspects from and on them.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P318_B006_01

- 身份：正文
- PDF 页：318
- 偈颂：10
- 标题路径：CHAPTER 74 Effects of the Sudarshana Chakr
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sudarshana Chakr · Sloka 10 [present] · PDF page 318

10. A bhava gets advancement if it is occupied or aspected by
the lord or a benefic. The bhava which is occupied or
aspected by a malefic is harmed.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P318_B007_01

- 身份：正文
- PDF 页：318
- 偈颂：11-13
- 标题路径：CHAPTER 74 Effects of the Sudarshana Chakr
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sudarshana Chakr · Sloka 11-13 [present] · PDF page 318

11-13. The effects of a bhava will be in accordance with the
grah occupying it or in accordance with the grah aspected if
no grah is in occupation of the bhava. The effects of a bhava
occupied by a benefic will be auspicious and the bhava
occupied by a malefic will be inauspicious. Effects of the
aspects will be the same. If a bhava is influenced (by
conjunction or aspect) both by benefics and malefics, the
results will depend on the majority amongst the benefics and
malefics. If the number of benefics is larger than the number
of malefics, the results will be auspicious. If reverse is
the case inauspicious or evil effects may be expected. If
there are equal number of malefics and benefics, those with
greater strength will influence the results of that bhava.
Mixed results should be declared if there be no difference in
the strength of malefics and benefics. The same would apply
to aspects.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P318_B008_01

- 身份：正文
- PDF 页：318
- 偈颂：14
- 标题路径：CHAPTER 74 Effects of the Sudarshana Chakr
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sudarshana Chakr · Sloka 14 [present] · PDF page 318

14. The effects should be declared according to its lord, if
the bhava is neither occupied nor aspected by a grah.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P319_B001_01

- 身份：正文
- PDF 页：319
- 偈颂：15-16
- 标题路径：CHAPTER 74 Effects of the Sudarshana Chakr
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sudarshana Chakr · Sloka 15-16 [present] · PDF page 319

15-16. A natural benefic loses his benevolence if he is in
more malefic vargas. Similarly, a natural malefic loses his
malevolence if he is in more benefic vargas (Saptavarg). A
grahas own rashi, his exaltation rashi, and benefic vargas
are considered auspicious. And malefics and the vargas of an
enemy and debilitated rashi, are considered inauspicious.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P319_B002_01

- 身份：正文
- PDF 页：319
- 偈颂：17
- 标题路径：CHAPTER 74 Effects of the Sudarshana Chakr
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sudarshana Chakr · Sloka 17 [present] · PDF page 319

17. The sage said that the results should be declared only
after assessing the auspiciousness and inauspiciousness of
all the bhavas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P319_B003_01

- 身份：正文
- PDF 页：319
- 偈颂：18
- 标题路径：CHAPTER 74 Effects of the Sudarshana Chakr
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sudarshana Chakr · Sloka 18 [present] · PDF page 319

18. Maitreya asked: O venerable sage! Kindly enlighten me on
one point. If all the bhavas are judged in accordance with
the Sudarshana Chakr, why many learned sages have advocated
declaration of effects from the bhavas reckoned from Lagn in
rashi kundali.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P319_B004_01

- 身份：正文
- PDF 页：319
- 偈颂：19-20
- 标题路径：CHAPTER 74 Effects of the Sudarshana Chakr
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sudarshana Chakr · Sloka 19-20 [present] · PDF page 319

19-20. The sage replied: The results should be declared in
accordance with the Sudarshana Chakr only when Surya and
Chandr being in separate rashis different from the rashi of
Lagn. If amongst Lagn, Surya, and Chandr, all the three or
two of them are in the same rashi, the judgment of effects
should be made from the rashi kundali only.
The sage said: O Brahmin! Now I will tell you about the
effects produced every year and every month by the twelve
bhavas in their Dasas and Antardasas according to Sudarshana
Chakr. Under this system every one of the twelve bhavas
beginning from the 1st, is allotted a Dasa period of one
year. Thus, every year in 12 years a bhava becomes Lagn of
the year and the remaining become 2nd, the bhava of wealth,
3rd, the bhava of brother, and so on. (This means in the 1st
year the 1st bhava will be Lagn and the 2nd year the 2nd
bhava will assume this role. Ultimately, in the 12th year,
the role of Lagn is taken over by the 12th bhava).
Every year every bhava will have Antardasa of one month. By
following the method of Lagn of the year, here also, there
will be a Lagn of the month. The first Antardasa will be of
the first bhava and then will follow for 12 months the
Antardasas of the other bhavas, every bhava assuming the role
of Lagn by turn. Every bhava gets Pratyantar Dasa of 2 1/2
days and Vidasa of 12 1/2 ghatikas. The same method is to be
adopted for judging the effects of bhavas in Pratyantar Dasas
and Vidasas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P319_B004_02

- 身份：正文
- PDF 页：319
- 偈颂：19-20
- 标题路径：CHAPTER 74 Effects of the Sudarshana Chakr
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sudarshana Chakr · Sloka 19-20 [present] · PDF page 319

19-20. The sage replied: The results should be declared in
accordance with the Sudarshana Chakr only when Surya and
Chandr being in separate rashis different from the rashi of
Lagn. If amongst Lagn, Surya, and Chandr, all the three or
two of them are in the same rashi, the judgment of effects
should be made from the rashi kundali only.
The sage said: O Brahmin! Now I will tell you about the
effects produced every year and every month by the twelve
bhavas in their Dasas and Antardasas according to Sudarshana
Chakr. Under this system every one of the twelve bhavas
beginning from the 1st, is allotted a Dasa period of one
year. Thus, every year in 12 years a bhava becomes Lagn of
the year and the remaining become 2nd, the bhava of wealth,
3rd, the bhava of brother, and so on. (This means in the 1st
year the 1st bhava will be Lagn and the 2nd year the 2nd
bhava will assume this role. Ultimately, in the 12th year,
the role of Lagn is taken over by the 12th bhava).
Every year every bhava will have Antardasa of one month. By
following the method of Lagn of the year, here also, there
will be a Lagn of the month. The first Antardasa will be of
the first bhava and then will follow for 12 months the
Antardasas of the other bhavas, every bhava assuming the role
of Lagn by turn. Every bhava gets Pratyantar Dasa of 2 1/2
days and Vidasa of 12 1/2 ghatikas. The same method is to be
adopted for judging the effects of bhavas in Pratyantar Dasas
and Vidasas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P320_B001_01

- 身份：正文
- PDF 页：320
- 偈颂：24-26
- 标题路径：CHAPTER 74 Effects of the Sudarshana Chakr
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sudarshana Chakr · Sloka 24-26 [present] · PDF page 320

24-26. At the time of commencement of a Dasa if there be
benefic in the 1st, 4th, 7th, 10th, 5th, 9th, and 8th,
favourable effects will be experienced in the concerned year,
month, etc. The bhava which is occupied by only Rahu or Ketu
becomes harmful. The same will be the fate of the bhava which
is occupied by a larger number of malefics. If there be
benefics in bhavas other than the 12th or 6th, the bhava
concerned will produce favourable effects. In other words, if
the benefics be in the 12th or 6th from the bhava concerned,
unfavourable effects will be derived in the related year,
month, etc.. If there be malefics in the 3rd, 6th, and 11th
from the bhava assuming the role of Lagn, then these three
bhavas will produce auspicious results. The effects can be
ascertained for every year, month, etc. in this manner. The
total number of years in Vimsottari Dasa are 120 years. After
every 12 years the same method of determining the Dasas,
Antardasas, etc., has to be repeated for Lagn and other
bhavas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P320_B002_01

- 身份：正文
- PDF 页：320
- 偈颂：27-28
- 标题路径：CHAPTER 74 Effects of the Sudarshana Chakr
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sudarshana Chakr · Sloka 27-28 [present] · PDF page 320

27-28. After ascertaining the effects of the years, months,
etc., in accordance with the Sudarshana Chakr, assessment of
effects for the years, months, etc., should be made on the
basis of Ashtakavarg. The benefic or malefic effects will be
full if the assessment from both produces the same results.
If they are different, the comparative strength of both
should be taken into account to declare the final results.
