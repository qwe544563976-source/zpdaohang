# 第 18 章：Effects Of Yuvati Bhava

- 来源：BPHS 97 章版
- 原始卡片：29 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P047_B002_01

- 身份：正文
- PDF 页：47
- 偈颂：1
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 1 [present] · PDF page 47

1. 0 excellent of the Brahmins, listen to me detailing the
effects of the 7th Bhava. If Yuvati lord is in his own
Rashi or in exaltation, one will derive full happiness
through his wife (and marriage),
~L7I6+L7I8+L7I12**-L7E*-L7O~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P047_B003_01

- 身份：正文
- PDF 页：47
- 偈颂：2
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 2 [present] · PDF page 47

2. SICK  WIFE: Should Yuvati lord be in Ari, 8th or Vyaya,
the wife will be sickly. This, however, does not apply to
own bhava or exaltation placement as above.
~6I7~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P047_B004_01

- 身份：正文
- PDF 页：47
- 偈颂：3
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 3 [present] · PDF page 47

3. EXCESSIVE LIBIDINOUSNESS/DEATH OF WIFE:
If Shukr is in Yuvati, the native will be exceedingly
libidinous.
~6Ym~n
If Shukr yuti a malefic in any bhava will cause loss of
wife.
~L7X*L7YB+L7X*L7AB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P047_B005_01

- 身份：正文
- PDF 页：47
- 偈颂：4-5
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 4-5 [present] · PDF page 47

4-5. THE 7TH LORD: Should Yuvati lord be endowed with
strength and be yuti with or be drishticd by a benefic,
the native will be wealthy, honourable, happy and
fortunate.
~L7d+L7c+L7e~n
Conversely, if Yuvati lord is in fall or is combust or
is in an Enemy's Rashi, one will acquire sick wives and
many wives.
~L7DB**L7IR7+L7IR2+L7IR10+L7I11~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P047_B006_01

- 身份：正文
- PDF 页：47
- 偈颂：6
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 6 [present] · PDF page 47

6. PLURALITY OF WIVES: If Yuvati lord is in a Rashi of
Shani or of Shukr and be drishtied by a benefic, there
will be many wives.
~L7E*L7DB**L7IR7+L7IR2+L7IR10+L7I11~
Should Yuvati lord be particularly in exaltation, the same
effects will come to pass (there will be many wives).
~1I7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P047_B007_01

- 身份：正文
- PDF 页：47
- 偈颂：7-8 1/2
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 7-8 1/2 [present] · PDF page 47

7-8 1/2. MlSCELLANEOUS MATTERS: The native will befriend
barren females (for sexual union) if Surya is in Yuvati.
~2I7~m
Chandr therein will cause association with such female as
corresponding to the Rashi becoming Yuvati.
~3I7~m
Mangal placed in Yuvati will denotes association with
marriageable girls (of those with menses) or with barren
females.
~4I7~n
Buddh indicates harlots, mean females and females
belonging
to traders's community.
~5I7~
Wife of a Brahmin or a pregnant female will be in the
native's association if Guru is in Yuvati.
~7I7+8I7+9I7~n
Base females and females having attained their courses are
denoted by Shani, Rahu/Ketu in Yuvati.
~3I7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P048_B001_01

- 身份：正文
- PDF 页：48
- 偈颂：8-9 1/2
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 8-9 1/2 [present] · PDF page 48

8-9 1/2. Mangal denotes a female with attractive breasts.
~7I7~n
Shani indicates sick and weak spouse.
~5I7~
Guru will bring a spouse with hard and prominent breasts.
~6I7~
Shukr will bring one with bulky and excellent breasts.
~mI12*mI7*2w*2I5~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P048_B002_01

- 身份：正文
- PDF 页：48
- 偈颂：10
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 10 [present] · PDF page 48

10 13 1/2. Malefics in Vyaya and 7th while decreasing
Chandr is in Putr denote that the native will be
controlled by spouse who will be inimical to the race (or
family).
~7I7+3I7+L7i7+L7i3~n
If Yuvati Bhava is occupied or owned by Shani/Mangal,
the native will beget a harlot as his spouse or he will be
attached to other illegally.
~N6IR1+N6IR8+6IR1+6IR8+6D3+6Y3~m
Should Shukr be in a Navamsa of Mangal or in a Rasi of
Mangal or receive a drishti from or be yuti with Mangal, the
native will "kiss" the private parts of the female.
~N6IR10+N6IR11+6IR10+6IR11+6D7+6Y7~m
If Shukr is so related to Shani, the native will "kiss"
the private parts of the male.
~L7E*L1I7*L1X*BI7*L1YB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P048_B003_01

- 身份：正文
- PDF 页：48
- 偈颂：14-15
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 14-15 [present] · PDF page 48

14-15. WORTHY SPOUSE: The native will beget a spouse
endowed with (the seven principal) virtues who will expand
his dynasty by sons and grandsons if the 7th lord is
exalted while Yuvati is occupied by strong Lagna lord and
a benefic.
~mI7+L7Ym~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P048_B004_01

- 身份：正文
- PDF 页：48
- 偈颂：16
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 16 [present] · PDF page 48

16. EVILS TO SPOUSE: If Yuvati Bhava or its lord is yuti
with a malefic the native's wife will incur evils,
especially if Yuvati Bhava or its lord is bereft of
strength.
~7Lx*7LI6+L7x*L7I8+L7x*L7I12+L7d~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P048_B005_01

- 身份：正文
- PDF 页：48
- 偈颂：17
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 17 [present] · PDF page 48

17. LOSS OF SPOUSE: If Yuvati lord is devoid of strength
and is relegated to Ari, 8th or Vyaya, or if Yuvati lord
is in fall, the native's wife will be destroyed (i.e. she
will die early).
~2I7*L7I12*6x~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P048_B006_01

- 身份：正文
- PDF 页：48
- 偈颂：18
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 18 [present] · PDF page 48

18. LACK OF CONJUGAL FELICITY: If Chandr is in Yuvati as
Yuvati lord is in Vyaya and the Karaka (indicator Shukr)
is bereft of strength, the native will not be endowed with
marital happiness.
~L7d*áiNL7+L7z*L7Ym*áiNL7+L7d*áiL7+L7z*L7Ym*áiL7~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P049_B001_01

- 身份：正文
- PDF 页：49
- 偈颂：19-21
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 19-21 [present] · PDF page 49

19-21. PLURALlIY OF WIVES: One will have two wives if
Yuvati lord is in fall, or in a malefic Rashi along with a
malefic while Yuvati Bhava or the 7th Navamsa belong to a
eunuch planet.
~3I7*6I7*L1I8+7I7*L1I8~n
If Mangal and Shukr are in Yuvati or if Shani is Yuvati
while the lord of Lagn is in Randhr, the native will have
3 wives.
~7IRd*ã7E*L7X~m
There will be many wives if Shukr is in a dual Rashi while
its lord is in exaltation as Yuvati lord is endowed with
strength.
~L7I!B*6E+L7I!B*6O+L7I9*6E+L7I9*6O~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P049_B002_01

- 身份：正文
- PDF 页：49
- 偈颂：22
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 22 [present] · PDF page 49

22. TIME OF MARRIAGE (upto sloka 34): If Yuvati lord is in
a benefic's Bhava (or in Dharm as subha Rashi so means)
while Shukr is exalted or is in own Rashi, the native will
marry at the age of 5 or 9.
~1I7*ã1Y6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P049_B003_01

- 身份：正文
- PDF 页：49
- 偈颂：23
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 23 [present] · PDF page 49

23. If Surya is in Yuvati while his dispositor is yuti
with Shukr, there will be marriage at 7th or 11th year of
age.
~6I2*L7I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P049_B004_01

- 身份：正文
- PDF 页：49
- 偈颂：24
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 24 [present] · PDF page 49

24. Shukr in Dhan while Yuvati lord is in Labh will give
marriage at the age of 10 or 16.
~6K*L1IR10+6K*L1IR11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P049_B005_01

- 身份：正文
- PDF 页：49
- 偈颂：25
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 25 [present] · PDF page 49

25. Marriage will take place during the 11th year if Shukr
is in an angle from Lagn while Lagn lord is in Makar or
Kumbh.
~6K*(7I7)6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P049_B006_01

- 身份：正文
- PDF 页：49
- 偈颂：26
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 26 [present] · PDF page 49

26. The native will marry at 12 or l9 if Shukr is in an
angle from the Lagna while Shani is in Yuvati counted from
Shukr.
~(6I7)2*(7I7)6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P049_B007_01

- 身份：正文
- PDF 页：49
- 偈颂：27
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 27 [present] · PDF page 49

27. Should Shukr be in Yuvati from Chandr while Shani is
in Yuvati from Shukr, marriage will be in the 18th year.
~L2I11*L1I10~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P049_B008_01

- 身份：正文
- PDF 页：49
- 偈颂：28
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 28 [present] · PDF page 49

28. Marriage will be in the 15th year if Dhan lord is in
Labh while Lagn lord is in Karm.
~L2I11*L11I2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P049_B009_01

- 身份：正文
- PDF 页：49
- 偈颂：29
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 29 [present] · PDF page 49

29. An exchange between the lords of Dhan and Labh will
bring marriage 13 years after birth.
~6I2*ã6Y3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P049_B010_01

- 身份：正文
- PDF 页：49
- 偈颂：30
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 30 [present] · PDF page 49

30. Ones 22nd/27th year will confer marriage if Shukr is
in Yuvati from the 8th Bhava (i.e. Dhan from Lagna), while
his dispositor is yuti with Mangal.
~L7I12*L1IN7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P049_B011_01

- 身份：正文
- PDF 页：49
- 偈颂：31
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 31 [present] · PDF page 49

31. Should Yuvati lord be in Vyaya while the natal lord is
in Yuvati in Navamsa, marriage will be in 23rd/26th year
of age.
~L8I7*6IN1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P050_B001_01

- 身份：正文
- PDF 页：50
- 偈颂：32
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 32 [present] · PDF page 50

32. Either the 25th year or the 33rd year will bring
marriage if Randhr lord is in Yuvati as Shukr is in
Navamsa Lagna.
~6I5*8I5+6I5*8I9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P050_B002_01

- 身份：正文
- PDF 页：50
- 偈颂：33
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 33 [present] · PDF page 50

33. Should Shukr be in Dharm from Dharm (i.e. in Putr
Bhava), while Rahu is in one of the said bhavas (i.e. in
Putr/Dharm), marriage will take place during 31st or 33rd
year.
~6I1*L7I7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P050_B003_01

- 身份：正文
- PDF 页：50
- 偈颂：34
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 34 [present] · PDF page 50

34. The native will marry at 30 or 27 if Shukr is in Lagn
while the 7th lord is in Yuvati itself.
~L7d*6I8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P050_B004_01

- 身份：正文
- PDF 页：50
- 偈颂：35-39
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 35-39 [present] · PDF page 50

35-39. TIMING OF WIFE'S DEATH: Loss of wife will occur in
the 18th year or 33rd year of age of the native if Yuvati
lord is in fall while Shukr is in Randhr.
~L7I8*L12I7~n
One will lose his spouse in his 19th year if Yuvati lord
is in the 8th while Vyaya lord is in Yuvati.
~8I2*3I7~n
The native's wife will die within three days of marriage
due to snake bite if the native has Rahu in Dhan and Mangal
in Yuvati.
~6I8*ã6IR10+6I8*ã6IR11~n
If Shukr is in Randhr while his dispositor is in a Rashi
of Shani, death of wife will take place during the
native's 12th or 21st year of age.
~L1d*L2I8~n
Should the ascendat lord be in his Rashi of debilitation
as Dhan lord is in Randhr, loss of wife will occur in the
13th year of age.
~(2I7)6*(4I7)2*L8I5~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P050_B005_01

- 身份：正文
- PDF 页：50
- 偈颂：40-41
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 40-41 [present] · PDF page 50

40-41. THREE MARRIAGES: Should Chandr be in Yuvati from
Shukr while Buddh is in Yuvati from Chandr and Randhr lord
is in Putr (from the Lagna), there will be marriage in
Karm year followed by another in the 22nd year and yet
another in the 33rd year.
~3I6*8I7*7I8~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P050_B006_01

- 身份：正文
- PDF 页：50
- 偈颂：42
- 标题路径：CHAPTER 18 Effects Of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects Of Yuvati Bhava · Sloka 42 [present] · PDF page 50

42. DEATH OF WlFE: lf Ari, 7th and 8th are in their order
occupied by Mangal, Rahu and Shani, the native's wife will
not live (long).
