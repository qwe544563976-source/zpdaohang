# 第 34 章：Yoga Karakas

- 来源：BPHS 97 章版
- 原始卡片：23 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P120_B002_01

- 身份：正文
- PDF 页：120
- 偈颂：1
- 标题路径：CHAPTER 34 Yoga Karakas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yoga Karakas · Sloka 1 [present] · PDF page 120

1. O Brahmin, thus I have told you about the effects
derivable through Karakamsh. Now listen to the effects
arising out of lordships of grahas over bhavas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P120_B003_01

- 身份：正文
- PDF 页：120
- 偈颂：2-7
- 标题路径：CHAPTER 34 Yoga Karakas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yoga Karakas · Sloka 2-7 [present] · PDF page 120

2-7. Nature due to Lordships of Grahas: Benefics owning
Kendras will not give benefic effects, while malefics
owning Kendras will not remain inauspicious.
The lord of a Kon will give auspicious results.
The lord of Lagn is specially auspicious as Lagn is a Kendr
as well as a Kon.
Putr and Dharm Bhava are specially for wealth,
while Yuvati and Karm Bhava are specially for happiness.
Any grah owning Sahaj, Ari, or Labh Bhava will give evil
effects.
The effects due to the lords of Vyaya and Randhr Bhava will
depend on their association. In each group, the
significance will be in the ascending order. Randhr's lord
is not auspicious as he owns the 12th from Dharm Bhava. If
the lord of Randhr Bhava simultaneously owns Sahaj, Yuvati,
or Labh Bhava, he will prove specifically harmful, while
his simultaneous ownership of a Kon will bestow auspicious
effects. The grah owning a predominant Bhava will stall the
effects due to another owning a less significant bhava and
will give his own results.
Randhr's lordship of Surya and Chandr is not evil.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P120_B004_01

- 身份：正文
- PDF 页：120
- 偈颂：8-10
- 标题路径：CHAPTER 34 Yoga Karakas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yoga Karakas · Sloka 8-10 [present] · PDF page 120

8-10. Natural Benefics and Natural Malefics: Guru and Shukr
are benefics, while Chandr is mediocre in benefice and
Buddh is neutral (i.e. a benefic when associated with a
benefic and a malefic when related to a malefic). Malefics
are Surya, Shani, and Mangal. Full Chandr, Buddh, Guru and
Shukr are stronger in the ascending order. Weak Chandr,
Surya, Shani, and Mangal are stronger (in malefic
disposition) in the ascending order. In revealing
maleficence due to rulership of Kendras, Chandr, Buddh,
Guru, and Shukr are significant in the ascending order.
~LKlLT+LKIT+&KiLT+&TiLK+(LKI7)LT+(3I10)7*LniR2+LniR4+LniR7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P120_B005_01

- 身份：正文
- PDF 页：120
- 偈颂：11-12
- 标题路径：CHAPTER 34 Yoga Karakas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yoga Karakas · Sloka 11-12 [present] · PDF page 120

11-12. Lordships of Kendras and Konas: If there be an
exchange between an lord of a Kendr and a lord of a Kon, or
if a lord of a Kendr is yuti with a lord of a Kon in a
Kendr or in a Kon, or if a lord of a Kon is in a Kendr or
vice versa, or if there happens to be a full drishti
between a lord of a Kendr and a lord of a Kon, they cause a
Yog. One born in such a Yog will become a king and be
famous.
~LKiLT+&IK+&IT~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P120_B006_01

- 身份：正文
- PDF 页：120
- 偈颂：13
- 标题路径：CHAPTER 34 Yoga Karakas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yoga Karakas · Sloka 13 [present] · PDF page 120

13. If one and the same grah gets the lordships of a Kon as
well as a Kendr, or if a grah is in a Kendr or in a Kon, it
will prove specially a Yog Karak.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P120_B007_01

- 身份：正文
- PDF 页：120
- 偈颂：14
- 标题路径：CHAPTER 34 Yoga Karakas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yoga Karakas · Sloka 14 [present] · PDF page 120

14. Lordship of Kendr: It has been said that a malefic
owning a Kendr will become auspicious, which is true only
when it simultaneously lords over a Kon and not by merely
owning a Kendr.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P121_B001_01

- 身份：正文
- PDF 页：121
- 偈颂：15
- 标题路径：CHAPTER 34 Yoga Karakas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yoga Karakas · Sloka 15 [present] · PDF page 121

15. If the lords of a Kendr or a Kon own simultaneously an
evil bhava. he (i.e. the lord of the Kendr or the lord of
the Kon) does not cause a Raj Yog by mere relations
stipulated (as per ch. 34, slokas 11 and 12).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P121_B002_01

- 身份：正文
- PDF 页：121
- 偈颂：16
- 标题路径：CHAPTER 34 Yoga Karakas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yoga Karakas · Sloka 16 [present] · PDF page 121

16. Rahu and Ketu: Rahu and Ketu give predominantly the
effects as due to their yuti with a bhava lord or as due to
the bhava they occupy.
~.NIK*.NDLT+8IT*8DLK+9IT*9DLK+.NIK*8ALT+8IT*8ALK+9IT*9ALK~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P121_B003_01

- 身份：正文
- PDF 页：121
- 偈颂：17
- 标题路径：CHAPTER 34 Yoga Karakas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yoga Karakas · Sloka 17 [present] · PDF page 121

17. If Rahu and Ketu are in Kendr receiving a drishti from
or in association with the lord of a Kon, or if Rahu or
Ketu happen to be in a Kendr receiving a drishti from or in
association with the lord of a Kendr it will become Yog
Karak.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P121_B004_01

- 身份：正文
- PDF 页：121
- 偈颂：18
- 标题路径：CHAPTER 34 Yoga Karakas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yoga Karakas · Sloka 18 [present] · PDF page 121

18. 0 Maharishi Parashar, please narrate according to the
rashis rising as to which grah is a Yog Karak and which is
inauspicious.
~R1I1~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P121_B005_01

- 身份：正文
- PDF 页：121
- 偈颂：19-22
- 标题路径：CHAPTER 34 Yoga Karakas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yoga Karakas · Sloka 19-22 [present] · PDF page 121

19-22. Grahas and Mesh Lagn: O Brahmin, listen to these
with examples. Even though Mangal is the lord of Randhr
Bhava, he will be helpful to (other) auspicious grahas.
Shani, Buddh, and Shukr are malefics. Auspicious are Guru
and Surya. The mere yuti of Shani with Guru will not
produce auspicious effects (although they own a Kon and a
Kendr). If Guru is at the disposal of a malefic, he will
surely give inauspicious results. Shukr is a direct (or
independent) killer. Shani, etc., will also inflict death
if associated with an adverse grah (i.e Shukr).
~R2I1~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P121_B006_01

- 身份：正文
- PDF 页：121
- 偈颂：23-24
- 标题路径：CHAPTER 34 Yoga Karakas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yoga Karakas · Sloka 23-24 [present] · PDF page 121

23-24. Grahas and Vrishabh Lagn: Guru, Shukr, and Chandr
are malefics. Shani and Surya are auspicious. Shani will
cause Raj Yog. Buddh is somewhat inauspicious; the Guru
group (Guru, Chandr, and Shukr), and Mangal will inflict
death.
~R3I1~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P121_B007_01

- 身份：正文
- PDF 页：121
- 偈颂：25-26
- 标题路径：CHAPTER 34 Yoga Karakas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yoga Karakas · Sloka 25-26 [present] · PDF page 121

25-26. Grahas and Mithun Lagn: Mangal, Guru, and Surya are
malefics, while Shukr is the only auspicious grah. The yuti
of Guru with Shani is similar to that for Mesh Lagn. Chandr
is the prime killer, but it is dependant on her
association.
~R4I1~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P121_B008_01

- 身份：正文
- PDF 页：121
- 偈颂：27-28
- 标题路径：CHAPTER 34 Yoga Karakas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yoga Karakas · Sloka 27-28 [present] · PDF page 121

27-28. Grahas and Kark Lagn: Shukr and Buddh are malefics,
Mangal, Guru, and Chandr are auspicious. Mangal is capable
of conferring a full-fledged Yog and giving auspicious
effects. Shani and Surya are killers and give effects
according to their associations.
~R5I1~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P121_B009_01

- 身份：正文
- PDF 页：121
- 偈颂：29-30
- 标题路径：CHAPTER 34 Yoga Karakas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yoga Karakas · Sloka 29-30 [present] · PDF page 121

29-30. Grahas and Simh Lagn: Buddh, Shukr, and Shani are
malefics. Auspicious effects will be given by Mangal, Guru,
and Surya. Guru's yuti with Shukr (though respectively Kon
and Kendr lords) will not produce auspicious results. Shani
and Chandr are killers who will give effects according to
their associations.
~R6I1~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P122_B001_01

- 身份：正文
- PDF 页：122
- 偈颂：31-32
- 标题路径：CHAPTER 34 Yoga Karakas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yoga Karakas · Sloka 31-32 [present] · PDF page 122

31-32. Grahas and Kanya Lagn: Mangal, Guru, and Chandr are
malefics, while Buddh and Shukr are auspicious. Shukr's
yuti with Buddh will produce Yog. Shukr is a killer as
well. Surya's role will depend on his association.
~R7I1~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P122_B002_01

- 身份：正文
- PDF 页：122
- 偈颂：33-34
- 标题路径：CHAPTER 34 Yoga Karakas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yoga Karakas · Sloka 33-34 [present] · PDF page 122

33-34. Grahas and Tula Lagn: Guru, Surya, and Mangal are
malefics. Auspicious are Shani and Buddh. Chandr and Buddh
will cause Raj Yog. Mangal is a killer. Guru and other
malefics will also acquire a disposition to inflict death.
Shukr is neutral.
~R8I1~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P122_B003_01

- 身份：正文
- PDF 页：122
- 偈颂：35-36
- 标题路径：CHAPTER 34 Yoga Karakas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yoga Karakas · Sloka 35-36 [present] · PDF page 122

35-36. Grahas and Vrischik Lagn: Shukr, Buddh, and Shani
are malefics. Guru and Chandr are auspicious. Surya as well
as Chandr are Yog Karakas. Mangal is neutral. Shukr and
other malefics acquire the quality of causing death.
~R9I1~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P122_B004_01

- 身份：正文
- PDF 页：122
- 偈颂：37-38
- 标题路径：CHAPTER 34 Yoga Karakas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yoga Karakas · Sloka 37-38 [present] · PDF page 122

37-38. Grahas and Dhanu Lagn: Only Shukr is inauspicious.
Mangal and Surya are auspicious. Surya and Buddh are
capable of conferring a Yog. Shani is a killer, Guru is
neutral. Shukr acquires killing powers.
~R10I1~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P122_B005_01

- 身份：正文
- PDF 页：122
- 偈颂：39-40
- 标题路径：CHAPTER 34 Yoga Karakas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yoga Karakas · Sloka 39-40 [present] · PDF page 122

39-40. Grahas and Makar Lagn: Mangal, Guru, and Chandr are
malefics, Shukr and Buddh are auspicious. Shani will not be
a killer on his own. Mangal and other malefics will inflict
death. Surya is neutral. Only Shukr is capable of causing a
superior Yog.
~R11I1~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P122_B006_01

- 身份：正文
- PDF 页：122
- 偈颂：41-42
- 标题路径：CHAPTER 34 Yoga Karakas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yoga Karakas · Sloka 41-42 [present] · PDF page 122

41-42. Grahas and Kumbh Lagn: Guru, Chandr, and Mangal are
malefics, while Shukr and Shani are auspicious. Shukr is
the only grah that causes Raj Yog. Guru, Surya, and Mangal
are killers. Buddh gives meddling effects.
~R12I1~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P122_B007_01

- 身份：正文
- PDF 页：122
- 偈颂：43-44
- 标题路径：CHAPTER 34 Yoga Karakas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yoga Karakas · Sloka 43-44 [present] · PDF page 122

43-44. Grahas and Meen Bhava: Shani, Shukr, Surya, and
Buddh are malefics. Mangal and Chandr are auspicious.
Mangal and Guru will cause a Yog. Though Mangal is a killer
he will not kill the native (independently). Shani and
Buddh are killers.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P122_B008_01

- 身份：正文
- PDF 页：122
- 偈颂：45-46
- 标题路径：CHAPTER 34 Yoga Karakas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Yoga Karakas · Sloka 45-46 [present] · PDF page 122

45-46. General: Thus, the auspicious and inauspicious
effects derivable through the grahas due to their lordship
according to the rising rashi, have to be estimated. Apart,
the effects due to Nabhash Yogas, etc., should also be
known which I narrate as under.
