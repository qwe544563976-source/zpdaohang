# 第 67 章：Trikon Shodhana (rectification) in the

- 来源：BPHS 97 章版
- 原始卡片：3 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P305_B002_01

- 身份：正文
- PDF 页：305
- 偈颂：—
- 标题路径：CHAPTER 67 Trikon Shodhana (rectification) in the › Ashtakavarg Scheme
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Trikon Shodhana (rectification) in the · Sloka unknown [unknown] · PDF page 305 · page_block BPHS_PL9_CHAP_97_P305_B002

Ashtakavarg Scheme

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P305_B003_01

- 身份：正文
- PDF 页：305
- 偈颂：1-2
- 标题路径：CHAPTER 67 Trikon Shodhana (rectification) in the › Ashtakavarg Scheme
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Trikon Shodhana (rectification) in the · Sloka 1-2 [present] · PDF page 305

1-2. The sage said: O Brahmin! After preparing the
Ashtakavarg of all the grahas including Lagn, Trikon shodhana
has to be done for each Rashi . A Trikon is made of three
rashis equidistant from each other. Thus, (I) Mesh, Simh and
Dhanu, (2) Vrishabh, Kanya and Makar, (3) Mithun, Tul and
Kumbh and (4) Kark, Vrischik and Meen, form the Trikonas of
the rashis.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P305_B004_01

- 身份：正文
- PDF 页：305
- 偈颂：3-5
- 标题路径：CHAPTER 67 Trikon Shodhana (rectification) in the › Ashtakavarg Scheme
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Trikon Shodhana (rectification) in the · Sloka 3-5 [present] · PDF page 305

3-5. The Trikon shodhana (rectification) should be done by
writing the rekhas in the Ashtakavargas of Surya, etc., under
the rashis Mesh etc.. Amongst the Trikon rashis, the rashi
which has lesser number of rekhas should be allotted rekhas
arrived at by deducting its number of rekhas from the total
number of rekhas of the three Trikon rashis. No Trikon
shodhana is necessary if any of the Trikon rashis has no
rekha. Shodhana should be done if all the three of them have
equal number of rekhas, that is, a zero should be written
against all of them. Thereafter Ekadhipatya Shodhana should
be done in the same manner described later.
For Shodhana of the Ashtakavarg of a grah, the first thing to
be done is to see in which rashi the grah is posited.
Beginning from that rashi, the names of the 12 rashis should
be written and then the names of the grahas posited in them
should be mentioned against them. Thereafter, the rekhas
gained by that rashi should be written below them and the
number achieved after Shodhana below it.
