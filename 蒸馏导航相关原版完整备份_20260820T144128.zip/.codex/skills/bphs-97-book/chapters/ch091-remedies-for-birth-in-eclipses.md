# 第 91 章：Remedies for Birth in Eclipses

- 来源：BPHS 97 章版
- 原始卡片：3 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P365_B002_01

- 身份：正文
- PDF 页：365
- 偈颂：1-14
- 标题路径：CHAPTER 91 Remedies for Birth in Eclipses
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies for Birth in Eclipses · Sloka 1-14 [present] · PDF page 365

1-14. The Sage said: O Brahmin! a person whose birth takes
place at the time of solar or lunar eclipse, suffers from
ailments, distress, and poverty and faces danger of death.
Therefore, I am going to describe for the benefit of the
mankind the remedial measures required to be undertaken to
nullify the above evil effects. The remedial rites are to be
performed in the following order:
(l) The following idols should be got prepared according to
one's means:
(a) in gold an idol of the deity of the nakshatr in which the
eclipse takes place (for details regarding deities of
nakshatras see 'notes' of verse 18 of Chapter 3, Vol. I);
(b) in gold an idol of Surya if the birth takes place during
solar eclipse; and
(c) in silver  an idol of Chandr if the birth takes place
during lunar eclipse;
(d) in lead an idol of Rahu;
(2) Besmear a clean spot on the ground (in the house) with
cow dung, cover it with a new (unused) beautiful piece of
cloth and instal the three idols on it;
(3) Make offerings of the following to the idols:
(a) in case of birth during solar eclipse, all things dear to
Surya, and red coloured akshat (akshata-rice), red sandal, a
garland of red coloured flowers, red clothes, etc.;
(b) incase of birth during a lunar eclipse, all things dear
to Chandr, and white sandal, white flowers, white clothes,
etc.;
(c) for Rahu: blackish clothes, blackish flowers, etc.;
(d) white flowers for the deity of the nakshatr in which the
eclipse takes place;

(4) The worship should be performed as follows:
(a) of Surya with the chanting of 'Akrishnim', etc., mantra;
(b) of Chandr with the chanting of 'Imadeva', etc., mantra;
and
(c) of Rahu with durva (a kind of grass) and with the
chanting of 'Kayanshicatra', etc., mantra;
(5) Thereafter, havan should be performed as follows:
(a) with the fuel of Aak wood pieces for Surya;
(b) with the fuel of Palas tree wood pieces for Chandr;
(c) with durva for Rahu;
(d) with Pipal tree wood pieces for the deity of the
nakshatr;
(6) Sprinkle the holy water of the Kalash on the child born
(and his parents);
(7) Offer worshipful regards to the priest performing the
remedial rites; and
(8) Lastly, feed as many Brahmins as possible within one's
means. By performance of the remedial rites in the manner
described above, evil effects of the inauspicious birth are
wiped and the native enjoys happiness and is blessed with
good fortune.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P365_B002_02

- 身份：正文
- PDF 页：365
- 偈颂：1-14
- 标题路径：CHAPTER 91 Remedies for Birth in Eclipses
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies for Birth in Eclipses · Sloka 1-14 [present] · PDF page 365

1-14. The Sage said: O Brahmin! a person whose birth takes
place at the time of solar or lunar eclipse, suffers from
ailments, distress, and poverty and faces danger of death.
Therefore, I am going to describe for the benefit of the
mankind the remedial measures required to be undertaken to
nullify the above evil effects. The remedial rites are to be
performed in the following order:
(l) The following idols should be got prepared according to
one's means:
(a) in gold an idol of the deity of the nakshatr in which the
eclipse takes place (for details regarding deities of
nakshatras see 'notes' of verse 18 of Chapter 3, Vol. I);
(b) in gold an idol of Surya if the birth takes place during
solar eclipse; and
(c) in silver  an idol of Chandr if the birth takes place
during lunar eclipse;
(d) in lead an idol of Rahu;
(2) Besmear a clean spot on the ground (in the house) with
cow dung, cover it with a new (unused) beautiful piece of
cloth and instal the three idols on it;
(3) Make offerings of the following to the idols:
(a) in case of birth during solar eclipse, all things dear to
Surya, and red coloured akshat (akshata-rice), red sandal, a
garland of red coloured flowers, red clothes, etc.;
(b) incase of birth during a lunar eclipse, all things dear
to Chandr, and white sandal, white flowers, white clothes,
etc.;
(c) for Rahu: blackish clothes, blackish flowers, etc.;
(d) white flowers for the deity of the nakshatr in which the
eclipse takes place;

(4) The worship should be performed as follows:
(a) of Surya with the chanting of 'Akrishnim', etc., mantra;
(b) of Chandr with the chanting of 'Imadeva', etc., mantra;
and
(c) of Rahu with durva (a kind of grass) and with the
chanting of 'Kayanshicatra', etc., mantra;
(5) Thereafter, havan should be performed as follows:
(a) with the fuel of Aak wood pieces for Surya;
(b) with the fuel of Palas tree wood pieces for Chandr;
(c) with durva for Rahu;
(d) with Pipal tree wood pieces for the deity of the
nakshatr;
(6) Sprinkle the holy water of the Kalash on the child born
(and his parents);
(7) Offer worshipful regards to the priest performing the
remedial rites; and
(8) Lastly, feed as many Brahmins as possible within one's
means. By performance of the remedial rites in the manner
described above, evil effects of the inauspicious birth are
wiped and the native enjoys happiness and is blessed with
good fortune.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P365_B002_03

- 身份：正文
- PDF 页：365
- 偈颂：1-14
- 标题路径：CHAPTER 91 Remedies for Birth in Eclipses
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies for Birth in Eclipses · Sloka 1-14 [present] · PDF page 365

1-14. The Sage said: O Brahmin! a person whose birth takes
place at the time of solar or lunar eclipse, suffers from
ailments, distress, and poverty and faces danger of death.
Therefore, I am going to describe for the benefit of the
mankind the remedial measures required to be undertaken to
nullify the above evil effects. The remedial rites are to be
performed in the following order:
(l) The following idols should be got prepared according to
one's means:
(a) in gold an idol of the deity of the nakshatr in which the
eclipse takes place (for details regarding deities of
nakshatras see 'notes' of verse 18 of Chapter 3, Vol. I);
(b) in gold an idol of Surya if the birth takes place during
solar eclipse; and
(c) in silver  an idol of Chandr if the birth takes place
during lunar eclipse;
(d) in lead an idol of Rahu;
(2) Besmear a clean spot on the ground (in the house) with
cow dung, cover it with a new (unused) beautiful piece of
cloth and instal the three idols on it;
(3) Make offerings of the following to the idols:
(a) in case of birth during solar eclipse, all things dear to
Surya, and red coloured akshat (akshata-rice), red sandal, a
garland of red coloured flowers, red clothes, etc.;
(b) incase of birth during a lunar eclipse, all things dear
to Chandr, and white sandal, white flowers, white clothes,
etc.;
(c) for Rahu: blackish clothes, blackish flowers, etc.;
(d) white flowers for the deity of the nakshatr in which the
eclipse takes place;

(4) The worship should be performed as follows:
(a) of Surya with the chanting of 'Akrishnim', etc., mantra;
(b) of Chandr with the chanting of 'Imadeva', etc., mantra;
and
(c) of Rahu with durva (a kind of grass) and with the
chanting of 'Kayanshicatra', etc., mantra;
(5) Thereafter, havan should be performed as follows:
(a) with the fuel of Aak wood pieces for Surya;
(b) with the fuel of Palas tree wood pieces for Chandr;
(c) with durva for Rahu;
(d) with Pipal tree wood pieces for the deity of the
nakshatr;
(6) Sprinkle the holy water of the Kalash on the child born
(and his parents);
(7) Offer worshipful regards to the priest performing the
remedial rites; and
(8) Lastly, feed as many Brahmins as possible within one's
means. By performance of the remedial rites in the manner
described above, evil effects of the inauspicious birth are
wiped and the native enjoys happiness and is blessed with
good fortune.
