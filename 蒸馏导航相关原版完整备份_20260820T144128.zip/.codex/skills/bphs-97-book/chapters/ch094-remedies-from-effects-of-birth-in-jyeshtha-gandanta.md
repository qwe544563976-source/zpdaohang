# 第 94 章：Remedies from Effects of Birth in Jyeshtha Gandanta

- 来源：BPHS 97 章版
- 原始卡片：6 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P369_B002_01

- 身份：正文
- PDF 页：369
- 偈颂：1-5
- 标题路径：CHAPTER 94 Remedies from Effects of Birth in Jyeshtha Gandanta
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from Effects of Birth in Jyeshtha Gandanta · Sloka 1-5 [present] · PDF page 369

1-5. The Sage said: O Maitreya! Now I will describe to you
the remedial measures to be adopted to ensure relief from the
evil effects of Jyeshtha Gandanta. The erection of a canopy
(Mandhup) installation of Kalash, selection of a priest,
etc., will be done in the same manner as has been recommended
for the Abhukta Mula in the previous chapter. In this
ceremony Indra will be the deity-in-chief, Adhideva will be
Agni (Fire) and the Pratyadhideva will be Rakshasa.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P369_B003_01

- 身份：正文
- PDF 页：369
- 偈颂：6
- 标题路径：CHAPTER 94 Remedies from Effects of Birth in Jyeshtha Gandanta
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from Effects of Birth in Jyeshtha Gandanta · Sloka 6 [present] · PDF page 369

6. Then, the remedial rites should be performed in the
following order:
(I) Install on a Kalash full of paddy rice an idol of gold
(according to one's means) with Indra seated on Airavat with
Vajra Ankusha in his hands.
(2) Perform worship of the chief deity Indra along with that
of the Adhideva and the Pratyadhideva with the recitation of
their appropriate mantras.
(3) Perform havan, Abhisheka and then feed the Brahmins in
accordance with one's means.
In addition to the above after doing Indrasukta and
Mrityunjaya Japas, prayers may be offered to Indra. These
measures will wipe out the evil effects of the Gandanta.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P369_B004_01

- 身份：正文
- PDF 页：369
- 偈颂：7
- 标题路径：CHAPTER 94 Remedies from Effects of Birth in Jyeshtha Gandanta
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from Effects of Birth in Jyeshtha Gandanta · Sloka 7 [present] · PDF page 369

7. In case the performance of remedial rites described above
is beyond the means of any person, he should give a cow in
charity. This will also appease the deities and promote
relief from the evil effects of the Gandanta. Because the
giving of a cow in charity has been considered a superior
remedial measure than giving in charity all the lands
belonging to a person.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P369_B005_01

- 身份：正文
- PDF 页：369
- 偈颂：8-9
- 标题路径：CHAPTER 94 Remedies from Effects of Birth in Jyeshtha Gandanta
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from Effects of Birth in Jyeshtha Gandanta · Sloka 8-9 [present] · PDF page 369

8-9. According to prescribed remedial measures, 3 cows are to
be given in charity in the case of Jyeshtha Mula and Aslesha
Magha gandantas, 2 cows in Revati Ashvini gandantas . and 1
cow in other gandantas or in any inauspicious Yog. If cow or
cows are not available, their actual value should be given in
cash to a Brahmin.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P369_B006_01

- 身份：正文
- PDF 页：369
- 偈颂：10
- 标题路径：CHAPTER 94 Remedies from Effects of Birth in Jyeshtha Gandanta
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from Effects of Birth in Jyeshtha Gandanta · Sloka 10 [present] · PDF page 369

10. A girl born in Jyeshtha Nakshatr destroys (is the cause
of death of) the elder brother of her husband, and a girl
born in fourth quarter of Vishaka nakshatr destroys (is the
cause of death of) her husband's younger brother. Therefore,
a cow should be given in charity at the time of the marriage
of such girls to wipe out the above mentioned evil effects.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P369_B007_01

- 身份：正文
- PDF 页：369
- 偈颂：11-13
- 标题路径：CHAPTER 94 Remedies from Effects of Birth in Jyeshtha Gandanta
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from Effects of Birth in Jyeshtha Gandanta · Sloka 11-13 [present] · PDF page 369

11-13. A boy or girl born in the 2nd, 3rd, or 4th quarter of
Aslesha nakshatr destroys his/her mother-in-law and a boy or
a girl born in 1st, 2nd, or 3rd quarter of Mula nakshatr
becomes the destroyer (cause of death of his/her
father-in-law. Therefore, suitable measures, as may be
possible within one's means, should be taken at the time of
the marriage of such boys and girls. There will be no evil
effect if the husband has no elder brothers.
