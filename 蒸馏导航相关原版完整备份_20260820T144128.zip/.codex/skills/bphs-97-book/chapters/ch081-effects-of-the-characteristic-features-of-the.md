# 第 81 章：Effects of the Characteristic Features of the

- 来源：BPHS 97 章版
- 原始卡片：51 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P339_B002_01

- 身份：正文
- PDF 页：339
- 偈颂：—
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka unknown [unknown] · PDF page 339 · page_block BPHS_PL9_CHAP_97_P339_B002

Various Parts of the Woman's body.
I-2. Maitreya said: O Venerable Sage! I have been fully
enlightened by the auspicious and inauspicious effects
described by you with reference to the Janm Lagn (Lagn at
birth) in a female's horoscope. Now I request you to favour
me with knowledge of auspicious and inauspicious effects with
reference to the characteristic features of the various parts
of a woman's body.
Maharishi Parasara replied: O Brahmin! Now I will tell you
what Lord Shiva narrated to Goddess Parvati in this regard.
Soles of the feet

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P339_B003_01

- 身份：正文
- PDF 页：339
- 偈颂：3-4
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 3-4 [present] · PDF page 339

3-4. A woman whose soles are even, smooth, soft, well
developed, warm and shining in pink colour, without much
perspiration, will be enjoying full happiness befitting her
sex. The one whose soles are without pink colour, hard, dry,
coarse, uneven, shaped like a winnowing basket and bereft of
flesh, will suffer misery.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P339_B004_01

- 身份：正文
- PDF 页：339
- 偈颂：5-6
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 5-6 [present] · PDF page 339

5-6. The woman who has marks of conch, swastika, chakr,
lotus, flag, fish, umbrella, and a long line rising upwards
in her soles, becomes a queen and enjoys great happiness and
comforts. The one who possesses marks like those of snake,
rat, and crow, is bereft of wealth and suffers misery.
Nails of toes

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P339_B005_01

- 身份：正文
- PDF 页：339
- 偈颂：7
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 7 [present] · PDF page 339

7. The girl whose nails of toes are shining in pink colour,
smooth, raised, and round, enjoys great happiness and
comforts. Blackish and torn nails denotes misery.
The thumb of the foot (Great toe)

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P339_B006_01

- 身份：正文
- PDF 页：339
- 偈颂：8
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 8 [present] · PDF page 339

8. Raised, full (well developed, smooth, and round great toe
indicates happiness. The one which is small, irregular in
shape and flat denotes misery.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P339_B007_01

- 身份：正文
- PDF 页：339
- 偈颂：9
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 9 [present] · PDF page 339

9. The woman's toes which are soft, thick, round, and well
developed are considered auspicious. If the toes are long,
she will be of loose morals. Thin toes indicate poverty.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P340_B001_01

- 身份：正文
- PDF 页：340
- 偈颂：10-16
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 10-16 [present] · PDF page 340

10-16. Other effects about the toes are as under:
Short                  - short life
Short and long (of different sizes)
and irregular in shape - procurer and guileful
Flat                   - maid servant
Spaced more than average- bereft of wealth
Toes overlapping one over the other- widow and dependent on
others
If dust is thrown up when she walks- unchaste and brings
defame to all the three families (of her father, of her
mother, and of her husband)
If the smallest toe does not touch the ground- she will
destroy her husband and marry another
If the middle toe and the one next to it does not touch
the ground- widow
First toe (next to great toe)
longer than the great toe- she will develop illicit
connection with a man before marriage and will be of
loose morals.
Back of the feet

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P340_B002_01

- 身份：正文
- PDF 页：340
- 偈颂：17
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 17 [present] · PDF page 340

17. If the back of the feet of a woman is raised, without
perspiration, soft and smooth, she will become a queen. If
the indications are contrary she will be poverty-stricken.
She will be fond of travelling if the back part of the feet
be veined. Hair on that portion of feet denote that she will
be a maid servant. If the feet be bony or without flesh, she
will have a defective sexual organ.
Heels

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P340_B003_01

- 身份：正文
- PDF 页：340
- 偈颂：18
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 18 [present] · PDF page 340

18. If the heels are even, the woman concerned will have a
well formed and desirable sexual organ. If the heels be
stout, she will have a defective sexual organ. If the heels
be high, she will be unchaste. Long heels indicate misery.
Legs (portion below knees)

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P340_B004_01

- 身份：正文
- PDF 页：340
- 偈颂：19
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 19 [present] · PDF page 340

19. Even, smooth, evenly shaped, round, without hair, good
looking and without veins showing up, are rashis that the
woman will be a queen.
Knees

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P340_B005_01

- 身份：正文
- PDF 页：340
- 偈颂：20
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 20 [present] · PDF page 340

20. Round, smooth, firm knees are auspicious indications. If
the knees be bony the woman concerned will be of loose moral
character. If the knees be loose, she will be
poverty-stricken.
Thighs

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P340_B006_01

- 身份：正文
- PDF 页：340
- 偈颂：21
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 21 [present] · PDF page 340

21. If the thighs are round like the trunk of an elephant,
close to each other, soft and without hair, the woman
concerned will be a queen (it means very well off and
respected). If the thighs are flat and hairy she will be
poverty-stricken and a widow.
Waist

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P340_B007_01

- 身份：正文
- PDF 页：340
- 偈颂：22-23
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 22-23 [present] · PDF page 340

22-23. Circumference equal to the width of 24 fingers with
well developed hips indicate that the woman will be
fortunate. A waist which is flat, long, without flesh, caved
in or hairy, forebodes widowhood and misery.
Hips

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P341_B001_01

- 身份：正文
- PDF 页：341
- 偈颂：24
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 24 [present] · PDF page 341

24. Raised, fleshy and widespread hips in a woman are
auspicious in effects. If they are contrary they indicate
inauspiciousness.
Sexual organ

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P341_B002_01

- 身份：正文
- PDF 页：341
- 偈颂：25-27
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 25-27 [present] · PDF page 341

25-27. Hidden clitoris, pink coloured, curved like the back
of a tortoise, soft, hairy, shaped like the leaf of a pipal
tree and smooth, is highly auspicious. If shaped like the
feet of a deer or opening of an oven (furnace) with hard hair
and with raised clitoris, it indicates evil. If the left side
of the sexual organ of a woman is raised, she will beget more
female children and if the right side is raised, more boys.
If the organ is shaped like a conch, she will be barren.

Portion below the navel

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P341_B003_01

- 身份：正文
- PDF 页：341
- 偈颂：28
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 28 [present] · PDF page 341

28. A soft, spread out and slightly raised Vasti is
auspicious. Hairy, veins showing up and full of lines (folds)
or wrinkles) indicates inauspiciousness (misery).
Navel

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P341_B004_01

- 身份：正文
- PDF 页：341
- 偈颂：29
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 29 [present] · PDF page 341

29. A navel deep with right turns is productive of good
effects. The navel raised, with left turns and with knots is
inauspicious.
Stomach

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P341_B005_01

- 身份：正文
- PDF 页：341
- 偈颂：30-31
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 30-31 [present] · PDF page 341

30-31. A stomach well spread indicates a well formed sexual
organ and many sons. If the stomach of a woman resembles that
of a frog, her son will become a king. If a woman has a
raised stomach she will be childless. If the stomach is
wrinkled, she will become an ascetic. If it has circular
folds, she will become a maid servant.

Ribs

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P341_B006_01

- 身份：正文
- PDF 页：341
- 偈颂：32
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 32 [present] · PDF page 341

32. If the portion covering the ribs is even, well developed
and soft, auspicious effects may be expected. It will be
inauspicious if it is raised, hairy and full of veins.
Chest

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P341_B007_01

- 身份：正文
- PDF 页：341
- 偈颂：33
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 33 [present] · PDF page 341

33. The chest of a woman which is even and hairless is
auspicious. Wide spread and hairy chest is inauspicious.

Breasts

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P341_B008_01

- 身份：正文
- PDF 页：341
- 偈颂：34-36
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 34-36 [present] · PDF page 341

34-36. The breasts of a woman signify good luck if they are
of equal size, fleshy, round and firm but close together.
They are unlucky if they are thick in front, are not close
together and without flesh. Raised right breast indicates
that she will have sons. Raised left breast indicates that
she will have daughters. If the portion surrounding the
nipples is round, good looking and blackish, she will enjoy
good luck. Pressed in and unusually small breasts indicate
bad luck.
Shoulders

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P341_B009_01

- 身份：正文
- PDF 页：341
- 偈颂：37
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 37 [present] · PDF page 341

37. Even, well built up and without joints showing up are
rashis of good luck. Raised, hairy and without flesh are
unlucky.

Armpits

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P342_B001_01

- 身份：正文
- PDF 页：342
- 偈颂：38
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 38 [present] · PDF page 342

38. The armpits, if soft, with thin hair, well developed and
smooth are auspicious. Those which are deep, without flesh,
perspiring and with veins showing up are inauspicious.
Arms

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P342_B002_01

- 身份：正文
- PDF 页：342
- 偈颂：39-40
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 39-40 [present] · PDF page 342

39-40. Arms in which the bones do not show up and which are
soft jointed, hairless without obvious veins straight and
round are auspicious. Those without flesh (bony), hairy,
small, with obvious veins and irregular in shape are
inauspicious.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P342_B003_01

- 身份：正文
- PDF 页：342
- 偈颂：41
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 41 [present] · PDF page 342

41. If the thumbs of the woman are shaped like a lotus bud,
they are auspicious. If they are without flesh and irregular
in shape, they are inauspicious.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P342_B004_01

- 身份：正文
- PDF 页：342
- 偈颂：42-43
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 42-43 [present] · PDF page 342

42-43. If the palms of the woman are pink coloured, are
raised in the middle with fingers close together (with no
holes between them), soft and have very few lines, she enjoys
happiness and all comforts. If the palms are full of lines
she will become a widow. If there are no lines, she will be
poverty-stricken. If the veins show up in the palms she will
live on alms.

Back of the hands

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P342_B005_01

- 身份：正文
- PDF 页：342
- 偈颂：44
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 44 [present] · PDF page 342

44. If the backs of the hands of a woman are well built, soft
and hairless, she will enjoy auspicious effects. It will be
otherwise if the backs of the hands are with veins showing
up, deep and hairy.
Lines on the palm

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P342_B006_01

- 身份：正文
- PDF 页：342
- 偈颂：45-47
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 45-47 [present] · PDF page 342

45-47. A woman enjoys happiness and all comforts if there is
a clearly marked, pink coloured, circular, smooth, full and
deep line (perhaps line of life is meant). If there is mark
of a fish she will be very lucky. She will be wealthy with
mark of swastika. She will be a queen with mark of a lotus.
She will be the mother of a king if she has marks of conch,
umbrella, and tortoise.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P342_B007_01

- 身份：正文
- PDF 页：342
- 偈颂：48-50
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 48-50 [present] · PDF page 342

48-50. The woman who has lines forming the shapes of a
balance, elephant, bull, or horse becomes the wife of a
businessman. The woman who has lines forming the shape of a
house or vajra is lucky and gives birth to a son who becomes
learned in shastras. The woman who has lines forming the
shapes of a chariot, a plough, or a yoke, becomes the wife of
a farmer (agriculturist). She will become a queen if she has
lines forming the shape of chamar, ankush (an instrument used
for driving the elephant), trident, sword, mace, shakti, or
trumpet.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P342_B008_01

- 身份：正文
- PDF 页：342
- 偈颂：51-52
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 51-52 [present] · PDF page 342

51-52. If in the palm of a woman there is a line which
starting from the root of the thumb goes up to the root of
the little finger, she becomes a widow. If there are lines
forming the shape of a crow, a frog, a jackal,  a wolf, a
scorpion, a snake, a donkey, a camel, and a cat, the woman
concerned suffers misery.
Fingers

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P343_B001_01

- 身份：正文
- PDF 页：343
- 偈颂：53-54
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 53-54 [present] · PDF page 343

53-54. If the fingers of a woman are tender with good-Iooking
phalanges, tapering at the end and without hair, they are
considered auspicious. If they are very small, without flesh,
irregular, widely spaced (not close to each other), with
hair, and with more than usual phalanges or without
phalanges, they indicate misery.
Nails

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P343_B002_01

- 身份：正文
- PDF 页：343
- 偈颂：55
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 55 [present] · PDF page 343

55. If the nails of the fingers are pink coloured, raised,
and shaped well at the top, they are auspicious. Depressed,
dirty-looking or yellow or white coloured nails, or nails
with spots, are inauspicious.
Back

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P343_B003_01

- 身份：正文
- PDF 页：343
- 偈颂：56
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 56 [present] · PDF page 343

56. If the back of the woman is fleshy and well developed
with flesh, it is auspicious. The back with hair, irregular
in built and with veins showing up is inauspicious.
Neck

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P343_B004_01

- 身份：正文
- PDF 页：343
- 偈颂：57-58
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 57-58 [present] · PDF page 343

57-58. The neck of a woman with three lines (folds), with
bones not obvious, round, well developed and tender, is
auspicious. A thick necked woman becomes a widow. An
irregularly built neck indicates that the woman concerned
will become a maid servant. Flat necked woman will be barren.
A woman with a small neck is childless.
Throat

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P343_B005_01

- 身份：正文
- PDF 页：343
- 偈颂：59
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 59 [present] · PDF page 343

59. A straight, well developed, somewhat raised throat is
auspicious. One without flesh, with veins obvious, with hair
and irregular in built, is inauspicious.
Chin

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P343_B006_01

- 身份：正文
- PDF 页：343
- 偈颂：60
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 60 [present] · PDF page 343

60. Pink coloured, tender and firm chin is auspicious. A
broad chin with hair and clefts is unlucky.
Cheeks

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P343_B007_01

- 身份：正文
- PDF 页：343
- 偈颂：61
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 61 [present] · PDF page 343

61. Raised, firm and round cheeks which are hard skinned,
depressed and without flesh are indicative of misfortune.
Mouth

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P343_B008_01

- 身份：正文
- PDF 页：343
- 偈颂：62
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 62 [present] · PDF page 343

62. If the mouth of a woman is of normal size, firm, round
emitting fragrance, smooth and good-looking, it is indicative
of good luck. If otherwise, it will be inauspicious.

Lips

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P343_B009_01

- 身份：正文
- PDF 页：343
- 偈颂：63-65
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 63-65 [present] · PDF page 343

63-65. If the lower lip of a woman is red like a lotus,
smooth, divided in the middle and good looking, she becomes a
queen. If it be without flesh, coarse, long, dry, and
blackish it is indicative of misery and widowhood. If the
upper lip of a woman is pink coloured, smooth, and slightly
raised in the middle, it is indicative of happiness and good
fortune. If otherwise, it will be inauspicious.
Teeth

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P343_B010_01

- 身份：正文
- PDF 页：343
- 偈颂：66-67
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 66-67 [present] · PDF page 343

66-67. A woman whose teeth are smooth, milk white, 32 in
number and whose upper and lower teeth though equal in size
are slightly raised, will be lucky. If lower teeth are more
in number, are yellow or black coloured, fierce looking,
widely spaced and double, they are indicative of misfortune.
Tongue

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P344_B001_01

- 身份：正文
- PDF 页：344
- 偈颂：68-69
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 68-69 [present] · PDF page 344

68-69. If the tongue of a woman is red and soft, she enjoys
great happiness and comforts. Caved in the middle and spread
out in front indicates misery. White tongue indicates death
in water. Dark tongue indicates quarrelsome nature. Thick
tongue denotes poverty. Long tongue denotes one who is
omnivorous. Long and broad tongue denotes lunacy.
Palate

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P344_B002_01

- 身份：正文
- PDF 页：344
- 偈颂：70-71
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 70-71 [present] · PDF page 344

70-71. Red like lotus, soft, and smooth- good luck
White- widowhood
Yellow- ascetism
Black- barrenness
Dry- large family.
Laughter

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P344_B003_01

- 身份：正文
- PDF 页：344
- 偈颂：72
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 72 [present] · PDF page 344

72. When a woman laughs, if her cheeks are raised and teeth
are not visible, she will be lucky. If it is otherwise, she
will not be lucky.
Nose

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P344_B004_01

- 身份：正文
- PDF 页：344
- 偈颂：73-74
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 73-74 [present] · PDF page 344

73-74. If the nose of a woman is evenly round and has small
nostrils it is auspicious. If the nose is thick in its front
part and flat in the middle it is inauspicious.
If the tip of the nose is red or shrunken, widowhood is
indicated. Flat nose indicates engagement in a menial job
(maid servant). Too small or too large nose denotes
quarrel-some nature.
Eyes

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P344_B005_01

- 身份：正文
- PDF 页：344
- 偈颂：75-77
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 75-77 [present] · PDF page 344

75-77. Black pupils with cow's milk like white portion of the
eye, large and broad, smooth, with black eye lashes are lucky
rashis.
Raised eyes show short life. Round eyes denote loose moral
character. Honey coloured eyes indicate good fortune and
happiness. The eyes like those of a pigeon indicate
wickedness. Eyes like those of an elephant indicate misery.
If the left eye is blind, adulterous tendency will manifest.
Blindness of the right eye indicates barrenness.
Eye lashes

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P344_B006_01

- 身份：正文
- PDF 页：344
- 偈颂：78
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 78 [present] · PDF page 344

78. A woman with soft, black, compact eye lashes with thin
hair, is fortunate. Eye lashes thick, scattered and with
tawny coloured hair indicate misery.
Eye brows

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P344_B007_01

- 身份：正文
- PDF 页：344
- 偈颂：79
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 79 [present] · PDF page 344

79. If the eye brows of a woman are round, shaped like a bow,
smooth, black, not joined and with soft hair, she is blessed
with happiness and fame.
Ears

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P344_B008_01

- 身份：正文
- PDF 页：344
- 偈颂：80
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 80 [present] · PDF page 344

80. Ears of a woman long with a round turn indicate children
and happiness. Small, unevenly shaped, very thin, with veins
showing up cause her misery.
Fore head

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P345_B001_01

- 身份：正文
- PDF 页：345
- 偈颂：81-82
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 81-82 [present] · PDF page 345

81-82. The fore head of a woman without veins showing
through, without hair, shaped like a half moon, even, with
equal to three fingers, are rashis of a fortunate woman
blessed with husband and children. Rashi of swastika on the
fore head denotes a queen. Very long, highly raised and hairy
fore head causes misery.
Head

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P345_B002_01

- 身份：正文
- PDF 页：345
- 偈颂：83
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 83 [present] · PDF page 345

83. Head of a woman high and round like that of an elephant
is indicative of happiness. A head which is spread out, flat,
big and uneven indicates misery.
Hair

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P345_B003_01

- 身份：正文
- PDF 页：345
- 偈颂：84-85
- 标题路径：CHAPTER 81 Effects of the Characteristic Features of the
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Characteristic Features of the · Sloka 84-85 [present] · PDF page 345

84-85. The hair of a woman are indicative of good fortune. If
they are soft, black, long, thin and yellow, they indicate
misfortune. But honey coloured hair of a fair complexioned
woman and black hair of a dark complexioned woman are also
considered auspicious. Most of the characteristic features
described in this chapter apply to men also.
