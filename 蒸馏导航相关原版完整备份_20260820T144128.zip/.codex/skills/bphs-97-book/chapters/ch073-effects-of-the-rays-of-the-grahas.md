# 第 73 章：Effects of the Rays of the Grahas

- 来源：BPHS 97 章版
- 原始卡片：7 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P316_B002_01

- 身份：正文
- PDF 页：316
- 偈颂：1-2
- 标题路径：CHAPTER 73 Effects of the Rays of the Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Rays of the Grahas · Sloka 1-2 [present] · PDF page 316

1-2. The sage said: O Brahmin! Now I am going to tell you
about the number of rays of the grahas. When Surya, etc., are
in their deep exaltation point their rays are: Surya-10,
Chandr-9, Mangal-5, Buddh-5, Guru-7, Shukr-8, and Shani-5.
The rays are nil when these grahas are in deep debilitation,
the number of rays would be proportionate with the number of
rashi. The following method is to be adopted for ascertaining
the proportionate number of rays. Deduct the debilitation
rashi etc., of the grah whose rays are to be ascertained,
from his longitude. If the remainder is less than 6 rashis it
should be multiplied by the number of rays of that grah
mentioned above and the product should be divided by 6. The
result will denote the number of rays of that grah. In case
after deduction the remainder is more than 6 rashis, then it
should be deducted from 12. The other procedure will remain
the same.
Correction of the ascertained rays

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P316_B003_01

- 身份：正文
- PDF 页：316
- 偈颂：3-7
- 标题路径：CHAPTER 73 Effects of the Rays of the Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Rays of the Grahas · Sloka 3-7 [present] · PDF page 316

3-7. The Sage said: O Maitreya! other Acharyas have
recommended further correction of the number of rays worked
out in the manner described above. The corrections have to be
made as follows:
(I) If the grah be in his exaltation rashi the number of
rays ascertained should be trebled.
(2) If the grah be in his Mooltrikon, the number of rays
ascertained should be doubled.
(3) If he be in his own rashi, the number of rays ascertained
should be multiplied by 3 and the product be divided by 2.
(4)If he be in the  rashi of his Adhimitr (great friend), the
number of rays ascertained should be multiplied by 4 and the
product be divided by 3.
(5) If he be in the bhava of a friend the number of rays
should be multiplied by 6 and the product be divided by 5.
(6) The number of rays ascertained should be halved if the
grah be in the bhava of his enemy.
(7) If he be in the bhava of his Adhi-Shastru (great enemy),
the number of rays ascertained should be multiplied by 2 and
the product be divided by 5.
(8) No correction is to be made if the grah is in the bhava
of a neutral. The effects should be declared after
computation of the net number of rays of each grah.
Effects of rays of the grahas according to their number

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P316_B003_02

- 身份：正文
- PDF 页：316
- 偈颂：3-7
- 标题路径：CHAPTER 73 Effects of the Rays of the Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Rays of the Grahas · Sloka 3-7 [present] · PDF page 316

3-7. The Sage said: O Maitreya! other Acharyas have
recommended further correction of the number of rays worked
out in the manner described above. The corrections have to be
made as follows:
(I) If the grah be in his exaltation rashi the number of
rays ascertained should be trebled.
(2) If the grah be in his Mooltrikon, the number of rays
ascertained should be doubled.
(3) If he be in his own rashi, the number of rays ascertained
should be multiplied by 3 and the product be divided by 2.
(4)If he be in the  rashi of his Adhimitr (great friend), the
number of rays ascertained should be multiplied by 4 and the
product be divided by 3.
(5) If he be in the bhava of a friend the number of rays
should be multiplied by 6 and the product be divided by 5.
(6) The number of rays ascertained should be halved if the
grah be in the bhava of his enemy.
(7) If he be in the bhava of his Adhi-Shastru (great enemy),
the number of rays ascertained should be multiplied by 2 and
the product be divided by 5.
(8) No correction is to be made if the grah is in the bhava
of a neutral. The effects should be declared after
computation of the net number of rays of each grah.
Effects of rays of the grahas according to their number

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P317_B001_01

- 身份：正文
- PDF 页：317
- 偈颂：8-18
- 标题路径：CHAPTER 73 Effects of the Rays of the Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Rays of the Grahas · Sloka 8-18 [present] · PDF page 317

8-18. The effects produced by the number of rays of grahas
are given below:
Number of rays         Effects
Between 1 and 5    Poor and unhappy even if born in an
eminent family.
Between 6 and 10   Poor, carrier of loads and without wife
and children.
11  Meagre wealth and few children
12  Meagre wealth, idiot, and wicked
13  Thief
14  Wealthy, protector and maintainer of
several families, learned and observer
of the traditions of the family.
15  Head of the family, achieves proficiency
in many kinds of learnings, good
qualities. This is what lord Brahma has
said.
16  Most distinguished in the family.
17  Employer of many servants.
18  Maintainer of large family.
19  Possessor of name and fame.
20  Blessed with a large family and kinsmen.
21  Maintainer and protector of 50 persons.
22  Charitable and kind.
23  Well cultured and happy.
Between 24 and 30  Healthy, powerful, favourite of the king,
splendourous, possessor of a large family.
Between 31 and 40  Minister (high dignitary) and maintainer
and protector of 100 to 1000 persons.
Between 40 and 50  King (possesses a very high administrative
or political position).
51 and above  Powerful sovereign.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P317_B002_01

- 身份：正文
- PDF 页：317
- 偈颂：19
- 标题路径：CHAPTER 73 Effects of the Rays of the Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Rays of the Grahas · Sloka 19 [present] · PDF page 317

19. The effects should be predicted according to the number
of rays of the grahas at the time of birth, after taking into
account the status of the native.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P317_B003_01

- 身份：正文
- PDF 页：317
- 偈颂：20
- 标题路径：CHAPTER 73 Effects of the Rays of the Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Rays of the Grahas · Sloka 20 [present] · PDF page 317

20. For example, if the rays are more than 50 in number, one
born a Kshatriya king's family, will become a powerful
sovereign, one born in a Vaishy family, will become a king
(or high dignitary), one born in Sudra family, will become
wealthy, and one born in a Brahmin family, will become very
learned and will observe all religious norms.
21.The effects of the grahas moving from their debilitation
to exaltation are full. The effects of the grahas moving from
their exaltation to debilitation will be lesser than
described above.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P317_B004_01

- 身份：正文
- PDF 页：317
- 偈颂：22-23
- 标题路径：CHAPTER 73 Effects of the Rays of the Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Rays of the Grahas · Sloka 22-23 [present] · PDF page 317

22-23. Auspicious and inauspicious effects of all the grahas
are according to the number of rays they possess. The
prediction will not be correct without the knowledge of the
effects of the rays. Therefore, it is imperative that in the
judgment of rashi kundalis and declaring results, the effects
of the number of rays of the grahas be taken into account.
