# 第 96 章：Remedies from evil effects of unusual delivery

- 来源：BPHS 97 章版
- 原始卡片：4 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P371_B002_01

- 身份：正文
- PDF 页：371
- 偈颂：1-3
- 标题路径：CHAPTER 96 Remedies from evil effects of unusual delivery
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from evil effects of unusual delivery · Sloka 1-3 [present] · PDF page 371

1-3. The Sage said: O Brahmin! I will now tell you about
inauspicious and unusual deliveries by women which are
ominous for the village, town, and the country. These may be
of the following kinds:
(l) Delivery of a child 2, 3, or 4 months earlier or later
from the approximate due date.
(2) Delivery of a child without hands, feet, or any other
limbs, without head or with two heads.
(3) Delivery of an animal shaped being by a woman or a human
shaped being by an animal.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P371_B003_01

- 身份：正文
- PDF 页：371
- 偈颂：4-5
- 标题路径：CHAPTER 96 Remedies from evil effects of unusual delivery
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from evil effects of unusual delivery · Sloka 4-5 [present] · PDF page 371

4-5. Deliveries of these kinds by women or cows, etc., in a
house are ominous for all the members of the family living
there. Therefore, remedial measures are essential for
obtaining relief from their evil effects. The best remedial
measure will be to abandon (or turn out from the bhava) such
women and animals (cows, mares etc.).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P371_B004_01

- 身份：正文
- PDF 页：371
- 偈颂：6-9
- 标题路径：CHAPTER 96 Remedies from evil effects of unusual delivery
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from evil effects of unusual delivery · Sloka 6-9 [present] · PDF page 371

6-9. It is considered inauspicious for a girl to become
pregnant or to deliver a child in her 15th or 16th year from
birth. If a cow delivers when Surya is in Simh, or a female
buffalo delivers when Surya is in Makar, they are disasterous
to their owner and the person who looks after them.
Therefore, either such cow or buffalo should be given away to
a Brahmin or suitable remedial measures should be taken to
escape from the above mentioned evil effects. The remedial
measures to be adopted are the same as given in verses 3-9
in chapter 95 (previous chapter).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P371_B005_01

- 身份：正文
- PDF 页：371
- 偈颂：10
- 标题路径：CHAPTER 96 Remedies from evil effects of unusual delivery
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from evil effects of unusual delivery · Sloka 10 [present] · PDF page 371

10. Thus, whenever there is any kind if aristha, adoption of
appropriate remedial measures will ensure long life,
happiness, and prosperity for the person concerned.
