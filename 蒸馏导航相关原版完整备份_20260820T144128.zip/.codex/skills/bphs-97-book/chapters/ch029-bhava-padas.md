# 第 29 章：Bhava Padas

- 来源：BPHS 97 章版
- 原始卡片：32 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P093_B002_01

- 身份：正文
- PDF 页：93
- 偈颂：1-3
- 标题路径：CHAPTER 29 Bhava Padas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 1-3 [present] · PDF page 93

1-3. Method of Bhava Calculation : O  Brahmin, I shall now
tell you about the Padas (or Arudhas) for bhavas and grahas
as well, as laid down by the earlier Maharishis. The Pad of
Lagn will correspond to the rashi arrived at by counting so
many rashis from Lagn's lord as he is away from Tanu Bhava.
Similarly, Padas for other bhavas be known through their
lords. The word "Pad"exclusively denotes the Pad for Lagn
(or Lagn Pad).
(Names of the 12 Arudhas are:

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P093_B003_01

- 身份：正文
- PDF 页：93
- 偈颂：1
- 标题路径：CHAPTER 29 Bhava Padas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 1 [present] · PDF page 93

1. Lagn Pad (or simply Pad) : Arudh of Tanu Bhava.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P093_B004_01

- 身份：正文
- PDF 页：93
- 偈颂：2
- 标题路径：CHAPTER 29 Bhava Padas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 2 [present] · PDF page 93

2. Dhan Pad : Arudh of Dhan Bhava.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P093_B005_01

- 身份：正文
- PDF 页：93
- 偈颂：3
- 标题路径：CHAPTER 29 Bhava Padas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 3 [present] · PDF page 93

3. Vikram (Bhratru) Pad : Arudh of Sahaj Bhava.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P093_B006_01

- 身份：正文
- PDF 页：93
- 偈颂：4
- 标题路径：CHAPTER 29 Bhava Padas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 4 [present] · PDF page 93

4. Matru (Sukh) Pad : Arudh of Bandhu Bhava.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P093_B007_01

- 身份：正文
- PDF 页：93
- 偈颂：5
- 标题路径：CHAPTER 29 Bhava Padas › 5. Mantra or Putr Pad : Arudh of Putr Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 5 [present] · PDF page 93

5. Mantra or Putr Pad : Arudh of Putr Bhava

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P093_B008_01

- 身份：正文
- PDF 页：93
- 偈颂：6
- 标题路径：CHAPTER 29 Bhava Padas › 6. Rog or Satru Pad : Arudh of Ari Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 6 [present] · PDF page 93

6. Rog or Satru Pad : Arudh of Ari Bhava

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P093_B009_01

- 身份：正文
- PDF 页：93
- 偈颂：7
- 标题路径：CHAPTER 29 Bhava Padas › 7. Dar Pad (Kalatr Pad) : Arudh of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 7 [present] · PDF page 93

7. Dar Pad (Kalatr Pad) : Arudh of Yuvati Bhava

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P093_B010_01

- 身份：正文
- PDF 页：93
- 偈颂：8
- 标题路径：CHAPTER 29 Bhava Padas › 7. Dar Pad (Kalatr Pad) : Arudh of Yuvati Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 8 [present] · PDF page 93

8. Maran Pad : Arudh of Randhr Bhava.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P093_B011_01

- 身份：正文
- PDF 页：93
- 偈颂：9
- 标题路径：CHAPTER 29 Bhava Padas › 9. Pitru Pad : Arudh of Dharm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 9 [present] · PDF page 93

9. Pitru Pad : Arudh of Dharm Bhava

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P093_B012_01

- 身份：正文
- PDF 页：93
- 偈颂：10
- 标题路径：CHAPTER 29 Bhava Padas › 9. Pitru Pad : Arudh of Dharm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 10 [present] · PDF page 93

10. Karm Pad : Arudh of Karm Bhava.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P093_B013_01

- 身份：正文
- PDF 页：93
- 偈颂：11
- 标题路径：CHAPTER 29 Bhava Padas › 9. Pitru Pad : Arudh of Dharm Bhava
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 11 [present] · PDF page 93

11. Labh Pad : Arudh of Labh Bhava.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P093_B014_01

- 身份：正文
- PDF 页：93
- 偈颂：12
- 标题路径：CHAPTER 29 Bhava Padas › 12. Vyaya Pad : Arudh of Vyaya Bhava. )
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 12 [present] · PDF page 93

12. Vyaya Pad : Arudh of Vyaya Bhava. )

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P093_B015_01

- 身份：正文
- PDF 页：93
- 偈颂：4-5
- 标题路径：CHAPTER 29 Bhava Padas › 12. Vyaya Pad : Arudh of Vyaya Bhava. )
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 4-5 [present] · PDF page 93

4-5. Special Exceptions: The same bhava or the 7th from it
does not become its Pad. When the Pad falls in the same
bhava, the 10th there from be treated as its Pad.
Similarly, when the 7th becomes the Pad of a bhava, the 4th
from the original bhava in question be treated as its Pad.
If the ruler of a bhava be in the 4th from the bhava, then
the very bhava occupied be noted as the Pad.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P093_B016_01

- 身份：正文
- PDF 页：93
- 偈颂：6-7
- 标题路径：CHAPTER 29 Bhava Padas › 12. Vyaya Pad : Arudh of Vyaya Bhava. )
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 6-7 [present] · PDF page 93

6-7. Padas for Grahas: Note the position of a grah and see
how many rashis away is its own rashi with reference to its
position. Count so many rashis from the said own rashi and
the resultant rashi will become the Arudh of the grah. If a
grah owns two rashis or if a rashi is owned by two grahas;
consider the stronger and declare effects accordingly.
~(&I11)Lp+(!11D&)Lp~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P094_B001_01

- 身份：正文
- PDF 页：94
- 偈颂：8-11
- 标题路径：CHAPTER 29 Bhava Padas › 12. Vyaya Pad : Arudh of Vyaya Bhava. )
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 8-11 [present] · PDF page 94

8-11. Pad and Finance: (up to sloka 15) O Brahmin, I now
tell you of some effects of grahas based on Pad. If the
11th from Lagn Pad is occupied or receives a drishti from a
grah the native will be happy and rich;
~(BI11)Lp+(!11DB)Lp~
wealth will come through various means if a benefic is
related as above.
~(mI11)Lp+(!11Dm)Lp~n
A malefic will confer wealth through questionable means.
~(BI11)Lp+(!11DB)Lp**(mI11)Lp+(!11Dm)Lp~m
If there be both a benefic and a malefic, it wil be through
both means.
~(EI11)Lp+(!11DE)Lp+(OI11)Lp+(!11DO)Lp~
If the grah in question (i.e. the one so related to the
11th from Lagn Pad) be in exaltation or in own rashi, etc.,
there will be plenty of gains and plenty of happiness.
~-(!12D&)Lp*(!11D&)Lp~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P094_B002_01

- 身份：正文
- PDF 页：94
- 偈颂：12
- 标题路径：CHAPTER 29 Bhava Padas › 12. Vyaya Pad : Arudh of Vyaya Bhava. )
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 12 [present] · PDF page 94

12. 0 excellent of the Brahmins, if the 12th from Lagn Pad
does not receive a drishti as the 11th from Lagn Pad
receives a drishti from a grah, then, the gains will be
uninterrupted.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P094_B003_01

- 身份：正文
- PDF 页：94
- 偈颂：13-15
- 标题路径：CHAPTER 29 Bhava Padas › 12. Vyaya Pad : Arudh of Vyaya Bhava. )
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 13-15 [present] · PDF page 94

13-15. 0 Brahmin, the quantum of gains will correspond to
the number of grahas in or giving a drishti to the 11th
from Lagn Pad. If there is Argala for the said 11th there
will be more gains, while a benefic Argala will bring still
more gains. If the said benefic causing Argala is in his
exaltation rashi, the gains will be still higher. If the
said 11th receives a drishti from a benefic from Lagn, the
9th, etc., gains will increase in the ascending order. In
all these cases, the 12th from Pad should simultaneously be
free from malefic association.
~LaI9*BI1+LaI7*5I1+LaI11*5I1~
A benefic placed in Lagn giving a drishti to the 11th from
Arudh Lagn will be still beneficial.
~LaI5*BI9+LaI7*5I9+LaI3*5I9~
If the drishti is from the 9th from Lagn, it will confer
much more gains.
~(!12DB)Lp+(!12Dm)Lp+(mI12)Lp+(BI12)Lp~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P094_B004_01

- 身份：正文
- PDF 页：94
- 偈颂：16-17
- 标题路径：CHAPTER 29 Bhava Padas › 12. Vyaya Pad : Arudh of Vyaya Bhava. )
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 16-17 [present] · PDF page 94

16-17. Pad and Financial Losses: (up to sloka 21): If the
12th from Lagn Pad receives a drishti from or is yuti with
both benefics and malefics, there will be abundant earnings
but plenty of expenses, The benefic will cause through fair
means, malefic through unfair means and mixed grahas
through both fair and unfair means.
~(1I12)Lp*(6I12)Lp*(8I12)Lp~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P094_B005_01

- 身份：正文
- PDF 页：94
- 偈颂：18
- 标题路径：CHAPTER 29 Bhava Padas › 12. Vyaya Pad : Arudh of Vyaya Bhava. )
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 18 [present] · PDF page 94

18. If the 12th from Lagn Pad is conjunct Surya, Shukr, and
Rahu, there will be loss of wealth through the king.
~1D2*(1I12)Lp*(6I12)Lp*(8I12)Lp~n
Chandr giving a drishti to (the said trio in the said
bhava) will specifically cause more such losses.
~(4I12)Lp*4DB+(4I12)Lp*4YB~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P095_B001_01

- 身份：正文
- PDF 页：95
- 偈颂：19
- 标题路径：CHAPTER 29 Bhava Padas › 12. Vyaya Pad : Arudh of Vyaya Bhava. )
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 19 [present] · PDF page 95

19. If Buddh is in the 12th from Lagn Pad and is yuti with
or receives a drishti from a benefic similarly there will
be expenses through paternal relatives.
~(4I12)Lp*4Dm+(4I12)Lp*4Ym~n
A malefic so related to the said Buddh will cause loss of
wealth through disputes.
~(5I12)Lp*5DB+(5I12)Lp*5Dm~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P095_B002_01

- 身份：正文
- PDF 页：95
- 偈颂：20
- 标题路径：CHAPTER 29 Bhava Padas › 12. Vyaya Pad : Arudh of Vyaya Bhava. )
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 20 [present] · PDF page 95

20. 0 Brahmin, if Guru is in the 12th from Lagn Pad,
receiving a drishti from others, the expenses will be
through taxes and on the person himself.
~(7I12)Lp*7Y3*7D&~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P095_B003_01

- 身份：正文
- PDF 页：95
- 偈颂：21
- 标题路径：CHAPTER 29 Bhava Padas › 12. Vyaya Pad : Arudh of Vyaya Bhava. )
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 21 [present] · PDF page 95

21. 0 Brahmin, if Shani is in the 12th from Lagn Pad along
with Mangal and receives a drishti from others, the
expenses will be through one's co-born.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P095_B004_01

- 身份：正文
- PDF 页：95
- 偈颂：22
- 标题路径：CHAPTER 29 Bhava Padas › 12. Vyaya Pad : Arudh of Vyaya Bhava. )
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 22 [present] · PDF page 95

22. Gainful Sources: Whatever sources of expenses are
indicated above with reference to the 12th from Lagn Pad,
gains through similar sources will occur if Labh Bhava so
features with reference to Lagn Pad.
~(8I7)Lp+(9I7)Lp+(8I2)Lp+(9I2)Lp~n

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P095_B005_01

- 身份：正文
- PDF 页：95
- 偈颂：23
- 标题路径：CHAPTER 29 Bhava Padas › 12. Vyaya Pad : Arudh of Vyaya Bhava. )
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 23 [present] · PDF page 95

23. The 7th Bhava from Pad (up to sloka 27): If Rahu or
Ketu is placed in the 7th from Lagn Pad, the native will be
troubled by disorders of the stomach, or by fire.
~(9I7)Lp*9Dm+(9I7)Lp*9Ym+(9I2)Lp*9Dm+(9I2)Lp*9Ym~m

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P095_B006_01

- 身份：正文
- PDF 页：95
- 偈颂：24
- 标题路径：CHAPTER 29 Bhava Padas › 12. Vyaya Pad : Arudh of Vyaya Bhava. )
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 24 [present] · PDF page 95

24. Should there be Ketu in the 7th from Lagn Pad receiving
a drishti from or being yuti with another malefic, the
native will be adventurous, will have (prematurely) grey
hair and a big male organ.
~(5I7)Lp+(6I7)Lp+(2I7)Lp~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P095_B007_01

- 身份：正文
- PDF 页：95
- 偈颂：25
- 标题路径：CHAPTER 29 Bhava Padas › 12. Vyaya Pad : Arudh of Vyaya Bhava. )
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 25 [present] · PDF page 95

25. Should one, two, or all three of Guru, Shukr, and
Chandr be in the 7th from Lagn Pad, the native will be very
wealthy.
~(EI7)Lp+(EI2)Lp~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P095_B008_01

- 身份：正文
- PDF 页：95
- 偈颂：26
- 标题路径：CHAPTER 29 Bhava Padas › 12. Vyaya Pad : Arudh of Vyaya Bhava. )
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 26 [present] · PDF page 95

26. Whether a benefic or a malefic if be exalted in the 7th
from Lagn Pad, the native will be affluent, and be famous.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P095_B009_01

- 身份：正文
- PDF 页：95
- 偈颂：27
- 标题路径：CHAPTER 29 Bhava Padas › 12. Vyaya Pad : Arudh of Vyaya Bhava. )
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 27 [present] · PDF page 95

27. O Brahmin, these yogas as narrated by me with reference
to the 7th from Lagn Pad should also be considered from the
2nd of Lagn Pad.
~4E*(4I2)Lp*4X+5E*(5I2)Lp*5X+6E*(6I2)Lp*6X~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P095_B010_01

- 身份：正文
- PDF 页：95
- 偈颂：28
- 标题路径：CHAPTER 29 Bhava Padas › 12. Vyaya Pad : Arudh of Vyaya Bhava. )
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 28 [present] · PDF page 95

28. Anyone of Buddh, Guru, and Shukr being exalted in the
2nd from Lagn Pad and being with strength, will make the
subject rich.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P095_B011_01

- 身份：正文
- PDF 页：95
- 偈颂：29
- 标题路径：CHAPTER 29 Bhava Padas › 12. Vyaya Pad : Arudh of Vyaya Bhava. )
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 29 [present] · PDF page 95

29. The yogas so far stated by me with reference to Lagn
Pad be similarly evaluated from Karakamsh as well.
~(4I2)La~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P096_B001_01

- 身份：正文
- PDF 页：96
- 偈颂：30-37
- 标题路径：CHAPTER 29 Bhava Padas › 12. Vyaya Pad : Arudh of Vyaya Bhava. )
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Bhava Padas · Sloka 30-37 [present] · PDF page 96

30-37. General: If Buddh is in the 2nd from Arudh Lagn, the
native will lord over the whole country.
~(6I2)Lp~
Shukr in the 2nd from Lagn Pad will make one a poet or a
speaker.
~(LdK)Lp+(LdK)Lp+XILp*XILd~
If the Dar Pad (i e. the Pad of Yuvati Bhava) falls in an
angle or in a trine counted from Lagn Pad or if Lagn Pad
and Dar Pad both have strong grahas, the native will be
rich and be famous in his country.
~(LdI6)Lp+(LdI8)Lp+(LdI12)Lp~n
If the Dar Pad falls in the 6th/ 8th/12th from Lagn Pad,
then the native will be poor.
If Lagn Pad and the 7th there from or an angle, a trine, an
Upachaya there from is occupied by a strong grah, there
will be happiness between the husband and wife.
~(LdK)Lp*(LpK)Ld+(LdT)Lp*(LpT)Ld~
If Lagn Pad and Dar Pad are mutually in Kendras or Konas,
there will be amity between the couple;
~(LdI6)Lp+(LdI8)Lp+(LdI12)Lp+(LdI2)Lp~
if these be in mutually 6th/8th/12th, doubtlessly mutual
enmity will crop up. O Brahmin, similarly, mutual
relationship, or gain, or loss through son, etc., be known
based on Lagn Pad and the relative Bhava Pad.
~(LpK)Ld+(Lpi3)Ld+(LpI11)Ld+(LpT)Ld~
If Lagn Pad and Dar Pad are mutually angular or 3rd and
11th or in Konas, the native will be a king ruling the
earth.
Similar deductions be made with reference to mutual
positions of Lagn Pad and Dhan Pad.
