# 第 56 章：Effects of the Antar Dashas in the Dasha of

- 来源：BPHS 97 章版
- 原始卡片：36 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P241_B002_01

- 身份：正文
- PDF 页：241
- 偈颂：—
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka unknown [unknown] · PDF page 241 · page_block BPHS_PL9_CHAP_97_P241_B002

Guru
@5152@
Effects of the Antar Dasha of Guru in the Dasha of Guru
~5E+5O+5K+5T~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P241_B003_01

- 身份：正文
- PDF 页：241
- 偈颂：1-3 1/2
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 1-3 1/2 [present] · PDF page 241

1-3 1/2. Effects like sovereignty over many kings, very
well endowed with riches, revered by the king, gains of
cattle, clothes, ornaments, conveyances, construction of a
new house, and a decent mansion, opulence and glory, dawn
of fortune, success in ventures, meetings with Brahmins and
the king, extraordinary profits from the employer and
happiness to wife and  children, will be experienced in the
Antar Dasha of Guru in his own Dasha, if Guru is in his
Exaltation Rashi, in his own Rashi, in a Kendr, or in a
Trikon (from Lagn).
~5d+5Nd+5I6+5I12+5I8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P241_B004_01

- 身份：正文
- PDF 页：241
- 偈颂：4-5 1/2
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 4-5 1/2 [present] · PDF page 241

4-5 1/2. Association with the menials, great distress,
slander by coparceners, wrath of the employer, danger of
premature death, separation from wife and children, and
loss of wealth and grains will be the results, if Guru is
in his Debilitation Rashi, in his debilitated Navamsh, or
in Ari, Randhr, or Vyaya Bhava.
~5iL2+5iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P241_B005_01

- 身份：正文
- PDF 页：241
- 偈颂：6-7
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 6-7 [present] · PDF page 241

6-7. There will be pains in the body if Guru is the lord of
Yuvati Bhava (or of Dhan Bhava).
The remedial measure to obtain relief from the above evil
effects and to get fulfillment of ambitions, is recitation
of Rudr Japa and Shiva Sahasranam.
@5172@
Effects of the Antar Dasha of Shani in the Dasha of Guru
~7X**7E+7O+7K+7T~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P241_B006_01

- 身份：正文
- PDF 页：241
- 偈颂：8-11 1/2
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 8-11 1/2 [present] · PDF page 241

8-11 1/2. Effects like acquisition of a kingdom (attainment
of a high position in government), gain of clothes,
ornaments, wealth, grains, conveyances, cattle, and
position, happiness from son and friends, etc., gains
specially of a blue coloured horse, journey to the West,
audience with the king, and receipt of wealth from him,
will be derived in the Antar Dasha of Shani in the Dasha of
Guru, if Shani is in his Exaltation Rashi, in his own
Rashi, in a Kendr or Trikon endowed with strength.
~7I6+7I8+7I12+7c+7e~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P241_B007_01

- 身份：正文
- PDF 页：241
- 偈颂：12-14
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 12-14 [present] · PDF page 241

12-14. Loss of wealth, affliction with fever, mental agony,
infliction of wounds to wife and children, inauspicious
events at home, loss of cattle and employment, antagonism
with kinsmen, etc., will be results if Shani is in Ari,
Randhr, or Vyaya Bhava, if Shani is combust, or if Shani is
in an enemy's Rashi.
~(7I!K)5+(7I!T)5+(7I11)5+(7I2)5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P241_B008_01

- 身份：正文
- PDF 页：241
- 偈颂：15-15 1/2
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 15-15 1/2 [present] · PDF page 241

15-15 1/2. There will be gain of land, house, son, and
cattle, acquisition of riches and property through the
enemy, etc., if Shani is in Kendr, Trikon, the 11th, or
in the 2nd from the lord of the Dasha (Guru).
~(7Ia)5+7Am~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P242_B001_01

- 身份：正文
- PDF 页：242
- 偈颂：16-17
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 16-17 [present] · PDF page 242

16-17. Effects like loss of wealth, antagonistic relations
with kinsmen, obstacles in industrial ventures, pains in
the body, danger from the members of the family, etc., will
be realized if Shani is in the 6th, in the 8th, or in the
12th from the lord of the Dasha (Guru), or if Shani is
associated with a malefic.
~7iL2+7iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P242_B002_01

- 身份：正文
- PDF 页：242
- 偈颂：18-19
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 18-19 [present] · PDF page 242

18-19. There will be fear of premature death, if Shani is
Dhan's lord or Yuvati's lord.
The remedial measures to obtain relief from these evil
effects and to enjoy sound health, are recitation of Vishnu
Sahasranam and giving in charity a black cow or a female
buffalo.
@5142@
Effects of the Antar Dasha of Buddh in the Dasha of Guru.
~4E+4O+4K+4T+4A5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P242_B003_01

- 身份：正文
- PDF 页：242
- 偈颂：20-21 1/2
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 20-21 1/2 [present] · PDF page 242

20-21 1/2. Effects like gains of wealth, bodily felicity,
acquisition of a kingdom (attainment of a high position in
the government), gain of conveyances, clothes, and cattle
etc., will be derived in the Antar Dasha of Buddh in the
Dasha of Guru, if Buddh is in his Exaltation Rashi, in his
own Rashi, or in Kendr, in Trikon, or if Buddh is associated
with the lord of the Dasha (Guru).
~4D3~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P242_B004_01

- 身份：正文
- PDF 页：242
- 偈颂：22-22 1/2
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 22-22 1/2 [present] · PDF page 242

22-22 1/2. There will be increase in the number of enemies,
loss of enjoyment and comforts, loss in business,
affliction with fever and dysentery, if Buddh receives a
drishti from Mangal.
~(4I!K)5+(4I!T)5+4E~
23-24 Gains of wealth in his own country, happiness from
parents, and acquisition of conveyances by the beneficence
of the king (Government), will result if Buddh is in a
Kendr, in the 5th, or in the 9th from the lord of the Dasha
or if Buddh is in his Exaltation Rashi.
~(4Ia)5+4Am*-4DB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P242_B005_01

- 身份：正文
- PDF 页：242
- 偈颂：25-26
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 25-26 [present] · PDF page 242

25-26. There will be loss of wealth, journeys to foreign
countries, danger from thieves while traveling, wounds,
burning sensations, eye troubles, wanderings in foreign
lands, if Buddh is in the 6th, the 8th, or the 12th from
the lord of the Dasha (Guru) or if Buddh is associated with
a malefic without receiving a drishti from a benefic.
~7Am*7I6+7Am*7I8+7Am*7I12~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P242_B006_01

- 身份：正文
- PDF 页：242
- 偈颂：27-28
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 27-28 [present] · PDF page 242

27-28. Distress without reason, anger, loss of cattle, loss
in business, fear of premature death etc., will be the
results if Buddh be associated with a malefic or malefics
in Ari, in Randhr, or in Vyaya Bhava.
~7Am*7DB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P242_B007_01

- 身份：正文
- PDF 页：242
- 偈颂：29-29 1/2
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 29-29 1/2 [present] · PDF page 242

29-29 1/2. There will be enjoyment, gains of wealth
conveyances and clothes at the commencement of the Antar
Dasha, even if Buddh is associated with a malefic but
receives a drishti from a benefic. At the end of the Dasha,
however, there will be loss of wealth and bodily distress.
~7iL2+7iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P243_B001_01

- 身份：正文
- PDF 页：243
- 偈颂：30-31
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 30-31 [present] · PDF page 243

30-31. Premature death maybe expected if Buddh is Dhan's
lord or Yuvati's lord.
The most effective and beneficial remedial measure for
prolongation of longevity and to obtain relief from other
evil effects is recitation of Vishnu Sahasranam.
~(7I6)5+(7I8)5+(7I12)5+7Am*-7DB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P243_B002_01

- 身份：正文
- PDF 页：243
- 偈颂：25-26
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 25-26 [present] · PDF page 243

25-26. There will be loss of wealth, journeys to foreign
countries, danger from thieves while traveling, wounds,
burning sensations, eye troubles, wanderings in foreign
lands, if Buddh be in the 6th, the 8th or the 12th from the
lord of Dasha (Guru) or be associated with a malefic
without the aspect of a benefic.
@5192@
Effects of the Antar Dasha of Ketu in the Dasha of Guru
~9AB+9DB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P243_B003_01

- 身份：正文
- PDF 页：243
- 偈颂：32-32 1/2
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 32-32 1/2 [present] · PDF page 243

32-32 1/2. Moderate enjoyment, moderate gain of wealth,
coarse food or food given by others, food given at the time
of death ceremonies and acquisition of wealth though
undesirable means, will be the results, in the Antar Dasha
of Ketu in the Dasha of Guru, if Ketu is associated with or
receives a drishti from a benefic.
~(9I6)5+(9I8)5+(9I12)5+5Am~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P243_B004_01

- 身份：正文
- PDF 页：243
- 偈颂：33-34
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 33-34 [present] · PDF page 243

33-34. Effects like loss of wealth by the wrath of the
king, imprisonment, diseases, loss of physical strength,
antagonism with father and brother and mental agony, will
be experienced if Ketu be in the 6th, the 8th or the 12th
from the lord of the Dasha or be associated with malefics.
~(9I5)5+(9I9)5+(9I4)5+(9I10)5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P243_B005_01

- 身份：正文
- PDF 页：243
- 偈颂：35-36 1/2
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 35-36 1/2 [present] · PDF page 243

35-36 1/2. Acquisition of a palanquin (motor car),
elephants, etc., beneficence of the king, success in the
desired spheres, profits in business, increase in the
number of cattle, gain of wealth, clothes, etc., from a
Yavana king (Muslim dignitary), will be the auspicious
effects if Ketu is in the 5th, the 9th, the 4th or the 10th
from the lord of the Dasha (Guru).
~9iL2+9iL7+9I2+9I7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P243_B006_01

- 身份：正文
- PDF 页：243
- 偈颂：37-38
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 37-38 [present] · PDF page 243

37-38. There will be physical distress if Ketu is Dhan's
lord or Yuvati's lord (or if Ketu is in Dhan or in Yuvati
Bhava.
The remedial measure to obtain relief from the above evil
effects is performance of Mrityunjaya Japa in the
prescribed manner.
@5162@
Effects of the Antar Dasha of Shukr in the Dasha of Guru
~6K*6DB+6T*6DB+6I11*6DB+6O*6DB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P244_B001_01

- 身份：正文
- PDF 页：244
- 偈颂：39-43
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 39-43 [present] · PDF page 244

39-43. Effects like acquisition of conveyances like
palanquin, elephants, etc., gain of wealth by the
beneficence of the king (government), enjoyment, gain of
blue and red articles, extraordinary income from journeys
to the East, well-being in the family, happiness from
parents, devotion to deities, construction of reservoirs,
charities, etc., will be derived in the Antar Dasha of
Shukr if Shukr is in a Kendr, in a Trikon, or in Labh
Bhava, or if Shukr is in his own Rashi  and receives a
drishti from a benefic or from benefics.
~6I6+6I8+6I12+(6I6)5+(6I8)5+(6I12)5+6d~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P244_B002_01

- 身份：正文
- PDF 页：244
- 偈颂：44-44 1/2
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 44-44 1/2 [present] · PDF page 244

44-44 1/2. Evil effects like quarrels, antagonism with
kinsmen, distress to wife and children, will be felt if
Shukr is in the 6th, in the 8th, or the 12th from the lord
of the Dasha or lagn, or if Shukr is in his Debilitation
Rashi.
~6A7+6A8~
There will be quarrels, danger from the king (government),
antagonism with the wife, disputes with the father-in-law
and with brothers, loss of wealth, etc., if Shukr is
associated with Shani or with Rahu, or with both.
~(6I!K)5+(6I!T)5+(6I2)5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P244_B003_01

- 身份：正文
- PDF 页：244
- 偈颂：45-47 1/2
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 45-47 1/2 [present] · PDF page 244

45-47 1/2. There will be gain of wealth, happiness from
wife, meeting with the king (high governmental officials),
increase in the number of children, conveyances and cattle,
enjoyment of music, society with men of learning,
availability of sweetish  preparations, giving help and
assistance to kinsmen, etc., if Shukr is in a Kendr, in a
Trikon, or in the 2nd from the lord of the Dasha (Guru).
~6iL2+6iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P244_B004_01

- 身份：正文
- PDF 页：244
- 偈颂：48-50
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 48-50 [present] · PDF page 244

48-50. Loss of wealth, fear of premature death, antagonism
with wife, etc., will be experienced if Shukr is Dhan's
lord or Yuvati's lord.
The remedial measure to obtain relief from these evil
effects is giving a tawny coloured cow or a female buffalo
in charity.
@5112@
Effects of the Antar Dasha of Surya in the Dasha of Guru
~1E*1X+1O*1X+1K*1X+1T*1X+1I3*1X+1I11*1X+1I2*1X~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P244_B005_01

- 身份：正文
- PDF 页：244
- 偈颂：51-53
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 51-53 [present] · PDF page 244

51-53. Gain of wealth, reverence, happiness and acquisition
of conveyances, clothes, ornaments, etc., birth of
children, cordial relations with the king (government),
success in ventures, etc., will be the auspicious results
in the Antar Dasha of Surya in the Dasha of Guru, if Surya
is in his Exaltation Rashi, in his own Rashi, in a Kendr,
in a Trikon, or in Sahaj, Labh, or Dhan Bhava and be
endowed with strength.
~1I6+1I8+1I12+(1I6)5+(1I8)5+(1I12)5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P244_B006_01

- 身份：正文
- PDF 页：244
- 偈颂：54-55 1/2
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 54-55 1/2 [present] · PDF page 244

54-55 1/2. Effects like nervous disorder, fever, laziness
or reluctance in the performance of good deeds, indulgence
in sins, antagonistic attitude towards all, separation from
kinsmen, and distress without reasons, will be experienced
if Surya is in Ari, in Randhr, or in Vyaya Bhava, or if
Surya is in the 6th, in the 8th, or in the 12th from the
lord of the Dasha (Guru).
~1iL2+1iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P245_B001_01

- 身份：正文
- PDF 页：245
- 偈颂：56-57
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 56-57 [present] · PDF page 245

56-57. There will be physical distress if Surya is Dhan's
lord or Yuvati's lord.
The remedial measure to obtain relief from the above evil
effects and to enjoy good health is recitation of Adhitya
Hridaya Path.
@5122@
Effects of the Antar Dasha of Chandr in the Dasha of Guru
~2K+2T+2I11+2E+2O+(2I!K)5*2P*2X+(2I!T)5*2P*2X~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P245_B002_01

- 身份：正文
- PDF 页：245
- 偈颂：58-60 1/2
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 58-60 1/2 [present] · PDF page 245

58-60 1/2. Effects like reverence from the king
(government), opulence and glory, happiness from wife and
children, availability of good food, gain of reputation by
performance of good deeds, increase in the number of
children and grand children, comforts by the beneficence of
the king (government), religious and charitable
inclinations, etc., will be derived in the Antar Dasha of
Chandr in the Dasha of Guru, if Chandr is in a Kendr, in a
Trikon, or in Labh Bhava, or if Chandr is in her Exaltation
Rashi, or in her own Rashi, and if Chandr is full and
strong and in an auspicious bhava from the lord of the
Dasha (Guru).
~2v+2Am+2I6+2I8+2I12+(2I6)5+(2I8)5+(2I12)5~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P245_B003_01

- 身份：正文
- PDF 页：245
- 偈颂：61-63
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 61-63 [present] · PDF page 245

61-63. There will be loss of wealth and  kinsmen,
wanderings in foreign lands, danger from the king
(government) thieves, quarrels with co-parceners,
separation from a maternal uncle, distress to mother, etc.,
if Chandr is weak or is associated with malefics, or if
Chandr is in Ari, in Randhr, or in Vyaya Bhava, or if
Chandr is in the 6th, the 8th, or the 12th from the lord
of the Dasha (Guru).
~2iL2+2iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P245_B004_01

- 身份：正文
- PDF 页：245
- 偈颂：64
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 64 [present] · PDF page 245

64. Physical distress will be experienced if Chandr is
Dhan's lord or Yuvati's lord.
The remedial measure to obtain relief from the above
effects is Durga Saptashati Path.
@5132@
Effects of the Antar Dasha of Mangal in the Dasha of Guru
~3E+3O+3NO+3NE~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P245_B005_01

- 身份：正文
- PDF 页：245
- 偈颂：65-66
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 65-66 [present] · PDF page 245

65-66. Effects like the celebration of functions such as
marriage, etc., gain of land or villages, growth of
strength and valour, and success in all ventures, will be
derived in the Antar Dasha of Mangal in the Dasha of Guru,
if Mangal is in his Exaltation Rashi, in his own Rashi, or
in his exalted or own Navamsh.
~3K+3T+3I11+3I2**3AB+3DB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P245_B006_01

- 身份：正文
- PDF 页：245
- 偈颂：67-68
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 67-68 [present] · PDF page 245

67-68. There will be gain of wealth and grains,
availability of good sweetish preparations, pleasure of the
king (government), happiness from wife and children and
other auspicious effects, if Mangal is in a Kendr, in a
Trikon, in Labh, or in Dhan Bhava and is associated with,
or receives a drishti from benefics.
~(3I8)5+(3I12)5+3d*3Am+3d*3Dm~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P246_B001_01

- 身份：正文
- PDF 页：246
- 偈颂：69-71
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 69-71 [present] · PDF page 246

69-71. Loss of wealth and house, eye trouble and other
inauspicious effects will be the results, if Mangal is in
the 8th or in the 12th from the lord of the Dasha (Guru),
or if Mangal is in his Debilitation Rashi associated with,
or receiving a drishti from malefics. The effects will be
particularly adverse at the commencement of the Antar
Dasha. There will be some mitigation of evil effects
later.
~3iL2+3iL7~
There will be physical distress and mental agony if Mangal
is the lord of Dhan or Yuvati Bhava.
The remedial measure to obtain relief from the above evil
effects and to get gains of wealth and property, is to give
a bull in charity.
@5182@
Effects of the Antar Dasha of Rahu in the Dasha of Guru
~8E+8O+8M+8K+8T+8DL1+8DL4+8DL7+8DL10+8AB+8DB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P246_B002_01

- 身份：正文
- PDF 页：246
- 偈颂：72-75
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 72-75 [present] · PDF page 246

72-75. Effects like attachment to Yog, gain of wealth and
grains during the first five months, sovereignty over a
village or country, meeting with a foreign king (high
dignitary), well-being in the family, journeys to distant
lands, bathing in holy places, will be derived in the Antar
Dasha of Rahu in the Dasha of Guru, if Rahu is in his
Exaltation Rashi, in his own Rashi, in his Multrikon, or if
Rahu is in a Kendr or in a Trikon (from Lagn) or if Rahu
receives a drishti from the lord of a Kendr or if Rahu is
associated with or receives a drishti from a benefic.
~(8I8)5*8Am+(8I12)5*8Am~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P246_B003_01

- 身份：正文
- PDF 页：246
- 偈颂：76-78
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 76-78 [present] · PDF page 246

76-78. Danger from thieves, snakes, the king (government),
wounds, troubles in domestic affairs, antagonism with
co-borns, and coparceners, bad dreams,quarrels without
reason,danger from diseases, etc., will result if Rahu is
associated with a malefic, if Rahu is in the 8th, or in the
12th from the lord of the Dasha (Guru).
~8I2+8I7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P246_B004_01

- 身份：正文
- PDF 页：246
- 偈颂：79-80
- 标题路径：CHAPTER 56 Effects of the Antar Dashas in the Dasha of › Guru @5152@ Effects of the Antar Dasha of Guru in the Dasha of Guru ~5E+5O+5K+5T~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 79-80 [present] · PDF page 246

79-80. There will be physical distress if Rahu is in Dhan
or in Yuvati Bhava.
The remedial measures to obtain relief from the above evil
effects are Mrityunjaya Japa and giving a goat in charity.
