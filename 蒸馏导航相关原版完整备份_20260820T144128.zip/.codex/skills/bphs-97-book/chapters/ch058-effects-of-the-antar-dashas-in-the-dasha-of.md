# 第 58 章：Effects of the Antar Dashas in the Dasha of

- 来源：BPHS 97 章版
- 原始卡片：34 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P254_B002_01

- 身份：正文
- PDF 页：254
- 偈颂：—
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka unknown [unknown] · PDF page 254 · page_block BPHS_PL9_CHAP_97_P254_B002

Buddh
@4142@
Effects of the Antar Dasha of Buddh in the Dasha of Buddh
~4E+4O+4M+4G*-4Ia*-4Am~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P254_B003_01

- 身份：正文
- PDF 页：254
- 偈颂：1-3 1/2
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 1-3 1/2 [present] · PDF page 254

1-3 1/2. Gain of jewels like pearls, etc., learning,
increase in happiness and performance of pious deeds,
success in the educational sphere, acquisition of name and
fame, meeting with new kings (high dignitaries), gain of
wealth, and happiness from wife, children and parents will
be the effects in the Antar Dasha of Buddh in his own
Dasha, if Buddh is placed in his Exaltation Rashi, or is
otherwise well placed.
~4d+4g+4e+4I6+4I8+4I12+4Am~
There will be loss of wealth and cattle, antagonism with
kinsmen, diseases like stomach pains, piety in discharging
duties as a government official, if Buddh is in his
Debilitation Rashi, etc., or if Buddh is in Ari, Randhr, or
Vyaya Bhava, or if Buddh is associated with malefics.
~4Li2+4Li7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P254_B004_01

- 身份：正文
- PDF 页：254
- 偈颂：4-5
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 4-5 [present] · PDF page 254

4-5. Distress to wife, death of members of the family,
affliction with diseases like rheumatism and stomach pains,
etc., will result if Buddh is Dhan's lord or Yuvati's
lord.
Remedial measure to obtain relief from the above evil
effects, is recitation of Vishnu Sahasranam.
@4192@
Effects of the Antar Dasha of Ketu in the Dasha of Buddh
~9AB*9K+9AB*9T+9YL1+9Yy+(9I!K)4+(9I11)4~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P254_B005_01

- 身份：正文
- PDF 页：254
- 偈颂：6-8 1/2
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 6-8 1/2 [present] · PDF page 254

6-8 1/2. Effects like physical fitness, little gain of
wealth affectionate relations with kinsmen, increase in
cattle wealth, income from industries, success in the
educational sphere, acquisition of name and fame, honours,
audience with the king, and joining a banquet with him,
comforts of clothes etc., will be experienced, if Ketu is
associated with benefics in a Kendr or in a Trikon (from
Lagn) or if Ketu is yuti with Lagn's lord, or with a Yog
Karak. The same will be the results if Ketu is in a Kendr
or in the 11th from the lord of the Dasha (Buddh).
~9Am*(9I8)4+9Am*(9I12)4~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P254_B006_01

- 身份：正文
- PDF 页：254
- 偈颂：9-11
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 9-11 [present] · PDF page 254

9-11. Fall from a conveyance, distress to son, danger from
the king (government), indulgence in sinful deeds, danger
from scorpions, etc., quarrels with the menials, sorrow,
diseases and association with menials, etc., will be the
results, if Ketu is yuti with malefics in the 8th or in the
12th from the lord of the Dasha (Buddh).
~9iL2+9iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P254_B007_01

- 身份：正文
- PDF 页：254
- 偈颂：12
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 12 [present] · PDF page 254

12. There will be physical distress if Ketu is Dhan's lord
or Yuvati's lord.
The remedial measure to obtain relief from the above evil
effects, is giving a goat in charity.
@4162@
Effects of the Antar Dasha of Shukr in the Dasha of Buddh
~6K+6I11+6I5+6I9~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P255_B001_01

- 身份：正文
- PDF 页：255
- 偈颂：13-15 1/2
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 13-15 1/2 [present] · PDF page 255

13-15 1/2. Effects like inclination to perform religious
rites, fulfillment of all ambitions through the help of the
king (government) and friends, gains of agricultural lands,
and happiness, etc., will be derived in the Antar Dasha of
Shukr in the Dasha of Buddh, if Shukr is in a Kendr, in
Labh, in Putr, or in Dharm Bhava.
~(6I!K)4+(6I11)4+(6I5)4+(6I9)4~
There will be acquisition of a kingdom (attainment of a
high position in government), gain of wealth and property,
construction of a reservoir, readiness to give charities
and to perform religious rites, extraordinary gain of
wealth and gains in business, if Shukr is in a Kendr, in
the 5th, in the 9th, or in the 11th from the lord of the
Dasha (Buddh).
~6w**(6I6)4+(6I8)4+(6I12)4~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P255_B002_01

- 身份：正文
- PDF 页：255
- 偈颂：16-17 1/2
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 16-17 1/2 [present] · PDF page 255

16-17 1/2. Heart disease, defamation, fevers, dysentery,
separation from kinsmen, physical distress and agony will
result if Shukr is weak in the 6th, the 8th, or the 12th
from the lord or the Dasha.
~6iL2+6iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P255_B003_01

- 身份：正文
- PDF 页：255
- 偈颂：18-19
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 18-19 [present] · PDF page 255

18-19. There will be fear of premature death if Shukr is
Dhan's lord or Yuvati's lord.
The remedial measure to obtain relief from the above evil
effects is to recite mantras of Goddess Durga.
@4112@
Effects of the Antar Dasha of Surya in the Dasha of Buddh
~1O+1E+1K+1T+1I2+1I11+1NO+1NE~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P255_B004_01

- 身份：正文
- PDF 页：255
- 偈颂：20-22
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 20-22 [present] · PDF page 255

20-22. Effects like dawn of fortune by the beneficence of
the king (high government officials), happiness from
friends, etc., will be derived in the Antar Dasha of Surya
in the Dasha of Buddh, if Surya is in his own Rashi, or in
his Exaltation Rashi, or in a Kendr, or in a Trikon, or in
Dhan, or in Labh Bhava, or in his exalted or own Navamsh.
~1D3~
There will be acquisition of land if Surya receives a
drishti from Mangal.
~1DL1~
and comforts of good food, and clothes if such a Surya
receives a drishti from Lagn's lord.
~1Ia+(1Ia)4**1w*1A7*1A3*1A8~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P255_B005_01

- 身份：正文
- PDF 页：255
- 偈颂：23-24
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 23-24 [present] · PDF page 255

23-24. Fear or danger from thieves, fire, and weapons,
bilious troubles, headaches, mental agony, and separation
from friends, etc., will be the results if Surya is in Ari,
Randhr, or Vyaya Bhava, from lagna or from the lord of the
Dasha (Buddh), and if Surya is weak and associated with
Shani, Mangal, and Rahu.
1iL2+1iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P255_B006_01

- 身份：正文
- PDF 页：255
- 偈颂：25
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 25 [present] · PDF page 255

25. There will be fear of premature death if Surya is
Dhan's lord or Yuvati's lord.
Worship of Surya is the remedial measure to obtain relief
from the above evil effects.
@4122@
Effects of the Antar Dasha of Chandr in the Dasha of Buddh
~2K+2T+2E+2O*2A5+2O*2D5+2y~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P256_B001_01

- 身份：正文
- PDF 页：256
- 偈颂：26-27
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 26-27 [present] · PDF page 256

26-27. The Yog becomes very strong for beneficial effects
if in the Antar Dasha of Chandr in the Dasha of Buddh,
Chandr is in a Kendr or in a Trikon from Lagn, or if Chandr
is in her Exaltation Rashi, or in her own Rashi associated
with or receiving a drishti from Guru, or if Chandr is a Yog
Karak herself. Then there will be marriage, birth of a son,
and gain of clothes and ornaments.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P256_B002_01

- 身份：正文
- PDF 页：256
- 偈颂：28-29 1/2
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 28-29 1/2 [present] · PDF page 256

28-29 1/2. In the circumstances mentioned above, there will
also be construction of a new house, availability of
sweetish  preparations, enjoy-ment of music, study of
Shastras journey to the South, gains of clothes from beyond
the seas, gain of gems like pearls, etc..
~2d+2e~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P256_B003_01

- 身份：正文
- PDF 页：256
- 偈颂：30-31 1/2
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 30-31 1/2 [present] · PDF page 256

30-31 1/2. There will be physical distress if Chandr is in
her  Debilitation Rashi, or in an enemy's Rashi.
~(2i!K)4+(2i!T)4+(2I3)4+(2I11)4~
If Chandr is in a Kendr, in a Trikon, in the 3rd, or in the
11th from the lord of the Dasha of Buddh there will be at
the commencement of the Antar Dasha visits to sacred
shrines, patience, enthusiasm, and gains of wealth from
foreign countries.
~2w*(2I6)4+2w*(2I8)4+2w*(2I12)4~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P256_B004_01

- 身份：正文
- PDF 页：256
- 偈颂：32-33
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 32-33 [present] · PDF page 256

32-33. Danger from the king, fire, and thieves, defamation
or disgrace and loss of wealth on account of wife,
destruction of agricultural lands and cattle, etc., will be
the results if Chandr is weak, and is in the 6th, the 8th,
or the 12th from the lord of the Dasha (Buddh).
~2iL2+2iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P256_B005_01

- 身份：正文
- PDF 页：256
- 偈颂：34-35
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 34-35 [present] · PDF page 256

34-35. There will be physical distress if Chandr is Dhan's
lord or Yuvati's lord.
There will be relief, prolongation of longevity, and
restoration of comforts by the beneficence of Goddess Durga
if the mantras of the Goddess are recited in the prescribed
manner and clothes are given in charity.
@4132@
Effects of the Antar Dasha of Mangal in the Dasha of Buddh
~3E+3O+3K+3T+3AL1~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P256_B006_01

- 身份：正文
- PDF 页：256
- 偈颂：36-38 1/2
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 36-38 1/2 [present] · PDF page 256

36-38 1/2. Effects like well-being and enjoyments in the
family by the beneficence of the king (government),
increase in property, recovery of a lost kingdom, etc.,
(reinstatement in a high position in government), birth of
a son, satisfaction, acquisition of cattle, conveyances,
and agricultural lands, happiness from wife, etc., will be
derived in the Antar Dasha of Mangal in the Dasha of Buddh,
if Mangal is in his Exaltation Rashi, in his own Rashi, in
a Kendr or in a Trikon (from Lagn), or if Mangal is
asociated with Lagn's lord.
~3I8*3Am+3I8*3Dm+3I12*3Am+3I12*3Dm~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P256_B007_01

- 身份：正文
- PDF 页：256
- 偈颂：39-40 1/2
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 39-40 1/2 [present] · PDF page 256

39-40 1/2. Physical distress, mental agony, obstacles in
industrial ventures, loss of wealth, gout, distress from
wounds, and danger from weapons and fever, etc., will be
the results if Mangal be associated with or receives a
drishti from malefics in Randhr, or in Vyaya Bhava.
~(3I!K)4*3DB+(3I!T)4*3DB+(3I11)4*3DB~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P257_B001_01

- 身份：正文
- PDF 页：257
- 偈颂：41-42
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 41-42 [present] · PDF page 257

41-42. There will be gain of wealth, physical felicity,
birth of a son, good reputation, affectionate relations,
etc., with kinsmen, etc., if Mangal recieves a drishti from
benefics in a Kendr, in a Trikon, or in the 11th from the
lord of the Dasha (Buddh).
~(3I8)4*3Am+(3I12)4*3Am~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P257_B002_01

- 身份：正文
- PDF 页：257
- 偈颂：43-44 1/2
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 43-44 1/2 [present] · PDF page 257

43-44 1/2. If Mangal be associated with malefics in the 8th
or the 12th from the lord of the Dasha (Buddh), there will
be:
(1) Distress, danger from kinsmen, wrath of the king, and
fire, antagonism with the son, loss of position, at the
commencement of the Antar Dasha.
(2) Enjoyments and gains of wealth in the middle portion of
the Antar Dasha.
(3) Danger from the king (government) and loss of position
at the end of the Antar Dasha.
~3iL2+3iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P257_B003_01

- 身份：正文
- PDF 页：257
- 偈颂：45-46
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 45-46 [present] · PDF page 257

45-46. There will be fear of premature death if Mangal is
Dhan's lord or Yuvati's lord.
The remedial measures to be adopted to obtain relief from
the above evil effects are Mrityunjaya Japa and giving a
cow in charity.
@4182@
Effects of the Antar Dasha of Rahu in the Dasha of Buddh
~8K+8T+8IR1+8IR11+8IR6+8IR2~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P257_B004_01

- 身份：正文
- PDF 页：257
- 偈颂：47-49
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 47-49 [present] · PDF page 257

47-49. Effects like reverence from the king (government),
good reputation, gain of wealth, visits to sacred shrines,
performance of religious sacrifices and oblations,
recognition, gain of clothes, etc., are derived in the
Antar Dasha of Rahu in the Dasha (Buddh), if Rahu is in a
Kendr, or in a Trikon (from Lagn), or if Rahu is in Mesh,
Kumbh, Kanya, or Vrishabh. There will be some evil effects
at the commencement of the Antar Dasha, but all will be
well later.
~8I3+8I8+8I10+8I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P257_B005_01

- 身份：正文
- PDF 页：257
- 偈颂：51
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 51 [present] · PDF page 257

51. There will be an opportunity to have conversation or a
meeting with the king (high dignitaries), if Rahu is in
Sahaj, Randhr, Karm, or Labh Bhava.
~8I3+8I8+8I10+8I11**8AB#
In this position, if Rahu be associated with a benefic,
there will be a visit to a new king (dignitary).
~(8I8)4*8Am+(8I12)4*8Am~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P257_B006_01

- 身份：正文
- PDF 页：257
- 偈颂：52-53
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 52-53 [present] · PDF page 257

52-53. Pressure of hard work as a government functionary,
loss of position, fears, imprisonment, diseases, agony to
self and kinsmen, heart disease, loss of reputation and
wealth, will be the results if Rahu is associated with a
malefic or malefics in the 8th or in the 12th from the lord
of the Dasha (Buddh).
~8I2+8I6~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P258_B001_01

- 身份：正文
- PDF 页：258
- 偈颂：54-55
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 54-55 [present] · PDF page 258

54-55. There will be fear of premature death if Rahu is in
Dhan or in Ari Bhava.
The remedial measures to obtain relief from the above evil
effects, are recitation of mantras of Goddess Durga and
Goddess Lakshmi in the prescribed manner and giving a tawny
coloured cow or female buffalo in charity.
@4152@
Effects of the Antar Dasha of Guru in the Dasha of Buddh
~5K+5T+5I11+5E+5O~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P258_B002_01

- 身份：正文
- PDF 页：258
- 偈颂：56-58 1/2
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 56-58 1/2 [present] · PDF page 258

56-58 1/2. Effects like physical felicity, gain of wealth,
beneficence of the king, celebration of auspicious
functions like marriage etc., at home, availability of
sweetish preparations, increase in cattle wealth, attending
discourses on Puranas (religious scriptures), etc.,
devotion to deities and the preceptor, interest in
religion, charities, etc., worship of Lord Shiva, etc.,
will be derived in the Antar Dasha of Guru in the Dasha of
Buddh, if Guru is in a Kendr, in a Trikon, or in tLabh
Bhava, or if Guru is in his Exaltation Rashi, or in his own
Rashi.
~5d+5c+5I6+5I8+5I12+5A3*5D7+5A7*5D3+5A3*5A7+5D3*5D7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P258_B003_01

- 身份：正文
- PDF 页：258
- 偈颂：59-61
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 59-61 [present] · PDF page 258

59-61. Discord with king and kinsmen, danger from thieves,
etc., death of parents, disgrace, punishment from
government, loss of wealth, danger from snakes and poison,
fever, losses in agricultural production, loss of lands
etc., will be the results, if Guru is in his Debilitation
Rashi, if Guru is combust, or if Guru is in Ari, Randhr, or
in Vyaya Bhava, or if Guru is associated with or receives a
drishti from Shani and Mangal.
~5X*(5I!K)4+5X*(5i!T)4+5X*(5I11)4~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P258_B004_01

- 身份：正文
- PDF 页：258
- 偈颂：62-63 1/2
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 62-63 1/2 [present] · PDF page 258

62-63 1/2. There will be happiness from kinsmen and from
one's son, enthusiasm, increase in wealth and name and
fame, giving grains, etc., in charity, if Guru is in a
Kendr, in a Trikon, or in the 11th from the lord of the
Dasha (Buddh) and if Guru is endowed with strength.
~5v*(5I6)4+5v*(5I8)4+5v*(5I12)4~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P258_B005_01

- 身份：正文
- PDF 页：258
- 偈颂：64-64 1/2
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 64-64 1/2 [present] · PDF page 258

64-64 1/2. Agony, anxiety, danger from diseases, antagonism
with wife and kinsmen, wrath of the king (government),
quarrels, loss of wealth, danger from Brahmins (wrath of
Brahmins), will be the results if Guru is weak and if Guru
is in the 6th, the 8th, or the 12th from the lord of the
Dasha (Buddh).
~5iL2+5iL7+5I2+5I7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P258_B006_01

- 身份：正文
- PDF 页：258
- 偈颂：65-66
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 65-66 [present] · PDF page 258

65-66. There will be physical distress if Guru is Dhan's
lord or Yuvati's lord, or if Guru is in Dhan or in Yuvati
Bhava.
The remedial measures to obtain relief from the above evil
effects are recitation of Shiva Sahasranam and giving a cow
and gold in charity.
@4172@
Effects of the Antar Dasha of Shani in the Dasha of Buddh
~7E+7O+7K+7T+7I11~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P259_B001_01

- 身份：正文
- PDF 页：259
- 偈颂：67-68 1/2
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 67-68 1/2 [present] · PDF page 259

67-68 1/2. Effects like well-being in the family,
acquisition of a kingdom (attainment of a high position in
government), enthusiasm, increase in cattle wealth, gain of
a position, visits to sacred shrines, etc., will be derived
in the Antar Dasha of Shani in the Dasha of Buddh, if Shani
is in his Exaltation Rashi, his in his own Rashi, or in a
Kendr, or in a Trikon, or in Labh Bhava.
~(7I8)4+(7I12)4~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P259_B002_01

- 身份：正文
- PDF 页：259
- 偈颂：69-70 1/2
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 69-70 1/2 [present] · PDF page 259

69-70 1/2. Danger from enemies, distress to wife and
children, loss of thinking power, loss of kinsmen, loss in
ventures, mental agony, journeys to foreign lands, and bad
dreams, will be the results if Shani is in the 8th or in
the 12th from the lord of the Dasha (Buddh).
~7iL2+7iL7~

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P259_B003_01

- 身份：正文
- PDF 页：259
- 偈颂：71-72
- 标题路径：CHAPTER 58 Effects of the Antar Dashas in the Dasha of › Buddh @4142@ Effects of the Antar Dasha of Buddh in the Dasha of Buddh ~4E+4O+4M+4G*-4Ia*-4Am~
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Antar Dashas in the Dasha of · Sloka 71-72 [present] · PDF page 259

71-72. There will be fear of premature death if Shani is
Dhan's lord or Yuvati's lord.
The remedial measures to obtain relief from the above evil
effects and to regain sound health, are performance of
Mrityunaya Japa and giving a black cow and female buffalo
in charity.
