# 第 78 章：Lost Horoscopy

- 来源：BPHS 97 章版
- 原始卡片：8 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P327_B002_01

- 身份：正文
- PDF 页：327
- 偈颂：1-2
- 标题路径：CHAPTER 78 Lost Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Lost Horoscopy · Sloka 1-2 [present] · PDF page 327

1-2. Maitreya said: O Sage! You have so far described the
auspicious and inauspicious effects to be enjoyed or suffered
by a person on the basis of the time of birth, but can the
auspicious and inauspicious be ascertained when the time of
birth is not known? Kindly tell me if there is any way to
solve this problem.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P327_B003_01

- 身份：正文
- PDF 页：327
- 偈颂：3-4
- 标题路径：CHAPTER 78 Lost Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Lost Horoscopy · Sloka 3-4 [present] · PDF page 327

3-4. The Sage said: Your question is a good one and is for
the benefit of the world at large. Considering your
attachment, I will tell you about this problem also. If any
or all amongst the samvatsar, ayana, ritu, month, paksha,
tithi, nakshatr, Lagn, rashi, or amsas, etc., of the birth
are not known, these can be ascertained from Prasna Lagn
(Query chart).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P327_B004_01

- 身份：正文
- PDF 页：327
- 偈颂：5-6
- 标题路径：CHAPTER 78 Lost Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Lost Horoscopy · Sloka 5-6 [present] · PDF page 327

5-6. The samvatsar of the birth of the querist will be the
same as that of the rashi in the Dwadasams in which the
Prasna Lagn falls. (It means that Guru will be in that rashi
at birth). Saumyayan (Uttarayan the northern course of Surya)
will be in the first Hora of Lagn (Lagn of the query chart)
and Yamyayan (Dakshinayan-the southern course of the Surya)
will be in its second Hora. The ritu (season) may be
determined with reference to the lord of the Drekkan in which
Lagn falls. Shishir ritu will be indicated by the Drekkan of
Shani, grishma by that of Surya and Mangal, Vasanta ritu by
that of Shukr, varsha ritu by that of Chandr, Sharad ritu by
that of Buddh, and Hemanta ritu by that of Guru.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P327_B005_01

- 身份：正文
- PDF 页：327
- 偈颂：7
- 标题路径：CHAPTER 78 Lost Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Lost Horoscopy · Sloka 7 [present] · PDF page 327

7. If there be any contradiction in the ayana and ritu, the
ritu may be determined from Buddh in place of Mangal, from
Shukr in place of Chandr and from Shani in place of Guru.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P327_B006_01

- 身份：正文
- PDF 页：327
- 偈颂：8-9
- 标题路径：CHAPTER 78 Lost Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Lost Horoscopy · Sloka 8-9 [present] · PDF page 327

8-9. After the ritu becomes known, take the first part of the
Drekkan as its first month and latter part as the next month
of the ritu. Then, from the expired amsas of the Drekkan,
determine proportionately the tithi or the amsas of Surya.
The Istakal indicated by the amsas (degrees) of Surya, will
be the time of the birth of the querist. From the Istakal so
calculated have to be worked out the longitudes of the grahas
and bhavas (Grah Spast and Bhava Spast). Predictions should
then be made in accordance with the dispositions of the
bhavas and grahas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P327_B007_01

- 身份：正文
- PDF 页：327
- 偈颂：10
- 标题路径：CHAPTER 78 Lost Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Lost Horoscopy · Sloka 10 [present] · PDF page 327

10. Maitreya asked: O Sage! Guru returns to the same rashi
after every 12 years. Then from which circle of Guru should
samvatsar be determined.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P328_B001_01

- 身份：正文
- PDF 页：328
- 偈颂：11-12
- 标题路径：CHAPTER 78 Lost Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Lost Horoscopy · Sloka 11-12 [present] · PDF page 328

11-12. The Sage said in reply: O Maitreya! when there is any
doubt about the samvatsar, take the approximate age of the
querist and add multiples of 12 to the difference between the
rashi of the Guru at the time of query and his rashi at the
time of birth. The figure so arrived at should be taken as
the possible number of years and the samvatsar should be
determined accordingly. If by adding 12 there may appear to
be difference in age, the position of Guru should be fixed
according to guessed approximate age in the Trikon rashi 5th
or 9th of the Prasna Lagn (Lagn of the query chart) as may be
found feasible. Then, taking that as the samvatsar, the
Ayana, ritu etc., should be worked out accordingly in the
manner already explained.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P328_B002_01

- 身份：正文
- PDF 页：328
- 偈颂：13
- 标题路径：CHAPTER 78 Lost Horoscopy
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Lost Horoscopy · Sloka 13 [present] · PDF page 328

13. Maitreya asked again: O Sage! How will the time of birth
be known after ascertaining the month and the amsas etc., of
Surya. Please explain this for the benefit of the people.
14-16.The Sage said: After ascertaining the rashi,amsas,
etc., of Surya at the time of birth, the longitude of Surya
(Surya Spast) should be worked out for the next day after the
number of days taken by Surya after entering into the rashi
which will be equal to the expired amsas of Surya. Then, the
difference between the longitudes of this rising Surya and
Surya at the time of birth should be converted into kalas and
multiplied by 60. The product should be divided by Surya
Spast converted into kalas. The ghatikas etc., so becoming
available will represent the Istakal of the birth before and
after sunrise. If the longitude of the Ista Surya be more
than that of the rising Surya, the Istakal of the birth will
be so much after the sunrise. If the longitude, of the Ista
Surya be less than that of the rising Surya, the Istakal of
the birth will be so much before the sunrise.
