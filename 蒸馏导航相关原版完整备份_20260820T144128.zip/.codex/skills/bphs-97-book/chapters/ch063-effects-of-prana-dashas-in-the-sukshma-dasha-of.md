# 第 63 章：Effects of Prana Dashas in the Sukshma Dasha of

- 来源：BPHS 97 章版
- 原始卡片：82 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P285_B002_01

- 身份：正文
- PDF 页：285
- 偈颂：—
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka unknown [unknown] · PDF page 285 · page_block BPHS_PL9_CHAP_97_P285_B002

the Various Grahas

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P285_B003_01

- 身份：正文
- PDF 页：285
- 偈颂：1
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 1 [present] · PDF page 285

1. If we multiply the Sukshma Dasha spans by the Dasha
years of each grah and divide the product by 120, we will
get the Prana Dasha.
Effects of Prana Dashas in the Sukshma Dasha of Surya

@1415@2.
Surya-Surya: Interest in unnatural sexual intercourse,
danger from thieves, fire and the king, physical distress.
@1425@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P285_B004_01

- 身份：正文
- PDF 页：285
- 偈颂：3
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 3 [present] · PDF page 285

3. Surya-Chandr: Enjoyments, availability of good food,
development of intelligence, opulence, and glory like that
of a king by the beneficence of generous people.
@1435@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P285_B005_01

- 身份：正文
- PDF 页：285
- 偈颂：4
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 4 [present] · PDF page 285

4. Surya-Mangal: Antagonism with the king with the
connivance of others, dangers, and great losses.
@1485@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P285_B006_01

- 身份：正文
- PDF 页：285
- 偈颂：5
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 5 [present] · PDF page 285

5. Surya-Rahu: Hunger, danger from poison, loss of wealth
as a result of punishment by the king (government).
@1455@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P285_B007_01

- 身份：正文
- PDF 页：285
- 偈颂：6
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 6 [present] · PDF page 285

6. Surya-Guru: Success in many educational spheres, gain of
wealth, success in ventures as a result of the exchange of
visits with the king and Brahmins.
@1475@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P285_B008_01

- 身份：正文
- PDF 页：285
- 偈颂：7
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 7 [present] · PDF page 285

7. Surya-Shani: Imprisonment, death, excitement, obstacles,
and losses in ventures.
@1445@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P285_B009_01

- 身份：正文
- PDF 页：285
- 偈颂：8
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 8 [present] · PDF page 285

8. Surya-Buddh: Feeding from the kings kitchen, acquisition
of Chatr and Chamar with royal symbols, attainment of the
position of a high dignitary in government.
@1495@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P285_B010_01

- 身份：正文
- PDF 页：285
- 偈颂：9
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 9 [present] · PDF page 285

9. Surya-Ketu: Loss of wealth due to quarrels with the
preceptor (or elders), wife, and kinsmen.
@1465@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P285_B011_01

- 身份：正文
- PDF 页：285
- 偈颂：10
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 10 [present] · PDF page 285

10. Surya-Shukr: Recognition or reverence from the king,
increase in wealth, happiness from wife and children,
enjoyments from eating and drinking.
Effects of Prana Dashas in the Sukshma Dasha of Chandr
@2425@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P285_B012_01

- 身份：正文
- PDF 页：285
- 偈颂：11
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 11 [present] · PDF page 285

11. Chandr-Chandr: Happiness from wife and children, gain
of wealth, and clothes, Yog Sidhi.
@2435@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P285_B013_01

- 身份：正文
- PDF 页：285
- 偈颂：12
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 12 [present] · PDF page 285

12. Chandr-Mangal: Consumption, leprosy, destruction of
kinsmen, bleeding, creation of turbulence by friends and
goblins (evil spirits).
@2485@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P286_B001_01

- 身份：正文
- PDF 页：286
- 偈颂：13
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 13 [present] · PDF page 286

13. Chandr-Rahu: Danger from snakes, creation of turbulance
by evil spirits, weakness of eye sight, confusion of mind.
@2455@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P286_B002_01

- 身份：正文
- PDF 页：286
- 偈颂：14
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 14 [present] · PDF page 286

14. Chandr-Guru: Growth of religious mindedness,
forgiveness, devotion towards deities and Brahmins, good
fortune, meeting with near and dear ones.
@2475@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P286_B003_01

- 身份：正文
- PDF 页：286
- 偈颂：15
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 15 [present] · PDF page 286

15. Chandr-Shani: Unexpected and sudden physical distress,
creation of troubles by enemies, weakness of eye sight,
gain of wealth.
@2445@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P286_B004_01

- 身份：正文
- PDF 页：286
- 偈颂：16
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 16 [present] · PDF page 286

16. Chandr-Buddh: Gift of Chamar and Chatr by the king,
acquisition of a kingdom, even mindedness in people.
@2495@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P286_B005_01

- 身份：正文
- PDF 页：286
- 偈颂：17
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 17 [present] · PDF page 286

17. Chandr-Ketu: Danger from weapons, fromfire, from an
enemy and from poison, stomach troubles, separation from
wife and children.
@2465@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P286_B006_01

- 身份：正文
- PDF 页：286
- 偈颂：18
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 18 [present] · PDF page 286

18. Chandr-Shukr: Acquisition of friends and wife
(marriage), gain of wealth from foreign lands, all kinds of
enjoyments.
@2415@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P286_B007_01

- 身份：正文
- PDF 页：286
- 偈颂：19
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 19 [present] · PDF page 286

19. Chandr-Surya: Brutality, increase in anger, fear of
death, agony, going away from the homeland, dangers.
Effects of Prana Dasha in the Sukshma Dasha of Mangal
@3435@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P286_B008_01

- 身份：正文
- PDF 页：286
- 偈颂：20
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 20 [present] · PDF page 286

20. Mangal-Mangal: Quarrels with the enemy, imprisonment,
bilious and blood pollution troubles.
@3485@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P286_B009_01

- 身份：正文
- PDF 页：286
- 偈颂：21
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 21 [present] · PDF page 286

21. Mangal-Rahu: Separation from wife and children,
distress as a result of oppression by kinsmen, fear of
death, poison.
@3455@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P286_B010_01

- 身份：正文
- PDF 页：286
- 偈颂：22
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 22 [present] · PDF page 286

22. Mangal-Guru: Devotion towards deities, gain of wealth
competence in mantra rituals.
@3475@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P286_B011_01

- 身份：正文
- PDF 页：286
- 偈颂：23
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 23 [present] · PDF page 286

23. Mangal-Shani:Danger from fire, death, loss of wealth,
loss of position but good relations with kinsmen.
@3445@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P286_B012_01

- 身份：正文
- PDF 页：286
- 偈颂：24
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 24 [present] · PDF page 286

24. Mangal-Buddh: Gains of splendid garments, ornaments,
marriage.
@3495@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P286_B013_01

- 身份：正文
- PDF 页：286
- 偈颂：25
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 25 [present] · PDF page 286

25. Mangal-Ketu: Fear of falling down from a high place,
eye troubles, danger from snakes, loss of reputation.
@3465@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P286_B014_01

- 身份：正文
- PDF 页：286
- 偈颂：26
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 26 [present] · PDF page 286

26. Mangal-Shukr: Gain of wealth, reverence amongst people
(popularity), enjoyment of many kinds of luxuries.
@3415@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P287_B001_01

- 身份：正文
- PDF 页：287
- 偈颂：27
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 27 [present] · PDF page 287

27. Mangal-Surya: Fevers, lunacy, loss of wealth, wrath of
the king, poverty.
@3425@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P287_B002_01

- 身份：正文
- PDF 页：287
- 偈颂：28
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 28 [present] · PDF page 287

28. Mangal-Chandr: Comforts of good food and garments,
distress from heat and cold.
Effects of Prana Dashas in the Sukshma Dasha of Rahu
@8485@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P287_B003_01

- 身份：正文
- PDF 页：287
- 偈颂：29
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 29 [present] · PDF page 287

29. Rahu-Rahu: Loss of taste in eating, danger from poison,
loss of wealth through rashness.
@8455@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P287_B004_01

- 身份：正文
- PDF 页：287
- 偈颂：30
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 30 [present] · PDF page 287

30. Rahu-Guru: Physical well-being, fearlessness, gain of
conveyance, and quarrels with menials.
@8475@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P287_B005_01

- 身份：正文
- PDF 页：287
- 偈颂：31
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 31 [present] · PDF page 287

31. Rahu-Shani: Danger from fire, diseases, loss of wealth
through menials, imprisonment.
@8445@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P287_B006_01

- 身份：正文
- PDF 页：287
- 偈颂：32
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 32 [present] · PDF page 287

32. Rahu-Buddh: Devotion towards the preceptor and increase
of wealth through his beneficence, good qualities and well
cultured.
@8495@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P287_B007_01

- 身份：正文
- PDF 页：287
- 偈颂：33
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 33 [present] · PDF page 287

33. Rahu-Ketu: Antagonism with wife and children, going
away from home, loss of wealth through rashness.
@8465@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P287_B008_01

- 身份：正文
- PDF 页：287
- 偈颂：34
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 34 [present] · PDF page 287

34. Rahu-Shukr: Acquisition of Chatr, Chamar, conveyances,
etc., success in all ventures, worship of Lord Shiva,
construction of a house.
@8415@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P287_B009_01

- 身份：正文
- PDF 页：287
- 偈颂：35
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 35 [present] · PDF page 287

35. Rahu-Surya: Affliction with piles, wrath of the king,
loss of cattle.
@8425@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P287_B010_01

- 身份：正文
- PDF 页：287
- 偈颂：36
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 36 [present] · PDF page 287

36. Rahu-Chandr: Development of mental powers and
intelligence, popularity, visits of preceptors (elders),
danger of committing sins.
@8435@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P287_B011_01

- 身份：正文
- PDF 页：287
- 偈颂：37
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 37 [present] · PDF page 287

37. Rahu-Mangal: Dangers from menials and fire, loss of
position, disaster, filthiness and meanness.
Effects of Prana Dashas in the Sukshma Dasha of Guru
@5455@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P287_B012_01

- 身份：正文
- PDF 页：287
- 偈颂：38
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 38 [present] · PDF page 287

38. Guru-Guru: Happiness, increase in wealth, performance
of Havan, worship of Lord Shiva, acquisition of Chatr and
conveyances.
@5475@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P287_B013_01

- 身份：正文
- PDF 页：287
- 偈颂：39
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 39 [present] · PDF page 287

39. Guru-Shani: Failure in fasting, unhappiness, going away
to foreign lands, loss of wealth, antagonism with kinsmen.
@5445@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P288_B001_01

- 身份：正文
- PDF 页：288
- 偈颂：40
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 40 [present] · PDF page 288

40. Guru-Buddh: Progress in education, increase in
intelligence, happiness to wife and children, popularity,
gain of wealth.
@5495@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P288_B002_01

- 身份：正文
- PDF 页：288
- 偈颂：41
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 41 [present] · PDF page 288

41. Guru-Ketu: Opulence and glory, learnedness, gain of
knowledge of Shastras, worship of Lord Shiva, performance
of Havan, devotion towards preceptor.
@5465@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P288_B003_01

- 身份：正文
- PDF 页：288
- 偈颂：42
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 42 [present] · PDF page 288

42. Guru-Shukr: Freedom from diseases, enjoyments, increase
in wealth, happiness from wife and children.
@5415@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P288_B004_01

- 身份：正文
- PDF 页：288
- 偈颂：43
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 43 [present] · PDF page 288

43. Guru-Surya: Disorders of wind, bile, and phlegm, pains
due to disorders of juices in the body.
@5425@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P288_B005_01

- 身份：正文
- PDF 页：288
- 偈颂：44
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 44 [present] · PDF page 288

44. Guru-Chandr: Acquisition of Chatr with royal symbol,
opulence and glory, increase in children, eye and stomach
troubles.
@5435@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P288_B006_01

- 身份：正文
- PDF 页：288
- 偈颂：45
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 45 [present] · PDF page 288

45. Guru-Mangal: Danger of administration of poison by
wife, imprisonment, foreign journeys, confusion of mind.
@5485@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P288_B007_01

- 身份：正文
- PDF 页：288
- 偈颂：46
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 46 [present] · PDF page 288

46. Guru-Rahu: Distress from diseases, troubles from
thieves, danger from snakes, scorpions, etc..
Effects of Prana Dashas in the Sukshma Dasha of Shani
@7475@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P288_B008_01

- 身份：正文
- PDF 页：288
- 偈颂：47
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 47 [present] · PDF page 288

47. Shani-Shani: Loss of luster due to fevers, leprosy,
stomach troubles, danger of death from fire.
@7445@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P288_B009_01

- 身份：正文
- PDF 页：288
- 偈颂：48
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 48 [present] · PDF page 288

48. Shani-Buddh: Gain of wealth and grains, profits in
business, reverence, devotion towards deities and
Brahmins.
@7495@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P288_B010_01

- 身份：正文
- PDF 页：288
- 偈颂：49
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 49 [present] · PDF page 288

49. Shani-Ketu: Death like distress, creation of turbulence
by evil spirits, insult from a woman other than one's
wife.
@7465@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P288_B011_01

- 身份：正文
- PDF 页：288
- 偈颂：50
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 50 [present] · PDF page 288

50. Shani-Shukr: Enjoyments through wealth, son, and
beneficence of the king, performance of Havanas, marriage,
etc..
@7415@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P288_B012_01

- 身份：正文
- PDF 页：288
- 偈颂：51
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 51 [present] · PDF page 288

51. Shani-Surya: Troubles in the eyes and forehead, danger
from snakes and enemies, loss of wealth, distress.
@7425@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P288_B013_01

- 身份：正文
- PDF 页：288
- 偈颂：52
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 52 [present] · PDF page 288

52. Shani-Chandr: Sound health, birth of a son, relief,
thriving strength, devotion towards deities and Brahmins.
@7435@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P289_B001_01

- 身份：正文
- PDF 页：289
- 偈颂：53
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 53 [present] · PDF page 289

53. Shani-Mangal: Affliction with Gulma disease, danger
from enemy, danger of death during hunting, danger from
snakes, from fire, and from poison.
@7485@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P289_B002_01

- 身份：正文
- PDF 页：289
- 偈颂：54
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 54 [present] · PDF page 289

54. Shani-Rahu: Going away from the homeland, danger from
the king, bewitchment, taking of poison, troubles from wind
and bile.
@7455@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P289_B003_01

- 身份：正文
- PDF 页：289
- 偈颂：55
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 55 [present] · PDF page 289

55. Shani-Guru: Attainment of the position of a Commander
in the army, gain of land, association with ascetics,
reverence from the king.
Effects of Prana Dashas in the Sukshma Dasha of Buddh
@4445@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P289_B004_01

- 身份：正文
- PDF 页：289
- 偈颂：56
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 56 [present] · PDF page 289

56. Buddh-Buddh: Increase in enjoyments, wealth, and
religious mindedness, even mindedness in all living
beings.
@4495@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P289_B005_01

- 身份：正文
- PDF 页：289
- 偈颂：57
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 57 [present] · PDF page 289

57. Buddh-Ketu: Danger from thieves, from fire, and from
poison, death like suffering.
@4465@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P289_B006_01

- 身份：正文
- PDF 页：289
- 偈颂：58
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 58 [present] · PDF page 289

58. Buddh-Shukr: Supermacy over others, increase in wealth,
reputation and religious mindedness, devotion to Lord
Shiva, happiness from son.
@4415@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P289_B007_01

- 身份：正文
- PDF 页：289
- 偈颂：59
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 59 [present] · PDF page 289

59. Buddh-Surya: Agony, fevers, lunacy, affectionate
relations with wife and kinsmen, receipt of stolen
property.
@4425@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P289_B008_01

- 身份：正文
- PDF 页：289
- 偈颂：60
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 60 [present] · PDF page 289

60. Buddh-Chandr: Happiness from wife, birth of a daughter,
gain of wealth, and enjoyments all round.
@4435@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P289_B009_01

- 身份：正文
- PDF 页：289
- 偈颂：61
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 61 [present] · PDF page 289

61. Buddh-Mangal: Tendency to indulge in nefarious
(unlawful, wicked) activities, pain in eyes, teeth, and
stomach, piles, danger from death.
@4485@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P289_B010_01

- 身份：正文
- PDF 页：289
- 偈颂：62
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 62 [present] · PDF page 289

62. Buddh-Rahu: Gain of clothes, ornaments and wealth,
separation from one's own people, antagonism with Brahmins,
delirium.
@4455@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P289_B011_01

- 身份：正文
- PDF 页：289
- 偈颂：63
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 63 [present] · PDF page 289

63. Buddh-Guru: Sublimately, progress in education,
increase in wealth and good qualities, profits in
business.
@4475@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P289_B012_01

- 身份：正文
- PDF 页：289
- 偈颂：64
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 64 [present] · PDF page 289

64. Buddh-Shani: Danger of death from thieves, poverty,
beggary.
Effects of Prana Dashas in the Sukshma Dasha of Ketu
@9495@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P290_B001_01

- 身份：正文
- PDF 页：290
- 偈颂：65
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 65 [present] · PDF page 290

65. Ketu-Ketu: Danger of fall from a conveyance, quarrels
with the enemy, committing a murder inadvertently
(unintentionally).
@9465@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P290_B002_01

- 身份：正文
- PDF 页：290
- 偈颂：66
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 66 [present] · PDF page 290

66. Ketu-Shukr: Gain of land and conveyance, happiness,
destruction of enemy, increase in cattle wealth.
@9415@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P290_B003_01

- 身份：正文
- PDF 页：290
- 偈颂：67
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 67 [present] · PDF page 290

67. Ketu-Surya: Danger from fire and enemy, loss of wealth,
mental agony, death like suffering.
@9425@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P290_B004_01

- 身份：正文
- PDF 页：290
- 偈颂：68
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 68 [present] · PDF page 290

68. Ketu-Chandr: Devotion towards deities and Brahmin
journeys to distant places, gain of wealth and happiness,
eye and ear troubles.
@9435@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P290_B005_01

- 身份：正文
- PDF 页：290
- 偈颂：69
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 69 [present] · PDF page 290

69. Ketu-Mangal: Bilious troubles, enlargement of veins,
delirium, antagonism with kinsmen.
@9485@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P290_B006_01

- 身份：正文
- PDF 页：290
- 偈颂：70
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 70 [present] · PDF page 290

70. Ketu-Rahu: Antagonism with son and wife, going away
from home, loss in ventures due to rashness.
@9455@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P290_B007_01

- 身份：正文
- PDF 页：290
- 偈颂：71
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 71 [present] · PDF page 290

71. Ketu-Guru: Injuries from weapons, wounds, heart
disease, separation from wife and children.
@9475@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P290_B008_01

- 身份：正文
- PDF 页：290
- 偈颂：72
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 72 [present] · PDF page 290

72. Ketu-Shani: Confusion of mind, tendencies towards
nefarious (unlawful, wicked) deeds, imprisonment on account
of addictions (in drugs, etc.), distress.
@9445@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P290_B009_01

- 身份：正文
- PDF 页：290
- 偈颂：73
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 73 [present] · PDF page 290

73. Ketu-Buddh: Enjoyments of bed, perfumery, ornaments,
and sandal, good food and availability of all kinds of
comforts.
Effects of Prana Dashas in the Sukshma Dasha of Shukr
@6465@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P290_B010_01

- 身份：正文
- PDF 页：290
- 偈颂：74
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 74 [present] · PDF page 290

74. Shukr-Shukr: Learning, devotion to deities,
satisfaction, gain of wealth, increase in the number of
children.
@6415@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P290_B011_01

- 身份：正文
- PDF 页：290
- 偈颂：75
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 75 [present] · PDF page 290

75. Shukr-Surya: Good reputation in public, loss of
happiness in respect of children, heat troubles.
@6425@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P290_B012_01

- 身份：正文
- PDF 页：290
- 偈颂：76
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 76 [present] · PDF page 290

76. Shukr-Chandr: Devotion towards deities, competence,
relief by the application of mantras, increase in wealth
and fortune.
@6435@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P290_B013_01

- 身份：正文
- PDF 页：290
- 偈颂：77
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 77 [present] · PDF page 290

77. Shukr-Mangal: Fevers, wounds, ringworms, itches,
devotion towards deities and Brahmins.
@6485@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P291_B001_01

- 身份：正文
- PDF 页：291
- 偈颂：78
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 78 [present] · PDF page 291

78. Shukr-Rahu: Distress from an enemy, eye and stomach
troubles, antagonism with friends.
@6455@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P291_B002_01

- 身份：正文
- PDF 页：291
- 偈颂：79
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 79 [present] · PDF page 291

79. Shukr-Guru: Good longevity, sound health, happiness
from wealth, wife, and children, acquisition of Chatr and
conveyances.
@6475@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P291_B003_01

- 身份：正文
- PDF 页：291
- 偈颂：80
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 80 [present] · PDF page 291

80. Shukr-Shani: Danger from the king, loss of happiness,
critical disease, controversy with menials.
@6445@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P291_B004_01

- 身份：正文
- PDF 页：291
- 偈颂：81
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 81 [present] · PDF page 291

81. Shukr-Buddh: Satisfaction, reverence from the king,
gains of land and wealth from many directions, increase in
enthusiasm.
@6495@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P291_B005_01

- 身份：正文
- PDF 页：291
- 偈颂：82
- 标题路径：CHAPTER 63 Effects of Prana Dashas in the Sukshma Dasha of › the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of Prana Dashas in the Sukshma Dasha of · Sloka 82 [present] · PDF page 291

82. Shukr-Ketu: Loss of life, wealth, and reputation only
some money is left for charities and sustenance.
