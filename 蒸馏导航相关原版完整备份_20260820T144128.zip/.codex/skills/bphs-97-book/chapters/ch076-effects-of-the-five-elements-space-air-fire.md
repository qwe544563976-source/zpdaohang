# 第 76 章：Effects of the five Elements : Space, Air, Fire,

- 来源：BPHS 97 章版
- 原始卡片：18 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P323_B002_01

- 身份：正文
- PDF 页：323
- 偈颂：—
- 标题路径：CHAPTER 76 Effects of the five Elements : Space, Air, Fire, › Water, and Earth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the five Elements : Space, Air, Fire, · Sloka unknown [unknown] · PDF page 323 · page_block BPHS_PL9_CHAP_97_P323_B002

Water, and Earth

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P323_B003_01

- 身份：正文
- PDF 页：323
- 偈颂：1
- 标题路径：CHAPTER 76 Effects of the five Elements : Space, Air, Fire, › Water, and Earth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the five Elements : Space, Air, Fire, · Sloka 1 [present] · PDF page 323

1. The sage said: O Brahmin! Now I will tell you about the
effects of the five elements: space, air, fire, water, and
earth.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P323_B004_01

- 身份：正文
- PDF 页：323
- 偈颂：2
- 标题路径：CHAPTER 76 Effects of the five Elements : Space, Air, Fire, › Water, and Earth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the five Elements : Space, Air, Fire, · Sloka 2 [present] · PDF page 323

2. Space, air, fire, water, and earth are ruled by Guru,
Shani, Mangal,  Shukr,  and Buddh respectively. The effects
are experienced in proportion to the intensity of the various
elements.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P323_B005_01

- 身份：正文
- PDF 页：323
- 偈颂：3-4
- 标题路径：CHAPTER 76 Effects of the five Elements : Space, Air, Fire, › Water, and Earth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the five Elements : Space, Air, Fire, · Sloka 3-4 [present] · PDF page 323

3-4. The native will have temperament according to the
greater strength of the grah at the time of birth. Guru,
Shani, Mangal, Shukr, and Buddh will respectively give
spacial (etheral), airy (windly), fiery, watery, and earthy
temperament. If all of them or many of these grahas have
equal strength the temperament will be of a mixed character.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P323_B006_01

- 身份：正文
- PDF 页：323
- 偈颂：5
- 标题路径：CHAPTER 76 Effects of the five Elements : Space, Air, Fire, › Water, and Earth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the five Elements : Space, Air, Fire, · Sloka 5 [present] · PDF page 323

5. If Surya be endowed with strength the native will have
fiery temperament. If Chandr be strong, the native will have
watery temperament. All the grahas in course of their Dasa,
endow the native with bodily lustre relating to their
elements.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P323_B007_01

- 身份：正文
- PDF 页：323
- 偈颂：6
- 标题路径：CHAPTER 76 Effects of the five Elements : Space, Air, Fire, › Water, and Earth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the five Elements : Space, Air, Fire, · Sloka 6 [present] · PDF page 323

6. The characteristic features of the person with fiery
temperament are: distressed with hunger, restless, lean and
thin body, learned, consumes a large quantity of food, sharp,
fair complexioned, and proud.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P323_B008_01

- 身份：正文
- PDF 页：323
- 偈颂：7
- 标题路径：CHAPTER 76 Effects of the five Elements : Space, Air, Fire, › Water, and Earth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the five Elements : Space, Air, Fire, · Sloka 7 [present] · PDF page 323

7. The characteristic features of a person with earthy
temperament are: emits fragrance of camphor and lotus, is
fond of luxuries, comforts and enjoyments and is permanently
happy, forgiving, and has a deep voice like a lion.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P323_B009_01

- 身份：正文
- PDF 页：323
- 偈颂：8
- 标题路径：CHAPTER 76 Effects of the five Elements : Space, Air, Fire, › Water, and Earth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the five Elements : Space, Air, Fire, · Sloka 8 [present] · PDF page 323

8. The characteristic features of a person with etheral
temperament are: acquainted with semasiology, expert in
diplomacy, brilliant, learned, unmasked face, and long
stature.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P323_B010_01

- 身份：正文
- PDF 页：323
- 偈颂：9
- 标题路径：CHAPTER 76 Effects of the five Elements : Space, Air, Fire, › Water, and Earth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the five Elements : Space, Air, Fire, · Sloka 9 [present] · PDF page 323

9. The characteristic features of a person with watery
temperament are: is lustrous, can sustain burdens, is soft
spoken, king, has many friends, and is learned.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P323_B011_01

- 身份：正文
- PDF 页：323
- 偈颂：10
- 标题路径：CHAPTER 76 Effects of the five Elements : Space, Air, Fire, › Water, and Earth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the five Elements : Space, Air, Fire, · Sloka 10 [present] · PDF page 323

10. The characteristic features of a person with airy
temperament are: charitable, full of anger, fair complexion,
fond of wandering, victorious over enemies, king, and has
lean physique.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P323_B012_01

- 身份：正文
- PDF 页：323
- 偈颂：11
- 标题路径：CHAPTER 76 Effects of the five Elements : Space, Air, Fire, › Water, and Earth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the five Elements : Space, Air, Fire, · Sloka 11 [present] · PDF page 323

11. When the fire element is predominant in a person, that
is, the strength of Surya or Mangal is predominant, his face
and body exhibit lustre like gold and he has happy looking
eyes. He achieves success in all his ventures, is victorious
over his enemies and gets gains of wealth.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P323_B013_01

- 身份：正文
- PDF 页：323
- 偈颂：12
- 标题路径：CHAPTER 76 Effects of the five Elements : Space, Air, Fire, › Water, and Earth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the five Elements : Space, Air, Fire, · Sloka 12 [present] · PDF page 323

12. When the earth element is predominant, that is, if
Buddh's strength is predominant, the body of the person emits
various kinds of fragrances. His nails, hair and teeth are
are clean. He gets gains of happiness and wealth and is
religious minded.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P324_B001_01

- 身份：正文
- PDF 页：324
- 偈颂：13
- 标题路径：CHAPTER 76 Effects of the five Elements : Space, Air, Fire, › Water, and Earth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the five Elements : Space, Air, Fire, · Sloka 13 [present] · PDF page 324

13. When the other element is predominant, that is, if Guru's
strength is predominant, the person is a clever
conversationalist and becomes happy by learning to songs
etc..

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P324_B002_01

- 身份：正文
- PDF 页：324
- 偈颂：14
- 标题路径：CHAPTER 76 Effects of the five Elements : Space, Air, Fire, › Water, and Earth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the five Elements : Space, Air, Fire, · Sloka 14 [present] · PDF page 324

14. When the water element is predominant, that is, if the
strength of Chandr or Shukr is predominant,  the person's
body is slender, he enjoys good health and tasty food, and is
happy on that account.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P324_B003_01

- 身份：正文
- PDF 页：324
- 偈颂：15
- 标题路径：CHAPTER 76 Effects of the five Elements : Space, Air, Fire, › Water, and Earth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the five Elements : Space, Air, Fire, · Sloka 15 [present] · PDF page 324

15. When the air element is predominant, that is, when
Shani's strength is predominant, the body is filthy. The
person becomes an idiot and suffers from rheumatism, sorrows,
and agonies.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P324_B004_01

- 身份：正文
- PDF 页：324
- 偈颂：16
- 标题路径：CHAPTER 76 Effects of the five Elements : Space, Air, Fire, › Water, and Earth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the five Elements : Space, Air, Fire, · Sloka 16 [present] · PDF page 324

16. The sage said: O Brahmin! the effects of the five
elements which I have described above will be realized in
full if the grahas concerned are endowed with adequate
strength. If they are weak the effects will be reduced in
proportion to their weakness.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P324_B005_01

- 身份：正文
- PDF 页：324
- 偈颂：17
- 标题路径：CHAPTER 76 Effects of the five Elements : Space, Air, Fire, › Water, and Earth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the five Elements : Space, Air, Fire, · Sloka 17 [present] · PDF page 324

17. If the grah concerned is in his debilitation rashi or be
placed in an inauspicious bhava, the elemental effects will
be adverse, that is, opposite to the effects described above.
If a grah is without strength his elemental effects will be
experienced only in imagination.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P324_B006_01

- 身份：正文
- PDF 页：324
- 偈颂：18
- 标题路径：CHAPTER 76 Effects of the five Elements : Space, Air, Fire, › Water, and Earth
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the five Elements : Space, Air, Fire, · Sloka 18 [present] · PDF page 324

18. If a person's time, date, and place of birth is not known
he should determine the Dasa of a grah from the effects
mentioned above, and if he is facing evil effects he should
take appropriate remedial measures to appease the grah
concerned.
