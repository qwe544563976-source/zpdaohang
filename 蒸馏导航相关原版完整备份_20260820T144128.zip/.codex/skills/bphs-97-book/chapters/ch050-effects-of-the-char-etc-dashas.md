# 第 50 章：Effects of the Char, etc., Dashas

- 来源：BPHS 97 章版
- 原始卡片：32 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P208_B002_01

- 身份：正文
- PDF 页：208
- 偈颂：1-3
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 1-3 [present] · PDF page 208

1-3. Maharishi Parashar said: O Brahmin! I have already
described the Char, etc., Dashas. Now, I am going to tell
you the effects of these Dashas.
The effects of the Dashas of the Rashis should be judged
from the strength of the lords of Rashis and whether they
are benefics or malefics. If the lord of a Rashi possesses
full strength, the effects of the Dasha of the Rashi will
be realized in full. The effects of the Dasha will be of
medium nature if the strength is medium. If the lord of
Rashi possesses little strength, the effects will be
experienced accordingly.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P208_B003_01

- 身份：正文
- PDF 页：208
- 偈颂：4-10
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 4-10 [present] · PDF page 208

4-10. If there are malefics in the 8th, the 5th, and the
9th from a Dasha Rashi (that is, the Rashi whose Dasha is
in operation) the effects of the Dasha of that Rashi will
be distressful. If there are malefics in the 3rd and the
6th from a Dasha Rashi, the effects of the Dasha will be
victory over enemies and happiness. If there are benefics
in the 3rd and the 6th from the Dasha Rashi, there will be
defeat in its Dasha. If there are benefics or malefics in
the 11th from the Dasha Rashi, there will be conquests and
happiness in the Dasha. If the Dasha Rashi is occupied by
or is owned by a benefic, the effects of its Dasha will be
beneficial. If a Dasha Rashi owned by a benefic, is
occupied by a malefic, favourable effects will be
experienced in the first part of the Dasha and they will be
adverse in the latter part. If a Dasha Rashi owned by a
malefic is occupied by a benefic, the effects of the Dasha
will be the same. A Dasha Rashi owned and occupied by a
malefic will always yield unfavourable results. The reverse
will be the case in the case of the Dasha Rashi owned and
occupied by a benefic. If a Dasha Rashi owned by a benefic
is occupied by both benefic and malefic grahas, the effects
of Dasha will be adverse in its first part and favourable
in the latter part.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P208_B003_02

- 身份：正文
- PDF 页：208
- 偈颂：4-10
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 4-10 [present] · PDF page 208

4-10. If there are malefics in the 8th, the 5th, and the
9th from a Dasha Rashi (that is, the Rashi whose Dasha is
in operation) the effects of the Dasha of that Rashi will
be distressful. If there are malefics in the 3rd and the
6th from a Dasha Rashi, the effects of the Dasha will be
victory over enemies and happiness. If there are benefics
in the 3rd and the 6th from the Dasha Rashi, there will be
defeat in its Dasha. If there are benefics or malefics in
the 11th from the Dasha Rashi, there will be conquests and
happiness in the Dasha. If the Dasha Rashi is occupied by
or is owned by a benefic, the effects of its Dasha will be
beneficial. If a Dasha Rashi owned by a benefic, is
occupied by a malefic, favourable effects will be
experienced in the first part of the Dasha and they will be
adverse in the latter part. If a Dasha Rashi owned by a
malefic is occupied by a benefic, the effects of the Dasha
will be the same. A Dasha Rashi owned and occupied by a
malefic will always yield unfavourable results. The reverse
will be the case in the case of the Dasha Rashi owned and
occupied by a benefic. If a Dasha Rashi owned by a benefic
is occupied by both benefic and malefic grahas, the effects
of Dasha will be adverse in its first part and favourable
in the latter part.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P208_B004_01

- 身份：正文
- PDF 页：208
- 偈颂：11-17
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 11-17 [present] · PDF page 208

11-17. The assessment or the effects of the Dasha of the
Dasha Rashi should be made after taking into account the
disposition of the grahas in the Rashi at birth and the
disposition of grahas during the Dasha. If the Dasha Rashi
is well disposed both at the time of birth and during its
Dasha, the beneficial results will be realized in full. If
it is ill disposed during the Dasha, the effects will be of
mixed nature. If the Dasha Rashi is ill disposed both at
the time of birth and during its Dasha, only evil effects
will be experienced.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P208_B005_01

- 身份：正文
- PDF 页：208
- 偈颂：18-19
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 18-19 [present] · PDF page 208

18-19. The effects of the Dasha will be favourable if it is
occupied by a benefic and there is also a benefic in the
Rashi previous to it. If the Rashi is occupied by a
malefic, the effects will be of adverse nature. If there
are benefics in Putr and Dharm Bhava, the effects, of its
Dasha will be favourable. The reverse will be the case if
Putr and Dharm Bhava are occupied by malefics.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P209_B001_01

- 身份：正文
- PDF 页：209
- 偈颂：20-21
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 20-21 [present] · PDF page 209

20-21. Kumbh, Vrishabh, Simh, and Vrischik are Badhak
Bhavas for the four moveable Rashis: Mesh, Kark, Tula, and
Makar, in that order. In other words the 11th Rashi to a
moveable Rashi is its Badhak Bhava. If there is a malefic
in the Bhava occupied by its lord or in Badhak Bhava of
that Rashi, there will be occasions of great sorrow,
imprisonment, and diseases during the Dasha.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P209_B002_01

- 身份：正文
- PDF 页：209
- 偈颂：22
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 22 [present] · PDF page 209

22. The Dasha of a Rashi will be favourable if it is
occupied by its own lord or an exalted grah. The Dasha of a
Rashi not occupied by any grah will be adverse.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P209_B003_01

- 身份：正文
- PDF 页：209
- 偈颂：23-25
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 23-25 [present] · PDF page 209

23-25. There will be great danger, imprisonment during a
journey, displeasure of Government and danger from enemies,
in the Dasha and Antar Dasha of the Rashi from which its
Badhak Bhava, Vyaya, Ari, and Randhr Bhava are occupied by
Rahu. There will be loss due to the displeasure of the king
and danger there from in the Antar Dasha (sub-period) of
the Rashi that is occupied by Surya, Mangal, Rahu, and
Shani. There will be the possibility of death if the 5th
and the 9th from the Antar Dasha Rashi are occupied by a
debilitated or malefic Grah.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P209_B004_01

- 身份：正文
- PDF 页：209
- 偈颂：26-28
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 26-28 [present] · PDF page 209

26-28. There will be enjoyment, acquisition of chiefship of
a town or village, birth of a son, financial gains,
well-being, dawn of fortune, attainment of the position of
a commander of an army and progress all round if there is
an exalted grah in the Trikon from the Antar Dasha Rashi.
There will be in his Dasha financial gains, well being and
birth of a son if the Grah, who is the lord of the Dasha,
happens to be in a benefic Rashi and receives a drishti
from Guru.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P209_B005_01

- 身份：正文
- PDF 页：209
- 偈颂：29-32
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 29-32 [present] · PDF page 209

29-32. Vrishabh, Tula, Makar, Kumbh, and Mithun are the
inimical Rashis of Surya. The inimical Rashis of Chandr and
other grahas may be reckoned similarly. If a Grah is in an
inimical Rashi, his Dasha will be full of adversities. The
effects of the Dasha of Rashis and Grahas should be judged
after taking into account the above rules.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P209_B006_01

- 身份：正文
- PDF 页：209
- 偈颂：33-34
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 33-34 [present] · PDF page 209

33-34. The Dashas of that Grah will be favourable who is
Raj Yog Karak, who is disposed between two benefics (that
is, there are benefics in the 2nd and the 12th bhavas to
that grah), and who has benefics in the 2nd, 3rd and 4th
Bhavas from him. A malefic Grah becomes favourable if he is
disposed between benefics.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P209_B007_01

- 身份：正文
- PDF 页：209
- 偈颂：35-36
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 35-36 [present] · PDF page 209

35-36. The whole of the Dasha of a Grah who is related to a
friendly and benefic Grah at the commencement and the end
of the Dasha, will be favourable. In an unfavorable Dasha,
the Antar Dasha of a benefic (Grah or Rashi) becomes
favourable. The Dasha of a Grah or Rashi who has benefics
in the 5th or the 9th from it, is also favourable. In this
manner the effects of  the Dasha should be judged after
taking into account the dispositions of the Grah or Rashi,
at the commencement and at the end of the Dasha.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P210_B001_01

- 身份：正文
- PDF 页：210
- 偈颂：37-39
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 37-39 [present] · PDF page 210

37-39. The Dasha of the Grahas and Rashis who have benefics
in the Trikon from them is favourable. If the Dasha of a
benefic Rashi commences in a benefic Rashi, it will be very
favourable. If an evil Dasha commences in a benefic Rashi,
it is also favourable. Therefore, the commencement of a
Dasha should always be kept in view in assessing the
results of the Dasha. There will be loss of fortune if at
the commencement of the Dasha there is a malefic Rashi or
if the lord of the Dasha Rashi is in debilitation.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P210_B002_01

- 身份：正文
- PDF 页：210
- 偈颂：40-41
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 40-41 [present] · PDF page 210

40-41. There will be loss of fortune, wealth and
agricultural products and infliction with disease during
the Dasha of the Rashi occupied by a debilitated grah, or
if there is a debilitated grah in the 5th from it or in the
9th from it, or whose lord is debilitated or related to a
debilitated grah.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P210_B003_01

- 身份：正文
- PDF 页：210
- 偈颂：42
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 42 [present] · PDF page 210

42. Four Rashis from Kumbh and four Rashis from Vrischik
belong to Rahu and Ketu respectively. If Rahu and Ketu are
in any one of the aforesaid Rashis, the Dasha will be
productive of beneficial results.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P210_B004_01

- 身份：正文
- PDF 页：210
- 偈颂：43-45
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 43-45 [present] · PDF page 210

43-45. If a Grah, whose Dasha is otherwise considered
favourable, is placed in a Marak Bhava, or if the Rashi in
which his Dasha comes to an end receives a drishti from
Shukr or Chandr, there will be in his Dasha displeasure of
government and loss of wealth.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P210_B005_01

- 身份：正文
- PDF 页：210
- 偈颂：46-47
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 46-47 [present] · PDF page 210

46-47. There will be loss of every thing, imprisonment,
death, exile from the country and great distress at the end
of the Dasha of Rahu. The above effects will definitely be
realized if there are malefics in the 5th and the 9th from
Rahu. Beneficial and adverse effects should be predicted in
this manner.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P210_B006_01

- 身份：正文
- PDF 页：210
- 偈颂：48-50
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 48-50 [present] · PDF page 210

48-50. The same would be the effects in the Dasha of the
Rashi occupied by malefics like Rahu, etc.. The association
of a Marak Grah with the Rashi at the time of commencement
of its Dasha is not productive of good effects. If such a
grah is Rahu there will be imprisonment or loss of wealth.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P210_B007_01

- 身份：正文
- PDF 页：210
- 偈颂：51-52
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 51-52 [present] · PDF page 210

51-52. The natural characteristics of the Bhava occupied by
Rahu are harmed at the commencement of the Dasha. If such a
bhava is Dhan Bhava, there will be loss of wealth. If
Chandr and Shukr are in Vyaya Bhava there will be losses
due to the displeasure of government. If Mangal and Ketu
are so disposed there will be death or danger from fire.
There will be acquisition of a kingdom if Shukr and Chandr
are in Dhan Bhava, at the commencement of the Dasha. This
means that the effects (good or bad) of the Bhava in which
Chandr and Shukr are placed at the commencement and end of
a Dasha, are strengthened. Thus, their disposition in Ari,
Randhr, and Vyaya Bhava will produce only adverse effects.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P211_B001_01

- 身份：正文
- PDF 页：211
- 偈颂：53-55
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 53-55 [present] · PDF page 211

53-55. Similarly, the sages have described the effects of
the Bhava with Argal. If there is an auspicious Argal
causing benefic or malefic Grah of a Rashi and Lagn
receives a drishti from him that Rashi will prevail. Here
Lagn is the secondary condition. If the Grah causing
uninterrupted Argal, gives a drishti to a Rashi, that Rashi
will prevail. In other words, good effects will be derived
in the Dasha of that Rashi. The Dasha of the Rashi which
does not receive a drishti from an auspicious Argal, or the
Dasha of a Rashi with Vipreet Argal, will not be
favourable. The Dasha of that Rashi which receives a
drishti from a benefic will be favourable.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P211_B002_01

- 身份：正文
- PDF 页：211
- 偈颂：56-59
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 56-59 [present] · PDF page 211

56-59. Financial gains will be derived in the Dasha of the
Rashi which is occupied by its benefic lord or by an
exalted Grah who receives a drishti from him. There will be
loss of wealth if such a Grah is in the 12th bhava to the
Rashi (or Bhava). There will be destruction of all good
effects, distress to children and father, and mental agony
in the Dasha of the Rashi if there are malefics in the 5th
and the 9th from the Rashi. Evil effects will be
experienced in the Dasha of the Rashi which is occupied by
Randhr's lord, Vyaya's lord, Surya, Mangal, or Shani.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P211_B003_01

- 身份：正文
- PDF 页：211
- 偈颂：60-63
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 60-63 [present] · PDF page 211

60-63. The Dasha of the Rashi will cause distress to
children, exile to a foreign country and continuous
disturbances in life if Rahu and Ketu are in the Trikon to
the Rashi. There will be danger from enemies, from the king
(Government), and disease in the Dasha of the Rashi which
is so posited that the 6th and the 8th from it are occupied
by malefic, debilitated, or combust grahas. There will be
destruction of house, land, and agricultural fields if
there is a malefic or debilitated Grah in the 4th from the
Rashi. There will be loss of house due to negligence if
such a Grah is Mangal; there will be heart pain and danger
from government if the Grah is Shani; and there will be
losses all round, and danger from poison and thieves, if
the Grah is Rahu.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P211_B004_01

- 身份：正文
- PDF 页：211
- 偈颂：64-66 1/2
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 64-66 1/2 [present] · PDF page 211

64-66 1/2. There will be pilgrimage to holy places in the
Dasha of the Rashi who has Rahu in the 10th to it. There
will be gain of earnings, religious rites, gain of wealth,
renown for good deeds, and success in efforts and ventures
in the Dasha of the Rashi which is so posited that the
10th, the 11th, and the 9th from it are occupied by
benefics. There will be birth of children, happiness from
wife and recognition by the Government in the Dasha of the
Rashi from which the 5th, the 7th, and the 9th are occupied
by benefic or exalted Grahas. During the Dasha of the
Bhavas (Rashis) occupied by Putr's lord, Labh's lord,
Karm's lord, Bandhu's lord, Dharm's lord, and Lagn's lord
there will be growth of these bhavas (good effects). The
good effects will be in proportion to the strength of the
Bhavas and the Grahas occupying them.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P212_B001_01

- 身份：正文
- PDF 页：212
- 偈颂：67-70
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 67-70 [present] · PDF page 212

67-70. In the Dasha of a Rashi (Bhava) there will be well
beings, increase in opulence and glory and devotion to
deities and Brahmins, if it is occupied by Guru, Shukr, or
the lord of a Trikon. There will be acquisition of more
conveyance and cattle, etc., in the Dasha of the Rashi
(Bhava) which is so posited that the 4th from it is
occupied by an exalted Grah or lord of a Trikon. Chandr
there, will give things like grains, ghee, etc.. Full
Chandr will favour with a treasure and jewels, etc.. Shukr
there, will provide enjoyment from music, etc..

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P212_B002_01

- 身份：正文
- PDF 页：212
- 偈颂：71-72
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 71-72 [present] · PDF page 212

71-72. There will be enjoyment of the palanquin like
conveyance in the Dasha of the Rashi (Bhava) from which the
4th is occupied by Guru. There will be success in all
ventures, great opulence and glory, acquisition of a
kingdom (attainment of a high position, etc.), during the
Dasha of a Rashi (Bhava) which has the Yog of the lord of
Lagn, Dharm's lord, Karm's lord, an exalted grah, or
benefics. The effects of the Dashas of various Bhavas
should be judged in this manner.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P212_B003_01

- 身份：正文
- PDF 页：212
- 偈颂：73-77
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 73-77 [present] · PDF page 212

73-77. The effects of the Dashas of each Rashi or Grah
(Nakshatr Dasha) depend on their 18 different kinds of
conditions. They are deep exaltation, exaltation,
dispositions on their either side, Multrikon, own Rashi,
Adhimitr Rashi, Tatkalik Mitra's Rashi, neutral Rashi,
enemy's Rashi, Adhisatru's Rashi, deep debilitation,
debilitated or enemy's Varg, own Varg, disposition in a
Kendr, disposition in a Trikon, defeated in war between
grahas, deep combustion.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P212_B004_01

- 身份：正文
- PDF 页：212
- 偈颂：78-83 1/2
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 78-83 1/2 [present] · PDF page 212

78-83 1/2. Acquisition of kingdom (attainment of a high
position in government), enjoyment and acquisition of more
property are the effects of the whole Dasha of the Grah who
is in deep exaltation and is fully equipped with all the
six kinds of strength (Shad Bal), great opulence and glory
with some possibility of affliction with disease are the
effects of the Grah placed in his Rashi of exaltation. The
Dasha of a Grah in deep debilitation is called 'rikt'.
Diseases, loss of wealth, and danger of death are the
effects of the Dasha of such a Grah. The Dasha of the Grah
who is in a condition in between deep exaltation and deep
debilitation is known as 'Avrohini' (descending). The Dasha
of the Grah in exaltation or in a friend's Rashi is called
Madhya (of middle order). This Dasha also yields moderately
good effects. The Dasha of a Grah placed in a condition in
between deep debilitation and deep exaltation is called
'Rohini' (ascending). The Dasha of a Grah placed in between
the debilitated and enemy Navamsh is called Adham (evil).
Dangers of various kinds, distress, and sorrows are the
results of the Dasha of such a Grah. These Dashas give
results according to their nomenclature.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P213_B001_01

- 身份：正文
- PDF 页：213
- 偈颂：84-87
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 84-87 [present] · PDF page 213

84-87. The Dashas of other Grahas become auspicious and
augment the fortune if the lord of Dharm Bhava and Guru are
in any way related with Yog, Kendr, or the Bhava concerned,
etc.. The Grah with Yog of good fortune at birth produces
good effects when he is free from retrogression and becomes
direct. The weakness, inabilities and Yogas of other Grahas
should also be taken into account in judging their effects.
All those Dashas give full, medium, and little effects in
accordance with the disposition of the Grahas in the Kendr,
Panaphara, and Apoklima Bhavas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P213_B002_01

- 身份：正文
- PDF 页：213
- 偈颂：88-89 1/2
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 88-89 1/2 [present] · PDF page 213

88-89 1/2. The Grahas in Shirshodaya Rashis, Ubhayodaya
Rashis, and Prishthodaya Rashis, yield their results
respectively at the commencement of the Dasha, in the
middle of the Dasha and at the end of the Dasha. All the
Grahas yield auspicious results in the Antar Dasha of
Naisargik (natural, constant) and Tatkalik (according to
position) friends. The results will be adverse in the Antar
Dasha of inimical Grahas.
Antar Dashas of Rashis

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P213_B003_01

- 身份：正文
- PDF 页：213
- 偈颂：90-96
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 90-96 [present] · PDF page 213

90-96. There are Antar Dashas of the 12 Rashis commencing
from the Rashi in which the lord of the Dasha is placed.
There will be auspicious results like acquisition of
kingdom (attainment of a high position in government) in
the Antar Dasha of a Rashi which is occupied by its own
lord or a friendly Grah. There will be inauspicious results
like loss of wealth, disputes, danger from diseases, etc.,
in the Antar Dasha of the Rashi which may be Ari, Randhr,
or Vyaya Bhava, or is occupied by a malefic, debilitated
Grah or a Grah placed in an inimical Rashi. The Rashi which
contained more auspicious marks in the Ashtak Varg will
yield benefic effects in its Antar Dasha. Adverse will be
the effects of the Antar Dasha of the Rashi which contains
more inauspicious marks. For assessing the results, the
Rashi from which the Dasha commences, should be  treated as
Lagn and the bhavas thereafter should be assumed to have
the characteristics as if they are so from Lagn. Thus, the
2nd Bhava from that Rashi will be the Bhava of the wealth,
the 3rd of co-borns and so on. There will be gains or
losses of Dhatus, etc., assigned to the Rashis and the
Grahas in the Antar Dasha of the Rashis concerned. In
judging the effects of the Antar Dashas of the Grahas their
benefic and malefic nature, relations with the malefic or
benefic drishtis on them and their disposition in Ari,
Randhr, or Vyaya Bhava, etc., should all be kept in view.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P213_B003_02

- 身份：正文
- PDF 页：213
- 偈颂：90-96
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 90-96 [present] · PDF page 213

90-96. There are Antar Dashas of the 12 Rashis commencing
from the Rashi in which the lord of the Dasha is placed.
There will be auspicious results like acquisition of
kingdom (attainment of a high position in government) in
the Antar Dasha of a Rashi which is occupied by its own
lord or a friendly Grah. There will be inauspicious results
like loss of wealth, disputes, danger from diseases, etc.,
in the Antar Dasha of the Rashi which may be Ari, Randhr,
or Vyaya Bhava, or is occupied by a malefic, debilitated
Grah or a Grah placed in an inimical Rashi. The Rashi which
contained more auspicious marks in the Ashtak Varg will
yield benefic effects in its Antar Dasha. Adverse will be
the effects of the Antar Dasha of the Rashi which contains
more inauspicious marks. For assessing the results, the
Rashi from which the Dasha commences, should be  treated as
Lagn and the bhavas thereafter should be assumed to have
the characteristics as if they are so from Lagn. Thus, the
2nd Bhava from that Rashi will be the Bhava of the wealth,
the 3rd of co-borns and so on. There will be gains or
losses of Dhatus, etc., assigned to the Rashis and the
Grahas in the Antar Dasha of the Rashis concerned. In
judging the effects of the Antar Dashas of the Grahas their
benefic and malefic nature, relations with the malefic or
benefic drishtis on them and their disposition in Ari,
Randhr, or Vyaya Bhava, etc., should all be kept in view.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P213_B004_01

- 身份：正文
- PDF 页：213
- 偈颂：97
- 标题路径：CHAPTER 50 Effects of the Char, etc., Dashas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Char, etc., Dashas · Sloka 97 [present] · PDF page 213

97. The results of the Antar Dashas (Sub-periods)
Pratyantar Dashas of the Rashis, should be assessed in the
manner explained in this chapter.
