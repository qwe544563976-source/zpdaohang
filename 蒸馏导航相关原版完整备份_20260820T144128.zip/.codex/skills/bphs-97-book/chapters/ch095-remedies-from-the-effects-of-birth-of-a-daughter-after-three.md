# 第 95 章：Remedies from the effects of birth of a daughter after three

- 来源：BPHS 97 章版
- 原始卡片：4 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P370_B002_01

- 身份：正文
- PDF 页：370
- 偈颂：—
- 标题路径：CHAPTER 95 Remedies from the effects of birth of a daughter after three
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from the effects of birth of a daughter after three · Sloka unknown [unknown] · PDF page 370 · page_block BPHS_PL9_CHAP_97_P370_B002

sons

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P370_B003_01

- 身份：正文
- PDF 页：370
- 偈颂：1-2
- 标题路径：CHAPTER 95 Remedies from the effects of birth of a daughter after three
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from the effects of birth of a daughter after three · Sloka 1-2 [present] · PDF page 370

1-2. The Sage said: O Brahmin! I will now tell you about
other kinds of inauspicious births. The birth of a daughter
after the birth of three sons or the birth of a son after the
birth of three daughters is ominous for both the maternal and
paternal families of such children. Therefore, remedial
measures described below may be taken to get deliverence from
these evil effects.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P370_B004_01

- 身份：正文
- PDF 页：370
- 偈颂：3-9
- 标题路径：CHAPTER 95 Remedies from the effects of birth of a daughter after three
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from the effects of birth of a daughter after three · Sloka 3-9 [present] · PDF page 370

3-9. The rites should be performed on the morning next to the
last day of Sutak, or on any other auspicious day in the
following order:
(I) After selecting a priest and some Brahmins to perform the
remedial religious rites, the priest after paying obeisance
to the nine grahas should install four Kalashas on a heep of
paddy, place the idols of Brahma, Vishnu, Mahesha, and Indra
made of gold on them and perform their worship in the
prescribed manner.
(2) A Brahmin (an assistant of the priest) after taking bath,
etc., should recite four Rudra Suktas and the whole of Shanti
Sukta.
(3) The priest should perform havan with samidha, ghee, and
sesame seeds 1008, 108, or 28 times (as may be possible
within one's means) with the recitation of the prescribed
mantras of Brahma, Vishnu, Mahesha, and Indra.
(4) Svistkrata and Purnahuti and abhisheka of the child with
his family should be done and presents in cash should be
given to the priest and his assistants according to one's
means.
(5) The Brahmins should be fed (this should also be done
according to one's means).
(6) The father and the mother of the child should see their
reflections in the ghee kept in a bronze vessel.
(7). Lastly, grains and clothes should be distributed to the
poor and the needy.
By the performance of the above remedial rites, the evil
effects are wiped out and the child and his parents, etc.,
enjoy happiness.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P370_B004_02

- 身份：正文
- PDF 页：370
- 偈颂：3-9
- 标题路径：CHAPTER 95 Remedies from the effects of birth of a daughter after three
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Remedies from the effects of birth of a daughter after three · Sloka 3-9 [present] · PDF page 370

3-9. The rites should be performed on the morning next to the
last day of Sutak, or on any other auspicious day in the
following order:
(I) After selecting a priest and some Brahmins to perform the
remedial religious rites, the priest after paying obeisance
to the nine grahas should install four Kalashas on a heep of
paddy, place the idols of Brahma, Vishnu, Mahesha, and Indra
made of gold on them and perform their worship in the
prescribed manner.
(2) A Brahmin (an assistant of the priest) after taking bath,
etc., should recite four Rudra Suktas and the whole of Shanti
Sukta.
(3) The priest should perform havan with samidha, ghee, and
sesame seeds 1008, 108, or 28 times (as may be possible
within one's means) with the recitation of the prescribed
mantras of Brahma, Vishnu, Mahesha, and Indra.
(4) Svistkrata and Purnahuti and abhisheka of the child with
his family should be done and presents in cash should be
given to the priest and his assistants according to one's
means.
(5) The Brahmins should be fed (this should also be done
according to one's means).
(6) The father and the mother of the child should see their
reflections in the ghee kept in a bronze vessel.
(7). Lastly, grains and clothes should be distributed to the
poor and the needy.
By the performance of the above remedial rites, the evil
effects are wiped out and the child and his parents, etc.,
enjoy happiness.
