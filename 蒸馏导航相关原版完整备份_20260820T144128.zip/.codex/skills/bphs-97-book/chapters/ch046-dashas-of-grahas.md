# 第 46 章：Dashas of Grahas

- 来源：BPHS 97 章版
- 原始卡片：98 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P174_B002_01

- 身份：正文
- PDF 页：174
- 偈颂：1
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 1 [present] · PDF page 174

1. Maitreya said: O venerable Maharishi Parashar! You are
omniscient. There is no subject with which you are not
conversant. Therefore, now, please favour me with guidance
about the different kinds of Dashas (periods) of the
various grahas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P174_B003_01

- 身份：正文
- PDF 页：174
- 偈颂：2-5
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 2-5 [present] · PDF page 174

2-5. Maharishi Parashar replied: O Brahmin! Dashas are of
many kinds. Amongst them Vimshottari is the most
appropriate for the general populace. But, the other Dashas
followed in special cases are Astottari, Shodshottari,
Dwadashottari, Panchottari, Shatabdik, Chaturashiti-sama,
Dwisaptati-sama, Shastihayani, Shatvimsh-sama. Our ancients
have described these different kinds of Dashas based on
Nakshatras (constellations).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P174_B004_01

- 身份：正文
- PDF 页：174
- 偈颂：6-11
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 6-11 [present] · PDF page 174

6-11. 0 Brahmin! Some Maharishis have made a mention of
Kala Dasha and Chakr Dasha; but they have recognized the
Kala Chakr Dasha as supreme. The other kinds of Dashas
propagated by the sages are: Char Dasha, Sthir Dasha, Kendr
Dasha, Karak Dasha, Brahma Grah Dasha, Manduk Dasha, Shul
Dasha, Yogardh Dasha, Drig Dasha, Trikon Dasha, Rashi
Dasha, Panchswara Dasha, Yogini Dasha, Pind Dasha,
Nausargik Dasha, Asht Varg Dasha, Sandhya Dasha, Pachak
Dasha, Tara Dasha, etc.. But, in our view all these Dashas
are not appropriate (for the purpose for which they are
meant).
Vimshottari Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P174_B005_01

- 身份：正文
- PDF 页：174
- 偈颂：12-14
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 12-14 [present] · PDF page 174

12-14. Beginning from Kritika the lords of Dashas are
Surya, Chandr, Mangal, Rahu, Guru, Shani, Buddh, Ketu and
Shukr in that order. Thus, if the nakshatras from Kritika
to the Janm Nakshatr (natal constellation) are divided by
nine, the remainder will signify the lord of the commencing
Dasha. The remaining Dashas will be of the grahas in the
order given above.
In Kali Yuga the natural life span of a human being is
generally taken as 120 years. Therefore, Vimshottari Dasha
is considered to be the most appropriate and the best of
all Dashas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P174_B006_01

- 身份：正文
- PDF 页：174
- 偈颂：15
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 15 [present] · PDF page 174

15. The periods of Dashas of Surya, Chandr, Mangal, Rahu,
Guru, Shani, Buddh, Ketu, and Shukr are 6, 10, 7, 18, 16,
19, 17, 7, and 20 in that order.
Table of Dashas
Constellations                         Dasha Lord Years
Kritika, Uttaraphalguni & Uttarashadha Surya      6
Rohini, Hast & Shravan                 Chandr     10
Mrigashira, Chitra & Dhanishtha        Mangal     7
Ardra, Swati & Shatabhisha             Rahu       18
Punarvasu, Vishakah & Purvabhadrapad   Guru       16
Pushya, Anuradha & Uttarabhadrapad     Shani      19
Aslesha, Jyeshtha & Revati             Buddh      17
Magha, Mul & Ashvini                   Ketu       7
Purvaphalguni, Purvashadha & Bharani   Shukr      20

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P175_B001_01

- 身份：正文
- PDF 页：175
- 偈颂：16
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 16 [present] · PDF page 175

16. To find out the remainder of the Dasha operating at the
time of birth, first find out the expired portion of the
Dasha of the concerned grah. This is done as follows:
Multiply the Dasha period of the grah concerned by the
period of the stay of Chandr in Janm Nakshatr that has
expired, and divide that amount by the total period of the
stay of Chandr in that Nakshatr. The figure in years,
months, etc., so arrived at will be the expired period of
the Dasha.
If this figure is deducted from the total period of the
Dasha, we will get the balance of Dasha at the time of
birth.
Ashtottari Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P175_B002_01

- 身份：正文
- PDF 页：175
- 偈颂：17-20
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 17-20 [present] · PDF page 175

17-20. Maharishi Parashar said: O Brahmin, the sages have
recommended the adoption of Ashtottari Dasha, when Rahu not
being in Lagn, in any other Kendr or Trikon to the lord of
the Lagn. From 4 Nakshatras from Ardra commences the Dasha
of Surya; from 3 Nakshatras after that begins the Dasha of
Chandr; 4 Nakshatras after that will bring the Dasha of
Mangal; 3 Nakshatras after that the lord of Dasha will be
Buddh; 4 Nakshatras therefrom will have Shani as the Dasha
Lord; 3 Nakshatras thereafter the Dasha Lord will be Guru;
Rahu will be the lord of the Dasha 4 Nakshatras after that,
and then Shukr will take over the lordship of the Dasha 3
Nakshatras from the last one mentioned above. The lord of
the Dasha at birth will be determined by counting in this
order up to the Janm Nakshatr.
The duration of Ashtottari Dasha for Surya, Chandr, Mangal,
Buddh, Shani, Guru, Rahu, and Shukr are 6, 15, 8, 17, 10,
19, 12, and 21, in that order. Thus, in this Dasha system
only 8 grahas play the role of Dasha lords, Ketu having
been denied this privilege.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P175_B003_01

- 身份：正文
- PDF 页：175
- 偈颂：21-22
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 21-22 [present] · PDF page 175

21-22. The Dashas of the various grahas have been specified
above. In the case of malefic grahas the Dasha span of one
Nakshatr is 1/4th of the Dasha of the grah. It is 1/3rd in
the case of benefics. Thus, the expired portion of the
Dasha is calculated according to the method followed for
Vimshottari Dasha by multiplying the Bhayat, i.e. the
expired period of the stay of Chandr in the Janm Nakshatr,
by the Dasha portion of the Janm Nakshatr and dividing it
by Bhabhog, i.e. the total period of the stay of Chandr in
the Janm Nakshatr. Then, the balance of Dasha at birth can
also be ascertained.
If Uttarashadha happens to be the Janm Nakshatr the
duration of its first three padas is taken as Bhabhog, and
the Dasha calculations should be done accordingly. The
Dasha and calculations for Abhijit Nakshatr are done by
taking the 4th pad of Uttarashadha plus the 15th part of
the beginning of Shravan. For Shravan the Bhabhog would be
the total of its duration in ghatikas minus the 1/15th part
of the beginning of Shravan.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P175_B004_01

- 身份：正文
- PDF 页：175
- 偈颂：23
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 23 [present] · PDF page 175

23. It will be advisable to adopt the Ashtottari Dasha if
the birth is in the day in Krishna Paksh (Dark half of the
month) or at night in Shukla Paksh (Bright half of the
month ).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P176_B001_01

- 身份：正文
- PDF 页：176
- 偈颂：24-26
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 24-26 [present] · PDF page 176

24-26. The Dasha may be adopted when the Lagn is in the
Hora of Chandr with birth in the Krishna Paksh (Dark half
of the month) or when Lagn is in the hora of Surya, with
birth in the Shukla Paksh (Bright half of the month ).
Count the number of Nakshatras from Pushya to the Janm
Nakshatr. Divide this number by 8. The remainder will
indicate the Dashas of Surya, Mangal, Guru, Shani, Ketu,
Chandr, Buddh, and Shukr (Rahu has no Dasha in this
system). The Dashas of the above grahas are of: 11 (Surya),
12 (Mangal), 13 (Guru), 14 (Shani), 15 (Ketu), 16 (Chandr),
17 (Buddh), and 18 years (Shukr).
Dwadashottari Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P176_B002_01

- 身份：正文
- PDF 页：176
- 偈颂：27-28
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 27-28 [present] · PDF page 176

27-28. This Dasha system will be appropriate for one whose
Lagn is in the Navamsh of Shukr. Count from Janm Nakshatr
to Revati. Divide this number by 8. The remainder will
indicate the Dasha of the grah concerned. The Dasha order
is Surya, Guru, Ketu, Buddh, Rahu, Mangal, Shani, Chandr.
(Shukr does not find a place in this Dasha system.). The
Dashas will be of 7 (Surya), 9 (Guru), 11 (Ketu), 13
(Buddh), 15 (Rahu), 17 (Mangal), 19 (Shani), and 21 years
(Chandr) of the grahas.
Panchottari Dasha
This Dasha is considered suitable for those whose Lagn is
Kark and also in the Kark Dvadashamsh. Count from Anuradha
up to the Janm Nakshatr and divide the number by 7. The
remainder will indicate the Dasha. The order of the Dasha
lords is Surya, Buddh, Shani, Mangal, Shukr, Chandr, and
Guru (Rahu and Ketu find no place in this system). The
Dashas of the grahas are 12 (Surya), 13 (Buddh), 14
(Shani), 15 (Mangal), 16 (Shukr), 17 (Chandr), and 18 years
(Guru).
For Example: The Janm Nakshatr is Mrigashira. Therefore,
Buddh Dasha will be in force at the time of birth. Buddh
Dasha is 13 years. The balance of Dasha at birth is to be
calculated after taking into account the Bhayat and Bhabhog
of the Janm Nakshatr in the manner already explained
earlier.
Shatabdik Dasha
This Dasha system has been considered appropriate if Lagn
is Vargottama. This happens when Lagn in the Rashi Kundali
and the Navamsh Lagn are in the same rashi.
Count from Revati to the Janm Nakshatr and divide this
number by seven. The remainder will indicate the lords of
Dashas in this order: Surya, Chandr, Shukr, Buddh, Guru,
Mangal, and Shani. Their Dashas will be of 5 (Surya), 5
(Chandr), 10 (Shukr), 10 (Buddh), 20 (Guru), 20 (Mangal),
and 30 years (Shani). (Rahu and Ketu do not have a place in
this Dasha system).
Shatabdik Dasha Table
Surya  Revati     Punarvasu   Chitra   U.Ashadha   5 years
Chandr Ashvini    Pushya      Swati    Shravan     5 years
Shukr  Bharani    Aslesha     Vishakah Dhanishtha  10 years
Buddh  Kritika    Magha       Anuradha Shatabhisha 10 years
Guru   Rohini     P. Phalguni Jyeshtha P. Bhadra   20 years
Mangal Mrigashira U. Phalguni Mul      U. Bhadra   20 years
Shani  Ardra      Hast        P.Ashadha            30 years
Chaturashiti sama Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P176_B002_02

- 身份：正文
- PDF 页：176
- 偈颂：27-28
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 27-28 [present] · PDF page 176

27-28. This Dasha system will be appropriate for one whose
Lagn is in the Navamsh of Shukr. Count from Janm Nakshatr
to Revati. Divide this number by 8. The remainder will
indicate the Dasha of the grah concerned. The Dasha order
is Surya, Guru, Ketu, Buddh, Rahu, Mangal, Shani, Chandr.
(Shukr does not find a place in this Dasha system.). The
Dashas will be of 7 (Surya), 9 (Guru), 11 (Ketu), 13
(Buddh), 15 (Rahu), 17 (Mangal), 19 (Shani), and 21 years
(Chandr) of the grahas.
Panchottari Dasha
This Dasha is considered suitable for those whose Lagn is
Kark and also in the Kark Dvadashamsh. Count from Anuradha
up to the Janm Nakshatr and divide the number by 7. The
remainder will indicate the Dasha. The order of the Dasha
lords is Surya, Buddh, Shani, Mangal, Shukr, Chandr, and
Guru (Rahu and Ketu find no place in this system). The
Dashas of the grahas are 12 (Surya), 13 (Buddh), 14
(Shani), 15 (Mangal), 16 (Shukr), 17 (Chandr), and 18 years
(Guru).
For Example: The Janm Nakshatr is Mrigashira. Therefore,
Buddh Dasha will be in force at the time of birth. Buddh
Dasha is 13 years. The balance of Dasha at birth is to be
calculated after taking into account the Bhayat and Bhabhog
of the Janm Nakshatr in the manner already explained
earlier.
Shatabdik Dasha
This Dasha system has been considered appropriate if Lagn
is Vargottama. This happens when Lagn in the Rashi Kundali
and the Navamsh Lagn are in the same rashi.
Count from Revati to the Janm Nakshatr and divide this
number by seven. The remainder will indicate the lords of
Dashas in this order: Surya, Chandr, Shukr, Buddh, Guru,
Mangal, and Shani. Their Dashas will be of 5 (Surya), 5
(Chandr), 10 (Shukr), 10 (Buddh), 20 (Guru), 20 (Mangal),
and 30 years (Shani). (Rahu and Ketu do not have a place in
this Dasha system).
Shatabdik Dasha Table
Surya  Revati     Punarvasu   Chitra   U.Ashadha   5 years
Chandr Ashvini    Pushya      Swati    Shravan     5 years
Shukr  Bharani    Aslesha     Vishakah Dhanishtha  10 years
Buddh  Kritika    Magha       Anuradha Shatabhisha 10 years
Guru   Rohini     P. Phalguni Jyeshtha P. Bhadra   20 years
Mangal Mrigashira U. Phalguni Mul      U. Bhadra   20 years
Shani  Ardra      Hast        P.Ashadha            30 years
Chaturashiti sama Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P177_B001_01

- 身份：正文
- PDF 页：177
- 偈颂：35-36
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 35-36 [present] · PDF page 177

35-36. Chaturashiti sama Dasha is considered appropriate in
cases where the Karm's lord is placed in Karm Bhava.
Count from Swati to the Janm Nakshatr and divide this
number by 7. The remainder will indicate the Dasha lords in
the following order: Surya, Chandr, Mangal, Buddh, Guru,
Shukr, and Shani (Rahu and Ketu do not get a place in this
system). The Dasha period of each grah is 12 years.
Chaturashiti sama Dasha Table
Surya  Swati     Shravan     Bharani    Aslesha     12 years
Chandr Vishakah  Dhanishtha  Kritika    Magha       12 years
Shukr  P.Ashadha Revati      Punarvasu  Chitra      12 years
Buddh  Jyeshtha  P. Bhadra   Mrigashira U. Phalguni 12 years
Guru   Mul       U. Bhadra   Ardra      Hast        12 years
Mangal Anuradha  Shatabhisha Rohini     P. Phalguni 12 years
Shani  U.Ashadha Ashvini     Pushya                 12 years
Dwisaptati sama Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P177_B002_01

- 身份：正文
- PDF 页：177
- 偈颂：37-39
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 37-39 [present] · PDF page 177

37-39. This Dasha system is considered suitable is cases
where the lord of Lagn is in Lagn or in Yuvati Bhava.
Count from Mul to the Janm Nakshatr and divide the number
by 8. The remainder will determine the Dasha lords in the
following order: Surya, Chandr, Mangal, Buddh, Guru, Shukr,
Shani, and Rahu (Ketu has no place in this Dasha system).
In this Dasha system all the eight grahas have Dashas of 9
years each.
Dwisaptati sama Dasha Table
Surya   Mul         Revati     Pushya     Vishakah  9 Years
Chandr  P.Ashadha   Ashvini    Aslesha    Anuradha  9 Years
Mangal  U.Ashadha   Bharini    Magha      Jyeshtha  9 Years
Buddh   Shravan     Kritika    P.Phalguni           9 Years
Guru    Dhanishtha  Rohini     U.Phalguni           9 Years
Shukr   Shatabhisha Mrigashira Hast                 9 Years
Shani   P.Bhadra    Ardra      Chitra               9 Years
Rahu    U.Bhadra    Punarvasu  Swati                9 Years
Shastihayani Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P177_B003_01

- 身份：正文
- PDF 页：177
- 偈颂：40-41
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 40-41 [present] · PDF page 177

40-41. This Dasha may be adopted in cases where Surya is
posited in Lagn. The order of Dasha lords in this system is
as follows: Guru, Surya, Mangal, Chandr, Buddh, Shukr,
Shani, and Rahu. The following table (which is in
accordance with the above slokas) shows the Nakshatras
falling under the various Dasha lords. The Dashas of Guru,
Surya,and Mangal are of 13 years. The remaining grahas have
Dashas of 6 years each.
Shastihayani Dasha Table
Guru   Ashvini     Bharani    Kritika   Punarvasu  10 Years
Surya  Rohini      Mrigashira Ardra     U. Ashadha 10 Years
Mangal Pushya      Aslesha    Magha     Revati     10 Years
Chandr P.Phalguni  U.Phalguni Hast                  6 Years
Buddh  Swati       Vishakah   Anuradha              6 Years
Shukr  Jyeshtha    Mul        P.Ashadha             6 Years
Shani  Abhijit     Shravan    Dhanishtha            6 Years
Rahu   Shatabhisha P.Bhadra   U.Bhadra              6 Years
Shat-trimshat sama Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P178_B001_01

- 身份：正文
- PDF 页：178
- 偈颂：42-43
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 42-43 [present] · PDF page 178

42-43. Count from Shravan to the Janm Nakshatr and divide
the number by 8. The remainder 1, etc., will indicate the
Dasha lords whose order will be as follows: Chandr, Surya,
Guru, Mangal, Buddh, Shani, Shukr, and Rahu. Their Dashas
will be 1 (Chandr), 2 (Surya), 3 (Guru), 4 (Mangal), 5
(Buddh), 6 (Shani), 7 (Shukr), and 8 years (Rahu). If the
birth is during the day and Lagn is in the Hora of Surya,
and if the birth is at night and Lagn is in the Hora of
Chandr, adoption of this system would be preferable.
For Example: This is like the Vimshottari Dasha System.
Janm Nakshatr is Mrigashira. Guru is thus the first Dasha
lord. The Dasha span of Guru is 3 years. From this the
balance of Dasha at birth may be calculated after taking
into account the Bhayat and Bhabhog of the Janm Nakshatr.
Notes: According to Maharishi Parashar Vimshottari is the
main Dasha system applicable to all. The other Dashas like
Ashtottari, etc., are meant for use in special
circumstances.
Shat-trimshat sama Dasha Table
Chandr Shravan     Kritika    P.Phalguni Mul       1 year
Surya  Dhanishtha  Rohini     U.Phalguni P.Ashadha 2 years
Guru   Shatabhisha Mrigashira Hast       U.Ashadha 3 years
Mangal P.Bhadra    Ardra      Chitra               4 years
Buddh  U.Bhadra    Punarvasu  Swati                5 years
Shani  Revati      Pushya     Vishakah             6 years
Shukr  Ashvini     Aslesha    Anuradha             7 years
Rahu   Bharani     Magha      Jyeshtha             8 years
Kaal Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P178_B001_02

- 身份：正文
- PDF 页：178
- 偈颂：42-43
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 42-43 [present] · PDF page 178

42-43. Count from Shravan to the Janm Nakshatr and divide
the number by 8. The remainder 1, etc., will indicate the
Dasha lords whose order will be as follows: Chandr, Surya,
Guru, Mangal, Buddh, Shani, Shukr, and Rahu. Their Dashas
will be 1 (Chandr), 2 (Surya), 3 (Guru), 4 (Mangal), 5
(Buddh), 6 (Shani), 7 (Shukr), and 8 years (Rahu). If the
birth is during the day and Lagn is in the Hora of Surya,
and if the birth is at night and Lagn is in the Hora of
Chandr, adoption of this system would be preferable.
For Example: This is like the Vimshottari Dasha System.
Janm Nakshatr is Mrigashira. Guru is thus the first Dasha
lord. The Dasha span of Guru is 3 years. From this the
balance of Dasha at birth may be calculated after taking
into account the Bhayat and Bhabhog of the Janm Nakshatr.
Notes: According to Maharishi Parashar Vimshottari is the
main Dasha system applicable to all. The other Dashas like
Ashtottari, etc., are meant for use in special
circumstances.
Shat-trimshat sama Dasha Table
Chandr Shravan     Kritika    P.Phalguni Mul       1 year
Surya  Dhanishtha  Rohini     U.Phalguni P.Ashadha 2 years
Guru   Shatabhisha Mrigashira Hast       U.Ashadha 3 years
Mangal P.Bhadra    Ardra      Chitra               4 years
Buddh  U.Bhadra    Punarvasu  Swati                5 years
Shani  Revati      Pushya     Vishakah             6 years
Shukr  Ashvini     Aslesha    Anuradha             7 years
Rahu   Bharani     Magha      Jyeshtha             8 years
Kaal Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P178_B002_01

- 身份：正文
- PDF 页：178
- 偈颂：44-49
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 44-49 [present] · PDF page 178

44-49. 5 ghatikas before the sight of the semi-disk (half)
of the setting Surya and 5 ghatikas after that , and 5
ghatikas before and after the rising of Surya, that is 10
ghatikas in the evening and 10 ghatikas in the morning
respectively. The total period of both these Sandhyas
(twilight) is said to be 20 ghatikas. The 20 ghatikas of
the night have been given the named Purna and the 20
ghatikas of the day have been given the name Mugdha. The
Sandhya at the time of sunrise is called Khanda and the
Sandhya at the time of sunset is said to be Sudh. Both of
these Sandhyas are of 10  ghatikas each. If the birth is in
Purna or Mugdha, its past ghatikas should be multiplied by
2 and the product should be divided by 15. The figure so
arrived at should be converted into years, months, etc.. By
multiplying it by the serial number of Surya and other
grahas (1, 2, etc.,) in their normal order (i.e. Surya,
Chandr, Mangal, Buddh, Guru, Shukr, Shani, Rahu and Ketu),
we will get the Kaal Dasha of these grahas. If the birth is
during Sandhya, then, its past ghatikas should be
multiplied by 4 and the product divided by 15. The figure
so arrived at in terms of years, months, etc., should be
multiplied by the serial number of Surya and the other
grahas (1,2, etc.) to get the Kaal Dasha of all the nine
grahas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P178_B002_02

- 身份：正文
- PDF 页：178
- 偈颂：44-49
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 44-49 [present] · PDF page 178

44-49. 5 ghatikas before the sight of the semi-disk (half)
of the setting Surya and 5 ghatikas after that , and 5
ghatikas before and after the rising of Surya, that is 10
ghatikas in the evening and 10 ghatikas in the morning
respectively. The total period of both these Sandhyas
(twilight) is said to be 20 ghatikas. The 20 ghatikas of
the night have been given the named Purna and the 20
ghatikas of the day have been given the name Mugdha. The
Sandhya at the time of sunrise is called Khanda and the
Sandhya at the time of sunset is said to be Sudh. Both of
these Sandhyas are of 10  ghatikas each. If the birth is in
Purna or Mugdha, its past ghatikas should be multiplied by
2 and the product should be divided by 15. The figure so
arrived at should be converted into years, months, etc.. By
multiplying it by the serial number of Surya and other
grahas (1, 2, etc.,) in their normal order (i.e. Surya,
Chandr, Mangal, Buddh, Guru, Shukr, Shani, Rahu and Ketu),
we will get the Kaal Dasha of these grahas. If the birth is
during Sandhya, then, its past ghatikas should be
multiplied by 4 and the product divided by 15. The figure
so arrived at in terms of years, months, etc., should be
multiplied by the serial number of Surya and the other
grahas (1,2, etc.) to get the Kaal Dasha of all the nine
grahas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P179_B001_01

- 身份：正文
- PDF 页：179
- 偈颂：50-51
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 50-51 [present] · PDF page 179

50-51. If the birth is at night the Dasha will commence
from Lagn Rashi (the sign of Lagn). If the birth is during
the day, the Dasha will start from the rashi in which the
lord of Lagn is placed. If the birth is during Sandhya (the
period of twilight), the Dasha will begin from the rashi of
the second bhava. The Dasha of each rashi is 10 years. As
it is the Dasha system o the 12 rashis in the Zodiac, it
has been named as Chakr Dasha.
Kaal Chakr Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P179_B002_01

- 身份：正文
- PDF 页：179
- 偈颂：52-53
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 52-53 [present] · PDF page 179

52-53. Maharishi Parashar said: O Brahmin! Now, after
making obedience to Lord Shiva, I shall describe the Kala
Chakr Dasha. Whatever was related by Lord Shiva to Goddess
Parvati is being explained by me for the use of sages to be
utilized for the welfare of the people.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P179_B003_01

- 身份：正文
- PDF 页：179
- 偈颂：54-55
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 54-55 [present] · PDF page 179

54-55. By drawing vertical and horizontal lines prepare 2
Kundalis: Savya and Apsavya of 12 apartments (Kosthas)
each. From the second Kostha in each Kundali fix the rashis
Mesh, Vrishabh, Mithun, Kark, Simh, Kanya, Tula, Vrischik,
Dhanu, Makar, Kumbh, Meen.  Then, Nakshatras may be
incorporated in the manner indicated here after. These
Kundalis indicative of the 12 rashis are called Kala
Chakr.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P179_B004_01

- 身份：正文
- PDF 页：179
- 偈颂：56-58
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 56-58 [present] · PDF page 179

56-58. Write Ashvini, Bharani, and Kritika Nakshatras in
the Savya Chakr and Rohini, Mrigashira, Ardra Nakshatras in
the Apsavya Chakr. Then, incorporate the three following
Nakshatras, Punarvasu, Pushya, and Aslesha in the Savya and
Magha, Purvaphalguni, and Uttaraphalguni in the Apsavya
Chakr. Then, incorporate the three following Nakshatras,
Hast, Chitra, and Swati in the Savya Chakr and incorporate
Vishakah, Anuradha, and Jyeshtha in the Apsavya Chakr.
Then, incorporate Mul, Purvashadha, and Uttarashadha in the
Savya Chakr, and Shravan, Dhanishtha, and Shatabhisha in
the Apsavya Chakr. Finally, incorporate the last three
Nakshatras, Purvabhadrapad, Uttarabhadrapad, and Revati in
the Savya Chakr. Now, there will be 15 nakshatras in the
Savya and 12 nakshatras in the Apsavya Chakr, (because for
the 12 Rashis there are 12 padas of 3 Nakshatras: the
Navamshas). The padas of Ashvini, Punarvasu, Hast, Mul,
Purvabhadrapad, Kritika, Aslesha, Swati, Uttarashadha, and
Revati of the Savya Chakr should be reckoned in the same
manner as the padas of Ashvini.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P179_B005_01

- 身份：正文
- PDF 页：179
- 偈颂：59
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 59 [present] · PDF page 179

59. Now, I shall describe in detail how the Deha and Jiva
should be reckoned in the padas (or quarters) of the
Nakshatras.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P179_B006_01

- 身份：正文
- PDF 页：179
- 偈颂：60
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 60 [present] · PDF page 179

60. In the first pad of Ashvini, Mesh is indicative of Deha
(body) and Dhanu is indicative of Jiva (life). And the
lords of Mesh, Vrishabh, Mithun, Kark, Simh, Kanya, Tula,
Vrischik, and Dhanu are lords of the Dashas in the order as
described before.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P179_B007_01

- 身份：正文
- PDF 页：179
- 偈颂：61
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 61 [present] · PDF page 179

61. In the second pad of Ashvini, Makar is Deha and Mithun
is Jiva, and the lords of the nine rashis from Makar to
Mithun are lords of the Dashas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P180_B001_01

- 身份：正文
- PDF 页：180
- 偈颂：62
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 62 [present] · PDF page 180

62. In the third pad of the ten Nakshatras beginning from
Ashvini, Vrishabh is Deha and Mithun is Jiva. The lords of
the rashis Vrishabh, Mesh, Meen, Kumbh, Makar, Dhanu, Mesh,
Vrishabh, and Mithun are lords of the Dashas in that order,
that is, the lords in.that order are Shukr, Mangal, Guru,
Shani, Shani, Guru, Mangal, Shukr, and Buddh.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P180_B002_01

- 身份：正文
- PDF 页：180
- 偈颂：63-64
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 63-64 [present] · PDF page 180

63-64. For the 4th Pad of the 10 Nakshatras beginning from
Ashvini, Kark is Deha and Meen is Jiva, and the lords of
the nine rashis from Kark to Meen (i.e. Kark, Simh, Kanya,
Tula, Vrischik, Dhanu, Makar, Kumbh, and Meen), namely,
Chandr, Surya, Buddh, Shukr, Mangal, Guru, Shani, Shani,
and Guru are the lords of Dashas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P180_B003_01

- 身份：正文
- PDF 页：180
- 偈颂：65
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 65 [present] · PDF page 180

65. In the four Padas of the 5 Nakshatras: Bharani, Pushya,
Chitra, Purvashadha and Uttarabhadrapad, Deha and Jiva are
the same as for Bharani.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P180_B004_01

- 身份：正文
- PDF 页：180
- 偈颂：66
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 66 [present] · PDF page 180

66. In the first Pad of Bharani, Vrischik is Deha and Meen
is Jiva, and the lords of the rashis Vrischik, Tula, Kanya,
Kark, Simh, Mithun, Vrishabh, Mesh, and Meen, namely,
Mangal, Shukr, Buddh, Chandr, Surya, Buddh, Shukr, Mangal,
and Guru, are the lords of Dashas  in this order.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P180_B005_01

- 身份：正文
- PDF 页：180
- 偈颂：67
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 67 [present] · PDF page 180

67. In the 2nd Pad of Bharani, Kumbh is Deha and Kanya is
Jiva, and the lords of Kumbh, Makar, Dhanu, Mesh, Vrishabh,
Mithun, Kark, Simh and Kanya, namely, Shani, Shani, Guru,
Mangal, Shukr, Buddh, Chandr, Surya, and Buddh are the
lords of Dashas in that order.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P180_B006_01

- 身份：正文
- PDF 页：180
- 偈颂：68
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 68 [present] · PDF page 180

68. In the 3rd Pad of Bharani, Tula is Deha and Kanya is
Jiva, and lords of the rashis Tula, Vrischik, Dhanu, Makar,
Kumbh, Meen, Vrischik, Tula, and Kanya are the Dasha lords
in this order.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P180_B007_01

- 身份：正文
- PDF 页：180
- 偈颂：69
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 69 [present] · PDF page 180

69. In the 4th Pad of Bharani, Kark is Deha and Kumbh is
Jiva, and the lords of the rashis Kark, Simh, Mithun,
Vrishabh, Mesh, Meen, Kumbh, Makar and Dhanu namely Chandr,
Surya, Buddh, Shukr, Mangal, Guru, Shani, Shani, and Guru
are the Dasha lords in this order.
(As already pointed out in Verse 65, the 4 Padas of Pushya,
Chitra, Purvashadha and Uttarabhadrapad Deha and Jiva and
the Dasha lords are the same as in the 4 Padas of Bharani).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P180_B008_01

- 身份：正文
- PDF 页：180
- 偈颂：71-72
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 71-72 [present] · PDF page 180

71-72. 0 Brahmin! I have thus given you the description of
Savya Chakr. Now, I shall give the description of Apsavya
Chakr. Prepare a similar chart of 10 apartments and from
the 2nd apartment onwards place the rashis from Vrischik
onwards in the reverse order, that is, Vrischik, Tula,
Kanya etc. In this chart Deha and Jiva would be the same
for Rohini Magha Vishakah, and Shravan as for Rohini.
(Similarly, the Dasha lords would be the same as has
been described for the Savya Chakr).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P181_B001_01

- 身份：正文
- PDF 页：181
- 偈颂：73-76
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 73-76 [present] · PDF page 181

73-76. In the first Pad of Rohini, Kark is Deha and Dhanu
is Jiva. The lords of the rashis Dhanu, Makar, Kumbh, Meen,
Mesh, Vrishabh, Mithun, Simh, and Tula, namely, Guru,
Shani, Shani, Guru, Mangal, Shukr, Buddh, Surya, and Shukr
will be the Dasha lords in this order.
In the 2nd Pad of Rohini, Tula will be Deha and Kanya the
Jiva, and the lords of the rashis Kanya, Tula, Vrischik,
Meen, Kumbh, Makar, Dhanu, Vrischik, and Vrischik, namely,
Buddh, Shukr, Mangal, Guru, Shani, Shani, Guru, Mangal and
Mangal will be the Dasha lords in this order.
In the 3rd Pad of Rohini, Kumbh will be Deha and Kanya
Jiva. The lords of the rashis Kanya, Simh, Kark, Mithun,
Vrishabh, Mesh, Dhanu, Makar, and Kumbh, namely, Buddh,
Surya, Chandr, Buddh, Shukr, Mangal, Guru, Shani, and Shani
will be the Dasha lords in this order.
In the 4th Pad of Rohini, Vrischik, will be Deha and Meen
Jiva, and the lords of the rashis Meen, Mesh, Vrishabh,
Mithun, Simh, Kark, Kanya, Tula, and Vrischik, namely,
Guru, Mangal, Shukr, Buddh, Surya, Chandr, Buddh, Shukr,
and Mangal will be the lords in this order.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P181_B002_01

- 身份：正文
- PDF 页：181
- 偈颂：77
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 77 [present] · PDF page 181

77. In the 4 Padas of the Apsavya Nakshatras: Mrigashira,
Ardra, Purvaphalguni, Uttaraphalguni, Anuradha, Jyeshtha,
Dhanishtha, and Shatabhisha. The Deha and Jiva, and the
Dasha lords will be the same as for Mrigashira.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P181_B003_01

- 身份：正文
- PDF 页：181
- 偈颂：78-81
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 78-81 [present] · PDF page 181

78-81. In the first Pad of Mrigashira, Kark is Deha and
Meen is Jiva, and the lords of the rashis Meen, Kumbh,
Makar, Dhanu, Vrischik, Tula, Kanya, Simh, and Kark,
namely, Guru, Shani, Shani, Guru, Mangal, Shukr, Buddh,
Surya, and Chandr will be the Dasha lords in this order.
In the 2nd Pad of Mrigashira, Vrishabh is Deha and Mithun
is Jiva, and the lords of the rashis Mithun, Vrishabh,
Mesh, Dhanu, Makar, Kumbh, Meen,  Mesh, and Vrishabh,
namely, Buddh, Shukr, Mangal, Guru, Shani, Shani, Guru,
Mangal, and Shukr will be the Dasha lords in this order.
In the 3rd Pad of Mrigashira, Makar is Deha and Mithun is
Jiva, and the lords of the rashis Mithun, Simh, Kark,
Kanya, Tula, Vrischik, Meen, Kumbh, and Makar, namely,
Buddh, Surya, Chandr, Buddh, Shukr, Mangal, Guru, Shani,
and Shani will be the Dasha lords in this order.
In the 4th Pad of Mrigashira, Mesh will be Deha and Dhanu
Jiva, and the lords of the rashis Dhanu, Vrischik, Tula,
Kanya, Simh, Kark, Mithun, Vrishabh, and Mesh, namely,
Guru, Mangal, Shukr, Buddh, Surya, Chandr, Buddh, Shukr and
Mangal, will be the Dasha lords in this order.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P181_B004_01

- 身份：正文
- PDF 页：181
- 偈颂：82
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 82 [present] · PDF page 181

82. Maharishi Parashar said: O Brahmin! The description of
the Deha and Jiva of the Padas of the Apsavya Nakshatras
and the Dasha lords is the same as narrated by Lord
Mahadeva to Goddess Parvati.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P181_B005_01

- 身份：正文
- PDF 页：181
- 偈颂：83
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 83 [present] · PDF page 181

83. Maitreya said: O venerable Maharishi Parashar! Now
please guide me about the Dasha spans of the Dasha lords
described by you. Please also demonstrate how the
commencement of the Dasha its expired and the remaining
periods at the birth are to be calculated .

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P181_B006_01

- 身份：正文
- PDF 页：181
- 偈颂：84
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 84 [present] · PDF page 181

84. Maharishi Parashar said: 5, 21, 7, 9, 10, 16, and 4
years are the Dasha spans of Surya, Chandr, Mangal, Buddh,
Guru, Shukr, and Shani in that order.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P182_B001_01

- 身份：正文
- PDF 页：182
- 偈颂：85-86
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 85-86 [present] · PDF page 182

85-86. The span of life of a person is determined from the
Padas (Amshas) of the Nakshatr at the time of birth or the
time of query and the years allotted to the 9 rashis
commencing from it, (the Pad of the Nakshatr). Some sages
are of the view that the person will enjoy full span of
life (Purna Ayu) if his birth is at the commencement of the
Padas, he will have middle span of life (Madhaya Ayu) if
the birth is in the middle of the Padas and short span of
life ('Alap Ayu') or will face death like sufferings if the
birth is at the end of the Padas of the Nakshatr.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P182_B002_01

- 身份：正文
- PDF 页：182
- 偈颂：87-88
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 87-88 [present] · PDF page 182

87-88. According to this principle we should be acquainted
with the Padas of the Nakshatras. Now, I shall tell you how
the calculations are made according to the proportion of
the Padas of a Nakshatr. The number of Ashvini, etc.
whichever may be the past Nakshatras should be divided by

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P182_B003_01

- 身份：正文
- PDF 页：182
- 偈颂：3
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 3 [present] · PDF page 182

3. Thereafter, the remainder should be multiplied by 4. To
the figure so made available, the Pad of the present
Nakshatr should be added. The product will be the Navamsh
from Mesh onwards.
For Example: The birth is in the 4th Pad of Mrigashira. The
number of past nakshatras from Ashvini to Rohini will be 4;
divide it by 3. The remainder will be 1. Multiply 1 by 4.
The product will be 4. To this add 4 (4th Pad of
Mrigashira). Surya will indicate the Navamsh of the rashi.
In this case 4+4=8 will indicate the Navamsh which falls in
Vrischik the 8th rashi from Mesh.
Explanation: In 3 Nakshatras there are Navamshas of 12
rashis. There are four Navamshas in one Nakshatr. It is for
this reason that we divide the number of past rashis by 3
and multiply the remainder by 4 and add the number of Padas
of the resent Pad to know the rashi in which the Navamsh
will fall.
Now, will be described the number of years allotted to the
rashis placed in the Kaal Chakr.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P182_B004_01

- 身份：正文
- PDF 页：182
- 偈颂：89
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 89 [present] · PDF page 182

89. The number of years (Purna Ayu) are as under:
For the Amsh in Mesh 100 years
For the Amsh in Vrishabh 85 years
For the Amsh in Mithun 83 years
For the Amsh in Kark 86 years.
The number of years will be the same for rashis situated
the 5th and 9th to them.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P183_B001_01

- 身份：正文
- PDF 页：183
- 偈颂：90-91
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 90-91 [present] · PDF page 183

90-91. Multiply the past ghatikas of the Padas of the
Nakshatr in which a person is born by the existing ghatikas
and palas and divide it by 15. The result will indicate the
expired period of the Dasha in years, months, etc.. By
deducting it from the total number of years allotted, we
get the balance of Dasha at birth. The Dasha should be
taken as commencing from that rashi.
We give below the Savya and Apsavya Kaal Chakr Charts:
For Example: The birth is in Mrigashira 4th Pad. It is in
the Apsavya Kaal Chakr. The lord of Deha is Mangal and that
of Jiva is Guru. The Bhabhog of Mrigashira is 59/31 (5
ghatikas and 31 palas) and Bhayat is 58/15 (58 ghatikas and
15 palas). 1/4 of the Bhabhog comes to 14/52/44. That would
be the value of one Pad. Multiplying this by 3 will get
ghatikas of 3 Padas, namely, 44/38/15. Deducting this from
Bhayat the past ghatikas, palas, etc., of the 4th Pad will
be 13/36/45. The full Dasha years are 100. Multiplying this
by 13/36/45 we get 1300/3600/4500 = 1361/15. This divided
by 15 will give the expired period at birth namely 90 years
and 9 months.
See the Kaal Chakr. There we count from Jiva, etc., and
Deha. In the 4th Pad of Mrigashira Jiva is in Dhanu and
Deha in Mesh. Therefore, by deducting the total year of
Dhanu from Mithun, namely 77 from 90 years 9 months we get
the expired period of Vrishabh, namely 13 years and 9
months. By deducting this from the present 16 years of
Shukr, we will get 2 years and 3 months as the balance of
Dasha at birth. Accordingly, like Vimshottari Dasha, the
order of Dasha will be Vrishabh, Mesh, Dhanu, Vrischik,
etc..

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P183_B001_02

- 身份：正文
- PDF 页：183
- 偈颂：90-91
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 90-91 [present] · PDF page 183

90-91. Multiply the past ghatikas of the Padas of the
Nakshatr in which a person is born by the existing ghatikas
and palas and divide it by 15. The result will indicate the
expired period of the Dasha in years, months, etc.. By
deducting it from the total number of years allotted, we
get the balance of Dasha at birth. The Dasha should be
taken as commencing from that rashi.
We give below the Savya and Apsavya Kaal Chakr Charts:
For Example: The birth is in Mrigashira 4th Pad. It is in
the Apsavya Kaal Chakr. The lord of Deha is Mangal and that
of Jiva is Guru. The Bhabhog of Mrigashira is 59/31 (5
ghatikas and 31 palas) and Bhayat is 58/15 (58 ghatikas and
15 palas). 1/4 of the Bhabhog comes to 14/52/44. That would
be the value of one Pad. Multiplying this by 3 will get
ghatikas of 3 Padas, namely, 44/38/15. Deducting this from
Bhayat the past ghatikas, palas, etc., of the 4th Pad will
be 13/36/45. The full Dasha years are 100. Multiplying this
by 13/36/45 we get 1300/3600/4500 = 1361/15. This divided
by 15 will give the expired period at birth namely 90 years
and 9 months.
See the Kaal Chakr. There we count from Jiva, etc., and
Deha. In the 4th Pad of Mrigashira Jiva is in Dhanu and
Deha in Mesh. Therefore, by deducting the total year of
Dhanu from Mithun, namely 77 from 90 years 9 months we get
the expired period of Vrishabh, namely 13 years and 9
months. By deducting this from the present 16 years of
Shukr, we will get 2 years and 3 months as the balance of
Dasha at birth. Accordingly, like Vimshottari Dasha, the
order of Dasha will be Vrishabh, Mesh, Dhanu, Vrischik,
etc..

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P183_B002_01

- 身份：正文
- PDF 页：183
- 偈颂：92
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 92 [present] · PDF page 183

92. Multiply the past ghatikas, palas, etc., of the present
Pad of the Nakshatr by the number of years and divide the
product by the fourth part of Bhabhog. The years, etc., so
obtained may then be deducted from the total Dasha period.
The result will be the balance of Dasha at birth in years,
months, etc..

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P184_B001_01

- 身份：正文
- PDF 页：184
- 偈颂：93
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 93 [present] · PDF page 184

93. The past kalas (=minutes) of the Navamsh in which Chandr
may be placed should be multiplied by the years allotted to
Chandr and the product should be divided by 200. The
resulting years, etc., will be the expired portion of the
Dasha. By deducting them from the total number of years the
balance of the Dasha at birth is obtained.
For Example: Suppose that at the time of birth of a person
in Kritika Nakshatr the longitude of Chandr (Chandr Spast)
is 1/4/50. This converted into kalas will be 2090 at birth.
The Dasha should be taken as commencing from that. Divide
by 800 the kalas of one Nakshatr the result will be the 2nd
Nakshatr namely Bharini and the remainder will be 490.
These will be the past kalas of Kritika. There are 200
kalas in one Pad (Navamsh). Divide 490, the past kalas of
Kritika, by 200. We will then get 2 as past Padas and the
remainder 90 will represent the past kalas of the present
Nakshatr. By multiplying this by 83, the Dasha years, we
will get 7470 which divided by 200 will indicate the
expired portion of the Dasha as 37 years, 4 months and 6
days. By deducting the years of Dehamsh commencing from
Vrishabh in the order: Vrishabh, Mesh, Meen, Kumbh
(16+7+10+4 = 37), we will get O years, 4 months, and 6
days. This will be the expired portion of Makar. Deducting
this from 4, the Dasha period of Makar, we get the balance
of the Dasha of Makar, namely 3 years, 7 months, and 24
days. See in this connection the Savya Kaal Chakr.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P184_B001_02

- 身份：正文
- PDF 页：184
- 偈颂：93
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 93 [present] · PDF page 184

93. The past kalas (=minutes) of the Navamsh in which Chandr
may be placed should be multiplied by the years allotted to
Chandr and the product should be divided by 200. The
resulting years, etc., will be the expired portion of the
Dasha. By deducting them from the total number of years the
balance of the Dasha at birth is obtained.
For Example: Suppose that at the time of birth of a person
in Kritika Nakshatr the longitude of Chandr (Chandr Spast)
is 1/4/50. This converted into kalas will be 2090 at birth.
The Dasha should be taken as commencing from that. Divide
by 800 the kalas of one Nakshatr the result will be the 2nd
Nakshatr namely Bharini and the remainder will be 490.
These will be the past kalas of Kritika. There are 200
kalas in one Pad (Navamsh). Divide 490, the past kalas of
Kritika, by 200. We will then get 2 as past Padas and the
remainder 90 will represent the past kalas of the present
Nakshatr. By multiplying this by 83, the Dasha years, we
will get 7470 which divided by 200 will indicate the
expired portion of the Dasha as 37 years, 4 months and 6
days. By deducting the years of Dehamsh commencing from
Vrishabh in the order: Vrishabh, Mesh, Meen, Kumbh
(16+7+10+4 = 37), we will get O years, 4 months, and 6
days. This will be the expired portion of Makar. Deducting
this from 4, the Dasha period of Makar, we get the balance
of the Dasha of Makar, namely 3 years, 7 months, and 24
days. See in this connection the Savya Kaal Chakr.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P184_B002_01

- 身份：正文
- PDF 页：184
- 偈颂：94-95
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 94-95 [present] · PDF page 184

94-95. In the Savya Chakr the first Amsh is called Deha and
the last Amsh Jiva. The opposite is the case in the Apsavya
Chakr (the first Amsh is Jiva and the last is Deha).
Therefore, the calculations should be based on the Deha,
etc., in the Savya Chakr and on the Jiva, etc., in Apsavya
Chakr.
Gati (Movements) of Rashis in the Kaal Chakr

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P184_B003_01

- 身份：正文
- PDF 页：184
- 偈颂：96-98
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 96-98 [present] · PDF page 184

96-98. There are three kinds of movements (Gati) of the
Rashis in the Kaal Chakr, namely, Manduki, Markati, and
Simhavlokan. The movement of one Rashi by jumping over one
Rashi is known as Manduki gati. Backward movement to the
previous Rashi is called Markati gati. The movement of a
Rashi to the 5th and 9th Rashi is said to be Simhavlokan.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P184_B004_01

- 身份：正文
- PDF 页：184
- 偈颂：99-100
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 99-100 [present] · PDF page 184

99-100. Movement from Kanya to Kark and from Simh to Mithun
is Manduki Gati. Movement from Simh to Kark is Markati
Gati. Movement from Meen to Vrischik and from Dhanu to Mesh
is called Simhavlokan Gati.
Effects of Dashas of Rashis as a result of these Gati

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P184_B005_01

- 身份：正文
- PDF 页：184
- 偈颂：101-102
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 101-102 [present] · PDF page 184

101-102. The effects of the Dasha of the Rashis with
Manduki gati in the Savya Chakr are distress to friends,
relations, parents and elders, and there is likely to be
cause for trouble from poison, weapons, thieves, and
enemies. In the Manduki Dasha of the Gati of a Rashi from
Simh to Mithun, there is the likelihood of the death of the
mother or self, trouble from Government (or king) and
possibility of brain fever.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P184_B006_01

- 身份：正文
- PDF 页：184
- 偈颂：103
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 103 [present] · PDF page 184

103. The effects of the Dasha of Rashi with Markati Gati in
the Savya Chakr, are loss of wealth, agricultural products
and animals, death of father or an elderly close relation,
and feeling of lethargy.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P185_B001_01

- 身份：正文
- PDF 页：185
- 偈颂：104-105
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 104-105 [present] · PDF page 185

104-105. The effects of the Dasha of the Rashis with
Simhavlokan Gati in the Savya Chakr are, possibility of
injury from animals, loss of amity with friends, distress
to near relations, drowning in a well, fall from animals,
possibility of harm from poison, weapons, and diseases and
destruction of residential dwelling.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P185_B002_01

- 身份：正文
- PDF 页：185
- 偈颂：106-108
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 106-108 [present] · PDF page 185

106-108. In the Dasha of the Rashis with the Manduki Gati
in the Apsavya Chakr, the effects will be distress to wife
and conditions,  loss of children, possibility of feverish
conditions, and loss of position.
In the Dasha of the Rashis with the Markati Gati there may
be danger from watery places, loss of position, distress
from father, punishment from Government, and wandering in
the forests.
In the Dasha of Rashis with the Simhavlokan Gati in the
Apsavya Chakr, there may be destruction of the dwelling and
death of father, etc..

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P185_B003_01

- 身份：正文
- PDF 页：185
- 偈颂：109-111
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 109-111 [present] · PDF page 185

109-111. If the movement is from Meen to Vrischik, the
native may suffer from fever.
If the movement is from Kanya to Kark, there may be loss of
brothers and kinsmen.
If the movement is from Simh to Mithun, there may be ill
health of the wife.
If the movement is from Simh to Kark, the native may die.
If the movement is from Dhanu to Mesh, there may be death
of uncles and similar relations.
If the Rashi is yuti with a malefic, adverse conditions may
be expected in the Dasha Rashi.
Favorable effects will be felt in its Dasha if the Rashi is
yuti with a benefic.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P185_B004_01

- 身份：正文
- PDF 页：185
- 偈颂：112-113
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 112-113 [present] · PDF page 185

112-113. 0 Brahmin! In the Kaal Chakr Dasha favourable and
unfavorable effects may be predicted after taking into
account the directions of the Rashis and Grahas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P186_B001_01

- 身份：正文
- PDF 页：186
- 偈颂：114-119
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 114-119 [present] · PDF page 186

114-119. If the movement is from Kanya to Kark, good
results are realized in places located in the East and at
that time journeys to the places in the North prove
fruitful.
Unfavourable effects will be felt in places located in the
West and the South. It will be advisable not to undertake
journeys in those directions in the Dasha of these Rashis.
If the movement is from Simh to Mithun, no journey should
be undertaken to places located in the East.
However, the journeys to the South-West will prove fruitful
in the Dasha of those Rashis. If the movement is from Kark
to Simh, journeys during that period to the South will
prove unfavourable and result in loss, and the native has
to return from the South to the West.
If the movement is from Meen to Vrischik, there will
distress if the native goes to the North. The same would
happen if the movement is from Dhanu to Makar.
There may be ill health, imprisonment, or death if the
movement is from Dhanu to Mesh. There may be gains comforts
and property and marriage if the movement is from Dhanu to
Vrischik.
It will not be advisable to undertake journeys to the West
during the related period if the movement is from Simh to
Kark.
Favourable results should be predicted if the Rashis are
yuti with benefics and adverse if the Rashis are yuti with
malefics.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P186_B001_02

- 身份：正文
- PDF 页：186
- 偈颂：114-119
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 114-119 [present] · PDF page 186

114-119. If the movement is from Kanya to Kark, good
results are realized in places located in the East and at
that time journeys to the places in the North prove
fruitful.
Unfavourable effects will be felt in places located in the
West and the South. It will be advisable not to undertake
journeys in those directions in the Dasha of these Rashis.
If the movement is from Simh to Mithun, no journey should
be undertaken to places located in the East.
However, the journeys to the South-West will prove fruitful
in the Dasha of those Rashis. If the movement is from Kark
to Simh, journeys during that period to the South will
prove unfavourable and result in loss, and the native has
to return from the South to the West.
If the movement is from Meen to Vrischik, there will
distress if the native goes to the North. The same would
happen if the movement is from Dhanu to Makar.
There may be ill health, imprisonment, or death if the
movement is from Dhanu to Mesh. There may be gains comforts
and property and marriage if the movement is from Dhanu to
Vrischik.
It will not be advisable to undertake journeys to the West
during the related period if the movement is from Simh to
Kark.
Favourable results should be predicted if the Rashis are
yuti with benefics and adverse if the Rashis are yuti with
malefics.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P186_B002_01

- 身份：正文
- PDF 页：186
- 偈颂：120-122
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 120-122 [present] · PDF page 186

120-122. According to the above mentioned Kaal Chakr the
person born in the Amshas of the various Rashis will be as
under:
Mesh Amsh    : Brave and a thief.
Vrishabh Amsh: Wealthy
Mithun Amsh  : Learned
Kark Amsh    : King (or like a king)
Simh Amsh    : Respected by king (Government)
Kanya Amsh   : Learned
Tula Amsh    : Minister or Adviser
Dhanu Amsh   : Sinful
Kumbh Amsh   : Business man
Meen Amsh    : Wealthy.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P187_B001_01

- 身份：正文
- PDF 页：187
- 偈颂：123-128
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 123-128 [present] · PDF page 187

123-128. If the Deha or Jiva Rashis are yuti with Surya,
Mangal, Shani or Rahu the native will die.
Worse results may be expected if the Deha and Jiva Rashis
are yuti with two or all of them.
If there is a malefic in Deha Rashi the native suffers ill
health;
a malefic in a Jiva Rashi will make the native very timid.
If the Deha and/or  Jiva Rashi are yuti with two malefics
there will be distress and diseases.
Three malefics in the Deha and/or Jiva Rashi will cause
premature death.
Four malefics in the Deha and Jiva Rashi will cause
definite death.
If both the Deha and Jiva Rashis are occupied by malefics,
there will be fear king and thieves, and death of the
native.
If Surya is in the Deha or Jiva Rashi, there will be danger
from fire.
Chandr in the Deha or Jiva Rashi will cause danger from
water;
Mangal in the Deha or Jiva Rashi will cause fear from
weapons;
Buddh in the Deha or Jiva Rashi will cause fear from windy
troubles;
Shani in the Deha or Jiva Rashi will cause fear from gulma
(a disease);
Rahu and Ketu in the Deha or Jiva Rashi will cause fear
from poison.
If the Deha or Jiva Rashis are occupied by Buddh, Guru, and
Shukr, the native will be wealthy, will enjoy all kinds of
comforts, and will have good health.
Mixed results may be expected if the Deha and Jiva Rashis
are occupied by both benefics and malefics.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P187_B001_02

- 身份：正文
- PDF 页：187
- 偈颂：123-128
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 123-128 [present] · PDF page 187

123-128. If the Deha or Jiva Rashis are yuti with Surya,
Mangal, Shani or Rahu the native will die.
Worse results may be expected if the Deha and Jiva Rashis
are yuti with two or all of them.
If there is a malefic in Deha Rashi the native suffers ill
health;
a malefic in a Jiva Rashi will make the native very timid.
If the Deha and/or  Jiva Rashi are yuti with two malefics
there will be distress and diseases.
Three malefics in the Deha and/or Jiva Rashi will cause
premature death.
Four malefics in the Deha and Jiva Rashi will cause
definite death.
If both the Deha and Jiva Rashis are occupied by malefics,
there will be fear king and thieves, and death of the
native.
If Surya is in the Deha or Jiva Rashi, there will be danger
from fire.
Chandr in the Deha or Jiva Rashi will cause danger from
water;
Mangal in the Deha or Jiva Rashi will cause fear from
weapons;
Buddh in the Deha or Jiva Rashi will cause fear from windy
troubles;
Shani in the Deha or Jiva Rashi will cause fear from gulma
(a disease);
Rahu and Ketu in the Deha or Jiva Rashi will cause fear
from poison.
If the Deha or Jiva Rashis are occupied by Buddh, Guru, and
Shukr, the native will be wealthy, will enjoy all kinds of
comforts, and will have good health.
Mixed results may be expected if the Deha and Jiva Rashis
are occupied by both benefics and malefics.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P187_B002_01

- 身份：正文
- PDF 页：187
- 偈颂：129-130
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 129-130 [present] · PDF page 187

129-130. In the Dasha of the Rashis owned by malefics the
body and soul will be in distress. The effects will be
favourable in the Dasha of the Rashis owned by benefics.
If a malefic Rashi is occupied by a benefic Grah, or if a
benefic Rashi is occupied by a malefic Grah, the effects
will be of a mixed nature.
Effects of Kaal Chakr Dasha of the Rashis in Lagn and other
Bhavas.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P187_B003_01

- 身份：正文
- PDF 页：187
- 偈颂：131-132
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 131-132 [present] · PDF page 187

131-132. In the Kaal Chakr Dasha of the Rashi in Lagn (Lagn
Rashi) the body remains healthy and the native spends a
life with many kinds of comforts.
If the Lagn Rashi is a benefic one, the good effects (in
the Kaal Chakr Dasha) are realized fully.
If the Lagn Rashi is a malefic rashi there is likelihood of
ill health (in the Kaal Chakr Dasha).
If a Grah in exaltation or in its own Rashi occupies Lagn,
the native is respected by the king or government and
acquires wealth.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P187_B004_01

- 身份：正文
- PDF 页：187
- 偈颂：133-134
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 133-134 [present] · PDF page 187

133-134. In the Chakr Dasha of the Rashi in Dhan Bhava, the
native receives good food, enjoys happiness of wife and
children, gains wealth, achieves progress in the
educational sphere, becomes a clever conversationalist and
moves in good society. If the Rashi be a benefic, good
effects are realized in full, otherwise the effects would
be of a mixed nature.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P188_B001_01

- 身份：正文
- PDF 页：188
- 偈颂：135-136
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 135-136 [present] · PDF page 188

135-136. Happiness from co-borns, valour, patience,
comforts, acquisition of gold, ornaments, and clothes, and
recognition by the king or government, are the effects in
the Kaal Chakr Dasha of the Rashi in Sahaj Bhava. If the
Rashi is a benefic, the good results are realized in full,
otherwise adverse effects may also be experienced.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P188_B002_01

- 身份：正文
- PDF 页：188
- 偈颂：137-138
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 137-138 [present] · PDF page 188

137-138. Good relations with kinsmen, acquisition of land,
houses or a kingdom, conveyances and clothes, and enjoyment
of sound health, are the effects of the Chakr Dasha of the
Rashi in Bandhu Bhava. If the Rashi is a benefic one, the
good effects are realized in full. If it is a malefic Rashi
adverse results are also experienced.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P188_B003_01

- 身份：正文
- PDF 页：188
- 偈颂：139-140
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 139-140 [present] · PDF page 188

139-140. Being blessed with wife and children, favours from
Government, enjoyment of sound health, good relations with
friends, achievement of fame, good progress in the
educational sphere, patience and valour, are the effects of
the Chakr Dasha of the Rashi in Putr Bhava. If the Rashi is
a benefic one the good results are enjoyed in full. If the
Rashi is a malefic one, adverse effects are also
experienced.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P188_B004_01

- 身份：正文
- PDF 页：188
- 偈颂：141-142
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 141-142 [present] · PDF page 188

141-142. Danger from the king (government), fire and
weapons, and the possibility of suffering from diabetes,
gulma and jaundice are the effects in the Chakr Dasha of
the Rashi in Ari Bhava. If the Rashi is a malefic one, the
above adverse effects will be experienced in full. There
will be some mitigation of the evil effects in the case of
a benefic Rashi.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P188_B005_01

- 身份：正文
- PDF 页：188
- 偈颂：143-144
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 143-144 [present] · PDF page 188

143-144. Marriage, conjugal happiness, being blessed with
children gain of agricultural products, cows and clothes,
favours and recognition from the king (government), and
achievement of fame, are the effects in the Chakr Dasha of
the Rashi in Yuvati Bhava. The beneficial results will be
experienced in full if the Rashi is a benefic one. Meagre
good effects will be realized in the case of a malefic
Rashi.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P188_B006_01

- 身份：正文
- PDF 页：188
- 偈颂：145-146
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 145-146 [present] · PDF page 188

145-146. Destruction of a residential house, distress, loss
of wealth, poverty, and danger from enemies, are the
effects of the Chakr Dasha of the Rashi in Randhr Bhava.
The adverse effects will be realized in full in the Rashi
is a malefic one. Some mitigation in evil effects may be
expected in the case of a benefic Rashi.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P189_B001_01

- 身份：正文
- PDF 页：189
- 偈颂：158-166
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 158-166 [present] · PDF page 189

158-166. Now, I will tell you about the working out of the
Dasha years of Vrischik and Kumbh. If both the lords of the
two Rashis: Vrischik and Kumbh are placed in their own
Rashis, their Dasha will be of 12 years. Otherwise the
Dasha will be of the number of years, indicated by the
number counted from that Rashi to the Rashi occupied by its
lord. If one Grah be in his own Rashi and the other in any
other Rashi, the Dasha will be of the number of years
counted from the above first Rashi to the other. If the
lords are in different Rashis the counting is to be done up
to the Rashi which is stronger. The Rashi which has a Grah
placed in it, is considered more powerful than the Rashi
without a Grah in it. If both are with Grahas in them, the
one with more Grahas would be considered more powerful. If
both Rashis are occupied by an equal number of Grahas, the
strength of the Rashi itself should be taken into account.
The principle for considering the Bal (strength) of the
Rashi is that the fixed Rashi is considered stronger than
the movable one and the dual Rashi is considered more
powerful than the fixed Rashi. If there is equality in the
strength of the Rashis, then, to determine the number of
years of Dasha, counting should be done up to the Rashi
with bigger number. If one Rashi is occupied by a Grah in
exaltation, the counting should be done up to that Rashi
only. In addition 1 (one) should be added in the number of
years in the case of a Rashi with an exalted Grah and 1
(one) should be deducted from the number of years in the
case of a Rashi with a Grah in debilitation. The prediction
should be made after calculating the Dashas in this
manner.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P189_B001_02

- 身份：正文
- PDF 页：189
- 偈颂：158-166
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 158-166 [present] · PDF page 189

158-166. Now, I will tell you about the working out of the
Dasha years of Vrischik and Kumbh. If both the lords of the
two Rashis: Vrischik and Kumbh are placed in their own
Rashis, their Dasha will be of 12 years. Otherwise the
Dasha will be of the number of years, indicated by the
number counted from that Rashi to the Rashi occupied by its
lord. If one Grah be in his own Rashi and the other in any
other Rashi, the Dasha will be of the number of years
counted from the above first Rashi to the other. If the
lords are in different Rashis the counting is to be done up
to the Rashi which is stronger. The Rashi which has a Grah
placed in it, is considered more powerful than the Rashi
without a Grah in it. If both are with Grahas in them, the
one with more Grahas would be considered more powerful. If
both Rashis are occupied by an equal number of Grahas, the
strength of the Rashi itself should be taken into account.
The principle for considering the Bal (strength) of the
Rashi is that the fixed Rashi is considered stronger than
the movable one and the dual Rashi is considered more
powerful than the fixed Rashi. If there is equality in the
strength of the Rashis, then, to determine the number of
years of Dasha, counting should be done up to the Rashi
with bigger number. If one Rashi is occupied by a Grah in
exaltation, the counting should be done up to that Rashi
only. In addition 1 (one) should be added in the number of
years in the case of a Rashi with an exalted Grah and 1
(one) should be deducted from the number of years in the
case of a Rashi with a Grah in debilitation. The prediction
should be made after calculating the Dashas in this
manner.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P189_B002_01

- 身份：正文
- PDF 页：189
- 偈颂：167
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 167 [present] · PDF page 189

167. If the Rashi in Dharm Bhava is in an odd Pad, the
counting should be from the Rashi in the Lagn onwards. The
counting would be in the reverse order if the Pad is even.
The Dashas of Rashis have to be fixed keeping this in
view.
For Example:
In the above Tula is the Rashi in Dharm Bhava in an odd
Pad. Amongst the lords of Lagn Shani and Rahu, Rahu is
associated with a Grah. Therefore, Rahu is more powerful
than Shani. Therefore, counting should be done up to Rahu.
Kumbh is in even Pad, therefore, counting has to be done
from Kumbh up to Rahu in the reverse order by which the
Char Dasha for Kumbh would come to 8 years. Mesh is in odd
Pad. Therefore, the Char Dasha for Mesh will be one year.
The Dasha of other Rashis should be calculated in the same
manner.
Sthir Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P189_B003_01

- 身份：正文
- PDF 页：189
- 偈颂：168-169
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 168-169 [present] · PDF page 189

168-169. Maharishi Parashar said: Now, I am going to
describe the Sthir Dasha. In this Dasha system 7 years, 8
years, and 9 years are the Dasha spans of the movable
(Char), fixed (Sthir) and dual ('Dvisva Bhava') Rashis in
that order. In this system the Dasha of the 12 Rashis
begins from the Brahm Grah Ashrit Rashi. The Dasha are
counted onwards from the odd Rashis and in the reverse
order from the even Rashis.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P190_B001_01

- 身份：正文
- PDF 页：190
- 偈颂：170-173
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 170-173 [present] · PDF page 190

170-173. Maitreya said: O great Sage! Now, please enlighten
me how the Brahm Grah is picked out in a chart.
Maharishi Parashar said: From amongst the lords of Ari,
Randhr, and Vyaya Bhava the Grah who may possess the
greatest strength and is placed in Lagn or in Yuvati Bhava
with strength, the one placed in an odd Rashi within sixth
bhava from the bhava concerned, is called the Brahm Grah.
The lord of Randhr Bhava in Randhr Bhava is also accepted
as Brahm Grah. If Shani or Rahu/Ketu obtain Brahmatva (
Brahmatva-qualifications of Brahm Grah), they become Brahm
Grah. If a number of Grahas obtain Brahmatva, the one with
the largest number of degrees would become Brahm Grah. If
there is parity in the degrees of such Grahas, the most
powerful amongst them would become Brahm Grah.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P190_B002_01

- 身份：正文
- PDF 页：190
- 偈颂：174
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 174 [present] · PDF page 190

174. The spans of Dashas of the Rashis in the Yogardha
Dasha system are half of the total of the spans of Char and
Sthir Dashas. The Dasha will commence from the Rashi of
Lagn or Yuvati Bhava whichever is stronger. The order of
the Dashas of the 12 Rashis will be counted onwards if the
opening Dasha Rashi is an odd one. If it be an even Rashi
the Dashas will be in reverse order.
Kendradi Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P190_B003_01

- 身份：正文
- PDF 页：190
- 偈颂：175-176
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 175-176 [present] · PDF page 190

175-176. In this system there are Dashas of fixed Rashis in
the Kendr, etc., from Lagn or from Yuvati Bhava, whichever
is stronger. If Lagn or Yuvati Bhava with strength is
placed in an odd Rashi the Kendr, etc., are counted in the
onward order. If it be in an even Rashi the counting will
be in the backward or reverse order. In them also the
Dashas would be in the order of comparative strength of the
Rashis. The order of Dashas would be the same as reckoned
from the Atma Karak. The spans of Dashas would be the same
as they are in the Char Dasha. In calculating the years of
Dashas of Grahas counting is done from the Grah to his own
Rashi. The years of Dashas would be the number arrived at
by counting up to the Rashi of the Grah which is stronger
or more in number.
Notes: Under this system Dashas are of two kinds: namely,
Lagn Kendradi and Atma Karak Kendradi. There are also
Kendradi Rashi Dasha or Kendradi Grah Dasha in both the
Dasha system mentioned above.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P190_B004_01

- 身份：正文
- PDF 页：190
- 偈颂：177
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 177 [present] · PDF page 190

177. If a Grah owns two Rashis (except Surya and Chandr and
barring Rahu and Ketu, all the Grahas own two Rashis), the
Dasha years will be equal to the number which is greater
when counted from the Rashi occupied by him.
Karak Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P190_B005_01

- 身份：正文
- PDF 页：190
- 偈颂：178
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 178 [present] · PDF page 190

178. The system under which the first Dasha is of the Atma
Karak and the subsequent Dashas are of the remaining 7
Karakas in their order, is known as Karak Dasha. In this
system the Dasha years are equal to the number of Rashis
counted from Lagn up to the Karak concerned.
Manduk Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P191_B001_01

- 身份：正文
- PDF 页：191
- 偈颂：179-180
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 179-180 [present] · PDF page 191

179-180. Under the Manduk Dasha system the Dasha commences
from Lagn or Yuvati Bhava whichever is stronger. If the
Rashi of commencement is an odd Rashi the Dashas of 3
Moveable Rashis, 3 Fixed Rashis and 3 Dual Rashis will be
counted in the onwards order. They will be in the reverse
order in the case of an even Rashi. In this system the
Dasha years will be the same as in Sthir Dasha system (7
years for Movable Rashis, 8 years for Fixed Rashis and 9
years for Dual Rashis). In this system every Dasha is of
the next 3rd Rashi (after leaving out two Rashis).
Shula Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P191_B002_01

- 身份：正文
- PDF 页：191
- 偈颂：181-182
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 181-182 [present] · PDF page 191

181-182. Some sages have designed the Shula Dasha for
determining the time of death. In this system the Dasha
commences from Dhan or Randhr Bhava, whichever is stronger.
If the Rashi is an odd one, the order of the Dasha the
Rashis will be onwards. It will be backwards in the case of
an even Rashi. The Dasha years in this system are as
adopted for the Sthir Dasha. There is a possibility that
death appears in the Dasha of the Marak (killer) Rashi
which has greater strength.
Trikon Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P191_B003_01

- 身份：正文
- PDF 页：191
- 偈颂：183-184
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 183-184 [present] · PDF page 191

183-184. In this system the first Dasha commences from the
strongest amongst the Rashis in Kon (Trikon) to Lagn (Tanu,
Putr, and Dharm Bhava). The Dasha system is similar to the
Char Dasha. Here also the Dashas of the Rashis will be in
the onwards order in the case of odd Rashis and in the
reverse order in the case of even Rashis. The Dasha years
will be similar to that of Char Dasha. It has been named
Trikon because of the commencement of the Dasha from the
Rashis in Konas.
Dirga Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P192_B001_01

- 身份：正文
- PDF 页：192
- 偈颂：185-187
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 185-187 [present] · PDF page 192

185-187. In this system the order of the Dashas is as
follows:
(1) The Rashi occupying Dharm Bhava.
(2) The Rashis receiving a drishti from the Rashi in Dharm
Bhava.
(3) The Rashi in Karm Bhava.
(4) The Rashis receiving a drishti from the Rashi in Karm
Bhava.
(5) The Rashi in Labh Bhava, and
(6) The Rashis receiving a drishti from the Rashi in Labh
Bhava.
As this system is mostly based on drishtis, it has been
named as Dirga Dasha.
Three different processes are adopted for the Movable,
Fixed, and Dual Rashis, from Dharm, Karm, and Labh Bhava.
According to them Rashi which receives a drishti from the
Movable Rashi is counted backwards and the Rashi receiving
a drishti from the Fixed Rashi is counted onwards. In the
case of the Dual Rashi if it is odd, the counting is
onwards and the order is backwards in case of an even Rashi
for the Rashis receiving a drishti.
Notes: The intention is that from the point of view of
drishti, the process of Rashi receiving a drishti should be
started from the Rashi which is nearest. In this way in the
case of Movable Rashis, the Rashis previous to them ("at
their back") are nearest to them. In the case of Fixed
Rashis the Rashis after them are considered as nearest in
respect of drishtis. In the case of Dual Rashis, the Rashis
on both sides are treated equally. It is for this reason
that in their case difference of order has been made for
odd and even Rashis. In this connection readers may refer
to Rashi Drishtikathan Adhyaya Chapter 8, Verse 9 and the
table after that.
Lagnadi Rashi Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P192_B001_02

- 身份：正文
- PDF 页：192
- 偈颂：185-187
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 185-187 [present] · PDF page 192

185-187. In this system the order of the Dashas is as
follows:
(1) The Rashi occupying Dharm Bhava.
(2) The Rashis receiving a drishti from the Rashi in Dharm
Bhava.
(3) The Rashi in Karm Bhava.
(4) The Rashis receiving a drishti from the Rashi in Karm
Bhava.
(5) The Rashi in Labh Bhava, and
(6) The Rashis receiving a drishti from the Rashi in Labh
Bhava.
As this system is mostly based on drishtis, it has been
named as Dirga Dasha.
Three different processes are adopted for the Movable,
Fixed, and Dual Rashis, from Dharm, Karm, and Labh Bhava.
According to them Rashi which receives a drishti from the
Movable Rashi is counted backwards and the Rashi receiving
a drishti from the Fixed Rashi is counted onwards. In the
case of the Dual Rashi if it is odd, the counting is
onwards and the order is backwards in case of an even Rashi
for the Rashis receiving a drishti.
Notes: The intention is that from the point of view of
drishti, the process of Rashi receiving a drishti should be
started from the Rashi which is nearest. In this way in the
case of Movable Rashis, the Rashis previous to them ("at
their back") are nearest to them. In the case of Fixed
Rashis the Rashis after them are considered as nearest in
respect of drishtis. In the case of Dual Rashis, the Rashis
on both sides are treated equally. It is for this reason
that in their case difference of order has been made for
odd and even Rashis. In this connection readers may refer
to Rashi Drishtikathan Adhyaya Chapter 8, Verse 9 and the
table after that.
Lagnadi Rashi Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P192_B002_01

- 身份：正文
- PDF 页：192
- 偈颂：188-189
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 188-189 [present] · PDF page 192

188-189. In this system there are Dashas of all the 12
Rashis including Lagn in every Nakshatr. Consequently, the
Bhayat at birth may be multiplied by 12 and then the
product should be divided by Bhabhog. The Rashi, degree,
etc., so available may be added to the longitude of Lagn.
From the Rashi, becoming available by doing so, will start
the Dashas of the 12 Rashis (if that Rashi is odd, the
counting will be onwards. It will be in the reverse order
if the Rashi is even).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P192_B003_01

- 身份：正文
- PDF 页：192
- 偈颂：190
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 190 [present] · PDF page 192

190. For finding the balance of Dasha at birth, multiply
the expired degree, etc., by the Dasha years of the first
Dasha Rashi and divide it by 30. The years, etc., so
arrived at, may be deducted from the Dasha years. The
result will indicate the balance of Dasha at birth in
years, months, etc..
Panch Swar Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P193_B001_01

- 身份：正文
- PDF 页：193
- 偈颂：191-194
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 191-194 [present] · PDF page 193

191-194. Beginning from Akaradhi  5 swaras ('a' , 'i' , 'u'
, 'e' , 'o') write underneath them the Varnas in 6 lines.
Leave out the letters 'na', 'na' and 'na' because they are
not used in names. If they are found in any name, 'ga' may
be substituted for na,  'ja' for 'na', and 'da' for 'na',
for working out the Dashas and making predictions. In this
manner, the Swar under which the first Varna of the name of
the native is found, will determine the order of the Dashas
of the five swaras. Dashas are of 12 years for all the five
swaras. In the Dasha of every Swar, there will be Antar
Dashas of all the five Swaras in the same order.
Yogini Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P193_B002_01

- 身份：正文
- PDF 页：193
- 偈颂：195-199
- 标题路径：CHAPTER 46 Dashas of Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 195-199 [present] · PDF page 193

195-199. Maharishi Parashar said: O Brahmin! I have already
given you the description of Panch Swar Dasha. Now, I will
acquaint you with the Yogini Dasha as described by Lord
Mahadeva. There are 8 Yoginis namely:

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P193_B003_01

- 身份：正文
- PDF 页：193
- 偈颂：1
- 标题路径：CHAPTER 46 Dashas of Grahas › 1. Mangal, 2. Pingal, 3. Dhanya, 4. Bhramari, 5. Bhadrika,
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 1 [present] · PDF page 193

1. Mangal, 2. Pingal, 3. Dhanya, 4. Bhramari, 5. Bhadrika,

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P193_B004_01

- 身份：正文
- PDF 页：193
- 偈颂：6
- 标题路径：CHAPTER 46 Dashas of Grahas › 1. Mangal, 2. Pingal, 3. Dhanya, 4. Bhramari, 5. Bhadrika,
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 6 [present] · PDF page 193

6. Ulka, 7. Siddha, and 8. Sankat.
Chandr, Surya, Guru, Mangal, Buddh, Shani, Shukr, and Rahu,
are born from Mangal, Pingal, Dhanya, Bhramari, Bhadrika,
Ulka, Siddha, and Sankat, in that order. Add 3 to the Janm
Nakshatr and divide it by 8. The remainder (1, etc.) will
indicate the Yogini Dasha of Mangal,. etc.. The Dashas of
Mangal, Pingal, Dhanya, Bhramari, Bhadrika, Ulka, Siddha,
and Sankat are of 1, 2, 3, 4, 5, 6, 7, and 8 years
respectively. The balance of Dasha at birth should be
worked out from the Bhayat and Bhabhog, etc., as already
explained earlier.
Pind, Amsh, and Nisarg Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P193_B005_01

- 身份：正文
- PDF 页：193
- 偈颂：201-202
- 标题路径：CHAPTER 46 Dashas of Grahas › 1. Mangal, 2. Pingal, 3. Dhanya, 4. Bhramari, 5. Bhadrika,
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 201-202 [present] · PDF page 193

201-202. The Pind Dasha, Amsh Dasha, and Nisarg Dasha will
be the same as Pindayu, Amshayu and Nisargayu, the method
of determination of which has already been explained
previously. The order of Dashas will be as follows. The
first will be of Lagn, Surya, or Chandr, whoever is
stronger. The subsequent Dashas will be of Grahas in Kendr
to them, then of Grahas in Panaphara Bhavas and lastly of
Grahas in Apoklima Bhavas. The Dashas and Antar Dashas of
Lagn and the seven Grahas will also be in the same order.
(Rahu Ketu do not find place in this Dasha system).

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P193_B006_01

- 身份：正文
- PDF 页：193
- 偈颂：203
- 标题路径：CHAPTER 46 Dashas of Grahas › 1. Mangal, 2. Pingal, 3. Dhanya, 4. Bhramari, 5. Bhadrika,
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 203 [present] · PDF page 193

203. The effects of these Dashas will be in accordance with
Ashtak Varg Bal, which subject will be dealt with later.
These Dashas are also called Ashtak Varg Dashas.
Sandhya Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P193_B007_01

- 身份：正文
- PDF 页：193
- 偈颂：204
- 标题路径：CHAPTER 46 Dashas of Grahas › 1. Mangal, 2. Pingal, 3. Dhanya, 4. Bhramari, 5. Bhadrika,
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 204 [present] · PDF page 193

204. Sandhya is the Dvadashamsh Ayurdaya of the Param
Ayurdaya (maximum possible life span). In Sandhya Dasha the
Dasha of all the Rashis from Lagn onwards is of 1/12 the
years of Param Ayurdaya.
Pachak Dasha in Sandhya Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P194_B001_01

- 身份：正文
- PDF 页：194
- 偈颂：205-206
- 标题路径：CHAPTER 46 Dashas of Grahas › 1. Mangal, 2. Pingal, 3. Dhanya, 4. Bhramari, 5. Bhadrika,
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 205-206 [present] · PDF page 194

205-206. By multiplying the Dasha years of Sandhya Dasha
by 6 and dividing the product by 31, the years, months,
etc., so arrived at may be put in one apartment of a Table.
Thereafter, half of these years, months, etc., may be
written in the next three apartments. The remaining 8
apartments may be filled in by one third of the aforesaid
years, months, etc.. In this manner Pachak Dasha in Sandhya
Dasha of every Bhava can be worked out and predictions may
be made from it.
Tar Dasha

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P194_B002_01

- 身份：正文
- PDF 页：194
- 偈颂：207-209
- 标题路径：CHAPTER 46 Dashas of Grahas › 1. Mangal, 2. Pingal, 3. Dhanya, 4. Bhramari, 5. Bhadrika,
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 207-209 [present] · PDF page 194

207-209. O Brahmin! Some sages have given consideration to
Tar Dasha which is like Vimshottari Dasha. In this Dasha
Janm, Sampat, etc., in their order replace Surya, Chandr,
etc., placed in Kendras. This Dasha is applied in those
cases only where there are Grahas in Kendras. If there are
a number of Grahas, the first Dasha will belong to the
strongest amongst them.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P194_B003_01

- 身份：正文
- PDF 页：194
- 偈颂：210
- 标题路径：CHAPTER 46 Dashas of Grahas › 1. Mangal, 2. Pingal, 3. Dhanya, 4. Bhramari, 5. Bhadrika,
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Dashas of Grahas · Sloka 210 [present] · PDF page 194

210. 0 Brahmin! I have now completed the description of the
different kinds of Dashas (that are followed by the sages).
I will give the description of their Antar Dashas (sub
periods) later.
