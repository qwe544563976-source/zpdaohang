# 第 68 章：Ekadhipatya Shodhana in the Ashtakavarg Scheme

- 来源：BPHS 97 章版
- 原始卡片：3 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P306_B002_01

- 身份：正文
- PDF 页：306
- 偈颂：1-5
- 标题路径：CHAPTER 68 Ekadhipatya Shodhana in the Ashtakavarg Scheme
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ekadhipatya Shodhana in the Ashtakavarg Scheme · Sloka 1-5 [present] · PDF page 306

1-5. Ekadhipatya Shodhana is done after writing the numbers
for rashis arrived at by Trikon Shodhana. Ekadhipatya
Shodhana is done if both the two rashis owned by a grah have
gained a number after Trikon Shodhana. Ekadhipatya Shodhana
is not to be done if one rashi has got a number and the other
is bereft of any number. The following are the rules for
Ekadhipatya Shodhana:
(I) If both the rashis are without a grah and the Trikon
Shodhana numbers are different (one is more than other), both
should be given the smaller number.
(2) If both the rashis are with grahas, no Shodhana is to be
done.
(3) If amongst the two rashis, one is with a grah and a
smaller Trikon rectified number and the other is without grah
with a bigger number, deduct the smaller number from the
bigger number, and the number of the rashi with grah should
be kept unchanged.
(4) If the rashi with the grah has a bigger number than that
of the rashi without grah, the Shodhana should be done of the
number of the rashi without grah and the number of the rashi
with grah should be kept unchanged.
(5) If both the rashis are without grahas and possess the
same numbers, shodhana of both the numbers should be done and
the rectified numbers should be reduced to zero.
(6) If one rashi is with grah and the other is without any
grah, the number of the latter should be reduced to zero.
Surya and Chandr own one rashi only (Simh and Kark), their
numbers should be kept unchanged.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P306_B002_02

- 身份：正文
- PDF 页：306
- 偈颂：1-5
- 标题路径：CHAPTER 68 Ekadhipatya Shodhana in the Ashtakavarg Scheme
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ekadhipatya Shodhana in the Ashtakavarg Scheme · Sloka 1-5 [present] · PDF page 306

1-5. Ekadhipatya Shodhana is done after writing the numbers
for rashis arrived at by Trikon Shodhana. Ekadhipatya
Shodhana is done if both the two rashis owned by a grah have
gained a number after Trikon Shodhana. Ekadhipatya Shodhana
is not to be done if one rashi has got a number and the other
is bereft of any number. The following are the rules for
Ekadhipatya Shodhana:
(I) If both the rashis are without a grah and the Trikon
Shodhana numbers are different (one is more than other), both
should be given the smaller number.
(2) If both the rashis are with grahas, no Shodhana is to be
done.
(3) If amongst the two rashis, one is with a grah and a
smaller Trikon rectified number and the other is without grah
with a bigger number, deduct the smaller number from the
bigger number, and the number of the rashi with grah should
be kept unchanged.
(4) If the rashi with the grah has a bigger number than that
of the rashi without grah, the Shodhana should be done of the
number of the rashi without grah and the number of the rashi
with grah should be kept unchanged.
(5) If both the rashis are without grahas and possess the
same numbers, shodhana of both the numbers should be done and
the rectified numbers should be reduced to zero.
(6) If one rashi is with grah and the other is without any
grah, the number of the latter should be reduced to zero.
Surya and Chandr own one rashi only (Simh and Kark), their
numbers should be kept unchanged.

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P306_B003_01

- 身份：正文
- PDF 页：306
- 偈颂：6
- 标题路径：CHAPTER 68 Ekadhipatya Shodhana in the Ashtakavarg Scheme
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Ekadhipatya Shodhana in the Ashtakavarg Scheme · Sloka 6 [present] · PDF page 306

6. After doing Ekadhipatya Shodhana, Pinda Sadhana should be
taken in hand.
