# 第 62 章：Effects of the Sukshmantar Dashas in the

- 来源：BPHS 97 章版
- 原始卡片：83 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P278_B002_01

- 身份：正文
- PDF 页：278
- 偈颂：—
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka unknown [unknown] · PDF page 278 · page_block BPHS_PL9_CHAP_97_P278_B002

Pratyantar Dashas
of the Various Grahas

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P278_B003_01

- 身份：正文
- PDF 页：278
- 偈颂：1
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 1 [present] · PDF page 278

1. The Sukshmantar Dasha is arrived at by multiplying the
periods of Pratyantar Dasha separately for each grah by the
Dasha years of that grah and then by dividing the product
by 120.
Effects of Sukshmantar Dashas in the Pratyantar Dasha of
Surya
@1314@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P278_B004_01

- 身份：正文
- PDF 页：278
- 偈颂：2
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 2 [present] · PDF page 278

2. Surya-Surya: (This means: the Sukshm Dasha of Surya in
his Pratyantar Dasha of Surya): going away from homeland,
danger of death, loss of position, losses all round.
@1324@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P278_B005_01

- 身份：正文
- PDF 页：278
- 偈颂：3
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 3 [present] · PDF page 278

3. Surya-Chandr: Devotion towards deities and Brahmins,
interest in pious deeds, affectionate relations with
friends.
@1334@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P278_B006_01

- 身份：正文
- PDF 页：278
- 偈颂：4
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 4 [present] · PDF page 278

4. Surya-Mangal: Indulgence in sinful deeds, distress from
cruel enemies, bleeding.
@1384@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P278_B007_01

- 身份：正文
- PDF 页：278
- 偈颂：5
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 5 [present] · PDF page 278

5. Surya-Rahu: Danger from thieves, fire and poison, defeat
in war, religious inclination.
@1354@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P278_B008_01

- 身份：正文
- PDF 页：278
- 偈颂：6
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 6 [present] · PDF page 278

6. Surya-Guru: Recognition by government, respected by
government employees, becoming favourite of the king.
@1374@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P278_B009_01

- 身份：正文
- PDF 页：278
- 偈颂：7
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 7 [present] · PDF page 278

7. Surya-Shani: Causing trouble to respected persons and
Brahmins by theft and by other bold deeds, going away from
ones own place, mental agony.
@1344@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P278_B010_01

- 身份：正文
- PDF 页：278
- 偈颂：8
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 8 [present] · PDF page 278

8. Surya-Buddh: Gains of fancy garments association with a
beautiful damsel, sudden success in ventures.
@1394@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P278_B011_01

- 身份：正文
- PDF 页：278
- 偈颂：9
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 9 [present] · PDF page 278

9. Surya-Ketu: Achievement of glory through wife and
employees, loss of wealth, comforts from servants.
@1364@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P278_B012_01

- 身份：正文
- PDF 页：278
- 偈颂：10
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 10 [present] · PDF page 278

10. Surya-Shukr: Happiness from son, friends, and wife,
acquisition of many kinds of properties.
Effects of Sukshmantar Dashas in the Pratyantar Dasha of
Chandr
@2324@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P278_B013_01

- 身份：正文
- PDF 页：278
- 偈颂：11
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 11 [present] · PDF page 278

11. Chandr-Chandr: Gain of ornaments and land, reverence,
recognition from the king, anger, glory.
@2334@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P279_B001_01

- 身份：正文
- PDF 页：279
- 偈颂：12
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 12 [present] · PDF page 279

12. Chandr-Mangal: Distress, antagonism with the enemy,
stomach troubles, death of father, troubles due to
imbalance of wind and bile.
@2384@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P279_B002_01

- 身份：正文
- PDF 页：279
- 偈颂：13
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 13 [present] · PDF page 279

13. Chandr-Rahu: Disharmony with friends and kinsmen, going
away from homeland, loss of wealth, imprisonment.
@2354@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P279_B003_01

- 身份：正文
- PDF 页：279
- 偈颂：14
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 14 [present] · PDF page 279

14. Chandr-Guru: Opulence and glory with Royal symbols,
birth of a son, gain of property, enjoyments all round.
@2374@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P279_B004_01

- 身份：正文
- PDF 页：279
- 偈颂：15
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 15 [present] · PDF page 279

15. Chandr-Shani: Wrath of the king, loss of wealth in
business dealings, danger from thieves and Brahmins.
@2344@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P279_B005_01

- 身份：正文
- PDF 页：279
- 偈颂：16
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 16 [present] · PDF page 279

16. Chandr-Buddh: Reverence from the king, gain of wealth,
gain of conveyance from a foreign land, increase in the
number of children.
@2394@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P279_B006_01

- 身份：正文
- PDF 页：279
- 偈颂：17
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 17 [present] · PDF page 279

17. Chandr-Ketu: Loss in the livelihood earned by sale,
etc., grains, medicines, cattle, etc., danger from fire and
the sun's rays (Sun-stroke).
@2364@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P279_B007_01

- 身份：正文
- PDF 页：279
- 偈颂：18
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 18 [present] · PDF page 279

18. Chandr-Shukr: Marriage, gain of a kingdom, land,
garments, ornaments, reputation, etc..
@2314@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P279_B008_01

- 身份：正文
- PDF 页：279
- 偈颂：19
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 19 [present] · PDF page 279

19. Chandr-Surya: Troubles, losses in ventures, destruction
of grains and cattle, physical distress.
Effects of Suksmantar Dashas in the Pratyantar Dasha of
Mangal
@3334@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P279_B009_01

- 身份：正文
- PDF 页：279
- 偈颂：20
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 20 [present] · PDF page 279

20. Mangal-Mangal: Sorrows on account of loss of lands,
epilepsy imprisonment, unhappiness.
@3384@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P279_B010_01

- 身份：正文
- PDF 页：279
- 偈颂：21
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 21 [present] · PDF page 279

21. Mangal-Rahu: Physical distress, danger from the people
(due to unpopularity), loss of wife and children, danger
from fire.
@3354@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P279_B011_01

- 身份：正文
- PDF 页：279
- 偈颂：22
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 22 [present] · PDF page 279

22. Mangal-Guru: Devotion towards deities, Mantra Siddhi,
reverence from the people (popularity), enjoyments.
@3374@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P279_B012_01

- 身份：正文
- PDF 页：279
- 偈颂：23
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 23 [present] · PDF page 279

23. Mangal-Shani: Release from imprisonment, happiness on
account of wealth, gains of clothes and servants.
@3344@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P279_B013_01

- 身份：正文
- PDF 页：279
- 偈颂：24
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 24 [present] · PDF page 279

24. Mangal-Buddh: Comforts of Chatr, Chamar, etc.
(receiving respect as that of a king), breathing troubles.
@3334@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P279_B014_01

- 身份：正文
- PDF 页：279
- 偈颂：25
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 25 [present] · PDF page 279

25. Mangal-Ketu: Indulgence in undesirable deeds at the
instance of others, one always remains filthy.
@3364@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P280_B001_01

- 身份：正文
- PDF 页：280
- 偈颂：26
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 26 [present] · PDF page 280

26. Mangal-Shukr: Enjoyment with women of choice, gain of
wealth, food, etc..
@3314@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P280_B002_01

- 身份：正文
- PDF 页：280
- 偈颂：27
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 27 [present] · PDF page 280

27. Mangal-Surya: Wrath of the king, distress through
Brahmins, failure in ventures, odium in public ('Loka
Nindha').
@3324@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P280_B003_01

- 身份：正文
- PDF 页：280
- 偈颂：28
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 28 [present] · PDF page 280

28. Mangal-Chandr: Piousness, gain of wealth, devotion
towards deities and Brahmins, danger from diseases.
Effects of Sukshmantar Dashas in the Pratyantar Dasha of
Rahu
@8384@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P280_B004_01

- 身份：正文
- PDF 页：280
- 偈颂：29
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 29 [present] · PDF page 280

29. Rahu-Rahu: Tendering to create turbulence by people,
lack of wisdom in performance of duties, affliction of the
mind.
@8354@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P280_B005_01

- 身份：正文
- PDF 页：280
- 偈颂：30
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 30 [present] · PDF page 280

30. Rahu-Guru: Affliction with a chronic disease, poverty
but revered by the people and the religious mindedness.
@8374@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P280_B006_01

- 身份：正文
- PDF 页：280
- 偈颂：31
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 31 [present] · PDF page 280

31. Rahu-Shani: Gain of wealth through unfair means, wicked
or mean nature, performing other persons duties,
undesirable association.
@8344@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P280_B007_01

- 身份：正文
- PDF 页：280
- 偈颂：32
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 32 [present] · PDF page 280

32. Rahu-Buddh: Increase in desires for sexual acts with
women, eloquence, hunger, physical distress.
@8394@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P280_B008_01

- 身份：正文
- PDF 页：280
- 偈颂：33
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 33 [present] · PDF page 280

33. Rahu-Ketu: politeness, Loss of reputation,
imprisonment, cold heartedness, loss of public money.
@8364@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P280_B009_01

- 身份：正文
- PDF 页：280
- 偈颂：34
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 34 [present] · PDF page 280

34. Rahu-Shukr: Freedom from imprisonment, gain of position
and wealth.
@8314@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P280_B010_01

- 身份：正文
- PDF 页：280
- 偈颂：35
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 35 [present] · PDF page 280

35. Rahu-Surya: Settling down in foreign lands, affliction
with Gulma (enlargement of the skin), even temperament,
comforts of conveyances.
@8324@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P280_B011_01

- 身份：正文
- PDF 页：280
- 偈颂：36
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 36 [present] · PDF page 280

36. Rahu-Chandr: Gain of gems (money), wealth, education,
attachment to prayers, good behavior, and devotion towards
deities.
@8334@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P280_B012_01

- 身份：正文
- PDF 页：280
- 偈颂：37
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 37 [present] · PDF page 280

37. Rahu-Mangal: Fleeing after defeat, anger, imprisonment,
indulgence in thefts and stealing.
Effects of Suksmantar Dashas in the Pratyantar Dasha of
Guru
@5354@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P280_B013_01

- 身份：正文
- PDF 页：280
- 偈颂：38
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 38 [present] · PDF page 280

38. Guru-Guru: Banishment of sorrows, increase in wealth,
performing Havan, devotion to lord Shiva, gains of
conveyance marked with royal symbols.
@5374@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P281_B001_01

- 身份：正文
- PDF 页：281
- 偈颂：39
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 39 [present] · PDF page 281

39. Guru-Shani: Obstacles in fasting, agony, foreign
journeys, loss of wealth, antagonism with kinsmen.
@5344@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P281_B002_01

- 身份：正文
- PDF 页：281
- 偈颂：40
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 40 [present] · PDF page 281

40. Guru-Buddh: Success in education, increase in
intelligence, reverence from the people (popularity), gains
of wealth, all sorts of enjoyments and comforts at home.
@5394@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P281_B003_01

- 身份：正文
- PDF 页：281
- 偈颂：41
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 41 [present] · PDF page 281

41. Guru-Ketu: Knowledge, glory, learning, study of
Shastras, worship of Lord Shiva, Havan, devotion toward
preceptor.
@5364@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P281_B004_01

- 身份：正文
- PDF 页：281
- 偈颂：42
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 42 [present] · PDF page 281

42. Guru-Shukr: Recovery from diseases, enjoyments, gain of
wealth, happiness from wife and children.
@5314@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P281_B005_01

- 身份：正文
- PDF 页：281
- 偈颂：43
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 43 [present] · PDF page 281

43. Guru-Surya: Troubles of wind and bile, stomach pains
through imbalance of phlegm and Rasas.
@5324@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P281_B006_01

- 身份：正文
- PDF 页：281
- 偈颂：44
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 44 [present] · PDF page 281

44. Guru-Chandr: Glory with umbrella with Royal symbols,
celebrations on the birth of a son, distress in eyes and
stomach.
@5334@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P281_B007_01

- 身份：正文
- PDF 页：281
- 偈颂：45
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 45 [present] · PDF page 281

45. Guru-Mangal: Administration of poison by wife,
imprisonment, danger from diseases, going away to foreign
lands, confusion and misunderstandings.
@5384@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P281_B008_01

- 身份：正文
- PDF 页：281
- 偈颂：46
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 46 [present] · PDF page 281

46. Guru-Rahu: Danger from thieves, snakes, and scorpions,
diseases and distress.
Effects of Sukshmantar Dashas in the Pratyantar Dasha of
Shani
@7374@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P281_B009_01

- 身份：正文
- PDF 页：281
- 偈颂：47
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 47 [present] · PDF page 281

47. Shani-Shani: Loss of wealth, diseases like rheumatism,
etc., destruction of the family, taking meals separately
from the family, full of sorrows.
@7344@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P281_B010_01

- 身份：正文
- PDF 页：281
- 偈颂：48
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 48 [present] · PDF page 281

48. Shani-Buddh: Profits in business, progress in
education, increase in wealth and lands.
@7394@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P281_B011_01

- 身份：正文
- PDF 页：281
- 偈颂：49
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 49 [present] · PDF page 281

49. Shani-Ketu: Turbulence by thieves, leprosy, loss of
livelihood, physical pains.
@7364@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P281_B012_01

- 身份：正文
- PDF 页：281
- 偈颂：50
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 50 [present] · PDF page 281

50. Shani-Shukr: Opulence and glory, learning the use of
weapons, birth of a son, coronation, good health, and
fulfillment of all ambitions.
@7314@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P281_B013_01

- 身份：正文
- PDF 页：281
- 偈颂：51
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 51 [present] · PDF page 281

51. Shani-Surya: Wrath of the king, quarrels in the family,
physical distress.
@7324@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P282_B001_01

- 身份：正文
- PDF 页：282
- 偈颂：52
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 52 [present] · PDF page 282

52. Shani-Chandr: Development of intelligence, inauguration
of a big project, loss of luster, extravagance, happiness
from wife and children.
@7334@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P282_B002_01

- 身份：正文
- PDF 页：282
- 偈颂：53
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 53 [present] · PDF page 282

53. Shani-Mangal: Loss of luster, excitement, burning in
the stomach, misunderstanding, quarrels, and wind and bile
disorders.
@7384@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P282_B003_01

- 身份：正文
- PDF 页：282
- 偈颂：54
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 54 [present] · PDF page 282

54. Shani-Rahu: Death of parents, agony, extravagance,
failure in ventures.
@7354@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P282_B004_01

- 身份：正文
- PDF 页：282
- 偈颂：55
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 55 [present] · PDF page 282

55. Shani-Guru: Acquisition of gold coins, reverence from
the public (popularity), increase in wealth and grains,
acquisition of Chatr with royal symbols.
Effects of Sukshmantar Dashas in the Pratyantar Dasha of
Buddh
@4344@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P282_B005_01

- 身份：正文
- PDF 页：282
- 偈颂：56
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 56 [present] · PDF page 282

56. Buddh-Buddh: Dawn of fortune, reverence from the king,
increase in wealth and property and affectionate relations
with all.
@4394@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P282_B006_01

- 身份：正文
- PDF 页：282
- 偈颂：57
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 57 [present] · PDF page 282

57. Buddh-Ketu: Danger from fire, agony, distress to wife,
coarse food and immoral tendencies.
@4364@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P282_B007_01

- 身份：正文
- PDF 页：282
- 偈颂：58
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 58 [present] · PDF page 282

58. Buddh-Shukr: Gain of conveyances, wealth, grains
produced in water, good repute and enjoyments.
@4314@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P282_B008_01

- 身份：正文
- PDF 页：282
- 偈颂：59
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 59 [present] · PDF page 282

59. Buddh-Surya: Injuries, wrath of the king, confusion in
the mind, diseases, loss of wealth, ridicule in public.
@4324@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P282_B009_01

- 身份：正文
- PDF 页：282
- 偈颂：60
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 60 [present] · PDF page 282

60. Buddh-Chandr: Good fortune, stability of mind,
reverence from the king, gains of property, visits of
friends and the preceptor.
@4334@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P282_B010_01

- 身份：正文
- PDF 页：282
- 偈颂：61
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 61 [present] · PDF page 282

61. Buddh-Mangal: Danger from fire and poison, idiocy,
poverty, confusion of mind, excitement.
@4384@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P282_B011_01

- 身份：正文
- PDF 页：282
- 偈颂：62
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 62 [present] · PDF page 282

62. Buddh-Rahu: Danger from fire and snakes, and the
victory over an enemy (with difficulty), opprobrium
(disgrace, dishonour) from goblins (evil, mischievous
spirit).
@4354@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P282_B012_01

- 身份：正文
- PDF 页：282
- 偈颂：63
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 63 [present] · PDF page 282

63. Buddh-Guru: Construction of a house, interest in
charities, comforts, and enjoyments, increase in opulence,
gain of wealth from the king.
@4374@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P283_B001_01

- 身份：正文
- PDF 页：283
- 偈颂：64
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 64 [present] · PDF page 283

64. Buddh-Shani: Profits in business, progress in
education, and increase in wealth, marriage, circumambience
(encompassing) or comprehensiveness.
Effects of Sukshmantar Dashas in the Pratyantar Dasha of
Ketu
@9394@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P283_B002_01

- 身份：正文
- PDF 页：283
- 偈颂：65
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 65 [present] · PDF page 283

65. Ketu-Ketu: Happiness from wife and children, physical
troubles, poverty, begging.
@9364@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P283_B003_01

- 身份：正文
- PDF 页：283
- 偈颂：66
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 66 [present] · PDF page 283

66. Ketu-Shukr: Freedom from diseases, gains of wealth,
devotion towards Brahmins and the preceptor, union with
members of the family.
@9314@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P283_B004_01

- 身份：正文
- PDF 页：283
- 偈颂：67
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 67 [present] · PDF page 283

67. Ketu-Surya: Quarrels, loss of land, residence in
foreign lands, disaster upon friends.
@9324@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P283_B005_01

- 身份：正文
- PDF 页：283
- 偈颂：68
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 68 [present] · PDF page 283

68. Ketu-Chandr: Promotion in service, victory in war, good
reputation in public (popularity).
@9334@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P283_B006_01

- 身份：正文
- PDF 页：283
- 偈颂：69
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 69 [present] · PDF page 283

69. Ketu-Mangal: Danger of falling down from a horse, etc.,
distress from thieves and the wicked, suffering from Gulma
(enlargement of the skin) and headache.
@9384@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P283_B007_01

- 身份：正文
- PDF 页：283
- 偈颂：70
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 70 [present] · PDF page 283

70. Ketu-Rahu: Destruction of wife, father, etc.,
defamation due to association with a wicked woman,
vomiting, blood pollution, bilious diseases.
@9354@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P283_B008_01

- 身份：正文
- PDF 页：283
- 偈颂：71
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 71 [present] · PDF page 283

71. Ketu-Guru: Antagonism with the enemy, increase in
property and opulence, distress due to losses in cattle,
wealth, and agricultural production.
@9374@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P283_B009_01

- 身份：正文
- PDF 页：283
- 偈颂：72
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 72 [present] · PDF page 283

72. Ketu-Shani: Imaginary distress, little comfort,
fasting, antagonism with wife, indulgence in falsehood.
@9344@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P283_B010_01

- 身份：正文
- PDF 页：283
- 偈颂：73
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 73 [present] · PDF page 283

73. Ketu-Buddh: Union and separation from many kinds of
people, distress to the enemy, increase in wealth and
property.
@6364@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P283_B011_01

- 身份：正文
- PDF 页：283
- 偈颂：74
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 74 [present] · PDF page 283

74. Shukr-Shukr: Destruction of enemies, enjoyments,
construction of temples of lord Shiva, etc., and
reservoirs.
@6314@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P283_B012_01

- 身份：正文
- PDF 页：283
- 偈颂：75
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 75 [present] · PDF page 283

75. Shukr-Surya: Agony in mind and heart, confusion of
mind, wanderings, both losses and gains at different
times.
@6324@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P284_B001_01

- 身份：正文
- PDF 页：284
- 偈颂：76
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 76 [present] · PDF page 284

76. Shukr-Chandr: Sound health, increase in wealth, success
in ventures through business dealings, progress in
education, and increase of intelligence.
@6334@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P284_B002_01

- 身份：正文
- PDF 页：284
- 偈颂：77
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 77 [present] · PDF page 284

77. Shukr-Mangal: Idiocy, danger from an enemy, going away
from one's homeland, danger from diseases.
@6384@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P284_B003_01

- 身份：正文
- PDF 页：284
- 偈颂：78
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 78 [present] · PDF page 284

78. Shukr-Rahu: Danger from fire and snakes, destruction of
kinsmen, resignation from position (service, etc.).
@6354@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P284_B004_01

- 身份：正文
- PDF 页：284
- 偈颂：79
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 79 [present] · PDF page 284

79. Shukr-Guru: Success in ventures, increase in wealth and
agricultural production, abnormal profits from purchase and
sale business.
@6374@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P284_B005_01

- 身份：正文
- PDF 页：284
- 偈颂：80
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 80 [present] · PDF page 284

80. Shukr-Shani: Distress from an enemy, sorrows,
destruction of cattle, loss of persons belonging to the
Gotra of the native and elders (or preceptors).
@6344@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P284_B006_01

- 身份：正文
- PDF 页：284
- 偈颂：81
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 81 [present] · PDF page 284

81. Shukr-Buddh: Increase in wealth with the assistance of
kinsmen, gain of wealth through business, happiness from
wife and children.
@6394@

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P284_B007_01

- 身份：正文
- PDF 页：284
- 偈颂：82
- 标题路径：CHAPTER 62 Effects of the Sukshmantar Dashas in the › Pratyantar Dashas of the Various Grahas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Effects of the Sukshmantar Dashas in the · Sloka 82 [present] · PDF page 284

82. Shukr-Ketu: Danger from fire, distress from diseases,
distress in mouth, eyes, and forehead, loss of accumulated
wealth, mental agony.
