# 第 28 章：Isht and Kasht Balas

- 来源：BPHS 97 章版
- 原始卡片：10 条
- 身份规则：正文、译注、编辑意见和外典补充分开标注；不把译注改写成正文。

## 原始内容卡

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P091_B002_01

- 身份：正文
- PDF 页：91
- 偈颂：1
- 标题路径：CHAPTER 28 Isht and Kasht Balas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Isht and Kasht Balas · Sloka 1 [present] · PDF page 91

1. Now I narrate the benefic and malefic tendencies of
the grahas based on which the Dasha effects (good or bad)
can be decided.
{uchcal}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P091_B003_01

- 身份：正文
- PDF 页：91
- 偈颂：2
- 标题路径：CHAPTER 28 Isht and Kasht Balas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Isht and Kasht Balas · Sloka 2 [present] · PDF page 91

2. Exaltation Rays: Deduct the grah's debilitation point
from its actual position. If the sum exceeds 6 rashis,
deduct from 12 rashis. The said sum should then be
increased by 1 rashi. The degrees, etc., be multiplied by 2
which, when considered along with rashis, will indicate the
Uchch Rasmi of the grah.
{checal}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P091_B004_01

- 身份：正文
- PDF 页：91
- 偈颂：3-4
- 标题路径：CHAPTER 28 Isht and Kasht Balas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Isht and Kasht Balas · Sloka 3-4 [present] · PDF page 91

3-4. Chesht Rasmi: Chesht Rasmis are to be calculated from
Chesht Kendr similar to Uchch Rasmi computations. The
Chesht Kendras of grahas from Mangal to Shani have already
been explained. Add 3 rashis to Sayan Surya (i.e. with
Ayanamsh), which will be the Chesht Kendr for Surya. The
sidereal longitude of Surya should be deducted from Chandr
to get Chandr's Chesht Kendr. If the Chesht Kendr (for any
grah) is in excess of 6 rashis, deduct it from 12 rashis.
Add 1 rashi and multiply the degrees, etc., by 2 which will
indicate the Chesht Rasmi of the grah.
{subasu}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P091_B005_01

- 身份：正文
- PDF 页：91
- 偈颂：5
- 标题路径：CHAPTER 28 Isht and Kasht Balas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Isht and Kasht Balas · Sloka 5 [present] · PDF page 91

5. Benefic and Malefic Rays: Add the Uchch Rasmis and
Chesht Rasmis together and divide by two. The result will
be auspicious rays (Subh Rasmis). Deduct from 8 the Subh
Rasmis to obtain inauspicious rays (or Asubh Rasmis).
{ishkas}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P091_B006_01

- 身份：正文
- PDF 页：91
- 偈颂：6
- 标题路径：CHAPTER 28 Isht and Kasht Balas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Isht and Kasht Balas · Sloka 6 [present] · PDF page 91

6. Isht and Kasht (Benefic and Malefic Tendencies): Reduce
1 from each of Chesht Rasmi and Uchch Rasmi. Then, multiply
the products by 10 and add together. Half of the sum will
represent the Isht Phala (benefic tendency) of the grah.
Reduce Isht Phala from 60 to obtain the grah's Kasht Phala
(or malefic tendency).
{subcal}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P091_B007_01

- 身份：正文
- PDF 页：91
- 偈颂：7-9
- 标题路径：CHAPTER 28 Isht and Kasht Balas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Isht and Kasht Balas · Sloka 7-9 [present] · PDF page 91

7-9. Isht and Kasht and Sapt Varg Phal: 60, 45, 30, 22, 15,
8, 4, 2, and 0 are the Subhankas (or Subha Griha Pankthis,
or benefic points) due to a grah's placement respectively
in exaltation, Mooltrikon, own, great friend's, friend's,
neutral, enemy's, great enemy's, and debilitation rashi. If
Subhanka is deducted from 60, Asubhanka (or Asubh Pankthi,
or inauspicious points) will emerge. O Brahmin, in other
vargas, these are halved.
{subeff}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P091_B008_01

- 身份：正文
- PDF 页：91
- 偈颂：10
- 标题路径：CHAPTER 28 Isht and Kasht Balas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Isht and Kasht Balas · Sloka 10 [present] · PDF page 91

10. A grah is considered auspicious in the first five of
the said places. In the sixth place it is neutral, i.e.
neither good nor bad. And in the other three places it is
inauspicious.
{digeff}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P092_B001_01

- 身份：正文
- PDF 页：92
- 偈颂：11-12
- 标题路径：CHAPTER 28 Isht and Kasht Balas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Isht and Kasht Balas · Sloka 11-12 [present] · PDF page 92

11-12. Nature of Effects due to Dig Bal, etc.: The
directional strength of a grah is itself representative of
the effects due to the direction; and Dig Bal itself is
indicated of effects due to the day. Whatever quantum of
Dig Bal, etc., are obtained by a grah will be the extent of
auspicious effects acquirable on account of that strength.
Deducting those figures from 60, the extent of
inauspiciousness is known. If auspiciousness is more in the
case of a grah's strength, the Dasha and bhavas related to
that grah will be auspicious. These are converse if
inauspiciousness is predominant.
{subca2}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P092_B002_01

- 身份：正文
- PDF 页：92
- 偈颂：13-14
- 标题路径：CHAPTER 28 Isht and Kasht Balas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Isht and Kasht Balas · Sloka 13-14 [present] · PDF page 92

13-14. Sapt Varg Phal and Isht and Kasht (Continued): The
various strengths (i.e. the other 6 vargas vide slokas 7-9
supra) be multiplied by the respective grah's Shad Bal
Pinda which will indicate the auspiciousness of the Varg
concerned. Auspicious or inauspicious aspect will be by
multiplying the Subh or Asubh Pankthi. Similarly,
auspicious or inauspicious effects will be known by
multiplying the auspicious or inauspicious strength by the
respective Pankthi.
{bhaeff}

### BPHS_PL9_CHAP_97_CARD_BPHS_PL9_CHAP_97_P092_B003_01

- 身份：正文
- PDF 页：92
- 偈颂：15-20
- 标题路径：CHAPTER 28 Isht and Kasht Balas
- 引证：Brihat Parashara Hora Shastra · PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved · confirmed: Isht and Kasht Balas · Sloka 15-20 [present] · PDF page 92

15-20. Effects of a Bhava: The strength of a bhava and its
lord have already been explained. The actual effects will
be a combination of bhava strength and its lord's strength.
If there is a benefic in the bhava add the same to the
auspicious effects and deduct from inauspicious effects,
which will denote the inauspicious effects. If a malefic is
in the bhava, reverse the process, i.e. add inauspicious
effects and deduct auspicious effects. Similarly, drishtis
and Balas. If a grah is exalted or with such a dignity, add
auspicious effects and reduce inauspicious effects. For
debilitation etc., it is converse. In Ashtak Varg, add
Bindus (auspicious points) and deduct Karanas (inauspicious
points). If a bhava extends to two rashis, the
rectification will be done as per both the lords. In that
case which ever rashi has more Bindus that rashi will yield
more favourable results concerning that bhava. If both the
rashis have more auspicious Bindus take the average. Thus,
the auspicious and inauspicious effects of a bhava be
understood.
