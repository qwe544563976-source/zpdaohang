---
name: bphs-97-book
description: "BPHS 97 章版完整原文、版本路由与差异核对入口。用于用户明确查询 97 章版、比较 97/100 章节与措辞，或要求按 97 版为14 个主题组生成版本限定检索计划。公共判断方法复用 bphs-100-book，但正式引用必须来自用户要求的版本；2,096 条机器差异只能作待核对线索，不能冒充人工确认结论。"
---

<!-- argument-hint: [章节、概念、偈颂、原文问题或断盘主题] -->

# BPHS 97 章版原文、导航与差异

来源作者：Maharishi Parashara  
来源版本：PL9 CHAP text CHAP01-CHAP97; PL9 codes preserved  
原始卡片：2185 条

## 使用方法

1. 用户只查 97 版章节、术语、偈颂或原文时：先读 [INDEX.md](INDEX.md) 或 [glossary.md](glossary.md)，再读对应 `chapters/*.md`。回答必须给版本、章节、`card_id（原文卡永久编号）`、PDF 页、偈颂和身份。
2. 用户要求判断或版本比较时：先完整读取 [references/navigation/method-map.md](references/navigation/method-map.md) 和 [references/navigation/version-routing.md](references/navigation/version-routing.md)。
3. 再读取本技能的 [references/navigation/required-checks.json](references/navigation/required-checks.json)、[references/navigation/query-recipes.json](references/navigation/query-recipes.json) 及命中的 14 个主题入口；公共清单和四路查询的权威源是 `bphs-100-book/references/navigation/`，本技能只增加 97 版过滤、对应章节和差异边界。
4. 用户明确要 97 版时，查询计划的 `filters.work_ids` 只能是 `BPHS_PL9_CHAP_97`。支持、反例和边界由实验 RAG 执行；方法路逐条另发普通搜索，只限定 97 版、不限定书架。公共方法配方可来自 100 版导航，但正式原文引用不得混入 100 版。
5. 比较版本时，先用 [differences/chapter-map.md](differences/chapter-map.md) 找语义对应，再分别检索两版真实原文。差异文件和 2,096 条记录只能用于发现待核对线索。

## 原文定位事实

- 本版 `work_id（书籍编号）`：`BPHS_PL9_CHAP_97`。
- `parent_id（父段编号）` 只从正式成品包或 RAG 返回值读取；章节 Markdown 没有显示该字段时不得猜。
- `card_id（原文卡永久编号）` 是章节文件每个三级标题的完整编号。
- PL9 原始内部代码保留在原文卡正文或正式父段 `raw_text` 中；只原样引用，不解释代码含义。
- 正式引用以 RAG 返回的 `work_id + parent_id + card_id + 章节 + 偈号 + PDF 页 + citation（原始引证）` 为准。

## 判断硬门

- Skill 只决定“应该查什么”；Skill 摘要、章节映射、差异摘要和查询词都不是证据。
- 没有 97 版真实原文卡或完整父段时，写“97 章版本次未检索到”，不得用 100 版补写成 97 版。
- 单一配置不能直接套死结论；必须列出已满足、未满足和未核对的原文条件。
- 机器差异、案例、译注、编辑意见和外典不能冒充 97 版通用正文规则。
- 两版有冲突时并列展示，不擅自融合或裁决。
- 已完成 14 个主题组的版本导航；公共判断逻辑只读取 100 章版导航，正式证据仍只允许用户要求的版本。

## 97/100 内部差异层

- 章节语义映射：97 条。
- 差异记录：2096 条，属于机器文本对齐结果，尚未逐条完成方法论三重验证。
- 100 版独有章节：第 5、10、99 章。
- 入口：[differences/INDEX.md](differences/INDEX.md)；章节映射见 [differences/chapter-map.md](differences/chapter-map.md)。
- 差异层与 97 章原文库现在属于同一个顶层技能，不再单独暴露 `bphs-97-differences`。

## 原文身份

- `source（正文）`：可作为本版本的原文规则。
- `commentary / translation_note（译注）`：只能作为解释或版本意见，必须单独标明。
- 版本冲突：并列原文，不擅自裁决或改写。

## 单元总览

| 单元 | 标题 | 卡片数 |
|---|---|---:|
| 第 1 章 | The Creation | 9 |
| 第 2 章 | Great Incarnations (Of The Lord) | 5 |
| 第 3 章 | Grah Characters and Description | 62 |
| 第 4 章 | Zodiacal Rashis Described | 17 |
| 第 5 章 | Special Lagnas | 9 |
| 第 6 章 | The Sixteen Divisions of a Rashi | 20 |
| 第 7 章 | Divisional Considerations | 13 |
| 第 8 章 | Drishtis of the Rashis | 3 |
| 第 9 章 | Evils at Birth | 36 |
| 第 10 章 | Antidotes for Evils | 8 |
| 第 11 章 | Judgement of Bhavas | 14 |
| 第 12 章 | Effects of Tanu Bhava | 10 |
| 第 13 章 | Effects of Dhan Bhava | 11 |
| 第 14 章 | Effects of Sahaj Bhava | 9 |
| 第 15 章 | Effects of Bandhu Bhava | 10 |
| 第 16 章 | Effects of Putr Bhava | 22 |
| 第 17 章 | Effects of Ari Bhava | 12 |
| 第 18 章 | Effects Of Yuvati Bhava | 29 |
| 第 19 章 | Effects of Randhr Bhava | 7 |
| 第 20 章 | Effects Of Dharm Bhava | 18 |
| 第 21 章 | Effects of Karm Bhava | 17 |
| 第 22 章 | Effects Of Labh Bhava | 11 |
| 第 23 章 | Effects Of Vyaya Bhava | 10 |
| 第 24 章 | Effects of the Bhava Lords | 142 |
| 第 25 章 | Effects of Non-Luminous Grahas | 85 |
| 第 26 章 | Evaluation of Drishtis of Grahas | 6 |
| 第 27 章 | Evaluation Of Strengths | 44 |
| 第 28 章 | Isht and Kasht Balas | 10 |
| 第 29 章 | Bhava Padas | 32 |
| 第 30 章 | Upa Pad | 20 |
| 第 31 章 | Argala or Intervention from Grahas | 11 |
| 第 32 章 | Karakatwas of the Grahas | 17 |
| 第 33 章 | Effects of Karakamsh | 30 |
| 第 34 章 | Yoga Karakas | 23 |
| 第 35 章 | Nabhash Yogas | 43 |
| 第 36 章 | Many Other Yogas | 21 |
| 第 37 章 | Chandr's Yogas | 6 |
| 第 38 章 | Surya's Yogas | 3 |
| 第 39 章 | Raj Yog | 38 |
| 第 40 章 | Yogas For Royal Association | 15 |
| 第 41 章 | Combinations For Wealth | 23 |
| 第 42 章 | Combinations for Penury | 16 |
| 第 43 章 | Longevity | 46 |
| 第 44 章 | Marak (Killer) Grahas | 19 |
| 第 45 章 | Avasthas of Grahas | 55 |
| 第 46 章 | Dashas of Grahas | 98 |
| 第 47 章 | Effects of Dashas | 28 |
| 第 48 章 | Distinctive Effects of the Nakshatr Dasha or of the | 6 |
| 第 49 章 | Effects of the Kaal Chakr Dasha | 14 |
| 第 50 章 | Effects of the Char, etc., Dashas | 32 |
| 第 51 章 | Working out of Antar Dashas of Grahas and Rashis | 10 |
| 第 52 章 | Effects of the Antar Dashas in the Dasha of | 27 |
| 第 53 章 | Effects of the Antar Dashas in the Dasha of | 29 |
| 第 54 章 | Effects of Antar Dashas in the Dashas of Mangal | 33 |
| 第 55 章 | Effects in the Antar Dashas in the Dasha of | 34 |
| 第 56 章 | Effects of the Antar Dashas in the Dasha of | 36 |
| 第 57 章 | Effects of the Antar Dashas in the Dasha of | 36 |
| 第 58 章 | Effects of the Antar Dashas in the Dasha of | 34 |
| 第 59 章 | Effects of the Antar Dashas in the Dasha of | 34 |
| 第 60 章 | Effects in the Antar Dashas of Shukr | 34 |
| 第 61 章 | Effects of Pratyantar Dashas in the Antar | 82 |
| 第 62 章 | Effects of the Sukshmantar Dashas in the | 83 |
| 第 63 章 | Effects of Prana Dashas in the Sukshma Dasha of | 82 |
| 第 64 章 | Effects of Antar Dashas in the Kala Chakr Dasha | 14 |
| 第 65 章 | Effects of Dashas of Rashis in the Amshas of | 14 |
| 第 66 章 | Ashtakavarg | 24 |
| 第 67 章 | Trikon Shodhana (rectification) in the | 3 |
| 第 68 章 | Ekadhipatya Shodhana in the Ashtakavarg Scheme | 3 |
| 第 69 章 | Pinda Sadhana in the Ashtakavarg Scheme | 2 |
| 第 70 章 | Effects of the Ashtakavarg | 30 |
| 第 71 章 | Determination of Longevity through the Ashtakavarg | 1 |
| 第 72 章 | Aggregational Ashtakavargas | 12 |
| 第 73 章 | Effects of the Rays of the Grahas | 7 |
| 第 74 章 | Effects of the Sudarshana Chakr | 14 |
| 第 75 章 | Characteristic Features of Panchmahapurushas | 6 |
| 第 76 章 | Effects of the five Elements : Space, Air, Fire, | 18 |
| 第 77 章 | Effects of Satwa Gun, etc. | 19 |
| 第 78 章 | Lost Horoscopy | 8 |
| 第 79 章 | Yogas leading to Ascetism | 15 |
| 第 80 章 | Female Horoscopy | 35 |
| 第 81 章 | Effects of the Characteristic Features of the | 51 |
| 第 82 章 | Effects of Moles, Marks, Signs, etc., for Men | 11 |
| 第 83 章 | Effects of curses in the previous birth | 27 |
| 第 84 章 | Remedial measures to obtain relief from the | 19 |
| 第 85 章 | Inauspicious Births | 1 |
| 第 86 章 | Remedial Measures for Birth on Amavasya | 2 |
| 第 87 章 | Remedies from the evil effects of birth on | 4 |
| 第 88 章 | Remedies from evil effects of birth in Bhadra and | 3 |
| 第 89 章 | Remedies from Nakshatr Birth | 2 |
| 第 90 章 | Remedies from Sankranti Birth | 5 |
| 第 91 章 | Remedies for Birth in Eclipses | 3 |
| 第 92 章 | Remedies from Birth in Gandanta | 7 |
| 第 93 章 | Remedies for Birth in Abhukta Mula | 7 |
| 第 94 章 | Remedies from Effects of Birth in Jyeshtha Gandanta | 6 |
| 第 95 章 | Remedies from the effects of birth of a daughter after three | 4 |
| 第 96 章 | Remedies from evil effects of unusual delivery | 4 |
| 第 97 章 | Conclusion | 5 |

## 边界

- 不虚构星盘位置、页码、偈颂或章节。
- 不把译注、编辑意见、外典补充写成正文。
- 古代绝对断语按来源原样呈现；若用户要求应用，必须同时写清命中的原始条件和未命中的条件。
