---
name: cangjie-skill
description: Distill long-form content into executable methods, or distill judgment-method candidates from an accepted formal package or an explicitly isolated read-only pilot fixture plus a traceable knowledge map. Use for ordinary book/video/course methodology extraction, or when building evidence-bound method skeletons, required facts, dependencies, four-lane retrieval plans, and stop conditions for book-to-judgment-navigation. Not for summarization, source chunking, OCR, or repairing evidence atoms.
---

# cangjie-skill — 把一本书蒸馏成一组可执行 skills 的元 skill

## 使命

把一本书里沉淀的方法论,拆解成一组**原子化、可被 agent 在真实场景下调用**的 skills,让读者真正用起来。

> **术语约定**: 本文档及 `methodology/`、`extractors/` 中所有的"书",泛指一切被蒸馏的长内容 — 书籍、长视频转写、播客文字稿、课程、访谈、长文、资料集。

**边界**:
- ✅ 做: 方法论 / 决策框架 / 清单 / 原则 / 概念体系的蒸馏
- ❌ 不做: 书摘 / 读后感 / 作者人设角色扮演 (后者请用 nuwa-skill)

## 先判断当前做哪一种工作

只有两条路，开工时选定后不得混跑：

- 输入是 `accepted-package.json（已验收书包凭证）`、明确隔离的 `PILOT_TEMP（只读临时测试夹具）`、冻结原文知识地图，或用户明确要求制作判断导航：进入下方“判断方法蒸馏模式”，并完整读取 [判断方法蒸馏模式](methodology/08-judgment-navigation-mode.md)。普通读书流程的阶段 0～5 全部不适用。
- 其他书籍、课程、播客和长文的方法论提炼：进入“普通方法论蒸馏模式”，执行 RIA-TV++。判断方法的书包、原文编号、执行许可和批次规则全部不适用。

拿不准时先检查输入文件和工作单；不能先跑普通流程，再把结果改名成判断方法产物。

## 核心方法论: RIA-TV++

一个五阶段 + 并行提取 + 三重验证 + darwin 兼容测试的流水线。详见 `methodology/00-overview.md`。

## 两种运行模式

### 普通方法论蒸馏模式

使用下方原有 RIA-TV++ 流程，把普通书籍、视频、播客或课程拆成可调用的方法技能。

### 判断方法蒸馏模式

用户提供 `accepted-package.json（已验收书包凭证）`、明确隔离的 `PILOT_TEMP（只读临时测试夹具）`、`book-to-skill（整书知识地图工具）`产出的知识地图，或明确要求制作判断导航时，必须改读 [判断方法蒸馏模式](methodology/08-judgment-navigation-mode.md)。

在 `C:/Users/aa/Documents/ChatGPT/洗书`项目中开工前，必须先读 `JUDGMENT_PIPELINE_STATUS.json（判断导航当前状态总账）`和`JUDGMENT_WRITE_OWNERSHIP.json（文件写入所有权表）`。当前范围被冻结或本窗口不是责任窗口时，只读并向主窗口报告，不修改文件；不得在其他文档复制当前状态或所有权。

正式方法批次开工前还必须从工作单取得当前 `accepted_package_path`，调用 `tools.register_accepted_package.run_authoritative_validation`只检查这一份书包。退出码不是 0 时停止本批，不得因为旧登记状态、旧知识地图或上一批曾经通过而继续读取正式原文生产方法；另一册书失败也不得连坐当前已经单独通过的书。逐页表格和结构反查属于上游责任；本工具只认上游权威检查结果，不打开 PDF 自行补证。

该模式：

- 不执行阶段 0 的自由整书阅读；
- 不调用五个并行提取器重新扫描整本正文；
- 不读取 PDF、`book.md` 或 `pages.jsonl`补内容；
- 不生成多个顶层技能；
- 先提方法骨架，再逐步骤绑定原文证据；
- `method-recipes.json（方法机器配方）`是方法唯一真相，人读方法文件只能由它生成；
- 判断方法批次只允许由 `scripts/build_methods.py（唯一方法生成脚本）`写入方法和查询配方；AI 输出先通过 `references/method-extraction.schema.json（严格结构合同）`，`tmp/`中的逐章生成脚本只作历史记录；
- 只产出候选或试验状态，不能自行发布。

### 判断方法生产不空转的纪律

- 格式、字段、逐字引文、页码、分支通电、占位事实和状态问题由生成器或验证器拦截；这些确定性问题不再反复交给独立人工智能检查。
- 独立人工智能只找“有没有扩大原意、漏掉前提、写反取消或缓解、错挂时间范围”等开放语义问题。它的等待只阻止本批并入全书，不阻止没有依赖关系的下一批继续生成和完成机器检查。审计报告提前返回时只落盘等待；主窗口完成当前批次机器检查后，才在批次交界点读取和处理，不因中途消息切走生产注意力。
- **明确分流**：当前没有可并入的绿批次，也不等于停产。只要正式书包通过、共享生成器和验证器没有处于待修状态、下一批不依赖被拒原文或受污染的验证器结果，下一批照常生成并做机器检查；被拒批次只保持拒绝，等修复后单独重跑，不能拖住整条生产线。
- 同一错误家族再次出现时，停止给单个批次打补丁；必须修改共享生成规则或验证器，并用能复现旧错的正反样本证明机器已经会拦。共享程序和验证器默认冻结；代码审计只有证明真实批次因此错误放行或错误拦截，才允许解冻。纯推演、伪造回执或空文件绕过等没有真实批次后果的项目，只登记到“本门不查什么”，不修、不停产。共享程序真正解冻时，独立审计一次提交完整的 OR 组合矩阵，不按“发现一个洞、修一个洞”循环。
- 项目总状态只写入 `JUDGMENT_PIPELINE_STATUS.json（判断导航当前状态总账）`，单批状态只写入批次目录的 `validation/batch-state.json（单批机器状态）`；不新增第二份审计队列或进度看板。

```
阶段 0: Adler 整书理解     → BOOK_OVERVIEW.md
阶段 1: 5 个 agent 并行提取 → 候选方法论单元池
阶段 1.5: 三重验证筛选       → 通过的单元 (用户轻确认)
阶段 2: RIA++ 构造 skill     → 每个 skill 的 SKILL.md
阶段 3: Zettelkasten 链接    → INDEX.md + GLOSSARY.md
阶段 4: 压力测试 (darwin 兼容) → test-prompts.json + 回炉淘汰
阶段 5: 交付                 → DIGEST.md 精华长文 + 安装到 skills 目录
```

## 何时调用此 skill

用户说类似:
- "帮我拆《穷查理宝典》"
- "把毛选蒸馏成 skill"
- "把这个 B 站视频/播客/课程蒸馏成 skill"
- "distill this book into skills: <path>"
- "我想把这本书的方法论做成可用的 skill"

## 输入要求

在开始前**必须**从用户处确认:
1. **内容文本来源**: PDF / EPUB / TXT / 字幕文件 / 转写稿路径, 或可访问的纯文本。**不要**在没有文本的情况下"凭记忆"蒸馏 — 宁可停下来问用户要。(视频/播客建议先用 video-downloader 类工具拿到转写文本)
2. **内容元信息**: 书籍是"书名 + 作者 + 出版年"; 视频/播客/课程是"标题 + 作者(UP 主/主播/讲者) + 发布时间"。用于目录命名和审计。
3. **是否首次试点**: 如果用户是第一次用 cangjie-skill,建议先蒸馏 1 份内容验证流程再批量。

判断方法蒸馏模式不使用上述正文入口。正式运行只接受 `accepted-package.json（已验收书包凭证）`；试验运行只接受明确标记且不可发布的 `PILOT_TEMP（临时测试夹具）`。两种运行都必须有明确读取范围、知识地图、工作单和本次蒸馏来源清单；缺少任何一项时停止，不得回退到普通整书提取，也不得直接接收裸原文原子路径。

**非书籍内容的字段映射**: `source_chapter` 等"章节"字段对视频填时间戳或分 P,对播客填集数,对课程填讲次 — 保证可追溯即可。

## 输出结构

```
books/<book-slug>/
├── PIPELINE_STATE.md          # 流水线状态: 当前阶段 + 各 skill 进度 (断点续跑用)
├── BOOK_OVERVIEW.md           # 阶段 0 产出: 主旨/骨架/术语/批判
├── verified.md                # 阶段 1.5 产出: 通过三重验证的单元 + 判定理由
├── INDEX.md                   # 阶段 3 产出: skill 总览 + 引用图
├── GLOSSARY.md                # 阶段 3 产出: 全书共享术语词典
├── DIGEST.md                  # 阶段 5 产出: 面向读者的精华长文
├── candidates/                # 阶段 1 产出: 原始候选池 (审计用)
├── rejected/                  # 阶段 1.5 淘汰的单元 + 原因 (审计用)
├── <skill-slug-1>/
│   ├── SKILL.md
│   ├── test-prompts.json      # darwin-skill 兼容格式
│   └── test-results.md        # 阶段 4 测试通过率 + 失败分析
├── <skill-slug-2>/
│   └── ...
```

## 执行流程 (严格按顺序)

**断点续跑**: 开始前先检查 `books/<slug>/PIPELINE_STATE.md` 是否存在。存在则读取并从记录的阶段续跑,不要从头重来。每完成一个阶段,更新该文件 (当前阶段 / 已完成产物 / 各 skill 状态 / 下一步),格式用简单的 checklist markdown 即可。

### 阶段 0 — 整书理解

1. 读取用户提供的书本文本。大文件分块阅读。
2. 执行 `methodology/01-stage0-adler.md` 中的 Adler 四步 (结构 / 解释 / 批判 / 应用)。
3. 按 `templates/BOOK_OVERVIEW.md.template` 填充,写入 `books/<slug>/BOOK_OVERVIEW.md`。
4. 把产出展示给用户确认:"骨架我理解对了吗?有没有你希望重点突出的方向?" 得到确认再进入阶段 1。

### 阶段 1 — 5 个 sub-agent 并行提取

本节只适用于普通方法论蒸馏模式。判断方法蒸馏模式禁止进入本节，改按 `methodology/08-judgment-navigation-mode.md`执行。

**并行** spawn 5 个 Task sub-agents(使用 Agent 工具,一次调用中发起 5 个):

| sub-agent | 读取的 prompt | 产出 |
|---|---|---|
| 框架提取器 | `extractors/framework-extractor.md` | 决策框架 / 思维模型 |
| 原则提取器 | `extractors/principle-extractor.md` | 原则 / 清单 / 规则 |
| 案例提取器 | `extractors/case-extractor.md` | 作者在书中亲自使用过的实例 |
| 反例提取器 | `extractors/counter-example-extractor.md` | 书中警告的失败模式 |
| 术语提取器 | `extractors/glossary-extractor.md` | 关键概念词典 |

每个 sub-agent 独立读书、独立提取、独立输出到 `books/<slug>/candidates/<type>.md`。

- **长文本**: 超出单个 sub-agent 上下文的内容,按 `methodology/02-stage1-parallel-extract.md` 的分块策略处理。
- **降级方案**: 当前环境不支持并行 sub-agent 时,用同样 5 个 extractor prompt **串行**执行,产出格式不变。

### 阶段 1.5 — 三重验证筛选

读取 `methodology/03-stage1.5-triple-verify.md`,对每个候选单元执行:

- **V1 跨域**: 书中至少 2 个独立段落有佐证?
- **V2 预测力**: 能用它回答一个书里没明说的新问题吗?
- **V3 独特性**: 不是任何聪明人都会说的常识吗?

通过的写入 `books/<slug>/verified.md`。不通过的写入 `books/<slug>/rejected/` 并附原因 — 保留审计轨迹,也允许用户事后捞回。

**用户轻确认** ★: 筛选完成后,把"通过的 N 个候选标题 + 淘汰的 M 个"列表展示给用户:"这 N 个会做成 skill,有想捞回或砍掉的吗?" 得到确认再进入阶段 2 — 阶段 2–4 是最耗时的部分,这一步确认能避免大量返工。

### 阶段 2 — RIA++ 构造 skill

对每个通过的单元,按 `templates/SKILL.md.template` 填充:

- **R (Reading)**: 原文引用 ≤150 字/段 (英文原文 ≤100 词/段)
- **I (Interpretation)**: 用自己的话重写方法论骨架 (避免照搬译本)
- **A1 (Past Application)**: 书中作者用过的案例
- **A2 (Future Trigger)** ★: 用户在什么情境下会需要这个 → skill 的 `description` 字段
- **E (Execution)**: 1-2-3 可执行步骤
- **B (Boundary)**: 什么时候不适用 / 来自阶段 0 批判阶段的作者盲点

细则见 `methodology/04-stage2-ria-plus.md`。注意: A2 中"与相邻 skill 的区分"此时只写**初稿** (基于 verified.md 的单元列表),阶段 3 建立链接后回填定稿。

### 阶段 3 — Zettelkasten 链接

按 `methodology/05-stage3-zettelkasten.md`:
1. 找出 skill 之间的引用关系 (A 依赖 B / A 对比 B / A 组合 B)
2. 在每个 SKILL.md 末尾补"相关 skills"段,并回填 A2 的"与相邻 skill 的区分"
3. 按 `templates/INDEX.md.template` 生成 `INDEX.md` (含引用图 mermaid)
4. 把 `candidates/glossary.md` 整理成 `books/<slug>/GLOSSARY.md` — 它是所有 skill 的共享词典,不该埋在审计目录里

### 阶段 4 — 压力测试 (darwin 兼容)

对每个 skill 按 `methodology/06-stage4-pressure-test.md`:
1. 设计 5–10 条测试 prompt,按 `templates/test-prompts.json.template` 写入 `test-prompts.json`
2. 至少包括 3 类: **应调用** / **不应调用 (诱饵)** / **边界模糊**。诱饵中至少 1 条必须是"应触发同书另一个 skill"的场景 (跨 skill 混淆测试)
3. 优先用独立 sub-agent 盲测每条 prompt,由主流程对照预期统计结果,**未过的回炉重做阶段 2** — 不做"表面修补"
4. 每个 skill 的测试结果写入 `<skill-dir>/test-results.md`

### 阶段 5 — 交付

按 `methodology/07-stage5-deliver.md`:
1. 生成 `books/<slug>/DIGEST.md` — 面向读者的精华长文 (按 `templates/DIGEST.md.template`),满足"不读全书、只看精华"的需求
2. 询问用户安装位置 (用户级 `~/.claude/skills/` 或项目级 `.claude/skills/` / `.cursor/skills/`),把通过测试的 skill 复制或 symlink 过去 — **没有这一步,产出的 skill 无法被真正调用**
3. 告知用户: "已完成,可一键喂给 darwin-skill 自动进化"

## 质量红线 (违反则阻止输出)

1. 每个 skill 必须通过**全部**三重验证
2. 每个 skill 必须有完整的 R / I / A1 / A2 / E / B 六段
3. 原文引用 ≤150 字/段 (英文 ≤100 词/段)
4. 每个 skill 必须有 `test-prompts.json`,且包含诱饵测试 (不应调用的场景),其中至少 1 条是同书兄弟 skill 的场景
5. `description` 字段必须明确 trigger 条件,不能只是"一个关于 X 的 skill"
6. 判断方法蒸馏模式的每个执行步骤必须有自己的 `source_status（来源可靠程度）`和`evidence_refs（逐步骤证据列表）`；每条步骤证据保存 `evidence_atom_id（原文证据永久编号）`、逐字短引和 PDF 页码。整份方法只挂一个宽泛来源时阻止输出
7. 判断方法蒸馏模式不得修改、补写、合并、拆分或重新编号原文原子；发现上游问题只记录并上报
8. `pilot_only = true` 的方法必须同时为 `publishable = false`，且不得安装进正式运行技能
9. 每个方法必须记录 `fact_binding_status（排盘事实接入状态）`和`upstream_issue_ids（上游问题编号列表）`；事实未接通或阻塞问题未解决时禁止执行
10. 人读方法、方法地图和核验状态展示必须从 `method-recipes.json（方法机器配方）`确定性生成，不得独立手写第二套状态或规则
11. 每个步骤必须同时具备 `evidence_atom_id（原文原子编号）`、逐字短引、非空 PDF 页码和非空停止条件；`intro`、`note`、案例、举例、译注和编辑意见只能作为辅助材料，不能进入通用步骤的 `evidence_refs（步骤证据列表）`
12. 每个步骤还必须保存适用范围、原文直接支持的最小意思、`produced_fact_keys（本步骤产出事实）`、`AND／OR／NOT` 条件关系、可选的`conditional_fact_requirements（按分支必查事实）`、例外／取消／缓解关系、禁止扩大解释，以及与 `required_fact_keys（步骤所需事实）`完全一致的 `stop_fact_keys（缺失即停字段）`。步骤产出不得作为本步输入、条件组输入或方法级事实；同一方法不得重复产出，后续步骤不得偷用未来产出
13. `validation/method-source-scan.json（全书方法审查清单）`必须给允许范围内每个原文编号一个且只有一个最终去向；知识地图已覆盖不能冒充方法语义已审查，任何 `review_pending（尚未审查）`都会阻止交付
14. `repeated_support（多处重复支持）`必须至少包含两个不同的原文编号；不得把同一原文拆成两条短引凑数。`single_explicit_source（单一明确来源）`可以保留，不得为了凑数量挂无关原文
15. 上游问题只允许登记为开放状态。蒸馏窗口不得自行标记已解决；验证器必须根据实际原文引用和方法依赖自动反查受影响方法，人工填写的影响范围不得作为唯一真相
16. 正式全书方法生产前，必须先完成原文分类校准和逐条盘点；每条记录分别保存 `semantic_class（原文实际类型）`、`disposition（处理去向）`和 `risk_flags（上下文与来源风险）`。分类未清零时只能保留旧草稿，禁止继续批量生成新方法
17. v2 批次必须使用 `build_methods.py`生成 `judgment-method-recipes/v2`，并通过 `validate_delivery.py --require-v2`；含大运流年、多星同聚或复杂瑜伽的批次强制逐步全审，生产连续不等于降低审计密度；只有结构单一的落宫章节连续三个批次独立全审且没有出现新的错误家族后才允许机器固定抽取 20% 步骤审查，一次性内容失误只退回本批
18. 新异议必须写入 `references/generation-rules.md（生成规则登记簿）`，同时增加共享代码拦截和正反回归；确定性错误必须有代码门，开放语义错误必须有真实标本和独立审计要求；只有错误样本、没有代码或运行记录不算闭环

## 与 nuwa-skill / darwin-skill 的生态定位

- **nuwa-skill**: 蒸馏人 (思维方式 / 表达 DNA)
- **cangjie-skill** (本 skill): 蒸馏书 (方法论 / 框架 / 原则)
- **darwin-skill**: 进化任意 skill

三者咬合: 本 skill 输出的 `test-prompts.json` 严格遵循 darwin-skill 格式,以便产出的 skill 可直接接入 darwin 做自动进化。

## 调用惯例

- **永远先试点 1 本** — 除非用户明确说"批量"
- **阶段之间主动汇报进度** — 不要静默跑完再 dump 结果
- **不凭记忆拆书** — 没文本就停下来问
- **保留审计轨迹** — candidates/ 和 rejected/ 都要留
- **随时可续跑** — 每完成一个阶段就更新 PIPELINE_STATE.md,中断后从状态文件恢复
